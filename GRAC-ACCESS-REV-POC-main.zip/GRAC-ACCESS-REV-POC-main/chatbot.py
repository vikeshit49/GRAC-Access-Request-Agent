"""
Local chatbot UI for testing the GRAC agent.
Serves a browser chat at http://localhost:8080
Proxies A2A JSON-RPC calls to the agent at http://localhost:9000

Usage:
    .venv\Scripts\python chatbot.py
"""

import json
import sys
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.request import urlopen, Request as URLRequest
from urllib.error import URLError

AGENT_URL = "http://localhost:9000/"
UI_PORT = 8080

HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GRAC Agent – Local Chatbot</title>
<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');

  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: "Inter", -apple-system, BlinkMacSystemFont, "72", "Segoe UI", sans-serif;
         background: #eef0f3; height: 100vh; display: flex; flex-direction: column; }

  /* ── header ── */
  header { background: linear-gradient(135deg, #0a6ed1 0%, #0854a0 100%);
           color: white; padding: 0 20px; height: 52px;
           display: flex; align-items: center; justify-content: space-between;
           box-shadow: 0 2px 8px rgba(0,0,0,.18); }
  .header-left { display: flex; align-items: center; gap: 10px; }
  .header-avatar { width: 28px; height: 28px; background: rgba(255,255,255,.22);
                   border-radius: 50%; display: flex; align-items: center;
                   justify-content: center; font-size: 14px; font-weight: 700; }
  header h1 { font-size: 15px; font-weight: 600; letter-spacing: .2px; }
  header small { font-size: 11px; opacity: .7; margin-left: 6px; }
  #controls { display: flex; gap: 8px; align-items: center; }
  #controls label { font-size: 12px; cursor: pointer; display: flex; align-items: center;
                    gap: 4px; opacity: .8; }
  button.reset { background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.35);
                 color: white; padding: 5px 12px; border-radius: 6px; cursor: pointer;
                 font-size: 12px; font-family: inherit; }
  button.reset:hover { background: rgba(255,255,255,.22); }

  /* ── chat area ── */
  #chat { flex: 1; overflow-y: auto; padding: 20px 24px; display: flex;
          flex-direction: column; gap: 14px; scroll-behavior: smooth; }

  /* ── message rows ── */
  .msg { display: flex; flex-direction: column; max-width: 75%; }
  .msg.user  { align-self: flex-end;   align-items: flex-end; }
  .msg.agent { align-self: flex-start; align-items: flex-start; }

  .bubble { padding: 11px 15px; border-radius: 16px; font-size: 14px;
            line-height: 1.65; word-break: break-word; }
  .msg.user  .bubble { background: #0a6ed1; color: white;
                        border-bottom-right-radius: 4px; white-space: pre-wrap;
                        box-shadow: 0 2px 6px rgba(10,110,209,.3); }
  .msg.agent .bubble { background: white; color: #1a1a1a;
                        border-bottom-left-radius: 4px;
                        box-shadow: 0 1px 4px rgba(0,0,0,.09); }
  .msg.agent .bubble p  { margin-bottom: .55em; }
  .msg.agent .bubble p:last-child { margin-bottom: 0; }
  .msg.agent .bubble pre  { background: #f5f5f5; padding: 8px 10px; border-radius: 6px;
                             overflow-x: auto; font-size: 12px; margin: .5em 0;
                             border: 1px solid #e8e8e8; }
  .msg.agent .bubble code { font-family: "Courier New", monospace; font-size: 12px;
                             background: #f0f0f0; padding: 1px 4px; border-radius: 3px; }
  .msg.agent .bubble pre code { background: none; padding: 0; }
  .msg.agent .bubble ul, .msg.agent .bubble ol { padding-left: 20px; margin: .3em 0; }
  .msg.agent .bubble li { margin: .2em 0; }
  .msg.agent .bubble strong { color: #111; }
  .msg.agent .bubble h3 { font-size: 13px; font-weight: 600; margin: .6em 0 .3em;
                           color: #333; text-transform: uppercase; letter-spacing: .4px; }

  /* ── outcome badge ── */
  .outcome-badge { display: inline-flex; align-items: center; gap: 5px;
                   padding: 4px 11px; border-radius: 20px; font-size: 11px;
                   font-weight: 600; letter-spacing: .4px; margin-bottom: 10px; }
  .outcome-clear            { background: #e6f4ea; color: #1e7e34; border: 1px solid #b7dfbf; }
  .outcome-requires-review  { background: #fff4e5; color: #c44d00; border: 1px solid #ffd49f; }
  .outcome-recommended-action { background: #e8f0fe; color: #1a56c4; border: 1px solid #a8c4f5; }

  /* ── risk chips ── */
  .risk-list { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; max-width: 440px; }
  .risk-chip { background: #fff4e5; color: #c44d00; border: 1px solid #ffd49f;
               padding: 3px 10px; border-radius: 12px; font-size: 11px;
               font-weight: 600; letter-spacing: .2px; }
  .risk-chip.mitigated { background: #f3e8ff; color: #6b21a8; border-color: #d8b4fe; }

  /* ── request confirmed ── */
  .request-confirmed { background: linear-gradient(135deg, #e6f4ea, #f0faf2);
                        border: 1px solid #b7dfbf; border-radius: 12px;
                        padding: 12px 16px; margin-top: 8px; display: flex;
                        align-items: center; gap: 12px; max-width: 320px;
                        box-shadow: 0 2px 8px rgba(30,126,52,.1); }
  .request-confirmed .req-icon { font-size: 22px; }
  .request-confirmed .req-info { display: flex; flex-direction: column; gap: 2px; }
  .request-confirmed .req-label { font-size: 10px; color: #4a7c5a; text-transform: uppercase;
                                    letter-spacing: .7px; font-weight: 600; }
  .request-confirmed .req-number { font-size: 18px; font-weight: 700; color: #1e7e34;
                                    letter-spacing: .5px; }

  /* ── card list ── */
  .card-list { display: flex; flex-direction: column; gap: 7px; max-width: 420px;
               margin-top: 8px; }
  .card { background: white; border-radius: 10px;
          box-shadow: 0 1px 3px rgba(0,0,0,.08), 0 1px 8px rgba(0,0,0,.04);
          padding: 10px 14px; display: flex; justify-content: space-between;
          align-items: center; gap: 10px; border: 1px solid #e8e8e8;
          transition: border-color .15s, box-shadow .15s; }
  .card:hover { border-color: #0a6ed1; box-shadow: 0 2px 10px rgba(10,110,209,.14); }
  .card-text { display: flex; flex-direction: column; gap: 2px; flex: 1; min-width: 0; }
  .card-title    { font-size: 13px; font-weight: 600; color: #111;
                   white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .card-subtitle { font-size: 12px; color: #666; line-height: 1.4; }
  .card-btn { background: #0a6ed1; color: white; border: none;
              border-radius: 7px; padding: 6px 14px; font-size: 12px; font-weight: 500;
              cursor: pointer; white-space: nowrap; flex-shrink: 0;
              font-family: inherit; transition: background .15s; }
  .card-btn:hover { background: #0854a0; }
  .card-btn:disabled { background: #a8c8ef; cursor: not-allowed; }

  /* ── meta ── */
  .msg-meta { font-size: 11px; color: #bbb; margin-top: 4px; padding: 0 2px;
              display: flex; gap: 8px; }

  details.raw { margin-top: 5px; font-size: 12px; }
  details.raw summary { cursor: pointer; color: #ccc; user-select: none; font-size: 11px; }
  details.raw pre { background: #111; color: #a8ff78; padding: 10px;
                    border-radius: 8px; overflow-x: auto; margin-top: 4px;
                    font-size: 11px; line-height: 1.4; max-height: 280px; overflow-y: auto; }

  /* ── thinking ── */
  .thinking { align-self: flex-start; padding: 10px 15px; background: white;
              border-radius: 16px; border-bottom-left-radius: 4px;
              box-shadow: 0 1px 4px rgba(0,0,0,.09);
              display: flex; align-items: center; gap: 8px;
              font-size: 13px; color: #888; }
  .dot { width: 7px; height: 7px; background: #0a6ed1; border-radius: 50%;
         animation: bounce .9s infinite; }
  .dot:nth-child(2) { animation-delay: .18s; }
  .dot:nth-child(3) { animation-delay: .36s; }
  @keyframes bounce { 0%,80%,100%{transform:translateY(0)} 40%{transform:translateY(-6px)} }

  /* ── input ── */
  #input-area { background: white; border-top: 1px solid #e0e0e0;
                padding: 10px 16px; display: flex; gap: 8px; align-items: flex-end; }
  #input-area textarea { flex: 1; border: 1px solid #d0d5dd; border-radius: 10px;
                          padding: 9px 12px; font-size: 14px; resize: none; outline: none;
                          min-height: 42px; max-height: 120px; line-height: 1.5;
                          font-family: inherit; color: #1a1a1a;
                          transition: border-color .15s; }
  #input-area textarea:focus { border-color: #0a6ed1;
                                box-shadow: 0 0 0 3px rgba(10,110,209,.1); }
  #send-btn { background: #0a6ed1; color: white; border: none; border-radius: 10px;
              padding: 9px 18px; font-size: 14px; cursor: pointer; height: 42px;
              min-width: 64px; font-weight: 500; font-family: inherit;
              transition: background .15s; }
  #send-btn:hover { background: #0854a0; }
  #send-btn:disabled { background: #a8c8ef; cursor: not-allowed; }

  #status-bar { font-size: 11px; color: #aaa; padding: 3px 16px;
                background: #f8f8f8; border-top: 1px solid #ececec; }
  #status-bar span.ok  { color: #1e7e34; }
  #status-bar span.err { color: #c0392b; }

  .sys-msg { text-align: center; font-size: 11px; color: #ccc; margin: 4px 0;
             display: flex; align-items: center; gap: 8px; }
  .sys-msg::before, .sys-msg::after { content: ''; flex: 1; height: 1px; background: #e8e8e8; }
</style>
</head>
<body>

<header>
  <div class="header-left">
    <div class="header-avatar">G</div>
    <div>
      <h1>GRAC Access Agent <small>·&nbsp;<span id="ctx-id">No session</span></small></h1>
    </div>
  </div>
  <div id="controls">
    <label><input type="checkbox" id="show-raw"> Raw JSON</label>
    <button class="reset" onclick="resetConversation()">New conversation</button>
  </div>
</header>

<div id="chat"></div>

<div id="input-area">
  <textarea id="user-input" placeholder="Type a message… (Shift+Enter for newline)" rows="1"
            onkeydown="handleKey(event)" oninput="autoResize(this)"></textarea>
  <button id="send-btn" onclick="sendMessage()">Send</button>
</div>
<div id="status-bar">Agent: <span id="agent-status">checking…</span></div>

<script>
let contextId = null;
let msgCounter = 0;

document.getElementById('show-raw').addEventListener('change', () => {});

// ── helpers ──────────────────────────────────────────────────────────────────

function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}

function handleKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
}

function resetConversation() {
  contextId = null;
  msgCounter = 0;
  document.getElementById('chat').innerHTML = '';
  document.getElementById('ctx-id').textContent = 'No session';
  addSysMsg('New conversation');
}

function addSysMsg(text) {
  const el = document.createElement('div');
  el.className = 'sys-msg';
  el.textContent = text;
  document.getElementById('chat').appendChild(el);
  scrollBottom();
}

function scrollBottom() {
  const c = document.getElementById('chat');
  c.scrollTop = c.scrollHeight;
}

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function appendUserBubble(text) {
  const el = document.createElement('div');
  el.className = 'msg user';
  el.innerHTML = `<div class="bubble">${escapeHtml(text)}</div>`;
  document.getElementById('chat').appendChild(el);
  scrollBottom();
}

function showThinking() {
  const el = document.createElement('div');
  el.className = 'thinking'; el.id = 'thinking-indicator';
  el.innerHTML = '<div class="dot"></div><div class="dot"></div><div class="dot"></div><span style="margin-left:4px;font-size:12px">Thinking…</span>';
  document.getElementById('chat').appendChild(el);
  scrollBottom();
}

function hideThinking() {
  const el = document.getElementById('thinking-indicator');
  if (el) el.remove();
}

function appendErrorBubble(msg) {
  const el = document.createElement('div');
  el.className = 'msg agent';
  el.innerHTML = `<div class="bubble" style="background:#fdf0f0;color:#c0392b;border:1px solid #f0c0c0;">
    ⚠ ${escapeHtml(msg)}</div>`;
  document.getElementById('chat').appendChild(el);
  scrollBottom();
}

// ── outcome badge ─────────────────────────────────────────────────────────────

function outcomeBadge(outcome) {
  if (!outcome) return '';
  const cls = 'outcome-' + outcome.toLowerCase().replace(/\s+/g, '-');
  const icon = outcome === 'CLEAR' ? '✓' : outcome === 'REQUIRES REVIEW' ? '⚠' : 'ℹ';
  return `<div class="outcome-badge ${cls}">${icon} ${escapeHtml(outcome)}</div>`;
}

// ── render agent response ─────────────────────────────────────────────────────

function renderAgentResponse(result, rawJson, durationMs) {
  const chat = document.getElementById('chat');
  const wrapper = document.createElement('div');
  wrapper.className = 'msg agent';

  // ── extract payload from data artifact ──────────────────────────────────
  let payload = null;
  for (const artifact of result.artifacts || []) {
    for (const part of artifact.parts || []) {
      if (part.kind === 'data' && part.data) { payload = part.data; break; }
    }
    if (payload) break;
  }

  // Fallback: status text parts
  if (!payload) {
    const statusMsg = result.status?.message;
    for (const part of statusMsg?.parts || []) {
      if (part.kind === 'text' && part.text) {
        const b = document.createElement('div');
        b.className = 'bubble';
        b.innerHTML = marked.parse(part.text);
        wrapper.appendChild(b);
      }
    }
    appendMeta(wrapper, durationMs, null);
    chat.appendChild(wrapper); scrollBottom(); return;
  }

  const message   = (payload.message || '').trim();
  const actions   = payload.actions || [];
  const inner     = payload.data || {};
  const outcome   = inner.outcome;
  const risks     = inner.risks_found || [];
  const reqInfo   = inner.request_created;

  // ── 1. Main message bubble ────────────────────────────────────────────────
  if (message) {
    const b = document.createElement('div');
    b.className = 'bubble';
    if (outcome) b.insertAdjacentHTML('afterbegin', outcomeBadge(outcome));
    b.insertAdjacentHTML('beforeend', marked.parse(message));
    wrapper.appendChild(b);
  }

  // ── 2. Risk chips ─────────────────────────────────────────────────────────
  if (risks.length > 0) {
    const rl = document.createElement('div');
    rl.className = 'risk-list';
    for (const r of risks) {
      const chip = document.createElement('span');
      chip.className = 'risk-chip' + (r.has_mitigation ? ' mitigated' : '');
      chip.title = r.conflicting_roles?.join(', ') || '';
      const mit = r.has_mitigation ? ' ✓' : '';
      chip.textContent = `${r.risk_id}${mit}`;
      rl.appendChild(chip);
    }
    wrapper.appendChild(rl);
  }

  // ── 3. Request confirmed card ─────────────────────────────────────────────
  if (reqInfo?.request_number) {
    const conf = document.createElement('div');
    conf.className = 'request-confirmed';
    conf.innerHTML = `<div class="req-icon">✅</div>
      <div class="req-info">
        <span class="req-label">Access request submitted</span>
        <span class="req-number">${escapeHtml(reqInfo.request_number)}</span>
      </div>`;
    wrapper.appendChild(conf);
  }

  // ── 4. Action cards (skip the text duplicate, render only list cards) ─────
  for (const action of actions) {
    if (action.type !== 'message') continue;
    const msg = action.message;
    if (!msg) continue;
    if (msg.type === 'text') continue;  // already rendered from payload.message

    if (msg.type === 'list') {
      const elements = msg.content?.elements || [];
      if (!elements.length) continue;
      const list = document.createElement('div');
      list.className = 'card-list';
      for (const elem of elements) {
        const card = document.createElement('div');
        card.className = 'card';
        const txt = document.createElement('div');
        txt.className = 'card-text';
        if (elem.title) {
          const t = document.createElement('div');
          t.className = 'card-title';
          t.textContent = elem.title;
          txt.appendChild(t);
        }
        if (elem.subtitle) {
          const s = document.createElement('div');
          s.className = 'card-subtitle';
          s.textContent = elem.subtitle;
          txt.appendChild(s);
        }
        card.appendChild(txt);
        for (const btn of elem.buttons || []) {
          const b = document.createElement('button');
          b.className = 'card-btn';
          b.textContent = btn.title || btn.text || 'Select';
          if (btn.type === 'postback') b.onclick = () => postback(btn.value);
          card.appendChild(b);
        }
        list.appendChild(card);
      }
      wrapper.appendChild(list);
    }
  }

  // ── 5. Meta line ─────────────────────────────────────────────────────────
  appendMeta(wrapper, durationMs, payload);

  // ── 6. Raw JSON toggle ───────────────────────────────────────────────────
  if (document.getElementById('show-raw').checked && rawJson) {
    const det = document.createElement('details');
    det.className = 'raw';
    det.innerHTML = `<summary>{ } Raw JSON</summary>
      <pre>${escapeHtml(JSON.stringify(rawJson, null, 2))}</pre>`;
    wrapper.appendChild(det);
  }

  chat.appendChild(wrapper);
  scrollBottom();
}

function appendMeta(wrapper, durationMs, payload) {
  const meta = document.createElement('div');
  meta.className = 'msg-meta';
  const parts = [];
  if (durationMs != null) parts.push(`${(durationMs/1000).toFixed(1)}s`);
  if (payload?.action_type && payload.action_type !== 'text') parts.push(payload.action_type);
  meta.textContent = parts.join('  ·  ');
  wrapper.appendChild(meta);
}

// ── postback (button click) ───────────────────────────────────────────────────

function postback(value) {
  document.querySelectorAll('.card-btn').forEach(b => b.disabled = true);
  const textarea = document.getElementById('user-input');
  textarea.value = value;
  sendMessage();
}

// ── send ─────────────────────────────────────────────────────────────────────

async function sendMessage() {
  const textarea = document.getElementById('user-input');
  const text = textarea.value.trim();
  if (!text) return;

  textarea.value = '';
  textarea.style.height = 'auto';
  document.getElementById('send-btn').disabled = true;

  appendUserBubble(text);
  showThinking();

  const t0 = Date.now();
  try {
    msgCounter++;
    const body = {
      jsonrpc: '2.0',
      method: 'message/send',
      id: crypto.randomUUID(),
      params: {
        message: {
          messageId: `msg-${String(msgCounter).padStart(3,'0')}`,
          role: 'user',
          parts: [{ kind: 'text', text }],
          metadata: { userEmail: 'pranay.garoo@sap.com' },
          ...(contextId ? { contextId } : {})
        }
      }
    };

    const resp = await fetch('/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    const data = await resp.json();
    const duration = Date.now() - t0;
    hideThinking();

    if (data.error) {
      appendErrorBubble(`JSON-RPC error ${data.error.code}: ${data.error.message}`);
      return;
    }

    const result = data.result || {};
    if (result.contextId) {
      contextId = result.contextId;
      document.getElementById('ctx-id').textContent = contextId.slice(0, 16) + '…';
    }

    renderAgentResponse(result, data, duration);

  } catch (err) {
    hideThinking();
    appendErrorBubble(`Request failed: ${err.message}`);
  } finally {
    document.getElementById('send-btn').disabled = false;
    textarea.focus();
  }
}

// ── health check ─────────────────────────────────────────────────────────────

async function checkAgent() {
  try {
    const r = await fetch('/proxy-health');
    document.getElementById('agent-status').innerHTML = r.ok
      ? '<span class="ok">● online (localhost:9000)</span>'
      : '<span class="err">● unreachable</span>';
  } catch {
    document.getElementById('agent-status').innerHTML =
      '<span class="err">● unreachable — is the agent running?</span>';
  }
}

checkAgent();
setInterval(checkAgent, 10000);
document.getElementById('user-input').focus();
</script>
</body>
</html>
"""


def _log_agent_response(resp_obj: dict, elapsed: float) -> None:
    """Print a readable summary of the agent's A2A response to stdout."""
    if resp_obj.get("error"):
        err = resp_obj["error"]
        print(f"AGENT ERROR [{err.get('code')}]: {err.get('message')}", flush=True)
        return

    result = resp_obj.get("result", {})

    # Extract data payload
    payload = {}
    for artifact in result.get("artifacts", []):
        for part in artifact.get("parts", []):
            if part.get("kind") == "data" and part.get("data"):
                payload = part["data"]
                break

    action_type = payload.get("action_type", "text")
    message     = payload.get("message", "")
    inner       = payload.get("data", {})
    outcome     = inner.get("outcome", "")
    risks       = inner.get("risks_found", [])
    req_created = inner.get("request_created")

    print(f"AGENT [{elapsed:.1f}s] action_type={action_type}"
          + (f"  outcome={outcome}" if outcome else ""), flush=True)

    if message:
        preview = message if len(message) <= 400 else message[:397] + "..."
        print(f"  message: {preview}", flush=True)

    if risks:
        risk_ids = [r.get("risk_id", "") for r in risks]
        print(f"  risks: {', '.join(risk_ids)}", flush=True)

    if req_created:
        print(f"  request: {req_created.get('request_number')}  role={req_created.get('role')}", flush=True)

    # Cards summary
    for action in payload.get("actions", []):
        msg = action.get("message", {})
        if msg.get("type") == "list":
            elements = msg.get("content", {}).get("elements", [])
            print(f"  [cards] {len(elements)} options:", flush=True)
            for el in elements[:6]:
                sub = el.get("subtitle", "")[:70]
                print(f"    • {el.get('title','')}  —  {sub}", flush=True)

    print(flush=True)
    sys.stdout.flush()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def do_GET(self):
        if self.path in ('/', '/index.html'):
            body = HTML.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == '/proxy-health':
            try:
                urlopen(URLRequest(AGENT_URL.rstrip('/') + '/health'), timeout=3)
                self.send_response(200)
                self.end_headers()
            except Exception:
                self.send_response(503)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == '/proxy':
            length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(length)

            try:
                req_obj  = json.loads(body)
                parts    = req_obj.get("params", {}).get("message", {}).get("parts", [])
                user_text = next((p.get("text", "") for p in parts if p.get("kind") == "text"), "")
                print(f"\n{'='*60}", flush=True)
                print(f"USER: {user_text}", flush=True)
            except Exception:
                pass

            t0 = time.monotonic()
            try:
                req = URLRequest(AGENT_URL, data=body,
                                 headers={'Content-Type': 'application/json'}, method='POST')
                with urlopen(req, timeout=120) as resp:
                    data = resp.read()
                elapsed = time.monotonic() - t0

                try:
                    resp_obj = json.loads(data)
                    _log_agent_response(resp_obj, elapsed)
                except Exception as parse_err:
                    print(f"[LOG] could not parse response: {parse_err}", flush=True)

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            except URLError as e:
                elapsed = time.monotonic() - t0
                print(f"[ERR] Proxy error after {elapsed:.1f}s: {e}", flush=True)
                err = json.dumps({
                    "jsonrpc": "2.0", "id": None,
                    "error": {"code": -32000, "message": f"Proxy error: {e}"}
                }).encode()
                self.send_response(502)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(err)))
                self.end_headers()
                self.wfile.write(err)
        else:
            self.send_response(404)
            self.end_headers()


def main():
    server = HTTPServer(("localhost", UI_PORT), Handler)
    print(f"Chatbot UI : http://localhost:{UI_PORT}")
    print(f"Agent proxy: {AGENT_URL}")
    print("Ctrl+C to stop.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
