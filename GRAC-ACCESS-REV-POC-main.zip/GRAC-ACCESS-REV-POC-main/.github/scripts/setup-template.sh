#!/bin/bash

# A2A Agent Template - Setup Script
# Automatically configures the template when a new repository is created
# This script is executed by GitHub Actions on the first workflow run

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Parse arguments
ORG="$1"
REPO="$2"

if [ -z "$ORG" ] || [ -z "$REPO" ]; then
    echo -e "${RED}Error: Organization and repository name are required${NC}"
    echo "Usage: $0 <organization> <repository-name>"
    exit 1
fi

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE}A2A Agent Template Setup${NC}"
echo -e "${BLUE}=========================================${NC}"
echo ""
echo -e "Organization: ${GREEN}$ORG${NC}"
echo -e "Repository:   ${GREEN}$REPO${NC}"
echo ""

# Sanitize repository name for Kubernetes (lowercase, replace _ with -)
APP_NAME=$(echo "$REPO" | tr '[:upper:]' '[:lower:]' | tr '_' '-')
# Sanitize repository name for YAML/Python (lowercase, replace - with _)
YAML_NAME=$(echo "$REPO" | tr '[:upper:]' '[:lower:]' | tr '-' '_')
# Create display name (Title Case with spaces)
DISPLAY_NAME=$(echo "$REPO" | tr '-' ' ' | tr '_' ' ' | sed 's/\b\(.\)/\u\1/g')
# Create namespace for capability (com.sap.{org}.{repo} format)
CAPABILITY_NAMESPACE="com.sap.$(echo "$ORG" | tr '[:upper:]' '[:lower:]').$(echo "$REPO" | tr '[:upper:]' '[:lower:]' | tr '-' '.' | tr '_' '.')"
# Create system alias (uppercase with underscores)
SYSTEM_ALIAS=$(echo "$REPO" | tr '[:lower:]' '[:upper:]' | tr '-' '_')

echo -e "App Name (K8s):          ${GREEN}$APP_NAME${NC}"
echo -e "YAML Name:               ${GREEN}$YAML_NAME${NC}"
echo -e "Display Name:            ${GREEN}$DISPLAY_NAME${NC}"
echo -e "Capability Namespace:    ${GREEN}$CAPABILITY_NAMESPACE${NC}"
echo -e "System Alias:            ${GREEN}$SYSTEM_ALIAS${NC}"
echo ""

# Old values to replace (template defaults)
OLD_APP_NAME="sample-agent"
OLD_YAML_NAME="sample_agent"
OLD_DISPLAY_NAME="Sample Agent"
OLD_CAPABILITY_NAMESPACE="com.sap.sample.agent"
OLD_SYSTEM_ALIAS="SAMPLE_AGENT"

echo -e "${YELLOW}📝 Updating files...${NC}"

# Function to update file with sed (handles both GNU and BSD sed)
update_file() {
    local file="$1"
    local search="$2"
    local replace="$3"
    
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS (BSD sed)
        sed -i '' "s|${search}|${replace}|g" "$file"
    else
        # Linux (GNU sed)
        sed -i "s|${search}|${replace}|g" "$file"
    fi
}

# 1. Update app.yaml (Kubernetes manifest)
if [ -f "app.yaml" ]; then
    echo -e "  → Updating ${BLUE}app.yaml${NC}"
    update_file "app.yaml" "name: $OLD_APP_NAME" "name: $APP_NAME"
fi

# 2. Update joule/da.sapdas.yaml (Joule DAS configuration)
if [ -f "joule/da.sapdas.yaml" ]; then
    echo -e "  → Updating ${BLUE}joule/da.sapdas.yaml${NC}"
    update_file "joule/da.sapdas.yaml" "name: $OLD_YAML_NAME" "name: $YAML_NAME"
fi

# 3. Update joule/a2a/capability.sapdas.yaml (A2A capability configuration)
if [ -f "joule/a2a/capability.sapdas.yaml" ]; then
    echo -e "  → Updating ${BLUE}joule/a2a/capability.sapdas.yaml${NC}"
    update_file "joule/a2a/capability.sapdas.yaml" "display_name: $OLD_DISPLAY_NAME" "display_name: $DISPLAY_NAME"
    update_file "joule/a2a/capability.sapdas.yaml" "namespace: $OLD_CAPABILITY_NAMESPACE" "namespace: $CAPABILITY_NAMESPACE"
    update_file "joule/a2a/capability.sapdas.yaml" "name: $OLD_YAML_NAME" "name: $YAML_NAME"
    update_file "joule/a2a/capability.sapdas.yaml" "$OLD_SYSTEM_ALIAS:" "$SYSTEM_ALIAS:"
    update_file "joule/a2a/capability.sapdas.yaml" "destination: $OLD_SYSTEM_ALIAS" "destination: $SYSTEM_ALIAS"
fi

# 4. Update joule/a2a/functions/sample_agent.yaml (Joule function)
if [ -f "joule/a2a/functions/sample_agent.yaml" ]; then
    echo -e "  → Renaming and updating ${BLUE}joule/a2a/functions/sample_agent.yaml${NC}"
    update_file "joule/a2a/functions/sample_agent.yaml" "system_alias: $OLD_SYSTEM_ALIAS" "system_alias: $SYSTEM_ALIAS"
    # Rename the file
    if [ "$YAML_NAME" != "$OLD_YAML_NAME" ]; then
        mv "joule/a2a/functions/sample_agent.yaml" "joule/a2a/functions/${YAML_NAME}.yaml"
    fi
fi

# 5. Update joule/a2a/scenarios/sample/sample.yaml (Joule scenario)
if [ -d "joule/a2a/scenarios/sample" ]; then
    echo -e "  → Renaming and updating ${BLUE}joule/a2a/scenarios/sample/${NC}"
    # Update file content first
    if [ -f "joule/a2a/scenarios/sample/sample.yaml" ]; then
        update_file "joule/a2a/scenarios/sample/sample.yaml" "name: $OLD_YAML_NAME" "name: $YAML_NAME"
        update_file "joule/a2a/scenarios/sample/sample.yaml" "Response from Sample Agent" "Response from $DISPLAY_NAME"
    fi
    # Rename folder and file
    SHORT_NAME=$(echo "$YAML_NAME" | cut -d'_' -f1)
    if [ "$SHORT_NAME" != "sample" ]; then
        mv "joule/a2a/scenarios/sample/sample.yaml" "joule/a2a/scenarios/sample/${SHORT_NAME}.yaml" 2>/dev/null || true
        mv "joule/a2a/scenarios/sample" "joule/a2a/scenarios/${SHORT_NAME}" 2>/dev/null || true
    fi
fi

# 6. Update README.md (Docker examples)
if [ -f "README.md" ]; then
    echo -e "  → Updating ${BLUE}README.md${NC}"
    update_file "README.md" "docker build -t a2a-agent" "docker build -t $APP_NAME"
    update_file "README.md" "docker run -p 5000:5000 --env-file .env a2a-agent" "docker run -p 5000:5000 --env-file .env $APP_NAME"
fi

# 7. Update app/main.py (Agent metadata)
if [ -f "app/main.py" ]; then
    echo -e "  → Updating ${BLUE}app/main.py${NC}"
    update_file "app/main.py" 'AGENT_NAME = "Sample Agent"' "AGENT_NAME = \"$DISPLAY_NAME\""
fi

echo ""
echo -e "${GREEN}✅ Template configuration completed successfully!${NC}"
echo ""
echo -e "${YELLOW}Changes made:${NC}"
echo -e "  • App name (K8s):       ${BLUE}$APP_NAME${NC}"
echo -e "  • YAML name:            ${BLUE}$YAML_NAME${NC}"
echo -e "  • Display name:         ${BLUE}$DISPLAY_NAME${NC}"
echo -e "  • Capability namespace: ${BLUE}$CAPABILITY_NAMESPACE${NC}"
echo -e "  • System alias:         ${BLUE}$SYSTEM_ALIAS${NC}"
echo ""
echo -e "${YELLOW}Files updated:${NC}"
echo -e "  • ${BLUE}app.yaml${NC} - Kubernetes metadata"
echo -e "  • ${BLUE}app/main.py${NC} - Agent display name"
echo -e "  • ${BLUE}joule/da.sapdas.yaml${NC} - Joule DAS configuration"
echo -e "  • ${BLUE}joule/a2a/capability.sapdas.yaml${NC} - A2A capability metadata"
echo -e "  • ${BLUE}joule/a2a/functions/${YAML_NAME}.yaml${NC} - Joule function"
echo -e "  • ${BLUE}joule/a2a/scenarios/*/$.yaml${NC} - Joule scenario"
echo -e "  • ${BLUE}README.md${NC} - Docker examples"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo -e "  1. Review the changes: ${BLUE}git diff${NC}"
echo -e "  2. Customize the agent logic in ${BLUE}app/agent.py${NC}"
echo -e "  3. Update service bindings in ${BLUE}app.yaml${NC} if needed"
echo -e "  4. The workflow will commit and push these changes automatically"
echo ""