# Update environment variable for the Agent's Docker Container

This document describe steps to update environment variable for the running agent's docker container. Use this when you need to update environment variables for a running agent without rebuilding the image.

# Step by step instructions
 ## 1. List running containers and identify the agent container
  ```bash
  docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Status}}"
  ```
- From the output, look for container names matching your agent or image names. (like "*agent*", "*hello-world*", etc.).

## 2. Confirm the agent container name from (step 1) with the user
  ```
  Question: "Is this the container, <container_name> your agent is currently running on?"
  Options:["Yes","No"]
  ```
- **If user says Yes**: Proceed and use the <image_name> and <container_name> in step 3.

- **If user says No**:
  ```
  Question: "Please provide the exact <container_name> running your agent:"
  ```
  - Retrieve the container's <image_name> after user input
    ```bash
    docker inspect --format='{{.Config.Image}}' <container_name>
    ```
    -  if the output has error, ask user for <container_name> again. Inform user that it can be found in the docker deskstop.   

## 3. Stop and re-run the container with updated env variables
- Extract agent port number from `agent_base_url ` in `app/.env.local` 
``` bash
docker stop <container_name>
docker rm <container_name>
docker run --name <container_name> -p <port>:<port> --env-file app/.env.local <image_name>
```

## 4. Verify the container is running with updated environment
```bash
docker logs <container_name> --tail 20
```
- Then check for these success patterns:
  - "Traceloop exporting traces" appears (confirms instrumentation enabled with new env vars)
  - "Starting A2A server" appears
  - "Application startup complete" appears
- Verify instrumentation is not disabled:
  - "OTEL_EXPORTER_OTLP_ENDPOINT not set. Instrumentation will be disabled." should NOT appear                                                                                    
  - "Metrics are disabled" is OK (expected behavior) 

