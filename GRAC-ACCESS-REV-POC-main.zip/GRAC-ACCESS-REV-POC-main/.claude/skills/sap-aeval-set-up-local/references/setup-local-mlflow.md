# Local MLflow Setup instruction for Aeval

This document describes step to set up Local MLflow tracking server for agent evaluation with Aeval.

# Step by step instructions

## 1. **Important:** Create MLflow data directory
```bash
# Verify we're in project root (check for marker file/folder)
[ ! -d "app" ] && echo "Error: Run from project root. Change directory to project root first." && exit 1
# Then create directory
mkdir -p aeval/mlflow && echo "Created aeval/mlflow directory"
```

## 2. Start MLflow server
```bash
# Set MLflow port
MLFLOW_PORT=3333 
# Find venv [search for three level depth from root] & takes first search
VENV_PATH=$(find . -maxdepth 3 -name ".venv" -type d | head -1)
# Check if found venv
[ -z "$VENV_PATH" ] && echo "Error: No venv found" && exit 1
# Activate Venv
source "$VENV_PATH/bin/activate"
# Verify mlflow is installed
if ! command -v mlflow > /dev/null 2>&1; then
    echo "Error: MLflow not installed"
    exit 1
fi
# Navigate to mlflow directory
cd aeval/mlflow
# Start server on port $MLFLOW_PORT in background
nohup mlflow server --port $MLFLOW_PORT

# Wait for server to start (max 60s) and verify database
for i in {1..60}; do
    curl -sf http://127.0.0.1:$MLFLOW_PORT >/dev/null 2>&1 && break 
    [ $i -eq 60 ] && echo "Error: MLflow failed to start. Check aeval/mlflow/mlflow.log" && exit 1 
    sleep 1 
done
# Verify database file was created
cd ../.. && ls aeval/mlflow/mlflow.db

# Kill Server after check
lsof -ti:$MLFLOW_PORT | xargs kill && echo "Successful MLflow Server Set up on port $MLFLOW_PORT"
```

**Troubleshooting:**
- If port 3333 is already in use, choose a different port:
```bash
mlflow server --port 3334
```
