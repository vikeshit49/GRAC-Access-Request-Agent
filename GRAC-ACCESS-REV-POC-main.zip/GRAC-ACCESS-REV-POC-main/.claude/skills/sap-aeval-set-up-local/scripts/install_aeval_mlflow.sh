#!/bin/bash
# Script to install sap-ai-agent-evaluation package
# Auto-detects virtual environment in the project workspace
# DO NOT INTERRUPT - the script will indicate when complete

set -e

echo "=========================================="
echo "  Aeval and MLflow Package Installer"
echo "=========================================="
echo ""

# Find the project root (where app folder is)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$SCRIPT_DIR"

# Navigate up to find project root (where app folder is)
while [[ ! -d "$PROJECT_ROOT/app" && "$PROJECT_ROOT" != "/" ]]; do
    PROJECT_ROOT="$(dirname "$PROJECT_ROOT")"
done

# Check if we found the app folder
if [[ ! -d "$PROJECT_ROOT/app" ]]; then
    echo "ERROR: app folder not found"
    echo "Please run this script from the project directory"
    exit 1
fi

cd "$PROJECT_ROOT"
echo "Project root: $PROJECT_ROOT"

# Auto-detect virtual environment
VENV_PATH=""

# Check for .venv in project root first
if [[ -d "$PROJECT_ROOT/.venv" ]]; then
    VENV_PATH="$PROJECT_ROOT/.venv"
    echo "Using existing virtual environment: .venv"
# Check for .venv in aeval folder
elif [[ -d "$PROJECT_ROOT/aeval/.venv" ]]; then
    VENV_PATH="$PROJECT_ROOT/aeval/.venv"
    echo "Using existing virtual environment: aeval/.venv"
# If no .venv found, create one in aeval folder (same level as app folder)
else
    echo "No .venv found. Creating one in aeval folder..."
    mkdir -p "$PROJECT_ROOT/aeval"
    VENV_PATH="$PROJECT_ROOT/aeval/.venv"
    python3 -m venv "$VENV_PATH"
    echo "Virtual environment created at: aeval/.venv"
fi

# Check if .env.local exists
ENV_FILE="$PROJECT_ROOT/app/.env.local"
if [[ ! -f "$ENV_FILE" ]]; then
    echo "ERROR: app/.env.local not found"
    echo "Please ensure app/.env.local exists with ARTIFACTORY_USER and ARTIFACTORY_TOKEN"
    exit 1
fi

# Use the venv's pip directly (no need to source activate)
PIP_CMD="$VENV_PATH/bin/pip"
PYTHON_CMD="$VENV_PATH/bin/python"

echo "Python: $PYTHON_CMD"
echo "Pip: $PIP_CMD"

echo ""
echo "=========================================="
echo "  Loading credentials from app/.env.local"
echo "=========================================="
echo ""

# Export only ARTIFACTORY credentials from .env.local (safer than exporting all variables)
# This avoids issues with special characters in other environment variables
while IFS= read -r line; do
    # Skip comments and empty lines
    [[ "$line" =~ ^[[:space:]]*# ]] || [[ -z "$line" ]] && continue

    # Extract key and value, handling quotes and whitespace
    if [[ "$line" =~ ^[[:space:]]*([A-Za-z_][A-Za-z0-9_]*)[[:space:]]*=[[:space:]]*(.*)[[:space:]]*$ ]]; then
        key="${BASH_REMATCH[1]}"
        value="${BASH_REMATCH[2]}"

        # Remove leading/trailing whitespace from value
        value="${value#"${value%%[![:space:]]*}"}"
        value="${value%"${value##*[![:space:]]}"}"

        # Remove quotes if present (both single and double)
        if [[ "$value" =~ ^[\"\'](.*)[\"\']$ ]]; then
            value="${BASH_REMATCH[1]}"
        fi

        # Only export ARTIFACTORY variables
        if [[ "$key" == "ARTIFACTORY_USER" ]] || [[ "$key" == "ARTIFACTORY_TOKEN" ]]; then
            export "$key=$value"
        fi
    fi
done < "$ENV_FILE"

# Check if required credentials are set
if [[ -z "$ARTIFACTORY_USER" || -z "$ARTIFACTORY_TOKEN" ]]; then
    echo "ERROR: ARTIFACTORY_USER and ARTIFACTORY_TOKEN must be set in app/.env.local"
    echo ""
    echo "Found in .env.local:"
    echo "  ARTIFACTORY_USER: ${ARTIFACTORY_USER:-<not set>}"
    echo "  ARTIFACTORY_TOKEN: ${ARTIFACTORY_TOKEN:+<set (hidden)>}${ARTIFACTORY_TOKEN:-<not set>}"
    exit 1
fi

echo "✓ ARTIFACTORY_USER: ${ARTIFACTORY_USER}"
echo "✓ ARTIFACTORY_TOKEN: <hidden (${#ARTIFACTORY_TOKEN} chars)>"
echo ""
echo "Credentials loaded successfully"
echo ""
echo "=========================================="
echo "  Starting pip install..."
echo "  This may take a 3-10 minutes."
echo "  DO NOT INTERRUPT - wait for completion."
echo "=========================================="
echo ""

# Create a log file for the installation
LOG_FILE="/tmp/pip_install_aeval_$$.log"

# Run pip install with the specified configuration
"$PIP_CMD" install "sap-ai-agent-evaluation==0.7.0" "mlflow==3.11.1" \
    -i "https://${ARTIFACTORY_USER}:${ARTIFACTORY_TOKEN}@common.repositories.cloud.sap/artifactory/api/pypi/agent-evaluation/simple" \
    --extra-index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple" \
    --progress-bar on \
    2>&1 | tee "$LOG_FILE"

# Check if installation succeeded
if [[ ${PIPESTATUS[0]} -eq 0 ]]; then
    echo ""
    echo "=========================================="
    echo "  SUCCESS! sap-ai-agent-evaluation and mlflow installed."
    echo "=========================================="
    echo ""
    echo "Package installed in virtual environment: $VENV_PATH"
    echo ""
    echo "To use the package, activate the virtual environment:"
    echo ""
    echo "  source $VENV_PATH/bin/activate"
    echo ""
    rm -f "$LOG_FILE"
    exit 0
else
    echo ""
    echo "=========================================="
    echo "  FAILED! See errors above."
    echo "=========================================="
    echo "Log saved to: $LOG_FILE"
    exit 1
fi
