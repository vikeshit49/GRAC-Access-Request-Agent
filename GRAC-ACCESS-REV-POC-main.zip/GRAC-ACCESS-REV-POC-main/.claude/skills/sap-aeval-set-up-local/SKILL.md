---
name: aeval-set-up
description: Sets up the Aeval agent evaluation framework for local testing with tracing and metrics. Creates configuration files, installs dependencies, and configures MLflow tracking. Use when the user wants to set up Aeval or run local evals. 
---

# Aeval Set up 
Sets up aeval folder structure, installs dependencies, and creates config files for agent evaluation with Aeval.

> **Note:** This skill contains macOS-optimized commands. The AI assistant should detect the current OS and adjust commands accordingly for Linux or Windows environments. 

# Prerequisites
**STOP and ask the user these questions before proceeding:** 
```
Question 1: "Have you successfully run your agent locally at least once?"

Options: ["Yes", "No"]
```

```
Question 2: "Is your `.env.local` file populated with required credentials (AI Core)?"

Options: ["Yes", "No"]
```

**Important**:
- Do NOT proceed to step by step instructions until the user has answered both questions
- Do NOT assume defaults without explicitly asking
- If the user answers "No" to either question, stop this skill and inform the user to run the agent
locally first using the `sap-agent-run-local` skill.

# Step by step instructions

## 0: Validate Prerequisites
- Check `app/.env.local` file exists:
```bash
find . -path "./app/.env.local" -type f 
```
**If the file is NOT found**:
- Stop skill immediately
- Inform the user: "The app/.env.local file is missing. Please run `sap-agent-run-local` skill first to set up the local environment and credentials before continuing with Aeval setup."

**If the file is found**:
- Verify Artifactory credentials are set in `app/.env.local`:
```bash
if grep -q '^ARTIFACTORY_USER=.' app/.env.local && grep -q '^ARTIFACTORY_TOKEN=.' app/.env.local; 
then echo "CREDENTIALS_OK"
else echo "CREDENTIALS_MISSING" 
fi  
```
- **If credentials are missing**, stop the skill and inform the user: "Missing Artifactory credentials in app/.env.local. Please add ARTIFACTORY_USER and ARTIFACTORY_TOKEN to access SAP's [Common JFrog Artifactory](https://common.repositories.sapcloud.cn/). This is required to install the aeval package and its dependencies." 
- **If credentials are present**, proceed to the next step.
                                  
## 1: Create `aeval` folder and its subdirectories
Create `aeval` folder, on the same level as `app` folder.
Create sub directories `aeval/configs`, `aeval/reports`, `aeval/testcases`.
The folder structure should look like this:

```
./
├── README.md
├── aeval/
    ├── configs/          
    ├── reports/          
    └── testcases/
```
## 2: Install aeval and MLflow packages
**ALWAYS use the install script**
```bash
SKILL_PATH=$(find . -type d -name "aeval-set-up-local" -path "*/skills/*" 2>/dev/null | head -1)
bash "$SKILL_PATH/scripts/install_aeval_mlflow.sh"
```

## 3: Set up MLflow tracking server
MLflow tracking server is required to store traces that is used for evaluation.

- Guide them through setting up a local MLflow server (instructions in `references/setup-local-mlflow.md`)
- After MLflow server set up, configure `app/.env.local` with the following values:
    - `TRACKING_URI`: The tracking URI for the local MLflow server (e.g., "http://127.0.0.1:3333")
    - `MLFLOW_EXPERIMENT_ID`: "0" for local MLflow's default experiment

Ensure the user provided environment variables are configured in the `app/.env.local` file:

## 4: Configure OTEL environment variables in `app/.env.local`
- Check current MLflow server mode based on user's previous answer (local or self-hosted)
```
  Question: "How do you run your agent locally: directly with Python, or in a Docker container?"
  Options:
  1. "Python Virtual Environment"
  2. "Docker"
  ```
**Set `OTEL_EXPORTER_OTLP_ENDPOINT` based on where your agent running**

**Agent runs in Python venv**:
- Use http://127.0.0.1:<port> (same as MLFLOW_TRACKING_URI)
- Example: OTEL_EXPORTER_OTLP_ENDPOINT=http://127.0.0.1:<port>

**Agent runs in Docker (on same host)**:
- Use http://host.docker.internal:<port> (Docker network to reach host)
- Example: OTEL_EXPORTER_OTLP_ENDPOINT=http://host.docker.internal:3333    

**Additional required OTLP variables in `app/.env.local`:**
```bash
OTEL_EXPORTER_OTLP_TRACES_HEADERS=x-mlflow-experiment-id=<MLFLOW_EXPERIMENT_ID>
OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
```

Ensure all the OTLP related environment variables has no quote around.

## 5: If agent is running on docker, ensure the updated environment variables are passed to the container
Ensure the new environment variables are loaded to the docker container using the instructions in `references/update-docker-env.md`.

## 6: **CRITICAL**: Update `AGENT_PUBLIC_URL` in `app/.env.local` to `http://127.0.0.1:<port>`.
- Extract port from `agent_base_url` (e.g., `9000`)

## 7: Copy agent-config.yaml from template and configure the required fields

```bash
SKILL_PATH=$(find . -type d -name "aeval-set-up" -path "*/skills/*" 2>/dev/null | head -1)
cp "$SKILL_PATH/templates/agent-config-template.yaml" aeval/configs/agent-config.yaml
```

Configure the required fields:
- `agent_base_url`: URL where your agent runs (e.g., "http://127.0.0.1:9000" for local testing)
- `tracking_uri`: MLflow tracking URI (e.g., "http://127.0.0.1:3333")
- `experiment_id`: "0" for local MLflow's default experiment

## 8: Copy `00_sample_test_case.yaml` from template

```bash
SKILL_PATH=$(find . -type d -name "aeval-set-up" -path "*/skills/*" 2>/dev/null | head -1)
cp "$SKILL_PATH/templates/00_sample_test_case.yaml" aeval/testcases/00_sample_test_case.yaml
```
## 9: Inform the user that eval has been set up if all steps are successful
**Important**: If any of the steps failed, inform the user about the failure and provide guidance on how to fix it.

## 10: Next steps
- Use the aeval-run-eval skill to run aeval.