# SPII Code Patterns

Complete Python/FastAPI implementation patterns for UCL SPII v3.0.0 tenant mapping.

## Project Structure

```
app/
├── main.py              # Application entry point
├── api/
│   └── spii.py          # SPII endpoint handlers
├── middleware/
│   └── mtls_auth.py     # mTLS authentication middleware
├── models/
│   └── spii.py          # Pydantic models
└── services/
    └── spii_service.py  # Business logic
```

## Models (Pydantic)

```python
# app/models/spii.py
from pydantic import BaseModel, Field
from typing import Optional, Literal, Dict, Any
from enum import Enum
from uuid import UUID


class AssignmentState(str, Enum):
    """SPII assignment states"""
    INITIAL = "INITIAL"
    CONFIG_PENDING = "CONFIG_PENDING"
    DELETING = "DELETING"
    ERROR = "ERROR"
    READY = "READY"


class OperationType(str, Enum):
    """SPII operation types"""
    ASSIGN = "assign"
    UNASSIGN = "unassign"


class Platform(str, Enum):
    """Platform type"""
    BTP = "btp"
    UNIFIED_SERVICES = "unified-services"


class Context(BaseModel):
    """Formation context"""
    platform: Platform
    crmId: Optional[str] = None
    accountId: str
    uclFormationId: UUID
    uclFormationName: str
    uclFormationTypeId: UUID
    operation: OperationType
    operationId: UUID


class TenantInfo(BaseModel):
    """Base tenant information"""
    deploymentRegion: str
    applicationNamespace: str
    applicationUrl: str
    applicationTenantId: str
    globalTenantId: Optional[str] = None
    subaccountId: Optional[UUID] = None
    subdomain: Optional[str] = None
    uclSystemName: str
    uclSystemTenantId: UUID
    parameters: Optional[Dict[str, Any]] = None
    configuration: Optional[Dict[str, Any]] = None


class ReceiverTenant(TenantInfo):
    """Receiver tenant (you)"""
    state: AssignmentState
    uclAssignmentId: UUID


class AssignedTenant(TenantInfo):
    """Assigned tenant (other party)"""
    state: Optional[AssignmentState] = None
    uclAssignmentId: Optional[UUID] = None


class NotificationPayload(BaseModel):
    """Complete SPII notification"""
    context: Context
    receiverTenant: ReceiverTenant
    assignedTenant: AssignedTenant


class SPIIResponse(BaseModel):
    """Sync response body"""
    state: Literal["CONFIG_PENDING", "READY"]
    configuration: Optional[Dict[str, Any]] = None


class SPIIErrorResponse(BaseModel):
    """Error response"""
    error: str
```

## API Endpoint

```python
# app/api/spii.py
import logging
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from app.models.spii import NotificationPayload, SPIIResponse, SPIIErrorResponse
from app.services.spii_service import SPIIService, ValidationError

logger = logging.getLogger(__name__)


async def handle_tenant_mapping_notification(request: Request) -> JSONResponse:
    """
    Handle SPII tenant mapping notification.
    
    PATCH /v1/tenantMappings/{tenantId}
    
    Security: mTLS (sap:cmp-mtls:v1)
    """
    tenant_id = request.path_params.get("tenantId")
    x_tenant_id = request.headers.get("x-tenant-id")
    
    logger.info(f"SPII notification for tenant {tenant_id}, x-tenant-id: {x_tenant_id}")
    
    try:
        # Parse and validate payload
        body = await request.json()
        payload = NotificationPayload(**body)
        
        logger.info(
            f"Operation: {payload.context.operation}, "
            f"Formation: {payload.context.uclFormationName}, "
            f"Assignment: {payload.receiverTenant.uclAssignmentId}"
        )
        
        # Process notification
        spii_service = SPIIService()
        result = await spii_service.handle_notification_sync(tenant_id, payload.model_dump())
        
        logger.info(f"Result: state={result.state}, has_config={result.configuration is not None}")
        
        # Return response
        if result.error:
            return JSONResponse(status_code=200, content={"error": result.error})
        
        response = SPIIResponse(state=result.state, configuration=result.configuration)
        return JSONResponse(status_code=200, content=response.model_dump(exclude_none=True))
        
    except (ValueError, ValidationError) as e:
        logger.error(f"Validation error: {e}")
        return JSONResponse(status_code=400, content={"error": str(e)})
        
    except Exception as e:
        logger.exception(f"Server error: {e}")
        return JSONResponse(status_code=500, content={"error": f"Internal error: {e}"})


def create_spii_routes() -> list[Route]:
    """Create SPII routes."""
    return [
        Route(
            "/v1/tenantMappings/{tenantId}",
            handle_tenant_mapping_notification,
            methods=["PATCH"]
        ),
    ]
```

## Service Layer

```python
# app/services/spii_service.py
import logging
import os
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class AssignmentState(str, Enum):
    INITIAL = "INITIAL"
    CONFIG_PENDING = "CONFIG_PENDING"
    READY = "READY"
    ERROR = "ERROR"


class ValidationError(Exception):
    """Validation error for SPII notifications"""
    pass


class StatusReport:
    """Status report returned to UCL"""
    
    def __init__(
        self, 
        state: AssignmentState, 
        configuration: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None
    ):
        self.state = state
        self.configuration = configuration
        self.error = error


# In-memory storage (use database in production)
assignments_store: Dict[str, Dict[str, Any]] = {}
processing_locks: Dict[str, datetime] = {}


class SPIIService:
    """Service for handling SPII notifications."""
    
    async def handle_notification_sync(
        self, 
        tenant_id: str, 
        notification_data: Dict[str, Any]
    ) -> StatusReport:
        """Handle SPII notification synchronously."""
        
        context = notification_data.get("context", {})
        receiver = notification_data.get("receiverTenant", {})
        assigned = notification_data.get("assignedTenant", {})
        
        operation = context.get("operation")
        ucl_assignment_id = receiver.get("uclAssignmentId")
        receiver_state = receiver.get("state")
        assigned_state = assigned.get("state", "")
        assigned_config = assigned.get("configuration")
        
        # Validate required fields
        self._validate(notification_data)
        
        # Check for duplicate processing
        lock_key = f"{ucl_assignment_id}:{operation}"
        if lock_key in processing_locks:
            assignment = assignments_store.get(ucl_assignment_id)
            if assignment:
                return StatusReport(
                    state=AssignmentState(assignment["state"]),
                    configuration=assignment.get("sent_configuration")
                )
            return StatusReport(state=AssignmentState.READY)
        
        try:
            processing_locks[lock_key] = datetime.now(timezone.utc)
            
            # Handle unassign
            if operation == "unassign":
                if ucl_assignment_id in assignments_store:
                    del assignments_store[ucl_assignment_id]
                return StatusReport(state=AssignmentState.READY)
            
            # Handle assign - Step 1
            if receiver_state in ["INITIAL", "ERROR"] and assigned_state in ["INITIAL", "CONFIG_PENDING", ""]:
                config = self._build_config()
                
                assignments_store[ucl_assignment_id] = {
                    "ucl_assignment_id": ucl_assignment_id,
                    "state": AssignmentState.CONFIG_PENDING.value,
                    "step": 1,
                    "sent_configuration": config,
                    "created_at": datetime.now(timezone.utc).isoformat()
                }
                
                return StatusReport(state=AssignmentState.CONFIG_PENDING, configuration=config)
            
            # Handle assign - Step 2
            if receiver_state in ["CONFIG_PENDING", "ERROR"] and assigned_state == "READY":
                assignment = assignments_store.get(ucl_assignment_id, {})
                assignment.update({
                    "state": AssignmentState.READY.value,
                    "step": 2,
                    "received_configuration": assigned_config,
                    "updated_at": datetime.now(timezone.utc).isoformat()
                })
                assignments_store[ucl_assignment_id] = assignment
                
                # Store config in environment or database for runtime use
                self._store_received_config(assigned_config)
                
                return StatusReport(state=AssignmentState.READY)
            
            return StatusReport(state=AssignmentState.CONFIG_PENDING)
            
        finally:
            if lock_key in processing_locks:
                del processing_locks[lock_key]
    
    def _validate(self, data: Dict[str, Any]) -> None:
        """Validate notification payload."""
        context = data.get("context", {})
        receiver = data.get("receiverTenant", {})
        
        if not context:
            raise ValidationError("context cannot be empty")
        if not receiver:
            raise ValidationError("receiverTenant cannot be empty")
        if not context.get("operation"):
            raise ValidationError("context.operation is required")
        if context.get("operation") not in ["assign", "unassign"]:
            raise ValidationError("context.operation must be 'assign' or 'unassign'")
        if not receiver.get("uclAssignmentId"):
            raise ValidationError("receiverTenant.uclAssignmentId is required")
        if not receiver.get("state"):
            raise ValidationError("receiverTenant.state is required")
    
    def _build_config(self) -> Dict[str, Any]:
        """Build configuration to send to other party."""
        return {
            "credentials": {
                "outboundCommunication": {
                    "basicAuthentication": {
                        "url": os.getenv("SPII_API_URL", "https://api.example.com"),
                        "username": os.getenv("SPII_API_USER", "user"),
                        "password": os.getenv("SPII_API_PASSWORD", "password")
                    }
                }
            }
        }
    
    def _store_received_config(self, config: Optional[Dict[str, Any]]) -> None:
        """Store received configuration for runtime use."""
        if not config:
            return
        
        credentials = config.get("credentials", {})
        outbound = credentials.get("outboundCommunication", {})
        
        # Extract and store based on auth type
        if "basicAuthentication" in outbound:
            basic = outbound["basicAuthentication"]
            os.environ["PARTNER_URL"] = basic.get("url", "")
            os.environ["PARTNER_USER"] = basic.get("username", "")
            os.environ["PARTNER_PASSWORD"] = basic.get("password", "")
        
        elif "oauth2mtls" in outbound:
            oauth = outbound["oauth2mtls"]
            os.environ["PARTNER_URL"] = oauth.get("url", "")
            os.environ["PARTNER_CLIENT_ID"] = oauth.get("clientId", "")
            os.environ["PARTNER_TOKEN_URL"] = oauth.get("tokenServiceUrl", "")
```

## mTLS Middleware

```python
# app/middleware/mtls_auth.py
import logging
import os
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from typing import Optional, List

logger = logging.getLogger(__name__)


def parse_dn(dn_string: str) -> dict:
    """Parse X.509 Distinguished Name into components."""
    result = {}
    if not dn_string:
        return result
    
    # Handle escaped commas in DN values
    parts = []
    current = ""
    i = 0
    while i < len(dn_string):
        if dn_string[i] == '\\' and i + 1 < len(dn_string):
            current += dn_string[i:i+2]
            i += 2
        elif dn_string[i] == ',':
            parts.append(current.strip())
            current = ""
            i += 1
        else:
            current += dn_string[i]
            i += 1
    if current:
        parts.append(current.strip())
    
    for part in parts:
        if '=' in part:
            key, value = part.split('=', 1)
            result[key.strip()] = value.strip()
    
    return result


class MTLSAuthMiddleware(BaseHTTPMiddleware):
    """
    Middleware to validate mTLS client certificates.
    
    Validates UCL's client certificate per sap:cmp-mtls:v1 access strategy.
    In production, TLS termination happens at gateway level.
    """
    
    def __init__(
        self,
        app,
        path_prefixes: Optional[List[str]] = None,
        expected_subject_dn: Optional[str] = None,
        expected_cn: Optional[str] = None,
        expected_org: Optional[str] = None
    ):
        super().__init__(app)
        self.path_prefixes = path_prefixes or ["/v1/tenantMappings"]
        self.expected_subject_dn = expected_subject_dn or os.getenv("UCL_CLIENT_CERT_SUBJECT")
        self.expected_cn = expected_cn or os.getenv("UCL_CLIENT_CERT_CN")
        self.expected_org = expected_org or os.getenv("UCL_CLIENT_CERT_ORG")
        
        logger.info(f"MTLSAuth: prefixes={self.path_prefixes}, cn={self.expected_cn}")
    
    async def dispatch(self, request: Request, call_next):
        """Validate client certificate for SPII endpoints."""
        
        # Only validate configured paths
        if not any(request.url.path.startswith(p) for p in self.path_prefixes):
            return await call_next(request)
        
        # Get certificate info from headers (set by gateway)
        cert_subject = request.headers.get("X-SSL-Client-Subject-DN")
        cert_issuer = request.headers.get("X-SSL-Client-Issuer-DN")
        
        # Allow if no validation configured (development)
        if not cert_subject:
            if self.expected_subject_dn or self.expected_cn or self.expected_org:
                logger.error("Client certificate required but not provided")
                return JSONResponse(
                    status_code=401,
                    content={"error": "Client certificate required"}
                )
            logger.warning("No certificate validation configured, allowing request")
            return await call_next(request)
        
        # Validate full Subject DN
        if self.expected_subject_dn and cert_subject != self.expected_subject_dn:
            logger.error(f"Subject DN mismatch: expected={self.expected_subject_dn}, got={cert_subject}")
            return JSONResponse(
                status_code=401,
                content={"error": "Invalid client certificate"}
            )
        
        # Validate CN and O
        attrs = parse_dn(cert_subject)
        
        if self.expected_cn and attrs.get("CN") != self.expected_cn:
            logger.error(f"CN mismatch: expected={self.expected_cn}, got={attrs.get('CN')}")
            return JSONResponse(
                status_code=401,
                content={"error": "Invalid client certificate"}
            )
        
        if self.expected_org and attrs.get("O") != self.expected_org:
            logger.error(f"Org mismatch: expected={self.expected_org}, got={attrs.get('O')}")
            return JSONResponse(
                status_code=401,
                content={"error": "Invalid client certificate"}
            )
        
        logger.info(f"Certificate validated: CN={attrs.get('CN')}, O={attrs.get('O')}")
        
        # Store cert info in request state
        request.state.client_cert = {
            "subject": cert_subject,
            "issuer": cert_issuer,
            "cn": attrs.get("CN"),
            "org": attrs.get("O")
        }
        
        return await call_next(request)
```

## Application Setup

```python
# app/main.py
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.responses import JSONResponse

from app.api.spii import create_spii_routes
from app.middleware.mtls_auth import MTLSAuthMiddleware


async def health_check(request):
    return JSONResponse({"status": "healthy"})


def create_app() -> Starlette:
    """Create and configure application."""
    
    # Configure middleware
    middleware = [
        Middleware(
            MTLSAuthMiddleware,
            path_prefixes=["/v1/tenantMappings"],
            # Configure via environment variables:
            # UCL_CLIENT_CERT_CN, UCL_CLIENT_CERT_ORG
        ),
    ]
    
    # Combine routes
    routes = [
        Route("/health", health_check, methods=["GET"]),
        *create_spii_routes(),
    ]
    
    return Starlette(
        routes=routes,
        middleware=middleware,
        debug=False
    )


app = create_app()
```

## Environment Variables

```bash
# mTLS validation (from UCL /v1/info endpoint)
UCL_CLIENT_CERT_SUBJECT="CN=compass-gateway,O=SAP SE,L=Walldorf,ST=Baden-Wuerttemberg,C=DE"
UCL_CLIENT_CERT_CN="compass-gateway"
UCL_CLIENT_CERT_ORG="SAP SE"

# Your API configuration (sent to other party)
SPII_API_URL="https://your-app.cfapps.eu12.hana.ondemand.com/api"
SPII_API_USER="api-user"
SPII_API_PASSWORD="secure-password"
```

## Testing

```python
# tests/test_spii.py
import pytest
from starlette.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_spii_assign_step1():
    """Test Step 1: Both INITIAL."""
    payload = {
        "context": {
            "platform": "btp",
            "accountId": "test-account",
            "uclFormationId": "550e8400-e29b-41d4-a716-446655440000",
            "uclFormationName": "test-formation",
            "uclFormationTypeId": "550e8400-e29b-41d4-a716-446655440001",
            "operation": "assign",
            "operationId": "550e8400-e29b-41d4-a716-446655440002"
        },
        "receiverTenant": {
            "state": "INITIAL",
            "uclAssignmentId": "550e8400-e29b-41d4-a716-446655440003",
            "deploymentRegion": "cf-eu10",
            "applicationNamespace": "sap.test.app",
            "applicationUrl": "https://test.example.com",
            "applicationTenantId": "tenant-123",
            "uclSystemName": "test-system",
            "uclSystemTenantId": "550e8400-e29b-41d4-a716-446655440004"
        },
        "assignedTenant": {
            "state": "INITIAL",
            "deploymentRegion": "cf-eu10",
            "applicationNamespace": "sap.s4",
            "applicationUrl": "https://s4.example.com",
            "applicationTenantId": "s4-tenant-456",
            "uclSystemName": "s4-system",
            "uclSystemTenantId": "550e8400-e29b-41d4-a716-446655440005"
        }
    }
    
    response = client.patch("/v1/tenantMappings/tenant-123", json=payload)
    
    assert response.status_code == 200
    data = response.json()
    assert data["state"] == "CONFIG_PENDING"
    assert "configuration" in data


def test_spii_unassign():
    """Test unassign operation."""
    payload = {
        "context": {
            "platform": "btp",
            "accountId": "test-account",
            "uclFormationId": "550e8400-e29b-41d4-a716-446655440000",
            "uclFormationName": "test-formation",
            "uclFormationTypeId": "550e8400-e29b-41d4-a716-446655440001",
            "operation": "unassign",
            "operationId": "550e8400-e29b-41d4-a716-446655440006"
        },
        "receiverTenant": {
            "state": "DELETING",
            "uclAssignmentId": "550e8400-e29b-41d4-a716-446655440003",
            "deploymentRegion": "cf-eu10",
            "applicationNamespace": "sap.test.app",
            "applicationUrl": "https://test.example.com",
            "applicationTenantId": "tenant-123",
            "uclSystemName": "test-system",
            "uclSystemTenantId": "550e8400-e29b-41d4-a716-446655440004"
        },
        "assignedTenant": {
            "deploymentRegion": "cf-eu10",
            "applicationNamespace": "sap.s4",
            "applicationUrl": "https://s4.example.com",
            "applicationTenantId": "s4-tenant-456",
            "uclSystemName": "s4-system",
            "uclSystemTenantId": "550e8400-e29b-41d4-a716-446655440005"
        }
    }
    
    response = client.patch("/v1/tenantMappings/tenant-123", json=payload)
    
    assert response.status_code == 200
    assert response.json()["state"] == "READY"
```
