SAP CMP mTLS Access Strategy (v1.0)
Description
This is an SAP internal access strategy that is used for publishing to the Unified Customer Landscape (UCL), which can describe a customer system landscape incl. the runtime perspective.

The UCL was previously known as Central Management Plane (CMP), which is why the access strategy ID has cmp inside of it.

The Specification ID for it is: sap:cmp-mtls:v1.

Here is the official Application Provider Guide.

The Unified Customer Landscape (UCL), previously known as Central Management Plane / CMP is a service that:

Provides a complete up-to-date/live model of the customer landscape as well as relevant relations between the components (systems, extensions, dependencies, run-times, etc) within
Enables context based grouping based on business processes, compliance requirements, access control, etc
Re-expose all collected metadata from the Systems and Services via a centralized API (ORD Discovery Service) in different contexts
Allows to seamlessly and reliably apply and extend business processes
Apply policy based governance and communication permissions in order to enable secure and transparent communication between the components within the landscape
Automatically reconciles new changes to the customer landscape, enables simulating scenarios and detection of regressions
Orchestrates the establishment of reliable and secure communication (api and event based) between systems, side-by-side extensions, etc
The main relation to ORD is that UCL acts as an ORD Aggregator that securely aggregates and re-exposes the ORD documents provided by the system instances. The UCL access strategy ensures that there is proper trust in place between the aggregator and the respective SAP system so that the ORD documents can be securely and reliably obtained.

Implementation
The sap:cmp-mtls:v1 access strategy MUST be specified by all SAP applications and services (or broadly speaking - all SAP systems) which are configured to trust Unified Customer Landscape's client certificate and wish to authenticate UCL in this manner when the ORD Documents are requested. On the other hand UCL as an ORD Aggregator should respect ORD systems which specify the sap:cmp-mtls:v1 access strategy and send its own client certificate as part of the requests for fetching the corresponding ORD documents.

Trusting UCL's client certificate is achieved through two actions:

Importing the SAP Cloud Root CA
Importing the SAP Cloud Root CA into the system's trust store.

Some SAP systems already trust the SAP Cloud Root CA, but all other systems should ensure that they've downloaded and injected it from the original source: ⬇️ Get CA certificate

Validating incoming client certificate's subject field
Validating incoming client certificate's Subject field to match the one defined in the UCL client certificate.

In order for SAP systems to trust UCL's client certificates they should be aware of the Subject field which will be part of UCL's certificate in order to assert that it's a well known one.

UCL exposes the value of the Subject field on a public /v1/info endpoint, more specifically in the certSubject JSON response property. The different parts of the Subject are separated using the delimiter ,, but may include whitespace that needs to be trimmed. The order of the parts is also not guaranteed.

It's recommended that Subject match validation is implemented by splitting the expected Subject into parts by using , as a delimiter and then trimming the whitespace from all parts of the Subject. Afterwards, the same should be done for the incoming actual Subject so that the Subject can be validated regardless of the ordering of Subject parts, because it could vary in different environments and circumstances. The parts from both subjects - actual and expected - should match exactly.

// Example implementation in JavaScript
subject.split(",").map((token) => token.trim());

⚠ Ensure the verified client certificate is from the SAP BP Certificate Service/rootCA trust chain. Do not trust certificates verified by other sources. Depending on your environment, this might be handled by your gateway, or you may need to manage it yourself. ℹ Make sure not to miss that the delimiter may be surrounded by whitespace that needs trimming. ℹ It's possible that some SAP systems are deployed in environments where a central router/gateway does SSL termination and so the actual SAP system doesn't receive the actual certificate information. In such cases the router/gateway should propagate the client certificate Subject in some way to the SAP system - ex. via headers, like it is done in CloudFoundry [SAP internal link].

Validating client certificate trust chain and issuer
In addition to the subject field verification, it also needs to be ensured that the client certificate is part of the trust chain and that the issuer is the BTP Certificate Service.

UCL environments
UCL runs on 4 different environments and so the /v1/info endpoint can be found on the following addresses:

Dev-main: https://compass-gateway.cmp-main.dev.kyma.cloud.sap/v1/info -> linked to BTP Staging
Dev: https://compass-gateway.mps.dev.kyma.cloud.sap/v1/info -> linked to BTP Integrate
Stage (Canary): https://compass-gateway.mps.stage.kyma.cloud.sap/v1/info -> linked to BTP Canary
Prod (Live): https://compass-gateway.mps.kyma.cloud.sap/v1/info -> linked to BTP Live
SAP systems also run on various environments and LoBs should configure their SAP systems to assert the correct Subject based on which UCL environnement (Dev, Stage, Prod) they are expected to communicate with.

Example: With S4's adoption of ORD and integration with UCL they've configured their environments like so:

DLAB S4 systems will be configured to expect the Subject from UCL Dev
VLAB S4 systems will be configured to expect the Subject from UCL Stage
Prod S4 systems will be configured to expect the Subject from UCL Prod
NOTE: Agreement on how to map SAP systems from specific environments to which UCL environment each of them should communicate with should be done on an individual basis for every SAP LoB that integrates with UCL. SAP LoBs have a rich variety of environment types and the proper mapping should be discussed and agreed upon carefully with the UCL team.