# SPII State Machine

This document details the state transitions and handling logic for UCL SPII tenant mapping notifications.

## Assignment States

| State | Description | Can Transition To |
|-------|-------------|-------------------|
| `INITIAL` | First notification for this assignment | `CONFIG_PENDING`, `READY`, `ERROR` |
| `CONFIG_PENDING` | Awaiting configuration from other party | `READY`, `ERROR` |
| `READY` | Assignment fully configured | - (terminal for assign) |
| `ERROR` | Processing failed, may retry | `CONFIG_PENDING`, `READY` |
| `DELETING` | Unassign in progress | `READY` (confirms deletion) |

## Two-Step Configuration Exchange

The standard SPII flow involves two notifications per participant:

```
┌─────────────────────────────────────────────────────────────────┐
│                     UCL Formation                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Step 1: Both parties INITIAL                                   │
│  ┌──────────┐                           ┌──────────┐            │
│  │  Your    │  receiverTenant.state:    │  Other   │            │
│  │  App     │  INITIAL                  │  Party   │            │
│  │          │  assignedTenant.state:    │          │            │
│  │          │  INITIAL                  │          │            │
│  └──────────┘                           └──────────┘            │
│       │                                                          │
│       ▼                                                          │
│  Send your config, return CONFIG_PENDING                        │
│                                                                  │
│  Step 2: You CONFIG_PENDING, Other READY                        │
│  ┌──────────┐                           ┌──────────┐            │
│  │  Your    │  receiverTenant.state:    │  Other   │            │
│  │  App     │  CONFIG_PENDING           │  Party   │            │
│  │          │  assignedTenant.state:    │          │            │
│  │          │  READY                    │          │            │
│  └──────────┘                           └──────────┘            │
│       │                                                          │
│       ▼                                                          │
│  Store received config, return READY                            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## State Decision Logic

```python
def determine_response(notification: dict) -> dict:
    """Determine SPII response based on current states."""
    
    operation = notification["context"]["operation"]
    receiver_state = notification["receiverTenant"]["state"]
    assigned_state = notification["assignedTenant"].get("state", "")
    assigned_config = notification["assignedTenant"].get("configuration")
    
    # Unassign operation
    if operation == "unassign":
        # Clean up resources for this assignment
        cleanup_assignment(notification["receiverTenant"]["uclAssignmentId"])
        return {"state": "READY"}
    
    # Assign operation - determine step based on states
    
    # Step 1: Both INITIAL - send our config
    if receiver_state == "INITIAL" and assigned_state == "INITIAL":
        return {
            "state": "CONFIG_PENDING",
            "configuration": build_our_config()
        }
    
    # Step 1 (retry): We're in ERROR, assigned still INITIAL/CONFIG_PENDING
    if receiver_state == "ERROR" and assigned_state in ["INITIAL", "CONFIG_PENDING"]:
        return {
            "state": "CONFIG_PENDING",
            "configuration": build_our_config()
        }
    
    # Step 2: We're CONFIG_PENDING, assigned is READY with config
    if receiver_state == "CONFIG_PENDING" and assigned_state == "READY":
        store_received_config(assigned_config)
        return {"state": "READY"}
    
    # Step 2 (retry): We're in ERROR, assigned is READY
    if receiver_state == "ERROR" and assigned_state == "READY":
        store_received_config(assigned_config)
        return {"state": "READY"}
    
    # Unexpected state combination
    raise ValueError(f"Unexpected states: receiver={receiver_state}, assigned={assigned_state}")
```

## Complete Implementation

```python
from enum import Enum
from typing import Dict, Any, Optional
from datetime import datetime, timezone

class AssignmentState(str, Enum):
    INITIAL = "INITIAL"
    CONFIG_PENDING = "CONFIG_PENDING"
    READY = "READY"
    ERROR = "ERROR"

class StatusReport:
    """Response to return to UCL."""
    
    def __init__(
        self, 
        state: AssignmentState, 
        configuration: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None
    ):
        self.state = state
        self.configuration = configuration
        self.error = error
    
    def to_dict(self) -> Dict[str, Any]:
        result = {"state": self.state.value}
        if self.configuration:
            result["configuration"] = self.configuration
        if self.error:
            result["error"] = self.error
        return result

# In-memory storage (use database in production)
assignments_store: Dict[str, Dict[str, Any]] = {}

async def process_notification(notification: dict) -> StatusReport:
    """Process SPII notification and return status."""
    
    operation = notification["context"]["operation"]
    ucl_assignment_id = notification["receiverTenant"]["uclAssignmentId"]
    receiver_state = notification["receiverTenant"]["state"]
    assigned_state = notification["assignedTenant"].get("state", "")
    assigned_config = notification["assignedTenant"].get("configuration")
    
    # Handle unassign
    if operation == "unassign":
        if ucl_assignment_id in assignments_store:
            del assignments_store[ucl_assignment_id]
        return StatusReport(state=AssignmentState.READY)
    
    # Handle assign - Step 1
    if receiver_state in ["INITIAL", "ERROR"] and assigned_state in ["INITIAL", "CONFIG_PENDING", ""]:
        config = build_outbound_config()
        
        # Store assignment
        assignments_store[ucl_assignment_id] = {
            "ucl_assignment_id": ucl_assignment_id,
            "ucl_formation_id": notification["context"]["uclFormationId"],
            "state": AssignmentState.CONFIG_PENDING.value,
            "step": 1,
            "sent_configuration": config,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        
        return StatusReport(state=AssignmentState.CONFIG_PENDING, configuration=config)
    
    # Handle assign - Step 2
    if receiver_state in ["CONFIG_PENDING", "ERROR"] and assigned_state == "READY":
        # Store received configuration
        assignment = assignments_store.get(ucl_assignment_id, {})
        assignment.update({
            "state": AssignmentState.READY.value,
            "step": 2,
            "received_configuration": assigned_config,
            "updated_at": datetime.now(timezone.utc).isoformat()
        })
        assignments_store[ucl_assignment_id] = assignment
        
        return StatusReport(state=AssignmentState.READY)
    
    # Unexpected state - return current state or CONFIG_PENDING
    return StatusReport(state=AssignmentState.CONFIG_PENDING)


def build_outbound_config() -> Dict[str, Any]:
    """Build configuration to send to other party."""
    return {
        "credentials": {
            "outboundCommunication": {
                "basicAuthentication": {
                    "url": "https://your-api.example.com/api",
                    "username": "api-user",
                    "password": "secure-password"
                }
            }
        }
    }
```

## Handling Retries

UCL may resend notifications when:
- Previous notification returned 500 error
- Previous state was `ERROR`
- Network timeout occurred

Always check `receiverTenant.state` to determine if this is a retry:
- `INITIAL` → First notification
- `ERROR` → Retry after failure
- `CONFIG_PENDING` → Continuation (Step 2)

## Idempotency Pattern

```python
# Prevent duplicate processing
processing_locks: Dict[str, datetime] = {}

async def handle_notification(notification: dict) -> StatusReport:
    ucl_assignment_id = notification["receiverTenant"]["uclAssignmentId"]
    operation = notification["context"]["operation"]
    lock_key = f"{ucl_assignment_id}:{operation}"
    
    # Check for concurrent processing
    if lock_key in processing_locks:
        # Return current state
        assignment = assignments_store.get(ucl_assignment_id)
        if assignment:
            return StatusReport(
                state=AssignmentState(assignment["state"]),
                configuration=assignment.get("sent_configuration")
            )
        return StatusReport(state=AssignmentState.READY)
    
    try:
        processing_locks[lock_key] = datetime.now(timezone.utc)
        return await process_notification(notification)
    finally:
        del processing_locks[lock_key]
```

## Common State Scenarios

### Scenario 1: Simple Integration
Both parties exchange basic authentication credentials.

| Notification | receiverTenant.state | assignedTenant.state | Response |
|--------------|---------------------|---------------------|----------|
| 1 | INITIAL | INITIAL | CONFIG_PENDING + basicAuth config |
| 2 | CONFIG_PENDING | READY | READY |

### Scenario 2: Retry After Error
First attempt failed, UCL retries.

| Notification | receiverTenant.state | assignedTenant.state | Response |
|--------------|---------------------|---------------------|----------|
| 1 | INITIAL | INITIAL | ERROR (returned 500) |
| 2 | ERROR | CONFIG_PENDING | CONFIG_PENDING + config |
| 3 | CONFIG_PENDING | READY | READY |

### Scenario 3: Unassign
Participant removed from formation.

| Notification | operation | receiverTenant.state | Response |
|--------------|-----------|---------------------|----------|
| 1 | unassign | DELETING | READY (cleanup done) |
