# SPII mTLS Authentication

This document describes how to secure your SPII endpoint using the `sap:cmp-mtls:v1` access strategy.

## Overview

The SPII tenant mapping endpoint (`PATCH /v1/tenantMappings/{tenantId}`) must be secured via mTLS. UCL sends its client certificate with each request, and your application must validate it.

## Access Strategy: `sap:cmp-mtls:v1`

This SAP-internal access strategy ensures mutual trust between UCL and your application.

## Implementation Steps

### 1. Import SAP Cloud Root CA

Import the SAP Cloud Root CA into your system's trust store.

**Download CA Certificate**: [SAP Cloud Root CA](https://help.sap.com/docs/connectivity/sap-btp-connectivity-cf/ca-certificate)

> **Note**: BTP applications using Cloud Foundry or Kyma typically have this pre-configured at the platform level.

### 2. Get UCL Certificate Subject

UCL exposes its certificate Subject via the `/v1/info` endpoint:

| Environment | URL | Linked To |
|-------------|-----|-----------|
| Dev-main | `https://compass-gateway.cmp-main.dev.kyma.cloud.sap/v1/info` | BTP Staging |
| Dev | `https://compass-gateway.mps.dev.kyma.cloud.sap/v1/info` | BTP Integrate |
| Stage | `https://compass-gateway.mps.stage.kyma.cloud.sap/v1/info` | BTP Canary |
| **Prod** | `https://compass-gateway.mps.kyma.cloud.sap/v1/info` | BTP Live |

Example response:
```json
{"certIssuer":"CN=SAP PKI Certificate Service Client CA,OU=SAP BTP Clients,O=SAP SE,L=cf-us10-staging,C=DE","certSubject":"CN=cmp-dev,OU=SAP Cloud Platform Clients,OU=Staging,OU=cmp-cf-us10-staging,O=SAP SE,L=Dev,C=DE","rootCA":"-----BEGIN CERTIFICATE-----\nMIIFZjCCA06gAwIBAgIQGHcPvmUGa79M6pM42bGFYjANBgkqhkiG9w0BAQsFADBN\nMQswCQYDVQQGEwJERTERMA8GA1UEBwwIV2FsbGRvcmYxDzANBgNVBAoMBlNBUCBT\nRTEaMBgGA1UEAwwRU0FQIENsb3VkIFJvb3QgQ0EwHhcNMTkwMjEzMTExOTM2WhcN\nMzkwMjEzMTEyNjMyWjBNMQswCQYDVQQGEwJERTERMA8GA1UEBwwIV2FsbGRvcmYx\nDzANBgNVBAoMBlNBUCBTRTEaMBgGA1UEAwwRU0FQIENsb3VkIFJvb3QgQ0EwggIi\nMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQChbHLXJoe/zFag6fB3IcN3d3HT\nY14nSkEZIuUzYs7B96GFxQi0T/2s971JFiLfB4KaCG+UcG3dLXf1H/wewq8ahArh\nFTsu4UR71ePUQiYlk/G68EFSy2zWYAJliXJS5k0DFMIWHD1lbSjCF3gPVJSUKf+v\nHmWD5e9vcuiPBlSCaEnSeimYRhg0ITmi3RJ4Wu7H0Xp7tDd5z4HUKuyi9XRinfvG\nkPALiBaX01QRC51cixmo0rhVe7qsNh7WDnLNBZeA0kkxNhLKDl8J6fQHKDdDEzmZ\nKhK5KxL5p5YIZWZ8eEdNRoYRMXR0PxmHvRanzRvSVlXSbfqxaKlORfJJ1ah1bRNt\no0ngAQchTghsrRuf3Qh/2Kn29IuBy4bjKR9CdNLxGrClvX/q26rUUlz6A3lbXbwJ\nEHSRnendRfEiia+xfZD+NG2oZW0IdTXSqkCbnBnign+uxGH5ECjuLEtvtUx6i9Ae\nxAvK2FqIuud+AchqiZBKzmQAhUjKUoACzNP2Bx2zgJOeB0BqGvf6aldG0n2hYxJF\n8Xssc8TBlwvAqtiubP/UxJJPs+IHqU+zjm7KdP6dM2sbE+J9O3n8DzOP0SDyEmWU\nUCwnmoPOQlq1z6fH9ghcp9bDdbh6adXM8I+SUYUcfvupOzBU7rWHxDCXld/24tpI\nFA7FRzHwKXqMSjwtBQIDAQABo0IwQDAOBgNVHQ8BAf8EBAMCAQYwDwYDVR0TAQH/\nBAUwAwEB/zAdBgNVHQ4EFgQUHLxmKw7KjUufjZNxqQ/KZ0ZpEyIwDQYJKoZIhvcN\nAQELBQADggIBABdSKQsh3EfVoqplSIx6X43y2Pp+kHZLtEsRWMzgO5LhYy2/Fvel\neRBw/XEiB5iKuEGhxHz/Gqe0gZixw3SsHB1Q464EbGT4tPQ2UiMhiiDho9hVe6tX\nqX1FhrhycAD1xHIxMxQP/buX9s9arFZauZrpw/Jj4tGp7aEj4hypWpO9tzjdBthy\n5vXSviU8L2HyiQpVND/Rp+dNJmVYTiFLuULRY28QbikgFO2xp9s4RNkDBnbDeTrT\nCKWcVsmlZLPJJQZm0n2p8CvoeAsKzIULT9YSbEEBwmeqRlmbUaoT/rUGoobSFcrP\njrBg66y5hA2w7S3tDH0GjMpRu16b2u0hYQocUDuMlyhrkhsO+Qtqkz1ubwHCJ8PA\nRJw6zYl9VeBtgI5F69AEJdkAgYfvPw5DJipgVuQDSv7ezi6ZcI75939ENGjSyLVy\n4SuP99G7DuItG008T8AYFUHAM2h/yskVyvoZ8+gZx54TC9aY9gPIKyX++4bHv5BC\nqbEdU46N05R+AIBW2KvWozQkjhSQCbzcp6DHXLoZINI6y0WOImzXrvLUSIm4CBaj\n6MTXInIkmitdURnmpxTxLva5Kbng/u20u5ylIQKqpcD8HWX97lLVbmbnPkbpKxo+\nLvHPhNDM3rMsLu06agF4JTbO8ANYtWQTx0PVrZKJu+8fcIaUp7MVBIVZ\n-----END CERTIFICATE-----\n\n","ordAggregatorVersion":"1.10.0","openResourceDiscovery":{"adoptedVersion":"1.10.0","validatorVersion":"6.4.3"}}
```

### 3. Configure Certificate Validation

Set environment variables with expected certificate values:

```bash
# Full Subject DN (from /v1/info certSubject)
UCL_CLIENT_CERT_SUBJECT="CN=compass-gateway, O=SAP SE, L=Walldorf, ST=Baden-Wuerttemberg, C=DE"

# Or validate individual components
UCL_CLIENT_CERT_CN="compass-gateway"
UCL_CLIENT_CERT_ORG="SAP SE"
```

### 4. Gateway Configuration

In production, TLS termination happens at the gateway (Istio, API Gateway, etc.). The gateway passes certificate information via headers:

| Header | Description |
|--------|-------------|
| `X-SSL-Client-Subject-DN` | Certificate Subject DN |
| `X-SSL-Client-Issuer-DN` | Certificate Issuer DN |
| `X-Forwarded-Client-Cert` | Full certificate (CF format) |

## Validation Logic

### Subject DN Parsing

The Subject DN components are comma-separated but may include whitespace. Parse carefully:

```python
def parse_dn(dn_string: str) -> dict:
    """Parse X.509 Distinguished Name."""
    result = {}
    if not dn_string:
        return result
    
    # Handle escaped commas
    parts = []
    current = ""
    i = 0
    while i < len(dn_string):
        if dn_string[i] == '\\' and i + 1 < len(dn_string):
            current += dn_string[i:i+2]
            i += 2
        elif dn_string[i] == ',':
            parts.append(current.strip())
            current = ""
            i += 1
        else:
            current += dn_string[i]
            i += 1
    if current:
        parts.append(current.strip())
    
    for part in parts:
        if '=' in part:
            key, value = part.split('=', 1)
            result[key.strip()] = value.strip()
    
    return result

# Usage
attrs = parse_dn("CN=compass-gateway, O=SAP SE, L=Walldorf")
# {'CN': 'compass-gateway', 'O': 'SAP SE', 'L': 'Walldorf'}
```

### Subject Comparison

When comparing subjects, handle different ordering and whitespace:

```python
def subjects_match(expected: str, actual: str) -> bool:
    """Compare Subject DNs regardless of ordering."""
    expected_parts = set(p.strip() for p in expected.split(","))
    actual_parts = set(p.strip() for p in actual.split(","))
    return expected_parts == actual_parts
```

## Middleware Implementation

```python
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
import os

class MTLSAuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        # Only validate SPII endpoint
        if not request.url.path.startswith("/v1/tenantMappings"):
            return await call_next(request)
        
        cert_subject = request.headers.get("X-SSL-Client-Subject-DN")
        expected_cn = os.getenv("UCL_CLIENT_CERT_CN")
        
        if not cert_subject and expected_cn:
            return JSONResponse(
                status_code=401,
                content={"error": "Client certificate required"}
            )
        
        if expected_cn:
            attrs = parse_dn(cert_subject)
            if attrs.get("CN") != expected_cn:
                return JSONResponse(
                    status_code=401,
                    content={"error": "Invalid client certificate"}
                )
        
        return await call_next(request)
```

## Environment Mapping

Map your deployment environments to UCL environments:

| Your Environment | UCL Environment |
|-----------------|-----------------|
| Development | Dev or Dev-main |
| Staging/QA | Stage (Canary) |
| Production | Prod (Live) |

> **Important**: Coordinate with the UCL team to confirm the correct environment mapping for your application.

## Security Checklist

- [ ] SAP Cloud Root CA imported to trust store
- [ ] UCL certificate Subject obtained from correct environment's `/v1/info`
- [ ] Gateway configured to pass certificate headers
- [ ] Middleware validates certificate Subject/CN/Org
- [ ] Development environment allows bypass for testing (optional)
- [ ] Logging enabled for authentication failures