---
name: sap-ucl-spii-base-implementation
description: Implement UCL SPII v3.0.0 (SaaS Provider Integration Interface) for tenant mapping. Use when building a BTP application that needs to participate in UCL formations, receive tenant assignment notifications, or exchange configuration with other formation participants via SPII protocol.
compatibility: Python 3.10+, FastAPI/Starlette, Pydantic. Requires mTLS setup at gateway level.
metadata:
  author: sap-ucl
  version: "3.0.0"
  protocol: spii-v3
---

# UCL SPII Base Implementation

This skill guides you through implementing the UCL SaaS Provider Integration Interface (SPII) v3.0.0 for synchronous tenant mapping notifications.

## Overview

SPII enables BTP applications to:
- Receive notifications when assigned to a UCL formation with other participants
- Exchange configuration (credentials, URLs) with other formation participants
- Handle both `assign` and `unassign` operations

## Key Concepts

### Endpoint

Implement `PATCH /v1/tenantMappings/{tenantId}` to receive SPII notifications from UCL.

### Security

Secure with mTLS using `sap:cmp-mtls:v1` access strategy. See [access-and-authentication.md](references/access-and-authentication.md).

### States

| State | Description |
|-------|-------------|
| `INITIAL` | First notification for assignment |
| `CONFIG_PENDING` | Processed successfully, awaiting configuration from other party |
| `READY` | Assignment complete, no more configuration needed |
| `ERROR` | Processing failed |

### Sync Response

Return HTTP 200 with JSON body:
```json
{
  "state": "READY|CONFIG_PENDING",
  "configuration": { /* optional config for other party */ }
}
```

## Implementation Steps

### 1. Create the SPII Endpoint

```python
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

async def handle_tenant_mapping(request: Request) -> JSONResponse:
    tenant_id = request.path_params.get("tenantId")
    body = await request.json()
    
    # Extract key fields
    operation = body["context"]["operation"]  # "assign" or "unassign"
    receiver_state = body["receiverTenant"]["state"]
    assigned_state = body["assignedTenant"].get("state", "")
    
    # Process based on operation and states
    if operation == "assign":
        result = handle_assign(body)
    else:
        result = handle_unassign(body)
    
    return JSONResponse(status_code=200, content=result)

routes = [Route("/v1/tenantMappings/{tenantId}", handle_tenant_mapping, methods=["PATCH"])]
```

### 2. Handle Assignment States

The two-step configuration exchange pattern:

**Step 1**: Both parties `INITIAL` → Send your config → Return `CONFIG_PENDING`
**Step 2**: Receiver `CONFIG_PENDING`, Assigned `READY` → Store received config → Return `READY`

See [state-machine.md](references/state-machine.md) for detailed state handling logic.

### 3. Build Configuration Response

The configuration you return depends on the **Formation Type ID** (`context.uclFormationTypeId`). SPII is a generic protocol—the same endpoint may handle multiple formation types, each with different integration contracts.

```python
def build_config_response(notification: dict) -> dict:
    """
    Build configuration based on formation type.
    
    Different formation types may require different configurations.
    
    Args:
        notification: Full SPII notification payload
        
    Returns:
        Configuration dict for the other party
    """
    formation_type_id = notification["context"]["uclFormationTypeId"]
    assigned_namespace = notification["assignedTenant"]["applicationNamespace"]
    
    # Route to appropriate handler based on formation type
    if formation_type_id == "your-s4-integration-type-id":
        return build_s4_config(notification)
    elif formation_type_id == "your-ias-integration-type-id":
        return build_ias_config(notification)
    else:
        # Default/fallback configuration
        return build_default_config(notification)


def build_default_config(notification: dict) -> dict:
    """Default configuration with basic authentication."""
    return {
        "credentials": {
            "outboundCommunication": {
                "basicAuthentication": {
                    "url": "https://your-api.example.com",
                    "username": "user",
                    "password": "secret"
                }
            }
        }
    }
```

> **Note**: If your application participates in multiple formation types, maintain a mapping of `uclFormationTypeId` → configuration handler. The tenant mapping contract (what credentials to exchange, which APIs to expose) is defined per formation type.

### 4. Add mTLS Middleware

```python
from starlette.middleware.base import BaseHTTPMiddleware

class MTLSAuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        if request.url.path.startswith("/v1/tenantMappings"):
            cert_subject = request.headers.get("X-SSL-Client-Subject-DN")
            if not self._validate_cert(cert_subject):
                return JSONResponse(status_code=401, content={"error": "Invalid certificate"})
        return await call_next(request)
```

## Reference Files

| File | Description |
|------|-------------|
| [swagger.yaml](references/swagger.yaml) | Complete OpenAPI spec for SPII v3.0.0 |
| [access-and-authentication.md](references/access-and-authentication.md) | mTLS setup and certificate validation |
| [state-machine.md](references/state-machine.md) | Detailed state transition logic |
| [code-patterns.md](references/code-patterns.md) | Complete Python implementation patterns |

## Request Payload Structure

```json
{
  "context": {
    "platform": "btp",
    "accountId": "global-account-id",
    "uclFormationId": "uuid",
    "uclFormationName": "my-formation",
    "operation": "assign|unassign",
    "operationId": "uuid"
  },
  "receiverTenant": {
    "state": "INITIAL|CONFIG_PENDING|ERROR",
    "uclAssignmentId": "uuid",
    "applicationTenantId": "local-tenant-id",
    "applicationNamespace": "sap.your.namespace",
    "configuration": { /* your previous config */ }
  },
  "assignedTenant": {
    "state": "INITIAL|CONFIG_PENDING|READY|ERROR|",
    "applicationTenantId": "other-tenant-id",
    "applicationNamespace": "sap.s4",
    "configuration": { /* other party's config */ }
  }
}
```

## Error Handling

- **400 Bad Request**: Validation errors (missing fields, invalid operation)
- **500 Internal Server Error**: Server errors (subject to UCL retry)

```python
# Validation error
return JSONResponse(status_code=400, content={"error": "context.operation is required"})

# Server error
return JSONResponse(status_code=500, content={"error": "Database connection failed"})
```

## Idempotency

**Important**: SPII notifications may be delivered multiple times. Implementations must be idempotent:
- Use `receiverTenant.uclAssignmentId` as the unique identifier for storing assignment state
- Check if assignment already processed before creating new resources
- Return current state if duplicate notification received
