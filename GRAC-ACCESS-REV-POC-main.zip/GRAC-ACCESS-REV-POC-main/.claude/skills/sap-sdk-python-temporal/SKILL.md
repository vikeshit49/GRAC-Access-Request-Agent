---
name: sap-sdk-python-temporal
description: Build Temporal workflow applications in Python using the open-source temporalio SDK. Use when the user needs to create workflows, activities, workers, or starters for Temporal-based orchestration, including deployment on SAP BTP Kyma Runtime.
---

# Temporal Workflow Orchestration with Python

This skill guides you through building Temporal workflow applications using the open-source [`temporalio`](https://docs.temporal.io/develop/python) Python SDK.

> **SAP BTP internal deployments (Kyma / Cloud Foundry):** If your app runs on SAP BTP and needs to connect to SAP Managed Temporal, the connection requires mTLS authentication via ZTIS (SPIFFE/SPIRE). Refer to the internal SAP `sap-sdk-python-temporal` (internal) skill or the SAP Temporal SDK documentation for credential setup. The patterns below apply in both cases — only the client creation differs.

## Installation

```bash
pip install temporalio
# or with uv
uv add temporalio
```

## Quick Start

```python
import asyncio
from temporalio.client import Client
from temporalio.worker import Worker
from temporalio import workflow, activity
from datetime import timedelta

@activity.defn
async def greet(name: str) -> str:
    return f"Hello, {name}!"

@workflow.defn
class GreetingWorkflow:
    @workflow.run
    async def run(self, name: str) -> str:
        return await workflow.execute_activity(
            greet, name, start_to_close_timeout=timedelta(seconds=30)
        )

async def main():
    client = await Client.connect("localhost:7233")
    async with Worker(client, task_queue="greetings", workflows=[GreetingWorkflow], activities=[greet]):
        result = await client.execute_workflow(
            GreetingWorkflow.run, "World", id="greeting-1", task_queue="greetings"
        )
        print(result)  # Hello, World!

asyncio.run(main())
```

## Defining Workflows

Workflows must be **deterministic** — they replay from event history on failure. Never use `time.time()`, `random`, or I/O directly inside a workflow. Use activities for all side effects.

```python
from temporalio import workflow
from datetime import timedelta

with workflow.unsafe.imports_passed_through():
    from app.activities import greet, send_notification

@workflow.defn
class GreetingWorkflow:
    @workflow.run
    async def run(self, name: str) -> str:
        greeting = await workflow.execute_activity(
            greet, name,
            start_to_close_timeout=timedelta(seconds=30),
        )
        await workflow.execute_activity(
            send_notification, greeting,
            start_to_close_timeout=timedelta(seconds=60),
        )
        return greeting
```

**Determinism rules:**
- No I/O, no `random`, no `time.time()` — use `workflow.now()` for the current time
- Import non-deterministic modules inside `workflow.unsafe.imports_passed_through()`
- Use `workflow.execute_activity()` for all side effects

## Defining Activities

Activities perform the actual work (HTTP calls, database writes, etc.):

```python
from temporalio import activity

@activity.defn
async def greet(name: str) -> str:
    return f"Hello, {name}!"

@activity.defn
async def send_notification(message: str) -> None:
    # HTTP calls, DB writes, file I/O go here
    print(f"Notification: {message}")
```

For long-running activities, heartbeat to report progress and allow cancellation:

```python
@activity.defn
async def process_batch(dataset_id: str) -> int:
    records = await load_records(dataset_id)
    for i, record in enumerate(records):
        await process_record(record)
        activity.heartbeat(i)  # Report progress; raises CancelledError on cancellation
    return len(records)
```

## Running a Worker

Workers poll a task queue and execute workflows and activities:

```python
import asyncio
from temporalio.client import Client
from temporalio.worker import Worker
from app.workflows import GreetingWorkflow
from app.activities import greet, send_notification

async def main():
    client = await Client.connect("localhost:7233")
    worker = Worker(
        client,
        task_queue="greetings",
        workflows=[GreetingWorkflow],
        activities=[greet, send_notification],
    )
    await worker.run()

asyncio.run(main())
```

## Starting Workflows

```python
client = await Client.connect("localhost:7233")

# Start and wait for result
result = await client.execute_workflow(
    GreetingWorkflow.run, "World",
    id="greeting-1", task_queue="greetings",
)

# Start without waiting
handle = await client.start_workflow(
    GreetingWorkflow.run, "World",
    id="greeting-1", task_queue="greetings",
)
result = await handle.result()  # Wait later

# Get handle to existing workflow
handle = client.get_workflow_handle("greeting-1")
result = await handle.result()
```

## Signals and Queries

```python
@workflow.defn
class OrderWorkflow:
    def __init__(self):
        self._status = "pending"

    @workflow.signal
    async def approve(self) -> None:
        self._status = "approved"

    @workflow.query
    def status(self) -> str:
        return self._status

    @workflow.run
    async def run(self, order_id: str) -> str:
        await workflow.wait_condition(lambda: self._status == "approved")
        return f"Order {order_id} approved"

# Signal a running workflow
handle = client.get_workflow_handle("order-123")
await handle.signal(OrderWorkflow.approve)

# Query a running workflow
status = await handle.query(OrderWorkflow.status)
```

## Schedules

```python
from temporalio.client import (
    Schedule, ScheduleActionStartWorkflow,
    ScheduleSpec, ScheduleIntervalSpec,
)
from datetime import timedelta

handle = await client.create_schedule(
    "daily-report",
    Schedule(
        action=ScheduleActionStartWorkflow(
            DailyReportWorkflow.run,
            id="daily-report",
            task_queue="reports",
        ),
        spec=ScheduleSpec(
            intervals=[ScheduleIntervalSpec(every=timedelta(hours=24))],
        ),
    ),
)
```

## Retry Policies

```python
from temporalio.common import RetryPolicy

result = await workflow.execute_activity(
    process_payment,
    payment_id,
    start_to_close_timeout=timedelta(seconds=60),
    retry_policy=RetryPolicy(
        initial_interval=timedelta(seconds=1),
        maximum_attempts=3,
        non_retryable_error_types=["PaymentDeclinedError"],
    ),
)
```

## Error Handling

```python
from temporalio.client import WorkflowFailureError
from temporalio.exceptions import ActivityError, ApplicationError

try:
    result = await client.execute_workflow(
        GreetingWorkflow.run, "World",
        id="greeting-1", task_queue="greetings",
    )
except WorkflowFailureError as e:
    print(f"Workflow failed: {e.cause}")
except Exception as e:
    print(f"Error: {e}")
```

Raise typed errors from activities:

```python
from temporalio.exceptions import ApplicationError

@activity.defn
async def process_payment(payment_id: str) -> str:
    if not valid(payment_id):
        raise ApplicationError("Invalid payment", payment_id, type="PaymentDeclinedError", non_retryable=True)
    return "ok"
```

## Workflow Options Reference

| Parameter | Description |
|-----------|-------------|
| `id` | Unique workflow ID |
| `task_queue` | Queue workers poll |
| `execution_timeout` | Max total workflow time |
| `run_timeout` | Max single run time |
| `task_timeout` | Max workflow task time |
| `id_reuse_policy` | How to handle duplicate IDs |
| `retry_policy` | Retry config for the workflow |
| `cron_schedule` | Cron string for recurring runs |
| `memo` | Arbitrary key-value metadata |
| `search_attributes` | Indexable attributes for visibility |

## Local Development

```bash
# Install Temporal CLI
brew install temporal

# Start the local dev server (UI at http://localhost:8233)
temporal server start-dev

# Run your worker
python worker.py

# Start a workflow
python starter.py
```

## Testing

Use `temporalio.testing` for unit tests without a running server:

```python
import pytest
from temporalio.testing import ActivityEnvironment, WorkflowEnvironment
from temporalio.worker import Worker
from app.activities import greet
from app.workflows import GreetingWorkflow

@pytest.mark.asyncio
async def test_greet_activity():
    env = ActivityEnvironment()
    result = await env.run(greet, "World")
    assert result == "Hello, World!"

@pytest.mark.asyncio
async def test_greeting_workflow():
    async with await WorkflowEnvironment.start_local() as env:
        async with Worker(env.client, task_queue="test", workflows=[GreetingWorkflow], activities=[greet]):
            result = await env.client.execute_workflow(
                GreetingWorkflow.run, "World",
                id="test-1", task_queue="test",
            )
            assert result == "Hello, World!"
```

## SAP BTP Kyma Deployment

For Kyma Runtime, mount the SPIFFE socket via the SPIFFE CSI driver — required when connecting to SAP Managed Temporal with mTLS.

### Step 1: Enable the ZTIS Agent Kyma Module

```bash
kubectl patch kyma default -n kyma-system \
  --type='json' \
  -p='[{"op":"add","path":"/spec/modules/-","value":{"name":"ztis-agent"}}]'

# Wait until Ready (~5 min)
kubectl get ztisagents
# NAME      STATE
# default   Ready
```

This installs the SPIRE DaemonSet and SPIFFE CSI driver on the cluster. No separate ZTIS ServiceInstance is needed — the module auto-registers the cluster.

### Step 2: Provision Temporal Service

```yaml
apiVersion: services.cloud.sap.com/v1
kind: ServiceInstance
metadata:
  name: temporal-instance
  namespace: my-app-ns
spec:
  serviceOfferingName: cobalttemporal
  servicePlanName: namespaced
  parameters:
    owner_email: team@example.com
    description: "Temporal workspace for my application"
    retention_period: 7d
    admin:
      users:
        - email: team@example.com
          userid: YOUR_SAP_USER_ID
---
apiVersion: services.cloud.sap.com/v1
kind: ServiceBinding
metadata:
  name: temporal-binding
  namespace: my-app-ns
spec:
  serviceInstanceName: temporal-instance
```

The binding secret contains `sdkhostname` (SPIFFE endpoint) and `namespace`.

### Step 3: Deploy with SPIFFE CSI Volume

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: temporal-worker
spec:
  template:
    spec:
      containers:
        - name: worker
          image: my-worker:latest
          env:
            - name: TEMPORAL_CALL_URL
              valueFrom:
                secretKeyRef:
                  name: temporal-binding
                  key: sdkhostname
            - name: TEMPORAL_NAMESPACE
              valueFrom:
                secretKeyRef:
                  name: temporal-binding
                  key: namespace
          volumeMounts:
            - name: spiffe-workload-api
              mountPath: /spiffe-workload-api
              readOnly: true
      volumes:
        - name: spiffe-workload-api
          csi:
            driver: csi.spiffe.io
            readOnly: true
```

The SPIFFE socket is available at `/spiffe-workload-api/spire-agent.sock` inside the pod.

> **Note:** Connecting to SAP Managed Temporal from Kyma requires mTLS via ZTIS. Use the internal `sap-temporal-sdk` (or `sap_cloud_sdk.temporal`) which handles SPIFFE credential resolution automatically. With the plain `temporalio` SDK you would need to wire the SPIFFE X.509 SVID into the gRPC TLS config manually.
