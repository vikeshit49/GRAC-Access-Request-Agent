"""MutationGuard template.

MutationGuard runs validators sequentially (pipeline). Each validator detects
an issue and fixes it — the fixed output feeds the next validator.
"""

import asyncio

from aegis import MutationGuard
from aegis.validators import InputSanitizer
from aegis.validators.mutation import TerminologyDetectionMutation


def build_input_mutation_guard() -> MutationGuard:
    return (
        MutationGuard("input-sanitizer")
        .use(InputSanitizer())
        .use(TerminologyDetectionMutation(
            terms={"blacklist": "blocklist", "whitelist": "allowlist", "master": "main"},
        ))
    )


def build_output_mutation_guard() -> MutationGuard:
    return (
        MutationGuard("output-sanitizer")
        .use(InputSanitizer(check_xss=True, check_sqli=True))
    )


async def sanitize_input(user_input: str) -> str:
    guard = build_input_mutation_guard()
    result = await guard.validate(value=user_input)

    if result.was_mutated:
        print(f"Input was sanitized ({len(result.mutations)} mutations applied)")
        return result.output_value
    return user_input


async def sanitize_output(agent_response: str) -> str:
    guard = build_output_mutation_guard()
    result = await guard.validate(value=agent_response)

    if result.was_mutated:
        print(f"Output was sanitized ({len(result.mutations)} mutations applied)")
        return result.output_value
    return agent_response


# --- Inspecting results ---

async def example_with_inspection():
    guard = MutationGuard("demo").use(InputSanitizer())
    result = await guard.validate(value="Normal text <script>alert('xss')</script>")

    # Check if anything was mutated
    print(f"Was mutated: {result.was_mutated}")

    # Access the final cleaned text
    print(f"Clean output: {result.output_value}")

    # Inspect individual results (pass/fail for each validator)
    for r in result.results:
        print(f"  {r.validator_name}: {type(r).__name__}")

    # Inspect mutations applied
    for m in result.mutations:
        print(f"  Mutated by {m.validator_name}: {m.metadata}")

    # Check if there were any detection failures (before mutation)
    if result.has_failures:
        for f in result.failures:
            print(f"  Detected: {f.error_code}")


if __name__ == "__main__":
    asyncio.run(sanitize_input("Add to the whitelist <script>alert(1)</script>"))
