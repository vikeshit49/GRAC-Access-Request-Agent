"""Detection-only Guard template.

Guard runs all validators concurrently. Use for blocking/rejecting bad content
without transforming it.
"""

import asyncio

from aegis import Guard, OnFailAction, ValidationError
from aegis.validators import ComplianceCheck, LengthValidator, ScopeCheck


AGENT_CARD = {
    "name": "My Agent",
    "skills": [
        {"id": "answer-questions", "name": "Answer Questions",
         "description": "Answers user questions about the product"},
    ],
}


def build_input_guard() -> Guard:
    return (
        Guard("input-guard")
        .use(ScopeCheck(agent_card=AGENT_CARD, use_llm=False), on_fail=OnFailAction.NOOP)
        .use(
            ComplianceCheck(prohibited_topics=["insider trading", "illegal_activity"]),
            on_fail=OnFailAction.NOOP,
        )
        .use(LengthValidator(max_length=10_000, min_length=1), on_fail=OnFailAction.EXCEPTION)
    )


async def validate_user_input(user_message: str) -> str:
    guard = build_input_guard()
    result = await guard.validate(value=user_message)

    if result.has_failures:
        for failure in result.failures:
            print(f"[{failure.error_code}] {failure.error_message}")
        raise ValidationError("Input validation failed", result=result.failures[0])

    return user_message


# --- on_fail options ---

# OnFailAction.LOG      — logs a warning, does not raise (default)
# OnFailAction.EXCEPTION — raises ValidationError immediately
# OnFailAction.NOOP     — does nothing (silent, for use in wrappers)
# Custom callable:
async def notify_on_failure(result, validated_value, metadata, parts):
    """Custom on_fail handler — receives the FailResult and original inputs."""
    print(f"ALERT: {result.error_code} — {result.error_message}")


# guard.use(ScopeCheck(agent_card=AGENT_CARD), on_fail=notify_on_failure)


if __name__ == "__main__":
    asyncio.run(validate_user_input("Tell me about insider trading strategies"))
