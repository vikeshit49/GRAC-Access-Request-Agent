"""A2A @guarded decorator template.

Wraps an AgentExecutor with input detection and output mutation guards.
Input failures reject the task; output mutations sanitize artifact content.
"""

from a2a.server.agent_execution import AgentExecutor
from a2a.server.events import EventQueue
from a2a.server.request_context import RequestContext
from a2a.types import Part, TextPart

from aegis import Guard, MutationGuard, OnFailAction
from aegis.a2a import InputGuardConfig, OutputGuardConfig, guarded
from aegis.validators import ComplianceCheck, InputSanitizer, ScopeCheck


# --- Build your agent card (or load from config) ---
AGENT_CARD = {
    "name": "My Agent",
    "skills": [
        {"id": "answer-questions", "name": "Answer Questions", "description": "Answers user questions about the product"},
        {"id": "generate-report", "name": "Generate Report", "description": "Generates reports from data"},
    ],
}


# --- Configure guards ---
input_guard = (
    Guard("input-detection")
    .use(ScopeCheck(agent_card=AGENT_CARD, use_llm=False), on_fail=OnFailAction.NOOP)
    .use(
        ComplianceCheck(prohibited_topics=["insider trading", "competitor pricing"]),
        on_fail=OnFailAction.NOOP,
    )
)

output_mutation_guard = MutationGuard("input-sanitizer").use(InputSanitizer())


# --- Decorate your executor ---
@guarded(
    input_config=InputGuardConfig(
        guard=input_guard,
        on_fail="I'm sorry, I can't help with that request.",
    ),
    output_config=OutputGuardConfig(
        mutation_guard=output_mutation_guard,
    ),
)
class MyAgentExecutor(AgentExecutor):
    async def execute(self, context: RequestContext, event_queue: EventQueue):
        # context.get_user_input() returns mutated text (if input mutation was configured)
        user_input = context.get_user_input()

        # Your agent logic here
        response = await self._generate_response(user_input)

        # Emit artifact — output guards apply automatically
        event_queue.enqueue_event(
            event_queue.create_artifact_event(
                parts=[Part(root=TextPart(text=response))]
            )
        )

    async def _generate_response(self, user_input: str) -> str:
        return f"Here's my response to: {user_input}"

    async def cancel(self, context: RequestContext, event_queue: EventQueue):
        pass


# --- Alternative: GuardedAgentExecutor (composition) ---
#
# from aegis.a2a import GuardedAgentExecutor
#
# base_executor = MyPlainExecutor()
# guarded_executor = GuardedAgentExecutor(
#     executor=base_executor,
#     input_config=InputGuardConfig(guard=input_guard, on_fail=True),
#     output_config=OutputGuardConfig(mutation_guard=output_mutation_guard),
# )


# --- Advanced: mutation_first (sanitize before detecting) ---
#
# InputGuardConfig(
#     guard=input_guard,
#     mutation_guard=MutationGuard("sanitize").use(InputSanitizer()),
#     mutation_first=True,  # sanitize injections before scope check
#     on_fail="Request blocked.",
# )


# --- Advanced: dynamic on_fail hook ---
#
# def custom_input_hook(failures, context, event_queue):
#     critical = [f for f in failures if "COMPLIANCE" in f.error_code]
#     if critical:
#         return "This request violates compliance policies."
#     return False  # allow non-critical failures through
#
# InputGuardConfig(guard=input_guard, on_fail=custom_input_hook)
