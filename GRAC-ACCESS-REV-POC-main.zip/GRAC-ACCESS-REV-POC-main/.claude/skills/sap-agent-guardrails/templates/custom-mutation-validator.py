"""Custom mutation validator template.

Subclass BaseMutationValidator to create a detect-and-fix validator for MutationGuard.
Implement validate() for detection and mutate() for transformation.
mutate() is only called when validate() returns FailResult.
"""

import re
from typing import Any

from a2a.types import Part

from aegis import (
    BaseMutationValidator,
    FailResult,
    MutateResult,
    MutationGuard,
    PassResult,
)


class UppercaseNormalizer(BaseMutationValidator):
    """Detects ALL CAPS text and normalizes to sentence case."""

    def __init__(self, min_length: int = 4):
        self._min_length = min_length

    async def validate(
        self,
        value: str | None = None,
        parts: list[Part] | None = None,
        metadata: dict[str, Any] | None = None,
    ):
        if not value:
            return PassResult()
        if value.isupper() and len(value) > self._min_length:
            return FailResult(
                error_message="Text is all uppercase",
                error_code="ALL_CAPS",
                metadata={"original_length": len(value)},
            )
        return PassResult()

    async def mutate(
        self,
        value: str | None = None,
        parts: list[Part] | None = None,
        metadata: dict[str, Any] | None = None,
        result: FailResult | None = None,
    ) -> MutateResult:
        normalized = value.capitalize() if value else None
        return MutateResult(
            value=normalized,
            metadata={"action": "normalized_to_sentence_case"},
        )


# --- Usage ---

guard = MutationGuard("text-normalizer").use(UppercaseNormalizer())

# result = await guard.validate(value="HELLO WORLD THIS IS ALL CAPS")
# result.was_mutated == True
# result.output_value == "Hello world this is all caps"


# --- Advanced: validator with LLM support ---

# from aegis.llm import LLMModelConfig
# from aegis.llm_client import OrchestrationLLMClient
#
# class ToneValidator(BaseMutationValidator):
#     DEFAULT_MODEL = LLMModelConfig(
#         name="anthropic--claude-3-haiku",
#         parameters={"max_completion_tokens": 500},
#     )
#
#     def __init__(self, *, use_llm: bool = True,
#                  model: LLMModelConfig | None = None):
#         if use_llm:
#             effective = model or self.DEFAULT_MODEL
#             self._client = OrchestrationLLMClient(
#                 model_name=effective.name,
#                 model_parameters=effective.parameters,
#             )
#         else:
#             self._client = None
#
#     async def validate(self, value=None, parts=None, metadata=None):
#         if not value:
#             return PassResult()
#         if self._client:
#             try:
#                 result = await self._client.complete(
#                     messages=[
#                         {"role": "system", "content": "Is this text professional?"},
#                         {"role": "user", "content": value},
#                     ],
#                     schema={
#                         "type": "object",
#                         "properties": {
#                             "professional": {"type": "boolean"},
#                             "issues": {"type": "array", "items": {"type": "string"}},
#                         },
#                         "required": ["professional", "issues"],
#                     },
#                 )
#                 if not result.get("professional"):
#                     return FailResult(
#                         error_message="Unprofessional tone detected",
#                         error_code="TONE_VIOLATION",
#                         metadata={"issues": result.get("issues", [])},
#                     )
#             except Exception:
#                 pass  # fail-open on LLM error
#         return PassResult()
#
#     async def mutate(self, value=None, metadata=None,
#                      parts=None, result=None):
#         if not self._client or not value:
#             return MutateResult(value=value)
#         try:
#             rewritten = await self._client.complete(
#                 messages=[
#                     {"role": "system", "content": "Rewrite to be professional."},
#                     {"role": "user", "content": value},
#                 ],
#             )
#             return MutateResult(value=rewritten)
#         except Exception:
#             return MutateResult(value=value)


# --- Working with parts (structured data) ---

class RedactPhoneFromParts(BaseMutationValidator):
    """Example of working with A2A Part objects."""

    PHONE_PATTERN = re.compile(r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b")

    async def validate(self, value=None, parts=None, metadata=None):
        text = value or ""
        if parts:
            from a2a.types import TextPart
            text = " ".join(
                p.root.text for p in parts if isinstance(p.root, TextPart)
            )
        if self.PHONE_PATTERN.search(text):
            return FailResult(error_message="Phone number detected", error_code="PHONE_DETECTED")
        return PassResult()

    async def mutate(self, value=None, parts=None, metadata=None, result=None):
        redacted_value = self.PHONE_PATTERN.sub("[PHONE_REDACTED]", value) if value else None
        return MutateResult(value=redacted_value)


# --- Testing ---

# import pytest
#
# @pytest.mark.asyncio
# async def test_uppercase_normalizer():
#     guard = MutationGuard("test").use(UppercaseNormalizer())
#     result = await guard.validate(value="THIS IS ALL CAPS")
#     assert result.was_mutated
#     assert result.output_value == "This is all caps"
#
# @pytest.mark.asyncio
# async def test_uppercase_normalizer_passes_normal():
#     guard = MutationGuard("test").use(UppercaseNormalizer())
#     result = await guard.validate(value="Normal text here")
#     assert not result.was_mutated
