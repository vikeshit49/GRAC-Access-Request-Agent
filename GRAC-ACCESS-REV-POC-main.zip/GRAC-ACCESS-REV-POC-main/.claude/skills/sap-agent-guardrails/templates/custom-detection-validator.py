"""Custom detection validator template.

Subclass BaseValidator to create a detection-only validator for use with Guard.
Implement validate() to return PassResult or FailResult.
"""

from typing import Any

from a2a.types import Part

from aegis import BaseValidator, FailResult, Guard, OnFailAction, PassResult


class DomainBlocklistValidator(BaseValidator):
    """Blocks messages containing URLs from prohibited domains."""

    def __init__(self, blocked_domains: list[str]):
        self._blocked = {d.lower() for d in blocked_domains}

    async def validate(
        self,
        value: str | None = None,
        parts: list[Part] | None = None,
        metadata: dict[str, Any] | None = None,
    ):
        if not value:
            return PassResult()

        found = [d for d in self._blocked if d in value.lower()]
        if found:
            return FailResult(
                error_message=f"Blocked domains found: {found}",
                error_code="BLOCKED_DOMAIN",
                metadata={"domains": found},
            )
        return PassResult()


# --- Usage ---

guard = Guard("url-check").use(
    DomainBlocklistValidator(blocked_domains=["malware.example.com", "phishing.test"]),
    on_fail=OnFailAction.EXCEPTION,
)

# result = await guard.validate(value="Visit https://malware.example.com/payload")
# result.has_failures == True
# result.failures[0].error_code == "BLOCKED_DOMAIN"


# --- Protocol-only alternative (no subclassing) ---

class MinimalValidator:
    """Satisfies the Validator protocol without BaseValidator."""

    @property
    def name(self) -> str:
        return "MinimalValidator"

    async def validate(self, value=None, metadata=None, parts=None):
        if value and len(value.split()) < 3:
            return FailResult(
                error_message="Message too short (min 3 words)",
                error_code="TOO_SHORT",
            )
        return PassResult()


# --- Testing ---

# import pytest
#
# @pytest.mark.asyncio
# async def test_domain_blocklist_blocks():
#     guard = Guard("test").use(DomainBlocklistValidator(blocked_domains=["evil.com"]))
#     result = await guard.validate(value="Go to evil.com")
#     assert result.has_failures
#     assert result.failures[0].error_code == "BLOCKED_DOMAIN"
#     assert "evil.com" in result.failures[0].metadata["domains"]
#
# @pytest.mark.asyncio
# async def test_domain_blocklist_passes_clean():
#     guard = Guard("test").use(DomainBlocklistValidator(blocked_domains=["evil.com"]))
#     result = await guard.validate(value="Visit safe-site.org")
#     assert not result.has_failures
