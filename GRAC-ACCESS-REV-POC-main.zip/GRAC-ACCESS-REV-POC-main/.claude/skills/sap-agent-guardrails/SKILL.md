---
name: sap-agent-guardrails
description: Use when users want to add a broad class of guardrails or safety checks to their agents — protecting against unsafe, off-scope, or non-compliant inputs and outputs, or enforcing custom domain policies, built on the Aegis SDK.
---

# Aegis Agent Guardrails

Aegis is a guardrail library for A2A agents. It provides `Guard` (concurrent detection — pass/fail) and `MutationGuard` (sequential detect-and-fix pipeline), plus A2A wrappers that integrate both into an `AgentExecutor` lifecycle.

## Decision Workflow

Follow these steps when helping a user add guardrails:

### Step 1 — Verify installation

Check `requirements.txt` (pip) or `pyproject.toml` (uv) for `sap-aegis`. If found, go to Step 2.

If not found, install it from the SAP Artifactory registry. Refer to [references/install-patterns.md](./references/install-patterns.md) for installation description.

**Ask the user first:**

1. Does this repo use `pip` or `uv`?
2. If the repo uses `docker compose`, should the compose file also be wired with environment variables and build args?

Update Docker build files accordingly.

**Remind the user of these prerequisites:**

Always remind the user of these prerequisites before or alongside the code changes:

- Generate an Artifactory API token in `common.repositories.cloud.sap`.
- Put `ARTIFACTORY_USER` and `ARTIFACTORY_TOKEN` in the local `.env` or the repo's secret manager.
- Never commit literal credentials into `requirements.txt`, `pyproject.toml`, `Dockerfile`, or source code.
- If they plan to use LLM-backed validators, also put these in `.env`: `AICORE_AUTH_URL`, `AICORE_CLIENT_ID`, `AICORE_CLIENT_SECRET`, `AICORE_RESOURCE_GROUP`, `AICORE_BASE_URL`.

Treat the AI Core reminder as required whenever the user mentions LLM validators or when you add validators that instantiate `OrchestrationLLMClient`.

**Apply the matching pattern from [references/install-patterns.md](./references/install-patterns.md).** Hard rules — non-negotiable:

- Package: `sap-aegis`. Index URL: `https://common.repositories.cloud.sap/artifactory/api/pypi/a2a-guardrail/simple`.
- `pip`: must use `--extra-index-url` (do not replace the public index).
- `uv`: the index name must remain `a2a-guardrail` so credential env vars stay `UV_INDEX_A2A_GUARDRAIL_USERNAME` / `UV_INDEX_A2A_GUARDRAIL_PASSWORD`.
- Always update Docker build files alongside the dependency change.
- `docker compose`: always use `${VAR}` substitution and `build.args` passthrough; never embed literal values.
- After editing, restate any manual follow-up the user still needs to do (`.env` setup, `uv lock` / `uv sync --frozen`, how `pip` will pick up Artifactory credentials at install time).

Do not proceed to Step 2 until `sap-aegis` is confirmed present.

### Step 2 — Present all validators and prompt user to choose

**IMPORTANT: Always start by printing the full validator table to the user, then asking them to select.**

First, output the following table to the user so they can see all available options:

```
Aegis Built-in Validators:

Detection Validators (for Guard — concurrent pass/fail):
| #  | Validator                      | Description                                              | LLM? |
|----|--------------------------------|----------------------------------------------------------|------|
| 1  | LengthValidator                | Enforces min/max text character length                   | No   |
| 2  | SizeValidator                  | Enforces max byte size (prevents memory abuse)           | No   |
| 3  | PromptLeakageCheck             | Prevents system prompt from leaking into output          | No   |
| 4  | ScopeCheck                     | Blocks requests outside the agent's declared skills      | Opt  |
| 5  | ComplianceCheck                | Blocks prohibited topics and patterns (legal/org rules)  | Opt  |
| 6  | OutputFormatCheck              | Validates output against JSON schema or LLM criteria     | Opt  |

Mutation Validators (for MutationGuard — sequential detect-and-fix):
| #  | Validator                      | Description                                              | LLM? |
|----|--------------------------------|----------------------------------------------------------|------|
| 7  | InputSanitizer                 | Strips XSS, SQL injection, XXE, formula injection        | No   |
| 8  | TerminologyDetectionMutation   | Replaces forbidden terms with preferred alternatives     | No   |
| 9  | UAStyleDetectionMutation       | Rewrites text to comply with UA style guidelines         | Yes  |

Need something else? Build a custom validator:
- PII detection/redaction, content filtering, XML validation, HTML sanitization, etc.
  → Use the custom validator templates (Step 5)
```

Then ask the user **three questions** (use multi-select for question 1):

**Question 1** (multi-select): "Which built-in validators would you like to include? Select from the table above."
- Present all 9 validators as options.

**Question 2**: "Do you need additional functionality not covered by the built-in validators (e.g., PII detection/redaction, content keyword filtering, XML validation, HTML sanitization)? If so, we'll build a custom validator."
- Options: Yes / No

**Question 3**: "Would you like LengthValidator + SizeValidator included as baseline protection? These are recommended for ALL agents."
- Options: Yes (recommended) / No

### Step 3 — Determine which part of the agent should the validator be implemented on

Ask: Which part of the agent should the validator be implemented on?
- **input** (agent input)
- **output** (agent responses)
- **both input/output**
- **specific agent component**?

**Read `references/validators.md`** to look up the exact parameters, error codes, and metadata shapes for each validator the user selected in Step 2. Use these details when configuring validators in the implementation.

### Step 4 — Choose integration approach

Ask the user which approach suits their project:

**Option A — `@guarded` decorator** (recommended for A2A agents):
Wraps the entire `AgentExecutor` class. Input guards run before `execute()`, output guards intercept artifact events.
→ Read `references/a2a-wrapper.md` and adapt it into the user's executor file.

**Option B — `GuardedAgentExecutor`** (composition):
Wraps an existing executor instance. Same behavior as `@guarded` but without class decoration.
→ Read `references/a2a-wrapper.md` for the `GuardedAgentExecutor` pattern and adapt it.

**Option C — Inside `agent.stream()`** (graph-level):
Place guards inside the agent's `stream()` method, before graph invocation. Guards check input before the graph runs; output guards run on the graph response before yielding. Rejection yields a completed response item directly.
→ Read `references/a2a-wrapper.md` for the stream-level integration pattern.

**Option D — Manual `Guard`/`MutationGuard`** (standalone or specific agent component):
Call `guard.validate()` directly in your code. Use when not working with A2A `AgentExecutor`.
→ Read `references/standalone.md` and integrate into the user's code.

**IMPORTANT:** Always read the relevant template file(s) listed above and use the code as the basis for the implementation. Adapt imports, variable names, and validator configuration to match the user's project.

### Step 5 — Custom validators (if needed)

If built-in validators don't cover the requirement, build a custom validator. Common use cases that require custom validators:

- **PII detection/redaction** — detect and/or redact email, phone, SSN, or other patterns
- **Content keyword filtering** — block messages containing specific keywords
- **XML validation** — validate XML structure (XXE-safe)
- **HTML sanitization** — strip dangerous HTML tags/attributes
- **Domain-specific checks** — any business logic not covered by built-in validators

Ask the user what their custom validator should do, then determine the guard type:

| Need | Use |
|------|-----|
| Block/reject bad content (no transformation) | `Guard` (detection only) |
| Clean/transform content (redact, sanitize, fix) | `MutationGuard` (detect + fix) |
| Both block AND clean | Use both: `Guard` for hard blocks, `MutationGuard` for sanitization |

Based on the guard type, read the corresponding template and adapt it:

- **Guard (Detection only)**: Read `templates/custom-detection-validator.py`. Subclass `BaseValidator`, implement `async def validate()` returning `PassResult` or `FailResult`. Use the `DomainBlocklistValidator` example as a starting point and rename/rework the class for the user's specific detection logic.
- **MutationGuard (detect + fix)**: Read `templates/custom-mutation-validator.py`. Subclass `BaseMutationValidator`, implement `validate()` + `mutate()`. Use the `UppercaseNormalizer` example as a starting point.
- **LLM-powered**: Read `references/llm-config.md` for the `OrchestrationLLMClient` pattern. Add `use_llm` and `model` params, always provide a keyword fallback for when LLM is unavailable.

### Step 6 — Testing

After implementing guardrails, run the agent end-to-end and exercise each guard with an A2A query. Recommend the run mode that matches the user's project.

#### Pick a run mode

Ask the user which they prefer:

- **`docker compose`** — when the repo has `compose.yaml` / `docker-compose.yaml` and the user's normal workflow is containerized.
- **`docker` (Dockerfile only)** — when the repo has a `Dockerfile` but no compose file. Build and run the container manually.
- **`uvicorn` / direct Python** — for fast iteration without rebuilding an image, or when the repo doesn't ship a Dockerfile at all. Best for iterating on a single validator.

#### Option A — Docker compose

```bash
docker compose up --build
docker compose logs -f   # watch guard execution and validation failures
```

The container may take 3–5 minutes to come up the first time.

#### Option B — Dockerfile only (no compose)

When the repo has a `Dockerfile` but no compose file, build and run the image directly. Pass Artifactory credentials as build args and runtime env vars from `.env` (do not bake them into the image):

```bash
# Build
docker build \
  --build-arg ARTIFACTORY_USER="$ARTIFACTORY_USER" \
  --build-arg ARTIFACTORY_TOKEN="$ARTIFACTORY_TOKEN" \
  -t my-agent .

# Run, forwarding .env (AI Core creds at runtime if LLM validators are enabled)
docker run --rm -p 5000:5000 --env-file .env my-agent

# Tail logs in another terminal
docker logs -f <container-id>
```

#### Option C — Run locally with uvicorn

If the agent exposes an ASGI app (typical A2A pattern), run it directly. Adjust the module path to match the repo:

```bash
# From repo root, with .env loaded
uv run uvicorn app.main:app --host 0.0.0.0 --port 5000 --reload
# or, for pip-managed projects:
uvicorn app.main:app --host 0.0.0.0 --port 5000 --reload
```

Make sure `.env` is sourced first (e.g. `set -a; source .env; set +a`) so `ARTIFACTORY_*` and any `AICORE_*` variables are visible to the process. `--reload` lets validator edits take effect without restarting.

#### Test cases to cover

Whichever mode is chosen, exercise each guard you added. For each validator, generate a few test cases that should pass/fail the validator if it's a guard. For mutation guard, test cases should check before and after the mutation guard.

Watch the relevant log stream for each mode: `docker compose logs -f` for compose, `docker logs -f <id>` for plain Docker, the terminal for uvicorn. Aegis logs each validator's pass/fail decision through the agent's logger.

#### Sending A2A requests

Use the project's normal A2A test helper if it has one. Otherwise, a minimal `curl` against the running server works:

```bash
curl -X POST http://localhost:5000/a2a/messages \
  -H "Content-Type: application/json" \
  -d '{"role":"user","parts":[{"kind":"text","text":"<your test query>"}]}'
```

Adjust the path/payload to match the agent's actual A2A endpoint.

#### Important note on testing

Let the user know that this testing is only for checking guardrail functionalities on top their agent. For more comprehensive evaluation, ask user to checkout AEVAL skills.


## Core Imports

```python
# Primitives (package: sap-aegis, imported as aegis)
from aegis import Guard, MutationGuard, OnFailAction, ValidationError
from aegis import BaseValidator, BaseMutationValidator
from aegis import PassResult, FailResult, MutateResult, GuardResult, MutationGuardResult
from aegis.llm import LLMModelConfig
from aegis.llm_client import OrchestrationLLMClient

# Built-in detection validators
from aegis.validators import (
    LengthValidator, SizeValidator, PromptLeakageCheck,
    ScopeCheck, ComplianceCheck, OutputFormatCheck,
)

# Built-in mutation validators
from aegis.validators import InputSanitizer
from aegis.validators.mutation import TerminologyDetectionMutation, UAStyleDetectionMutation

# A2A wrappers
from aegis.a2a import guarded, GuardedAgentExecutor, GuardedContext, InputGuardConfig, OutputGuardConfig
```

## Quick Patterns

### Detection guard (block bad input)

```python
guard = (
    Guard("input-guard")
    .use(ScopeCheck(agent_card=card), on_fail=OnFailAction.NOOP)
    .use(ComplianceCheck(prohibited_topics=["insider trading"]), on_fail=OnFailAction.NOOP)
    .use(LengthValidator(max_length=10_000), on_fail=OnFailAction.EXCEPTION)
)
result = await guard.validate(value=user_message)
if result.has_failures:
    for f in result.failures:
        print(f"{f.error_code}: {f.error_message}")
```

### Mutation guard (sanitize input)

```python
mutation_guard = (
    MutationGuard("input-sanitizer")
    .use(InputSanitizer())
    .use(TerminologyDetectionMutation(terms={"blacklist": "blocklist"}))
)
result = await mutation_guard.validate(value=user_message)
clean_input = result.output_value if result.was_mutated else user_message
```

### A2A wrapper (full agent protection)

```python
@guarded(
    input_config=InputGuardConfig(
        guard=Guard("input").use(ScopeCheck(agent_card=card), on_fail=OnFailAction.NOOP),
        mutation_guard=MutationGuard("sanitize").use(InputSanitizer()),
        on_fail="I'm unable to help with that request.",
    ),
    output_config=OutputGuardConfig(
        guard=Guard("output").use(
            PromptLeakageCheck(sensitive_fragments=[SYSTEM_PROMPT]),
            on_fail=OnFailAction.NOOP,
        ),
        on_fail="I cannot share that information.",
    ),
)
class MyAgentExecutor(AgentExecutor):
    async def execute(self, context, event_queue):
        user_input = context.get_user_input()  # mutated input if mutation was applied
        ...
```

## Key Concepts

- **Guard**: runs all validators concurrently via `asyncio.gather()`. Returns `GuardResult`. Use `on_fail` per validator: `OnFailAction.LOG` (default), `OnFailAction.EXCEPTION`, `OnFailAction.NOOP`, or a custom callable.
- **MutationGuard**: runs validators sequentially (pipeline). Each validator's `mutate()` output feeds the next. Returns `MutationGuardResult` with `output_value`/`output_parts`.
- **MutationValidators work in Guard too**: registering a mutation validator in a `Guard` only calls `validate()` (detection-only mode). Same class, different behavior based on context.
- **Pipeline order in wrappers**: default is Guard first, then MutationGuard. Set `mutation_first=True` in config to sanitize before detecting.
- **`on_fail` in wrappers**: Default is `None` (same as `True` = fail-closed). Input `on_fail=True` rejects with error messages, `on_fail="message"` rejects with custom text, `on_fail=False` allows through. Output `on_fail=True` suppresses artifact, `on_fail="text"` replaces content. Callables receive `(failures, context, event_queue)` for input or `(failures)` for output.
- **Default to generic `on_fail` messages**: Use `on_fail=True` (generic validator error messages) by default. Only use a specific custom string like `on_fail="I'm unable to help with that."` if the user explicitly requests a custom rejection message.
