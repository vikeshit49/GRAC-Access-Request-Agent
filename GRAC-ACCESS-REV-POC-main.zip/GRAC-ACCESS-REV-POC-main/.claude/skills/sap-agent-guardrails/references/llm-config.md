# LLM Configuration

Some Aegis validators optionally use an LLM (via SAP AI Core Orchestration Service). All LLM-enabled validators have a credential-free fallback mode (keyword/rule-based) except `UAStyleDetectionMutation` which requires LLM.

## Validators That Use LLM

| Validator | LLM Toggle | Default |
|-----------|-----------|---------|
| `ScopeCheck` | `use_llm=True/False` | `True` (falls back to keywords if LLM fails) |
| `ComplianceCheck` | `use_llm_for_nuanced_checks=True/False` | `False` |
| `OutputFormatCheck` | `acceptance_criteria=[...]` triggers LLM | Only when criteria provided |
| `UAStyleDetectionMutation` | Always uses LLM | N/A (no fallback) |

---

## Environment Variables

Set these to enable LLM features via SAP AI Core:

```bash
export AICORE_AUTH_URL="https://your-tenant.authentication.sap.hana.ondemand.com/oauth/token"
export AICORE_CLIENT_ID="your-client-id"
export AICORE_CLIENT_SECRET="your-client-secret"
export AICORE_RESOURCE_GROUP="default"
export AICORE_BASE_URL="https://api.ai.prod.us-east-1.aws.ml.hana.ondemand.com"
```

These are typically sourced from a BTP service binding. In local dev, set them in `.env` or shell profile.

---

## Keyword-Only Mode (No Credentials Needed)

All validators (except `UAStyleDetectionMutation`) work without LLM credentials:

```python
# Keyword-only scope checking
ScopeCheck(agent_card=card, use_llm=False)

# Pattern-only compliance checking
ComplianceCheck(prohibited_topics=[...], use_llm_for_nuanced_checks=False)

# Schema-only output format checking (no acceptance_criteria)
OutputFormatCheck(json_schema=schema)
```

---

## Model Configuration Per Validator

Each LLM-enabled validator accepts a `model_name` parameter to override the default model:

```python
# ScopeCheck — default: "anthropic--claude-3-haiku"
ScopeCheck(agent_card=card, model_name="anthropic--claude-3.5-sonnet")

# ComplianceCheck — default: "anthropic--claude-3-haiku"
ComplianceCheck(
    prohibited_topics=[...],
    model_name="anthropic--claude-3.5-sonnet",
    use_llm_for_nuanced_checks=True,
)

# OutputFormatCheck — default: "anthropic--claude-3-haiku"
OutputFormatCheck(
    acceptance_criteria=[...],
    model_name="anthropic--claude-3.5-sonnet",
)

# UAStyleDetectionMutation — default: "gpt-4o-mini"
UAStyleDetectionMutation(model_name="anthropic--claude-3.5-sonnet")
```

Available model names follow the SAP AI Core naming convention: `provider--model-name` (e.g., `anthropic--claude-3-haiku`, `anthropic--claude-3.5-sonnet`, `azure--gpt-4o`, `gpt-4o-mini`).

---

## LLMModelConfig (For Custom Validators)

When writing custom validators that need LLM, use `LLMModelConfig` with the `OrchestrationLLMClient`:

```python
from aegis.llm import LLMModelConfig
from aegis.llm_client import OrchestrationLLMClient

class MyLLMValidator(BaseValidator):
    DEFAULT_MODEL = LLMModelConfig(
        name="anthropic--claude-3-haiku",
        parameters={"max_completion_tokens": 200},
    )

    def __init__(self, *, use_llm: bool = True, model: LLMModelConfig | None = None):
        if use_llm:
            effective = model or self.DEFAULT_MODEL
            self._client = OrchestrationLLMClient(
                model_name=effective.name,
                model_parameters=effective.parameters,
            )
        else:
            self._client = None
```

### Client API

```python
# Plain text completion
response: str = await self._client.complete(
    messages=[
        {"role": "system", "content": "You are a classifier."},
        {"role": "user", "content": text_to_evaluate},
    ],
    temperature=0.1,
)

# Structured JSON output
response: dict = await self._client.complete(
    messages=[...],
    schema={
        "type": "object",
        "properties": {"decision": {"type": "boolean"}, "reason": {"type": "string"}},
        "required": ["decision", "reason"],
        "additionalProperties": False,
    },
    temperature=0.1,
)
```

### Error Handling Pattern

Always wrap LLM calls with a fallback:

```python
async def validate(self, value=None, parts=None, metadata=None):
    if self._client:
        try:
            return await self._llm_validate(value)
        except Exception as e:
            logger.warning(f"LLM call failed, falling back to keywords: {e}")
            return await self._keyword_validate(value)
    return await self._keyword_validate(value)
```

This ensures the validator never hard-fails due to transient LLM issues. Adjust based on risk tolerance:
- **Fail-open** (above): pass through on LLM error. Use for non-critical checks.
- **Fail-closed**: return `FailResult` on LLM error. Use for security-critical checks.

---

## Error Scenarios

| Scenario | Behavior |
|----------|----------|
| Credentials unresolved + `use_llm=True` | `ValueError` at validator construction |
| Transient LLM failure | Falls back to keyword/rule-based mode |
| Azure content filter triggered (400) | `ContentFilterError` — fail-closed (returns FailResult) |
| Invalid JSON in structured output | `ValueError` |

---

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| `ValueError` at validator construction | Missing/invalid env vars | Check `AICORE_*` variables are set |
| `ContentFilterError` during validation | AI Core content filter triggered | Input/output hit platform safety filter — handle gracefully |
| LLM validator silently using keyword mode | `use_llm=True` but transient failure | Check logs for LLM fallback warnings |
| Slow validator execution | LLM latency | Use `use_llm=False` for latency-sensitive paths, or switch to a faster model |
