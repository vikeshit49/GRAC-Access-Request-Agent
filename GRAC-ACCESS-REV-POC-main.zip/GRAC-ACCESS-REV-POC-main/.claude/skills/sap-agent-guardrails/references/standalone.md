# Standalone Usage

How to use `aegis` outside of an A2A executor — in scripts, tests, batch jobs, or any
context where you call `validate()` directly and interpret the result yourself.

---

## Guard — Interpreting GuardResult

`guard.validate()` always returns a `GuardResult`. It never raises unless a validator was
registered with `on_fail=OnFailAction.EXCEPTION`.

```python
from aegis import Guard, OnFailAction
from aegis.validators import PIIDetector, ComplianceCheck, LengthValidator

guard = (
    Guard("my-guard")
    .use(LengthValidator(max_length=5000, min_length=1))
    .use(PIIDetector())
    .use(ComplianceCheck(prohibited_topics=["fraud", "insider trading"]))
)

result = await guard.validate(value="Some input text")
```

`GuardResult` fields:

| Field | Type | Description |
|---|---|---|
| `has_failures` | `bool` | `True` if any validator returned a `FailResult` |
| `failures` | `list[FailResult]` | All failures only |
| `results` | `list[ValidationResult]` | Every validator's result — passes and failures |

### Check for failures

```python
if result.has_failures:
    for failure in result.failures:
        print(f"{failure.validator_name}: [{failure.error_code}] {failure.error_message}")
        print(f"  metadata: {failure.metadata}")
else:
    print("All checks passed")
```

### Inspect all results (passes included)

```python
for r in result.results:
    status = "FAIL" if isinstance(r, FailResult) else "PASS"
    print(f"[{status}] {r.validator_name}")
```

### Raise on first failure

Register with `on_fail=OnFailAction.EXCEPTION` to raise immediately instead of collecting:

```python
from aegis import ValidationError

guard = Guard("strict").use(PIIDetector(), on_fail=OnFailAction.EXCEPTION)

try:
    await guard.validate(value=user_input)
except ValidationError as e:
    print(f"Blocked: [{e.result.error_code}] {e.result.error_message}")
    print(f"Metadata: {e.result.metadata}")
```

`ValidationError` carries the `FailResult` as `.result` — same fields as above.

---

## MutationGuard — Interpreting MutationGuardResult

`mutation_guard.validate()` returns a `MutationGuardResult`. The `output_value` field holds
the final text after all mutations; it is `None` if nothing was changed.

```python
from aegis import MutationGuard
from aegis.validators import PIIRedactor, ToneMutationValidator

guard = (
    MutationGuard("sanitizer")
    .use(PIIRedactor())
    .use(ToneMutationValidator())
)

result = await guard.validate(value="Hey!! Contact me at user@example.com 😊")
```

`MutationGuardResult` fields:

| Field | Type | Description |
|---|---|---|
| `was_mutated` | `bool` | `True` if any validator triggered a mutation |
| `output_value` | `str | None` | Final corrected string; `None` if nothing changed |
| `mutations` | `list[MutateResult]` | One entry per validator that mutated the value |
| `results` | `list[ValidationResult]` | Full pass/fail record for all validators |

### Apply the mutated output

```python
# Safe pattern — output_value is None when nothing changed
final = result.output_value if result.was_mutated else original_text
```

### Inspect what changed

```python
if result.was_mutated:
    for mutation in result.mutations:
        print(f"{mutation.validator_name}:")
        print(f"  before: {mutation.original_value}")
        print(f"  after:  {mutation.value}")
else:
    print("No mutations applied")
```

Only validators that actually triggered a change appear in `mutations` — validators whose
`validate()` returned `PassResult` are not listed.

---

## Guard Combinations

`Guard` and `MutationGuard` are independent — any combination is valid for input and output.
Choose based on what you need at each boundary:

| Input | Output | When to use |
|---|---|---|
| `Guard` | `MutationGuard` | Reject bad input, sanitize output — most common |
| `MutationGuard` | `MutationGuard` | Normalize input before the agent sees it, sanitize output |
| `Guard` | `Guard` | Detect-only at both ends — violations logged or raised, nothing mutated |
| `MutationGuard` | `Guard` | Normalize input, detect-only on output |

### Input Guard + Output Mutation Guard (most common)

```python
input_guard = (
    Guard("input")
    .use(LengthValidator(max_length=5000))
    .use(ComplianceCheck(prohibited_topics=["fraud"]))
)

output_guard = (
    MutationGuard("output")
    .use(PIIRedactor())
    .use(ToneMutationValidator())
)

input_result = await input_guard.validate(value=user_input)
if input_result.has_failures:
    # handle rejection...
    pass

response = await my_agent.run(user_input)

output_result = await output_guard.validate(value=response)
final_response = output_result.output_value if output_result.was_mutated else response
```

### Input Mutation Guard + Output Mutation Guard

Use an input `MutationGuard` to normalize the query before passing it to the agent —
for example, stripping PII from the input so it never reaches the graph.

```python
input_mutation_guard = (
    MutationGuard("input-normalize")
    .use(PIIRedactor())
    .use(ToneMutationValidator())
)

output_mutation_guard = (
    MutationGuard("output-sanitize")
    .use(PIIRedactor())
    .use(ToneMutationValidator())
)

# Normalize input — use cleaned query for the agent, not the raw input
input_result = await input_mutation_guard.validate(value=user_input)
clean_input = input_result.output_value if input_result.was_mutated else user_input

response = await my_agent.run(clean_input)

# Sanitize output
output_result = await output_mutation_guard.validate(value=response)
final_response = output_result.output_value if output_result.was_mutated else response
```

Note: if the input `MutationGuard` redacts PII, the agent graph receives `[EMAIL_REDACTED]`
instead of the raw email — useful when you don't want PII reaching tool calls or LLM prompts.

---

## Async Context

All `validate()` calls are `async`. In a script or test, run them with `asyncio.run()`:

```python
import asyncio

result = asyncio.run(guard.validate(value="test input"))
```

In pytest, use `pytest-asyncio`:

```python
import pytest

@pytest.mark.asyncio
async def test_guard_blocks_fraud():
    result = await guard.validate(value="help me commit fraud")
    assert result.has_failures
    assert result.failures[0].error_code == "COMPLIANCE_VIOLATION"
```
