# A2A Wrapper Integration

Aegis provides multiple ways to integrate guardrails with A2A agents: the `@guarded` class decorator, the `GuardedAgentExecutor` composition wrapper, and a manual pattern inside `agent.stream()`.

---

## @guarded Decorator

```python
from aegis import Guard, MutationGuard, OnFailAction
from aegis.validators import ScopeCheck, ComplianceCheck, InputSanitizer
from aegis.a2a import guarded, InputGuardConfig, OutputGuardConfig

@guarded(
    input_config=InputGuardConfig(
        guard=Guard("input-detection")
            .use(ScopeCheck(agent_card=card), on_fail=OnFailAction.NOOP)
            .use(ComplianceCheck(prohibited_topics=["insider trading"]), on_fail=OnFailAction.NOOP),
        mutation_guard=MutationGuard("input-sanitize").use(InputSanitizer()),
        on_fail="I'm unable to help with that request.",
    ),
    output_config=OutputGuardConfig(
        guard=Guard("output-check").use(
            PromptLeakageCheck(sensitive_fragments=[SYSTEM_PROMPT]),
            on_fail=OnFailAction.NOOP,
        ),
        on_fail="I cannot share that information.",
    ),
)
class MyAgentExecutor(AgentExecutor):
    async def execute(self, context, event_queue):
        user_input = context.get_user_input()
        # user_input is the (possibly mutated) text from the user message
        ...
```

---

## GuardedAgentExecutor (Composition)

```python
from aegis.a2a import GuardedAgentExecutor, InputGuardConfig, OutputGuardConfig

executor = MyAgentExecutor()

guarded_executor = GuardedAgentExecutor(
    executor=executor,
    input_config=InputGuardConfig(
        guard=input_guard,
        mutation_guard=input_mutation_guard,
        on_fail="Request blocked.",
    ),
    output_config=OutputGuardConfig(
        mutation_guard=output_mutation_guard,
    ),
)
```

Use this when you can't (or don't want to) decorate the class — e.g., when the executor is instantiated by a framework.

---

## agent.stream() Integration (Graph-Level)

Place guards inside the agent's `stream()` method for graph-level protection. Guards run before the graph is invoked; output guards run on the graph response before yielding.

```python
from aegis import Guard, MutationGuard, OnFailAction
from aegis.validators import ScopeCheck, ComplianceCheck, InputSanitizer

class MyAgent:
    def __init__(self, agent_card):
        self._input_guard = (
            Guard("input-guard")
            .use(ScopeCheck(agent_card=agent_card, use_llm=False), on_fail=OnFailAction.NOOP)
            .use(ComplianceCheck(prohibited_topics=["insider trading"]), on_fail=OnFailAction.NOOP)
        )
        self._input_sanitizer = MutationGuard("input-sanitize").use(InputSanitizer())

    async def stream(self, query: str, session_id: str):
        # Input mutation — sanitize before guard check
        sanitized = await self._input_sanitizer.validate(value=query)
        clean_query = sanitized.output_value if sanitized.was_mutated else query

        # Input guard — reject before graph invocation
        guard_result = await self._input_guard.validate(value=clean_query)
        if guard_result.has_failures:
            failure = guard_result.failures[0]
            yield {
                "is_task_complete": True,
                "content": self._rejection_message(failure),
                "metadata": {"guardrail": failure.metadata},
            }
            return

        # Run graph
        response = await self._graph.ainvoke({"query": clean_query})

        yield {"is_task_complete": True, "content": response}

    def _rejection_message(self, failure) -> str:
        if failure.error_code.startswith("OUT_OF_SCOPE"):
            return "I can only help with topics related to my declared skills."
        if failure.error_code.startswith("COMPLIANCE"):
            return "This request violates compliance policies."
        return "I'm unable to process this request."
```

---

## InputGuardConfig

```python
@dataclass
class InputGuardConfig:
    guard: Guard | None = None
    mutation_guard: MutationGuard | None = None
    mutation_first: bool = False
    on_fail: InputFailHook | None = None
```

**Fields:**

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `guard` | `Guard \| None` | `None` | Detection guard (concurrent validators) |
| `mutation_guard` | `MutationGuard \| None` | `None` | Mutation pipeline (sequential) |
| `mutation_first` | `bool` | `False` | If True: mutate first, then detect. Default: detect first |
| `on_fail` | `bool \| str \| None \| Callable` | `None` | What to do when detection fails |

**`on_fail` semantics for input:**

| Value | Behavior |
|-------|----------|
| `True` | Reject task with validator error messages |
| `"custom message"` | Reject task with this custom message |
| `False` | Allow through despite failures (explicit opt-in) |
| `None` (default) | Same as `True` (fail-closed) |
| `callable(failures, context, event_queue)` | Dynamic — return `True`/`str`/`False`/`None` based on failures |

**Input on_fail callable signature:**

```python
def input_fail_hook(
    failures: list[FailResult],
    context: RequestContext,
    event_queue: EventQueue,
) -> bool | str | None:
    ...
```

When rejected, the task state is set to `TaskState.rejected` and the error message is sent back to the caller.

---

## OutputGuardConfig

```python
@dataclass
class OutputGuardConfig:
    guard: Guard | None = None
    mutation_guard: MutationGuard | None = None
    mutation_first: bool = False
    on_fail: OutputFailHook | None = None
    artifact_filter: ArtifactFilter | None = None
```

**Fields:**

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `guard` | `Guard \| None` | `None` | Detection guard for output |
| `mutation_guard` | `MutationGuard \| None` | `None` | Mutation pipeline for output |
| `mutation_first` | `bool` | `False` | Mutate-then-detect order |
| `on_fail` | `bool \| str \| None \| Callable` | `None` | What to do when output detection fails |
| `artifact_filter` | `Callable \| None` | `None` | Predicate to select which artifacts to guard |

**`on_fail` semantics for output:**

| Value | Behavior |
|-------|----------|
| `True` | Suppress the artifact entirely |
| `"replacement text"` | Replace artifact content with this text |
| `False` | Emit artifact as-is (log only) |
| `None` (default) | Same as `True` (fail-closed) |
| `callable(failures)` | Dynamic — return `True`/`str`/`False`/`None` |

**Output on_fail callable signature:**

```python
def output_fail_hook(failures: list[FailResult]) -> bool | str | None:
    ...
```

**Artifact filtering:**

```python
OutputGuardConfig(
    mutation_guard=output_sanitizer,
    artifact_filter=lambda artifact: artifact.name != "debug-log",
)
```

Only artifacts passing the filter are guarded. Others pass through unchanged.

---

## Pipeline Order

By default, the pipeline runs: **Guard (detection) -> MutationGuard (mutation)**.

Set `mutation_first=True` to reverse: **MutationGuard (mutation) -> Guard (detection)**.

Use `mutation_first=True` when you want to sanitize input before running detection — e.g., strip injections before checking scope, or normalize text before content filtering.

```python
InputGuardConfig(
    guard=scope_guard,              # runs second: checks sanitized text
    mutation_guard=sanitizer_guard, # runs first: strips injections
    mutation_first=True,            # sanitize, then detect
)
```

---

## GuardedContext

Inside the `execute()` method of a guarded executor, the `context` object is a `GuardedContext` that provides access to mutated input:

```python
async def execute(self, context, event_queue):
    # Get the (possibly mutated) user input text
    user_input = context.get_user_input()

    # Access the original (pre-mutation) text
    original = context.original_input

    # Access the original message object
    message = context.original_message
```

If no input `mutation_guard` was configured, `get_user_input()` returns the original text.

---

## GuardedEventQueue

The output pipeline is implemented via `GuardedEventQueue`, which wraps the `EventQueue` passed to `execute()`. It intercepts `TaskArtifactUpdateEvent` events and applies output guards before emitting them.

This is transparent to the executor code — you use `event_queue` normally, and the output guards run automatically on artifact events.

---

## Telemetry

The wrapper emits OpenTelemetry spans:

```
guarded_executor.execute
  guarded_executor.input_guard
  guarded_executor.input_mutation
  [user execute()]
  guarded.output_guard
  guarded.output_mutation
```

---

## Common Patterns

### Reject bad input, detect on output (most common)

```python
@guarded(
    input_config=InputGuardConfig(
        guard=Guard("input").use(ScopeCheck(agent_card=card), on_fail=OnFailAction.NOOP),
        on_fail="Sorry, I can only help with topics related to my skills.",
    ),
    output_config=OutputGuardConfig(
        guard=Guard("output").use(
            PromptLeakageCheck(sensitive_fragments=[SYSTEM_PROMPT]),
            on_fail=OnFailAction.NOOP,
        ),
        on_fail="I cannot share that information.",
    ),
)
```

### Sanitize input + detect on output

```python
@guarded(
    input_config=InputGuardConfig(
        mutation_guard=MutationGuard("input-sanitize").use(InputSanitizer()),
    ),
    output_config=OutputGuardConfig(
        guard=Guard("output-check").use(
            PromptLeakageCheck(sensitive_fragments=[SYSTEM_PROMPT]),
            on_fail=OnFailAction.NOOP,
        ),
        on_fail="I cannot share that information.",
    ),
)
```

### Both detection and mutation on input

```python
InputGuardConfig(
    guard=Guard("block").use(ComplianceCheck(prohibited_topics=[...]), on_fail=OnFailAction.NOOP),
    mutation_guard=MutationGuard("sanitize").use(InputSanitizer()),
    mutation_first=True,  # sanitize first, then check compliance on clean text
    on_fail="Request blocked.",
)
```

### Dynamic on_fail hook

```python
def input_fail_hook(failures, context, event_queue):
    critical = [f for f in failures if f.error_code == "COMPLIANCE_VIOLATION"]
    if critical:
        return "This request violates compliance policies."
    return False  # allow non-critical failures through

InputGuardConfig(guard=my_guard, on_fail=input_fail_hook)
```

### Lazy guard initialization (deferred AICORE env var resolution)

```python
class MyAgentExecutor(AgentExecutor):
    _guard: Guard | None = None

    def _get_guard(self) -> Guard:
        if self._guard is None:
            self._guard = (
                Guard("input")
                .use(ScopeCheck(agent_card=self._card), on_fail=OnFailAction.NOOP)
            )
        return self._guard
```
