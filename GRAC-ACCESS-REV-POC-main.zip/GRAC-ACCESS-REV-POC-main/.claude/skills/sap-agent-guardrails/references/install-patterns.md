# install-aegis-artifactory reference snippets

Use these snippets as the default patterns when applying the skill.

## Prerequisites

Remind the user to do this before testing the installation:

```env
ARTIFACTORY_USER=<artifactory-user-id>
ARTIFACTORY_TOKEN=<artifactory-api-token>
```

If they need validators backed by SAP AI Core, also remind them to add:

```env
AICORE_AUTH_URL=https://your-tenant.authentication.sap.hana.ondemand.com/oauth/token
AICORE_CLIENT_ID=your-client-id
AICORE_CLIENT_SECRET=your-client-secret
AICORE_RESOURCE_GROUP=default
AICORE_BASE_URL=https://api.ai.prod.us-east-1.aws.ml.hana.ondemand.com
```

## Procedure

1. Inspect the target repo and identify the dependency management path:
   - `pip`: `requirements.txt`, `requirements-dev.txt`, `constraints.txt`, plain `pip install`, or pip-based Docker builds.
   - `uv`: `pyproject.toml`, `uv.lock`, `tool.uv.index`, `tool.uv.sources`, or `uv sync`.
   - `docker compose`: `compose.yaml`, `compose.yml`, `docker-compose.yaml`, `docker-compose.yml`, `docker compose`, or `docker-compose` workflows.
2. Ask the clarification questions above before editing.
3. Apply the matching installation pattern from [reference snippets](./references/install-patterns.md).
4. Keep credentials externalized:
   - For `pip`, prefer environment-variable expansion with `${ARTIFACTORY_USER}` and `${ARTIFACTORY_TOKEN}`.
   - For `uv`, use `UV_INDEX_A2A_GUARDRAIL_USERNAME` and `UV_INDEX_A2A_GUARDRAIL_PASSWORD`.
5. Only edit Docker or container build files if the user said yes.
6. If the repo uses `docker compose` and the user said yes, update the compose service so it passes the required environment variables and `build.args` into the Docker build.
7. Prefer compose-level variable forwarding from `.env` or the shell instead of hardcoding values in YAML.
8. After edits, restate any manual follow-up the user still needs to do, especially `.env` setup and any lockfile or sync command.

## Edit rules

- Package name: `sap-aegis`
- Artifactory simple index URL: `https://common.repositories.cloud.sap/artifactory/api/pypi/a2a-guardrail/simple`
- For `pip` repos, prefer `--extra-index-url` over replacing the default public index unless the repo already centralizes index configuration another way.
- For `uv` repos, keep the index name stable as `a2a-guardrail` so the credential env vars remain `UV_INDEX_A2A_GUARDRAIL_USERNAME` and `UV_INDEX_A2A_GUARDRAIL_PASSWORD`.
- For `docker compose`, prefer `${VAR}` substitution and `build.args` passthrough rather than embedding literal values in the compose file.
- Do not write real secrets into committed files.
- Do not modify unrelated dependency tooling.

## Validation

After editing, verify:

- The chosen dependency file still matches the repo's package manager.
- No committed file contains literal Artifactory or AI Core secrets.
- Docker changes exist only when requested.
- Compose changes exist only when requested, and they forward the expected variables into the target service build.
- If `uv` files changed, tell the user whether `uv lock` or `uv sync --frozen` is still needed.
- If `pip` files changed, tell the user how the Artifactory credentials are expected to be supplied at install time.

## pip: direct install

Use for a one-off local installation, not for committed dependency files.

```bash
pip install sap-aegis \
  --index-url "https://${ARTIFACTORY_USER}:${ARTIFACTORY_TOKEN}@common.repositories.cloud.sap/artifactory/api/pypi/a2a-guardrail/simple"
```

## pip: requirements.txt

Prefer an env-expanded extra index instead of committed secrets.

```txt
--extra-index-url https://${ARTIFACTORY_USER}:${ARTIFACTORY_TOKEN}@common.repositories.cloud.sap/artifactory/api/pypi/a2a-guardrail/simple
sap-aegis==0.2.1
```

Install with:

```bash
pip install -r requirements.txt
```

## pip: Dockerfile

Only apply when the user wants container changes.

```dockerfile
ARG ARTIFACTORY_USER
ARG ARTIFACTORY_TOKEN

RUN pip install \
    --no-cache \
    --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple" \
    --extra-index-url "https://${ARTIFACTORY_USER}:${ARTIFACTORY_TOKEN}@common.repositories.cloud.sap/artifactory/api/pypi/a2a-guardrail/simple" \
    -r requirements.txt
```

## pip: docker compose

If the repo builds with `docker compose`, wire `.env` or shell variables through compose and into the image build.

```yaml
services:
  agent:
    build:
      context: .
      args:
        ARTIFACTORY_USER: ${ARTIFACTORY_USER}
        ARTIFACTORY_TOKEN: ${ARTIFACTORY_TOKEN}
```

Do not forward Artifactory credentials into the running container unless the container will install packages again after startup. Standard agent runtime does not need them.

If the agent uses LLM-backed validators at runtime, forward AI Core credentials instead:

```yaml
services:
  agent:
    environment:
      AICORE_AUTH_URL: ${AICORE_AUTH_URL}
      AICORE_CLIENT_ID: ${AICORE_CLIENT_ID}
      AICORE_CLIENT_SECRET: ${AICORE_CLIENT_SECRET}
      AICORE_RESOURCE_GROUP: ${AICORE_RESOURCE_GROUP}
      AICORE_BASE_URL: ${AICORE_BASE_URL}
```

## uv: pyproject.toml

Use this when the repo already manages dependencies with `uv`.

```toml
[[tool.uv.index]]
name = "a2a-guardrail"
url = "https://common.repositories.cloud.sap/artifactory/api/pypi/a2a-guardrail/simple"
explicit = true

[tool.uv.sources]
sap-aegis = { index = "a2a-guardrail" }
```

Then add `sap-aegis==0.2.1` using the repo's existing dependency style and update the lockfile with either `uv lock` or a non-frozen `uv sync`:

```bash
uv lock
# or
uv sync
```

Use `uv sync --frozen` only after `uv.lock` already includes `sap-aegis`, for example in CI or other reproducible install flows where the lockfile must not change.

Local credentials for `uv`:

```bash
export UV_INDEX_A2A_GUARDRAIL_USERNAME="$ARTIFACTORY_USER"
export UV_INDEX_A2A_GUARDRAIL_PASSWORD="$ARTIFACTORY_TOKEN"
```

## uv: Dockerfile

Only apply when the user wants container changes.

```dockerfile
ARG ARTIFACTORY_USER
ARG ARTIFACTORY_TOKEN

RUN UV_INDEX_A2A_GUARDRAIL_USERNAME=${ARTIFACTORY_USER} \
    UV_INDEX_A2A_GUARDRAIL_PASSWORD=${ARTIFACTORY_TOKEN} \
    uv sync --frozen --no-dev
```

## uv: docker compose

When `docker compose` drives the build, forward the Artifactory credentials as build args. Standard agent runtime does not need Artifactory credentials. Runtime env vars are only needed if the container will run `uv sync` or other authenticated package operations after startup.

```yaml
services:
  agent:
    build:
      context: .
      args:
        ARTIFACTORY_USER: ${ARTIFACTORY_USER}
        ARTIFACTORY_TOKEN: ${ARTIFACTORY_TOKEN}
```

If the agent uses LLM-backed validators at runtime, forward AI Core credentials instead:

```yaml
services:
  agent:
    environment:
      AICORE_AUTH_URL: ${AICORE_AUTH_URL}
      AICORE_CLIENT_ID: ${AICORE_CLIENT_ID}
      AICORE_CLIENT_SECRET: ${AICORE_CLIENT_SECRET}
      AICORE_RESOURCE_GROUP: ${AICORE_RESOURCE_GROUP}
      AICORE_BASE_URL: ${AICORE_BASE_URL}
```

## LLM validator reminder

Mention the AI Core `.env` requirement when the user adds or enables validators such as:

- `ScopeCheck` with `use_llm=True`
- `ComplianceCheck` with `use_llm_for_nuanced_checks=True`
- `OutputFormatCheck` in LLM mode
- `UAStyleDetectionMutation`

These validators resolve `AICORE_*` credentials from the environment when they initialize the built-in orchestration client.