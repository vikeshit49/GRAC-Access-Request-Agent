# Joule Integration — Why the SPII Handler Is Minimal

This reference explains the design rationale: **why does the Joule SPII handler return `READY` immediately, with no configuration exchange and no destination fragments?**

## Two applicationNamespaces, one handler

UCL delivers Joule SPII notifications under two `applicationNamespace` values:

- `sap.joule`
- `sap.joulecore`

Both describe the same integration contract. The handler declares both via a
`Sequence[str]` return from `application_namespace`, and the Facade dispatches
either to `JouleHandler`. The two values exist for product / lifecycle reasons
on the Joule side; from the agent's perspective the assign/unassign flow,
the response, and the side effects (none) are identical.

## What Joule Needs from the Agent

Joule is SAP's conversational AI assistant. When a customer creates a UCL formation that pairs Joule with an A2A agent, Joule's job is to:

1. **Discover** the agent — learn that it exists, its capabilities, and how to invoke it.
2. **Recommend** the agent in conversations — surface it to users when their intent matches the agent's capabilities.
3. **Invoke** the agent — call it via its public A2A endpoint.

For steps 1 and 2, Joule reads agent metadata from elsewhere — typically:
- The agent's **ORD (Open Resource Discovery) endpoint** — exposed by the agent so UMS / Joule can discover it. See `sap-agent-ord-endpoint`.
- The agent's **A2A AgentCard** — the well-known descriptor at `/.well-known/agent-card.json`. Configured during bootstrap (Phase 3.4 of `sap-agent-bootstrap`).

For step 3, Joule calls the agent's A2A endpoint directly using credentials provisioned by other SAP infrastructure (IAS / SCI), not by SPII.

In other words: **Joule does not need the SPII protocol to give it any configuration.** SPII for Joule is purely a registration signal — "this agent has been assigned to a Joule-aware formation; you may now consider it active."

## Why No Destination Fragments Today

The Agent Gateway SPII handler (`sap-agw-spii-implementation`) returns destination fragments in the `READY` response so the **Destinations Facilitator** can wire up subscriber IAS credentials. This is necessary for the Agent Gateway because it sits in a federated A2A topology and needs cross-tenant credentials.

Joule's call path into the agent does not (yet) require this provisioning step in the SPII response. If that contract changes — e.g., if Joule starts requiring agent-side credentials brokered via SCI App2App — the handler would need to grow:

- Add an `outboundCommunication.oauth2ResourceIndicator` block in a Step 1 response, transitioning to `CONFIG_PENDING`.
- Build `connectivity.fragments` in the Step 2 `READY` response from the partner's config.

Until that happens, returning `READY` immediately is correct. Adding empty/placeholder configuration would be wrong — UCL treats the absence of a `configuration` block as "no further provisioning needed," which is exactly the intended semantic.

## Why The Handler Is Stateless

Joule does not consume any agent-side state, and UCL carries the assignment
lifecycle (`receiverTenant.state` + `assignedTenant.state`) on every
notification — the agent has nothing to track that is not already in the
payload. The agent also runs as multiple Pods in Kubernetes; any in-memory
dict would be inconsistent across replicas and would not survive Pod
rescheduling. So the handler just logs and returns READY.

(An earlier version of this skill wrote an entry to an in-memory
`assignments_store` for "observability" and "future-proofing" reasons. That
storage was removed when the bug it caused — silent state loss on Pod
restarts — became visible. If Joule later requires per-tenant state, it
should be persisted somewhere that survives Pod rescheduling, not in a
process-local dict.)

## State Machine, Restated

```
operation | Action
----------|--------
assign    | log + return READY
unassign  | log + return READY
```

The `receiverTenant.state` and `assignedTenant.state` inputs are recorded for logging but do not branch the logic. UCL retries `assign` notifications when it sees `ERROR` on either side; for Joule the retry is a no-op write that lands on `READY` again, which is the correct idempotent behavior.
