---
name: sap-joule-spii-implementation
description: Implement UCL SPII v3.0.0 for the Joule formation type in an App Foundation
  agent. Use this skill whenever the user needs to add, fix, modify, or understand the
  SPII handler that registers an agent for Joule integration — including the
  applicationNamespaces "sap.joule" and "sap.joulecore" (same flow, both handled by the
  same handler), the single-step assign-to-READY flow (no config exchange, no destination
  fragments, no persisted assignment state), or the unassign acknowledgement. Also use
  when the user asks about Joule formations, registering an agent so Joule can
  discover/recommend it, troubleshooting Joule SPII notifications, or adding a Joule
  handler to an existing SPII Facade dispatch.
  STRICT PREREQUISITE — Joule SPII MUST be deployed alongside a complete Agent
  Gateway SPII implementation; the two are co-resident by design in App
  Foundation agents. The final generated code MUST include both the Joule
  handler AND the full Agent Gateway integration: SPIIService Facade with
  applicationNamespace dispatch, SPIIFormationHandler ABC, stateless handlers,
  PATCH /v1/tenantMappings route, Pydantic NotificationPayload models with
  empty-string-to-None validators, Starlette route injection, AgentGatewayHandler
  for the sap.agw namespace with SCI App2App Step 1/Step 2
  oauth2ResourceIndicator exchange, sci_app2app_service.py with
  _get_destination_instance_id and IAS fragment payload builders, plus
  INITIATOR_MT_IAS_CLIENT_ID and AGENT_PUBLIC_URL env vars. All of that ships
  from sap-agw-spii-implementation. If any of those files are not in the
  project, do NOT proceed — invoke sap-agw-spii-implementation first via the
  Skill tool, then return here.
compatibility: Python 3.10+, Starlette, Pydantic v2.
metadata:
  author: application-foundation/codegenandi
  version: "3.0.0"
  protocol: spii-v3
  application-namespace: "sap.joule, sap.joulecore"
---

# Joule SPII Implementation

This skill implements the **SPII handler for the Joule formation type**.

## Before you start — Agent Gateway is a required dependency

**Joule SPII MUST NOT be installed without the Agent Gateway SPII
implementation alongside it.** Any agent that participates in a Joule formation
in this catalog is also an A2A agent that participates in Agent Gateway
formations — the two are deployed together by design. The final code generated
by this skill MUST contain a complete, working Agent Gateway integration in
addition to the Joule handler.

This means: the SPII foundation files **and** the AGW formation handler must
be present.

**Verify all of the following exist:**

Foundation (shared by every handler):

- `app/services/spii_base.py` — `SPIIFormationHandler`, `AssignmentState`, `StatusReport`, `ValidationError`
- `app/services/spii_service.py` — `SPIIService` Facade with `_build_handler_registry()`
- `app/api/spii.py` — `PATCH /v1/tenantMappings/{tenantId}` route
- `app/models/spii.py` — `NotificationPayload` with empty-string-to-None validators

Agent Gateway handler (required co-resident, not optional):

- `app/services/spii_agw.py` — `AgentGatewayHandler` (`sap.agw` namespace, two-step SCI App2App flow)
- `app/services/sci_app2app_service.py` — `handle_initial` / `handle_config_pending` Step 1/Step 2 builders, IAS fragment payload, `_get_destination_instance_id`, `FRAGMENT_NAME_IAS`, `FRAGMENT_NAME_IAS_USER`, `FragmentLabelKey`, `FragmentTypeValue`
- `AgentGatewayHandler()` registered in `_build_handler_registry()` inside `spii_service.py`
- Env vars `INITIATOR_MT_IAS_CLIENT_ID` and `AGENT_PUBLIC_URL` declared in `app.yaml`

**If any of these are missing, stop and apply `sap-agw-spii-implementation`
first.** Do not reimplement any of it inline. Do not cherry-pick only the
foundation pieces — the whole AGW skill is the dependency.

```
Skill(skill: "sap-agw-spii-implementation",
      args: "install the full Agent Gateway SPII implementation: SPII foundation (Facade, base, models, PATCH route) and the AgentGatewayHandler (sap.agw namespace, SCI App2App Step 1/Step 2, sci_app2app_service helpers, env vars). All of it is a hard dependency for the Joule handler.")
```

Wait for that skill to finish, then return here and add the Joule handler on
top. Tell the user what you're doing so they aren't surprised:

> "Joule SPII is always paired with Agent Gateway SPII in App Foundation
> agents — they're co-resident by design. I'll apply
> `sap-agw-spii-implementation` first, which installs both the shared SPII
> foundation and the Agent Gateway handler (sap.agw namespace, SCI App2App
> integration, IAS fragment lifecycle). Then I'll add the Joule handler on
> top."

If the foundation files exist but `spii_agw.py` is missing or
`AgentGatewayHandler` is not in the registry, the project is in an
unsupported half-installed state — surface this to the user and ask whether
to complete the AGW install (the expected resolution) rather than patching
silently around it.

If `_build_handler_registry()` exists but does not support `Sequence[str]`
namespaces, that's drift from the canonical AGW implementation and the Joule
handler will not register correctly (it declares two namespaces:
`sap.joule` and `sap.joulecore`). Surface this; do not silently rewrite the
foundation.

When a customer creates a UCL formation that includes Joule and your agent,
UCL sends a `PATCH /v1/tenantMappings/{tenantId}` notification with
`assignedTenant.applicationNamespace` set to either `sap.joule` or
`sap.joulecore`. The handler records the assignment and immediately responds
with `state: READY` — Joule does not require a configuration exchange or
destination fragments from the agent side. Both namespaces share the same
flow; the handler accepts both via a `Sequence[str]` declaration.

## Joule Formation Specifics

| Field | Value |
|-------|-------|
| Application Namespaces | `sap.joule`, `sap.joulecore` (same flow) |
| Formation Name | Joule |
| Protocol Steps | **Single step** — go directly to `READY` |
| Config Exchange | None — no `configuration` payload returned |
| Side Effects | None — no Destination, no Fragment, no observer |
| Storage | None — handler is stateless; UCL is the source of truth |

The Joule handler is the simplest SPII formation type: assign returns
`READY`; unassign returns `READY`. There is no `CONFIG_PENDING` step because
the agent has nothing to negotiate with Joule — registration alone is enough
for Joule to recommend the agent based on conversation context.

> **Future work**: Joule may eventually require destination fragments so it can
> call back into the agent. The handler returns `READY` only today; if/when
> that contract changes (signal: UCL starts sending non-null
> `assignedTenant.configuration` for `sap.joule`), extend the handler the same
> way the Agent Gateway handler does (see
> [`sap-agw-spii-implementation`](../sap-agw-spii-implementation/SKILL.md)).

## Implementation Steps

### 1. Joule Handler (`app/services/spii_joule.py`)

The handler implements `SPIIFormationHandler` (from `services.spii_base`,
shipped by the foundation skill) with two methods: `handle_assign` (return
`READY`) and `handle_unassign` (return `READY`). Both log the assignment id
for traceability but persist nothing.

See [templates/app/services/spii_joule.py](templates/app/services/spii_joule.py)
for the full implementation.

Key aspects:

- **Two namespaces, one handler**: `application_namespace` returns the tuple
  `(sap.joule, sap.joulecore)` typed as `Sequence[str]`. The Facade dispatches
  notifications carrying either value to this handler — no separate
  `JouleCoreHandler` is needed because the integration contract is identical.
- **Single step**: No config exchange. On assign, the handler always returns
  `AssignmentState.READY` regardless of `receiver_state` / `assigned_state`.
- **Stateless**: The handler keeps no in-process assignment store and no
  idempotency lock table — UCL is the source of truth for assignment state,
  and the agent runs as multiple Pods, so any cross-Pod state would be
  inconsistent. Re-running the same assign on a UCL retry always lands on
  `READY`.
- **No observer**: The handler does not create destinations, fragments, or
  any other infrastructure. There is nothing to clean up on unassign.
- **Idempotent**: Both `handle_assign` and `handle_unassign` are pure
  functions of the payload (modulo a log line), so retries are safe.

### 2. Register the Handler

Add `JouleHandler` to `_HANDLERS` in `_build_handler_registry()` inside
`app/services/spii_service.py`:

```python
from services.spii_joule import JouleHandler

handlers: List[SPIIFormationHandler] = [
    AgentGatewayHandler(),
    JouleHandler(),               # ← this line
    # ... other handlers
]
```

That single line is the only Facade change needed — the dispatch logic from
the foundation skill is unchanged.

## Joule State Machine

```
receiverTenant.state | assignedTenant.state | operation | Action
---------------------|----------------------|-----------|-------
INITIAL / ERROR      | any                  | assign    | log + return READY
any                  | any                  | unassign  | log + return READY
```

There is no `CONFIG_PENDING` step. The handler's behavior does not depend on
the input states — it always lands on `READY`.

## Response

On both assign and unassign, the handler returns:

```json
{
  "state": "READY"
}
```

No `configuration` block is sent back — Joule does not consume one from the
agent.

## Design Note: Stateless Handlers

The Joule handler is stateless by design, matching every other handler in this
catalog. UCL is the source of truth for assignment state — every notification
carries `receiverTenant.state` and `assignedTenant.state`, so the agent has no
reason to maintain its own copy. There is no in-process assignment store and
no idempotency lock table. This is what makes the agent safe to run as
multiple Pods in Kubernetes: any Pod can handle any notification without
coordinating across instances, and a rescheduled Pod loses nothing.

Earlier versions of this skill (and of every SPII skill in this catalog)
shipped an in-memory `assignments_store` and a `processing_locks` table inside
the Facade. Both were removed because they duplicated UCL's state in a place
that does not survive Pod rescheduling, and the "idempotency lock" was
per-Pod, not distributed — so it never actually protected against concurrent
duplicate notifications across replicas. If you are merging this skill onto a
project that still carries those structures from an older version, delete
them along with the handler code that wrote to them. See
[`sap-agw-spii-implementation`](../sap-agw-spii-implementation/SKILL.md) for
the full discussion in the foundation skill.

## Testing

Test the Joule handler in isolation — no observer or destination service to
mock, no in-memory state to seed. Both namespaces flow through the same code
path; one assign test per namespace is enough to lock the contract:

```python
import pytest

from services.spii_joule import (
    JouleHandler,
    APPLICATION_NAMESPACE_JOULE,
    APPLICATION_NAMESPACE_JOULE_CORE,
)
from services.spii_base import AssignmentState


@pytest.mark.parametrize(
    "namespace",
    [APPLICATION_NAMESPACE_JOULE, APPLICATION_NAMESPACE_JOULE_CORE],
)
def test_joule_assign_returns_ready(namespace):
    handler = JouleHandler()
    notification = {
        "context": {"uclFormationId": "fid", "uclFormationTypeId": "ftid"},
        "receiverTenant": {"globalTenantId": "gtid", "subdomain": "sub"},
        "assignedTenant": {"applicationNamespace": namespace},
    }

    result = handler.handle_assign(
        ucl_assignment_id=f"aid-{namespace}",
        receiver_state="INITIAL",
        assigned_state="INITIAL",
        assigned_config=None,
        notification_data=notification,
        tenant_id="tenant-1",
    )

    assert result.state == AssignmentState.READY.value


def test_joule_handler_declares_both_namespaces():
    assert tuple(JouleHandler().application_namespace) == (
        APPLICATION_NAMESPACE_JOULE,
        APPLICATION_NAMESPACE_JOULE_CORE,
    )


def test_joule_unassign_returns_ready():
    handler = JouleHandler()
    result = handler.handle_unassign("aid-2", notification_data={})
    assert result.state == AssignmentState.READY.value


def test_joule_unassign_unknown_is_idempotent():
    handler = JouleHandler()
    result = handler.handle_unassign("never-seen", notification_data={})
    assert result.state == AssignmentState.READY.value
```

## Verification

After applying this skill, run the payload tests to confirm the implementation produces the exact outputs captured from a live formation, for both namespaces:

```bash
python3 -m pytest tests/test_spii_joule_payloads.py tests/test_spii_joulecore_payloads.py -v
```

All tests must pass before the skill is considered correctly applied.

## Implementation Files

| File | What it contains |
|---|---|
| [templates/app/services/spii_joule.py](templates/app/services/spii_joule.py) | Full `JouleHandler` implementation — handles both `sap.joule` and `sap.joulecore` |
| [templates/tests/test_spii_joule_payloads.py](templates/tests/test_spii_joule_payloads.py) | Captured payload tests for `sap.joule` — one per request/response pair |
| [templates/tests/test_spii_joulecore_payloads.py](templates/tests/test_spii_joulecore_payloads.py) | Captured payload tests for `sap.joulecore` — same flow, different namespace |
| [templates/tests/payloads/joule/](templates/tests/payloads/joule/) | 4 JSON files for `sap.joule`: `request_N_*.json` + `response_N_*.json` for assign and unassign |
| [templates/tests/payloads/joulecore/](templates/tests/payloads/joulecore/) | 4 JSON files for `sap.joulecore`: same shape, with `applicationNamespace = sap.joulecore` |

## Reference Files

| File | Description |
|------|-------------|
| [references/joule-integration.md](references/joule-integration.md) | What Joule does with a registered agent and why the handler is intentionally minimal |
