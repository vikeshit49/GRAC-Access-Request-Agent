"""
Payload-based tests for the Joule SPII integration.

Each test loads a real request payload captured from formation_joule.html and
asserts the response matches the corresponding captured response payload.
The Joule handler is single-step: assign goes directly to READY with no
configuration block, no fragments, and no mocking required.

The handler is stateless — no in-memory store is seeded before exercising
unassign.
"""

import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest
from starlette.applications import Starlette
from starlette.testclient import TestClient

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

from api.spii import create_spii_routes

PAYLOADS = Path(__file__).parent / "payloads" / "joule"


def load(filename: str) -> dict:
    return json.loads((PAYLOADS / filename).read_text())


@pytest.fixture
def client():
    routes = create_spii_routes()
    app = Starlette(routes=routes)
    return TestClient(app)


@pytest.fixture(autouse=True)
def env_vars():
    with patch.dict(os.environ, {
        "INITIATOR_MT_IAS_CLIENT_ID": "test-ias-client-id",
        "AGENT_PUBLIC_URL": "https://jupiter.joule-unit-test-dev-eu12.orbit.auttst.on.dwc.tools.sap",
    }):
        yield


def test_assign_returns_ready(client):
    """Assign (both INITIAL) — Joule handler returns READY with no configuration block."""
    request = load("request_1_assign.json")
    expected = load("response_1_assign.json")

    response = client.patch("/v1/tenantMappings/037c48fa-ff28-492c-a55c-6a12226194b8", json=request)

    assert response.status_code == 200
    assert response.json() == expected


def test_unassign_returns_ready(client):
    """Unassign — agent acknowledges with READY (no side effects)."""
    request = load("request_2_unassign.json")
    expected = load("response_2_unassign.json")

    response = client.patch("/v1/tenantMappings/037c48fa-ff28-492c-a55c-6a12226194b8", json=request)

    assert response.status_code == 200
    assert response.json() == expected
