"""
SPII Handler for the Joule formation type.

Joule integration is intentionally minimal: when a formation that includes
Joule is assigned to this agent, UCL sends a notification with
``assignedTenant.applicationNamespace`` set to either ``sap.joule`` or
``sap.joulecore`` and we acknowledge by returning ``state: READY``. There is
no configuration exchange and no destination fragment to provision —
registering the agent is enough for Joule to recommend it based on
conversation context. The integration flow is identical for both namespaces;
only the inbound ``applicationNamespace`` value differs.

The handler is stateless — UCL carries the assignment lifecycle on every
notification and the agent runs as multiple Pods, so there is nothing for
the handler to persist.
"""

import logging
from typing import Any, Dict, Optional, Sequence

from services.spii_base import (
    SPIIFormationHandler,
    AssignmentState,
    StatusReport,
)

logger = logging.getLogger(__name__)

APPLICATION_NAMESPACE_JOULE = "sap.joule"
APPLICATION_NAMESPACE_JOULE_CORE = "sap.joulecore"
JOULE_NAMESPACES = (APPLICATION_NAMESPACE_JOULE, APPLICATION_NAMESPACE_JOULE_CORE)


class JouleHandler(SPIIFormationHandler):
    """Handles SPII assign/unassign for the Joule formation type.

    Covers both ``sap.joule`` and ``sap.joulecore`` — same integration flow,
    different ``applicationNamespace`` on the assignedTenant.
    """

    @property
    def application_namespace(self) -> Sequence[str]:
        return JOULE_NAMESPACES

    def handle_assign(
        self,
        ucl_assignment_id: str,
        receiver_state: str,
        assigned_state: str,
        assigned_config: Optional[Dict[str, Any]],
        notification_data: Dict[str, Any],
        tenant_id: str,
    ) -> StatusReport:
        receiver_tenant = notification_data.get("receiverTenant", {})

        gtid = receiver_tenant.get("globalTenantId", "")
        subdomain = receiver_tenant.get("subdomain", "")

        logger.info(
            "Joule assign: assignment=%s, tenant=%s, gtid=%s, subdomain=%s, state=READY",
            ucl_assignment_id,
            tenant_id,
            gtid,
            subdomain,
        )

        # TODO: Return Destination Fragments via SPII configuration so Joule
        # can reach this agent. Not implemented yet.
        return StatusReport(state=AssignmentState.READY)

    def handle_unassign(
        self,
        ucl_assignment_id: str,
        notification_data: Dict[str, Any],
    ) -> StatusReport:
        logger.info("Joule unassign: assignment=%s", ucl_assignment_id)
        return StatusReport(state=AssignmentState.READY)
