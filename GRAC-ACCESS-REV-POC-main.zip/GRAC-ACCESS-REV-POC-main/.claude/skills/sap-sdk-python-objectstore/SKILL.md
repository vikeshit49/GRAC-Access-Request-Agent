---
name: sap-sdk-python-objectstore
description: Integrate S3-compatible object storage using the Application Foundation Python SDK. Use when the user needs to upload, download, list, or delete files in object storage in a Python application.
---

# ObjectStore Integration with Python SDK

This skill provides guidance for integrating S3-compatible object storage using the Application Foundation Python SDK. The objectstore module offers automatic environment detection with local development support using MinIO containers.

## ⚠️ Package Index Policy

All Python packages MUST be installed exclusively from the SAP PyPI proxy:
`https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple`

NEVER use `https://pypi.org/simple` or any other external package index.
NEVER add `--extra-index-url` pointing to PyPI.
If a package is not found in the SAP proxy, report the error — do NOT fall back to PyPI.

## app.yaml Configuration

To use the ObjectStore service, add the following to your `app.yaml` under `spec.requires`:

```yaml
requires:
  - name: my-object-store
    service: objectstore
    plan: standard
```

**Fields:**
- `name`: Instance name for the objectstore service (used in your code with `create_client("my-object-store")`)
- `service`: Must be `objectstore`
- `plan`: Use `standard` for S3-compatible storage

## Installation

```bash
# Using uv (recommended)
uv add sap-cloud-sdk --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"

# Using pip
pip install sap-cloud-sdk --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"
```

## Quick Start

```python
from sap_cloud_sdk.objectstore import create_client

# Automatically detects local vs cloud mode
client = create_client("my-instance")

# Upload a file
client.put_object_from_bytes(
    name="hello.txt",
    data=b"Hello, World!",
    content_type="text/plain"
)

# Download a file
with client.get_object("hello.txt") as response:
    content = response.read()
    print(content.decode('utf-8'))
```

## Uploading Objects

### From Bytes

```python
data = b"Hello, World!"
client.put_object_from_bytes(
    name="hello.txt",
    data=data,
    content_type="text/plain"
)
```

### From File

```python
client.put_object_from_file(
    name="document.pdf",
    file_path="/path/to/local/document.pdf",
    content_type="application/pdf"
)
```

### From Stream

```python
import io
import os

# From BytesIO
stream = io.BytesIO(b"Streamed content")
client.put_object(
    name="stream.txt",
    data=stream,
    size=len(b"Streamed content"),
    content_type="text/plain"
)

# From file object
with open("/path/to/file.txt", "rb") as f:
    size = os.path.getsize("/path/to/file.txt")
    client.put_object(
        name="uploaded.txt",
        data=f,
        size=size,
        content_type="text/plain"
    )
```

## Retrieving Objects

### Get Object Content

```python
# Using context manager (recommended)
with client.get_object("hello.txt") as response:
    content = response.read()
    text_content = content.decode('utf-8')

# Manual close
response = client.get_object("hello.txt")
content = response.read()
response.close()
```

### Check Object Existence

```python
if client.object_exists("hello.txt"):
    print("File exists!")
else:
    print("File not found")
```

### Get Object Metadata

```python
metadata = client.head_object("hello.txt")

print(f"Key: {metadata.key}")
print(f"Size: {metadata.size} bytes")
print(f"ETag: {metadata.etag}")
print(f"Last Modified: {metadata.last_modified}")
print(f"Content Type: {metadata.content_type}")
```

### List Objects

```python
# List all objects
all_objects = client.list_objects()

# List objects with a prefix
documents = client.list_objects(prefix="documents/")

# Process the results
for obj in documents:
    print(f"{obj.key} - {obj.size} bytes - {obj.last_modified}")
```

## Deleting Objects

```python
# Delete a single object
client.delete_object("hello.txt")

# Delete is idempotent - no error if object doesn't exist
client.delete_object("non-existent.txt")
```

## Error Handling

```python
from sap_cloud_sdk.objectstore import (
    ObjectNotFoundError,
    ObjectOperationError,
    ClientCreationError,
    ListObjectsError
)

try:
    content = client.get_object("missing-file.txt")
except ObjectNotFoundError:
    print("File not found")
except ObjectOperationError as e:
    print(f"Operation failed: {e}")

try:
    client.put_object_from_bytes("test.txt", b"data", "text/plain")
except ObjectOperationError as e:
    print(f"Upload failed: {e}")

try:
    objects = client.list_objects("folder/")
except ListObjectsError as e:
    print(f"Failed to list objects: {e}")
```

## Local Development Mode

Enable local mode for development:

```bash
export APPFND_LOCALDEV_OBJECTSTORE=true
```

When local mode is enabled:
- A MinIO container starts automatically on first use
- Default credentials are used (minioadmin/minioadmin)
- Container is accessible on a random available port
- No additional configuration needed

### Check Runtime Mode

```python
from sap_cloud_sdk.core.runtime_context import RuntimeContext

ctx = RuntimeContext()
if ctx.is_local("objectstore"):
    print("Running in local development mode")
else:
    print("Running in cloud mode")
```

## Cloud Mode Configuration

In cloud mode, credentials are resolved from:

### Environment Variables
```bash
export OBJECTSTORE_CREDENTIALS_ACCESS_KEY_ID="your-access-key"
export OBJECTSTORE_CREDENTIALS_SECRET_ACCESS_KEY="your-secret-key"
export OBJECTSTORE_CREDENTIALS_BUCKET="your-bucket-name"
export OBJECTSTORE_CREDENTIALS_HOST="s3.amazonaws.com"
```

### Mounted Secrets (Kubernetes)
```
/etc/secrets/objectstore/credentials/
├── access_key_id
├── secret_access_key  
├── bucket
└── host
```

## Custom Configuration

```python
from sap_cloud_sdk.objectstore import create_client

# Custom configuration with SSL disabled
client = create_client(
    "my-instance",
    disable_ssl=True  # Disable SSL (default is False)
)
```

## Common Patterns

### Storing JSON Data

```python
import json

data = {"key": "value", "items": [1, 2, 3]}
client.put_object_from_bytes(
    name="data.json",
    data=json.dumps(data).encode('utf-8'),
    content_type="application/json"
)

# Reading JSON
with client.get_object("data.json") as response:
    loaded_data = json.loads(response.read().decode('utf-8'))
```

### Working with Folders

```python
# Objects with folder-like prefixes
client.put_object_from_bytes("reports/2024/january.pdf", pdf_data, "application/pdf")
client.put_object_from_bytes("reports/2024/february.pdf", pdf_data, "application/pdf")

# List objects in a "folder"
january_reports = client.list_objects(prefix="reports/2024/")
```

### Copying Objects

```python
# Read and re-upload to copy
with client.get_object("source.txt") as response:
    data = response.read()

client.put_object_from_bytes("destination.txt", data, "text/plain")
```
