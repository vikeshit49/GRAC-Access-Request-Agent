# {{AGENT_TITLE}}

{{AGENT_DESCRIPTION}}

## Overview

Uses A2A Protocol, {{FRAMEWORK}}, LiteLLM, and Application Foundation SDK.

## Structure

- `app.yaml` - Workload configuration
- `Dockerfile` - Container build
- `app/main.py` - A2A server entry
- `app/agent_executor.py` - Request handling
- `app/agent.py` - Agent logic
