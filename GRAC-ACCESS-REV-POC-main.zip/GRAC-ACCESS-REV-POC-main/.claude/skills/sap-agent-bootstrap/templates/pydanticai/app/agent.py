"""
Sample Agent using PydanticAI + LiteLLM.

Customize the SYSTEM_PROMPT to change the agent's behavior.
"""

import logging
from typing import AsyncGenerator

import litellm
from pydantic_ai import Agent
from pydantic_ai.messages import (
    ModelMessage,
    ModelRequest,
    ModelResponse,
    SystemPromptPart,
    TextPart,
    UserPromptPart,
)
from pydantic_ai.models.function import AgentInfo, FunctionModel

logger = logging.getLogger(__name__)

# =============================================================================
# CUSTOMIZE YOUR AGENT'S BEHAVIOR HERE
# =============================================================================
SYSTEM_PROMPT = """You are a helpful AI assistant built with Application Foundation.

You can help users with general questions and tasks. Be friendly, concise, and helpful.

When responding:
- Be clear and direct
- Provide examples when helpful
- If you don't know something, say so honestly
"""
# =============================================================================

MAX_HISTORY_MESSAGES = 100


def _build_litellm_messages(messages: list[ModelMessage]) -> list[dict]:
    """Convert PydanticAI message history to LiteLLM message dicts."""
    result = []
    for msg in messages:
        if isinstance(msg, ModelRequest):
            for part in msg.parts:
                if isinstance(part, SystemPromptPart):
                    result.append({"role": "system", "content": part.content})
                elif isinstance(part, UserPromptPart):
                    content = part.content if isinstance(part.content, str) else str(part.content)
                    result.append({"role": "user", "content": content})
        elif isinstance(msg, ModelResponse):
            text = "".join(p.content for p in msg.parts if isinstance(p, TextPart))
            if text:
                result.append({"role": "assistant", "content": text})
    return result


def _make_litellm_model(model_name: str) -> FunctionModel:
    """Return a PydanticAI FunctionModel that routes calls through litellm.acompletion.

    PydanticAI's built-in 'litellm:' provider wraps an AsyncOpenAI client which
    bypasses LiteLLM's SAP provider. FunctionModel routes directly through
    litellm.acompletion so SAP AI Core credentials (set via AICORE_* env vars
    by sap_cloud_sdk) are picked up correctly.
    """

    async def call_litellm(
        messages: list[ModelMessage], info: AgentInfo
    ) -> ModelResponse:
        litellm_messages = _build_litellm_messages(messages)

        result = await litellm.acompletion(
            model=model_name,
            messages=litellm_messages,
        )
        text = result.choices[0].message.content or ""
        return ModelResponse(parts=[TextPart(content=text)])

    return FunctionModel(call_litellm)


class SampleAgent:
    """
    Sample Agent using PydanticAI.

    Uses LiteLLM to connect to SAP Gen AI Hub models.
    """

    SUPPORTED_CONTENT_TYPES = ["text", "text/plain"]

    def __init__(self, model: str = "sap/anthropic--claude-4.5-sonnet"):
        """Initialize the agent with specified model."""
        self._agent = Agent(
            _make_litellm_model(model),
            system_prompt=SYSTEM_PROMPT,
        )
        self._history: dict[str, list[ModelMessage]] = {}

    async def stream(self, query: str, context_id: str) -> AsyncGenerator[dict, None]:
        """
        Stream responses from the agent.

        Args:
            query: The user's question or request
            context_id: Unique identifier for the conversation context

        Yields:
            Status updates and final response
        """
        yield {
            "is_task_complete": False,
            "require_user_input": False,
            "content": "Processing...",
        }

        try:
            history = self._history.get(context_id, [])

            result = await self._agent.run(query, message_history=history)

            all_messages = result.all_messages()
            if len(all_messages) > MAX_HISTORY_MESSAGES:
                all_messages = all_messages[-MAX_HISTORY_MESSAGES:]
            self._history[context_id] = all_messages

            yield {
                "is_task_complete": True,
                "require_user_input": False,
                "content": result.output,
            }

        except Exception as e:
            logger.exception("Error processing request")
            yield {
                "is_task_complete": True,
                "require_user_input": False,
                "content": f"Error: {str(e)}",
            }
