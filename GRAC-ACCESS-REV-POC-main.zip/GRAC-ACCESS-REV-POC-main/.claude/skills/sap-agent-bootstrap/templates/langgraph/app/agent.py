"""
Sample Agent using LangChain + LangGraph + LiteLLM.

Customize the SYSTEM_PROMPT to change the agent's behavior.
"""

import logging
from collections import defaultdict, deque
from typing import AsyncGenerator

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_litellm import ChatLiteLLM
from langgraph.graph import START, MessagesState, StateGraph

logger = logging.getLogger(__name__)

# =============================================================================
# CUSTOMIZE YOUR AGENT'S BEHAVIOR HERE
# =============================================================================
SYSTEM_PROMPT = """You are a helpful AI assistant built with Application Foundation.

You can help users with general questions and tasks. Be friendly, concise, and helpful.

When responding:
- Be clear and direct
- Provide examples when helpful
- If you don't know something, say so honestly
"""
# =============================================================================


class SampleAgent:
    """
    Sample Agent using LangChain + LangGraph.
    
    Uses LiteLLM to connect to SAP Gen AI Hub models.
    """

    SUPPORTED_CONTENT_TYPES = ["text", "text/plain"]
    MAX_HISTORY_MESSAGES = 100

    def __init__(self, model: str = "sap/anthropic--claude-4.5-sonnet"):
        """Initialize the agent with specified model."""
        self.llm = ChatLiteLLM(model=model)
        self.graph = self._build_graph()
        self._history: dict[str, deque] = defaultdict(
            lambda: deque(maxlen=self.MAX_HISTORY_MESSAGES)
        )

    def _build_graph(self) -> StateGraph:
        """Build the LangGraph workflow."""
        async def call_model(state: MessagesState):
            response = await self.llm.ainvoke(state["messages"])
            return {"messages": [response]}

        builder = StateGraph(MessagesState)
        builder.add_node("model", call_model)
        builder.add_edge(START, "model")
        return builder.compile()

    async def stream(self, query: str, context_id: str) -> AsyncGenerator[dict, None]:
        """
        Stream responses from the agent.

        Args:
            query: The user's question or request
            context_id: Unique identifier for the conversation context

        Yields:
            Status updates and final response
        """
        yield {
            "is_task_complete": False,
            "require_user_input": False,
            "content": "Processing...",
        }

        try:
            self._history[context_id].append(HumanMessage(content=query))
            messages = [
                SystemMessage(content=SYSTEM_PROMPT),
                *self._history[context_id],
            ]
            result = await self.graph.ainvoke({"messages": messages})
            assistant_msg = result["messages"][-1]
            self._history[context_id].append(assistant_msg)

            yield {
                "is_task_complete": True,
                "require_user_input": False,
                "content": assistant_msg.content,
            }

        except Exception as e:
            logger.exception("Error processing request")
            yield {
                "is_task_complete": True,
                "require_user_input": False,
                "content": f"Error: {str(e)}",
            }