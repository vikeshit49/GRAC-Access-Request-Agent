# VS Code Devcontainer Setup

Sets up a VS Code devcontainer for App Foundation agent development with Python 3.13, SAP Artifactory, pre-installed extensions, and automatic dependency installation.

## Prerequisites

1. **Docker Desktop** installed and running
2. **VS Code** with the [Dev Containers extension](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-containers)

## Step 1: Copy devcontainer templates

**macOS/Linux:**
```bash
SKILL_PATH=$(find . -type d -name "sap-agent-bootstrap" -path "*/skills/*" 2>/dev/null | head -1)
mkdir -p .devcontainer
cp "$SKILL_PATH/optional-templates/devcontainer/Dockerfile" .devcontainer/Dockerfile
cp "$SKILL_PATH/optional-templates/devcontainer/devcontainer.json" .devcontainer/devcontainer.json
```

**Windows PowerShell:**
```powershell
$SkillPath = Get-ChildItem -Path . -Recurse -Directory -Filter "sap-agent-bootstrap" | Where-Object { $_.FullName -like "*skills*" } | Select-Object -First 1 -ExpandProperty FullName
New-Item -ItemType Directory -Force -Path .devcontainer
Copy-Item "$SkillPath/optional-templates/devcontainer/Dockerfile" -Destination ".devcontainer/Dockerfile"
Copy-Item "$SkillPath/optional-templates/devcontainer/devcontainer.json" -Destination ".devcontainer/devcontainer.json"
```

## Step 2: Open in Devcontainer

1. Open the project in VS Code
2. Click **"Reopen in Container"** when prompted (or Command Palette → `Dev Containers: Reopen in Container`)
3. Wait for the container to build — dependencies are installed automatically via `postCreateCommand`

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Reopen in Container" missing | Install Dev Containers extension, ensure Docker is running, restart VS Code |
| Port 9000 not accessible | Check `forwardPorts` in devcontainer.json, try `127.0.0.1:9000`, check for port conflicts |
| Dependencies not installed | Run `pip install --no-cache-dir -r requirements.txt --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"` manually |
| Rebuild needed | Command Palette → `Dev Containers: Rebuild Container` |
| View container logs | Command Palette → `Dev Containers: Show Container Log` |
