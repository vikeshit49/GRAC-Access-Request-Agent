---
name: sap-agent-bootstrap
description: Bootstrap or customize an App Foundation agent project. Use when the user wants to create a new AI agent for deployment on SAP App Foundation runtime, or configure an existing agent created from the template repository. Supports LangGraph (default) and PydanticAI frameworks. Use when the user explicitly mentions PydanticAI.
---
# App Foundation Agent Bootstrap

Creates a ready-to-deploy AI agent for SAP App Foundation with A2A protocol, SAP AI Core integration, and GitHub Actions CI/CD. Supports LangGraph and PydanticAI.

## Instructions

Follow these phases in order:

### Phase 0: Choose Framework

If the user has not already specified a framework, default to **LangGraph** without asking.
If the user mentioned PydanticAI in their request, use **PydanticAI**.

| Framework | When to use |
|-----------|-------------|
| **LangGraph** (default) | Multi-step agents, tool chaining, streaming |
| **PydanticAI** | Simpler async agents, lighter dependency footprint |

Store the choice as FRAMEWORK = `langgraph` or `pydanticai`. All subsequent steps reference this choice.

### Phase 1: Collect User Input

Ask the user to provide exactly 2 values BEFORE any file operations:

```
Question 1: "Please enter your agent name (e.g., expense-tracker-agent):"
Question 2: "Please enter your agent description (e.g., 'An AI agent that tracks business expenses'):"
```

**Example interaction:**
- User wants: "Create an agent to help with travel expenses"
- Agent name: `travel-expense-agent`
- Agent description: `An AI agent that helps employees manage and submit travel expenses`

### Phase 2: Copy Templates

Skip this phase if template files already exist (e.g., repo was created from a GitHub template). Check for the presence of `app.yaml` and `app/main.py` to determine this.

If files do NOT exist, copy the shared templates first, then the framework-specific ones. The framework-specific files overwrite nothing in shared — they are additive.

Set `FRAMEWORK` to `langgraph` or `pydanticai` (from Phase 0) before running:

**macOS/Linux:**
```bash
mkdir -p app .github/workflows
SKILL_PATH=$(find . -type d -name "sap-agent-bootstrap" -path "*/skills/*" 2>/dev/null | head -1)
FRAMEWORK=<langgraph|pydanticai>
cp -r "$SKILL_PATH/templates/shared/." ./
cp -r "$SKILL_PATH/templates/$FRAMEWORK/." ./
```

**Windows PowerShell:**
```powershell
New-Item -ItemType Directory -Force -Path app, .github/workflows
$SkillPath = Get-ChildItem -Path . -Recurse -Directory -Filter "sap-agent-bootstrap" | Where-Object { $_.FullName -like "*skills*" } | Select-Object -First 1 -ExpandProperty FullName
$Framework = "<langgraph|pydanticai>"
Get-ChildItem "$SkillPath/templates/shared" -Force | Copy-Item -Destination "./" -Recurse -Force
Get-ChildItem "$SkillPath/templates/$Framework" -Force | Copy-Item -Destination "./" -Recurse -Force
```

### Phase 3: Customize the Agent

Use the Edit tool to modify the template defaults with the user's input. Derive all values from the 2 inputs collected in Phase 1.

#### 3.1 — Update `app.yaml`

Change the metadata name and namespace:

```yaml
metadata:
  name: <agent-name>
  namespace: <agent-name>
```

#### 3.2 — Update `README.md`

Replace all three placeholders using sed. For `{{FRAMEWORK}}`, substitute `LangGraph` or `PydanticAI` (from Phase 0):

**macOS:**
```bash
sed -i '' \
  -e 's/{{AGENT_TITLE}}/<Agent Title>/g' \
  -e 's/{{AGENT_DESCRIPTION}}/<agent-description>/g' \
  -e 's/{{FRAMEWORK}}/LangGraph/g' \
  README.md
```

**Linux:**
```bash
sed -i \
  -e 's/{{AGENT_TITLE}}/<Agent Title>/g' \
  -e 's/{{AGENT_DESCRIPTION}}/<agent-description>/g' \
  -e 's/{{FRAMEWORK}}/LangGraph/g' \
  README.md
```

#### 3.3 — Update `app/main.py`

Edit the constants block near the top of the file:

```python
AGENT_NAME = "<Agent Title>"
AGENT_DESCRIPTION = "<agent-description>"
AGENT_TAGS = ["<tag1>", "<tag2>", ...]
AGENT_EXAMPLES = [
    "<example prompt 1>",
    "<example prompt 2>",
]
```

Also update the skill id:
```python
    skill = AgentSkill(
        id="<agent-name>",
```

#### 3.4 — Verify `AgentCard` in `app/main.py`

The template already contains a fully structured `AgentCard`. After updating the constants in 3.3, confirm the `AgentCard` object uses them correctly and that no placeholder values remain:

- `name` and `description` reference `AGENT_NAME` / `AGENT_DESCRIPTION`
- `url` uses `os.environ.get("AGENT_PUBLIC_URL", f"http://{host}:{port}/")`  — never hardcoded
- `version` is `"1.0.0"` (update only if `pyproject.toml` specifies otherwise)
- `capabilities`: `streaming=True` for LangGraph, `streaming=False` for PydanticAI
- `AgentSkill.id` matches the agent name (kebab-case)
- `AgentSkill.tags` and `examples` are derived from the agent name/description, not left as template defaults

No structural changes to `main.py` are needed if the template was copied unmodified.

#### 3.5 — Update `app/agent.py`

Edit the `SYSTEM_PROMPT` constant with a prompt tailored to the agent's description:

```python
SYSTEM_PROMPT = """You are <agent-description>. Help users with their requests.

When responding:
- Be clear and direct
- Provide examples when helpful
- If you don't know something, say so honestly
"""
```

**Framework note:** The model is configured differently per framework — `ChatLiteLLM(model=...)` for LangGraph, `Agent(_make_litellm_model(model), ...)` via a custom `FunctionModel` for PydanticAI. Do not swap them.

## Value Derivation Rules

Derive all values from the 2 user inputs:

| Target | Derivation | Example |
|--------|------------|---------|
| `app.yaml` name/namespace | Direct from agent name | `travel-expense-agent` |
| README title | Title-case: replace `-` with space, capitalize | `Travel Expense Agent` |
| README description | Direct from description input | `An AI agent that helps employees manage and submit travel expenses` |
| README framework | `LangGraph` or `PydanticAI` (from Phase 0) | `LangGraph` |
| `main.py` AGENT_NAME | Same as README title | `Travel Expense Agent` |
| `main.py` AGENT_DESCRIPTION | Direct from description input | `An AI agent that helps employees manage and submit travel expenses` |
| `main.py` AGENT_TAGS | Split agent name by `-` into list | `["travel", "expense", "agent"]` |
| `main.py` AGENT_EXAMPLES | Generate 2 example prompts from description | `["Help me submit a travel expense", "What are the expense policies?"]` |
| `main.py` skill id | Same as agent name | `travel-expense-agent` |
| `agent.py` SYSTEM_PROMPT | Template using description | `You are an AI agent that helps employees manage and submit travel expenses. Help users with their requests.` |

## Project Structure

For the full `app.yaml` schema reference, see the [App Foundation Agent Schema](https://github.tools.sap/app-fnd-runtime/helm-templates/blob/main/schemas/app-yaml.schema.json).

```
./
├── .github/workflows/managed-runtime-ci-cd.yml
├── .github/workflows/aggregate-static-ord.yml
├── .github/workflows/aggregate-dynamic-ord.yml
├── app.yaml
├── Dockerfile
├── .dockerignore
├── requirements.txt
├── .gitignore
├── README.md
└── app/
    ├── __init__.py
    ├── main.py
    ├── agent_executor.py
    └── agent.py
```

## Optional: External Services

Add to `app.yaml` under `spec.requires`:

```yaml
  requires:
    - name: default
      service: auditlog
      plan: oauth2
    - name: my-destination
      service: destination
      plan: lite
    - name: my-object-store
      service: objectstore
      plan: standard
```

## Customization

- **Model**: Change in `app.yaml` (models list) and `agent.py` (model parameter)
- **Tools**: Extend LangGraph in `agent.py` (LangGraph) / Add PydanticAI tools in `agent.py` (PydanticAI)
- **Skills**: Add `AgentSkill` definitions in `main.py`
- **History**: Adjust `MAX_HISTORY_MESSAGES` in `agent.py` (default: 100)

## Package Index Policy

All Python packages MUST be installed exclusively from the SAP PyPI proxy:
`https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple`

NEVER use `https://pypi.org/simple` or any other external package index.
NEVER add `--extra-index-url` pointing to PyPI.
If a package is not found in the SAP proxy, report the error — do NOT fall back to PyPI.

The project includes a `pip.conf` that enforces this. Do not override or bypass it.

## Important: Dependencies

Dependencies listed in `requirements.txt` are NOT installed during the bootstrap process. They will be installed:
- **Locally**: When you run the agent using the `sap-agent-run-local` skill
- **In the cluster**: Automatically during the deployment process via CI/CD pipeline

The bootstrap process only creates the project structure and configuration files. No local Python environment setup is performed at this stage.

## Next Steps

After presenting all the above information, **immediately invoke the following skill** before offering deploy or run options. Do NOT ask the user — this is a mandatory step for every new agent:

### Step 1 — Add ORD Endpoint
Invoke the `sap-agent-ord-endpoint` skill. This adds the ORD discovery endpoint required for UMS to find and provision the agent.

### Step 2 — Deploy or Run

Only after the ORD skill above is complete, ask the user how they would like to proceed:

```
"Your agent is now fully configured with ORD. How would you like to proceed?"

Options:
1. "Deploy remotely - Commit and push to trigger CI/CD"
2. "Run locally - Set up and run the agent on my machine"
3. "Tell me more about the project structure"
```

Based on the user's choice:

- **Option 1 (Deploy remotely)**:
  1. First, ask if the user wants to customize key parts before deploying:
     ```
     "Before deploying, would you like to edit any of these key files?"

     Options:
     - "Edit system prompt (app/agent.py)"
     - "Edit agent skills/description (app/main.py)"
     - "Edit model configuration (app.yaml)"
     - "No changes needed - deploy now"
     ```
  2. If user chooses to edit, help them make the changes and ask again.
  3. When user selects "No changes needed - deploy now", execute:
     ```bash
     git add -A
     git commit -m "feat: bootstrap <agent-name> agent"
     git push origin main
     ```
  4. After push succeeds, inform: "Code pushed! CI/CD pipeline is deploying your agent. Check GitHub Actions for progress."
  5. Then ask: "Would you like to test the deployed agent once it's ready?" - If yes, activate `sap-agent-test-remote` skill.

- **Option 2 (Run locally)**: Immediately invoke the `sap-agent-run-local` skill. Do NOT just mention the skill - actually load and execute it.

- **Option 3 (More info)**: Provide detailed explanations about the files and architecture

## Optional: VS Code Devcontainer Setup

If the user asks to develop inside a VS Code devcontainer or containerized environment, read and follow the instructions in `references/devcontainer.md` (located alongside this skill).
