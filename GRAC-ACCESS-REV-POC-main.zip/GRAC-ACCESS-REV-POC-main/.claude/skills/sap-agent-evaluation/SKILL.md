---
name: sap-agent-evaluation
description: >-
  Sets up and runs agent evaluation using the Aeval framework against a running A2A-compatible agent server. Supports two execution modes: local CLI-based evaluation (requires Python, MLflow, AI Core credentials, and a locally running agent) and remote evaluation via AI Core offline evaluation service (requires AI Core credentials and a deployed agent). Use when the user wants to "evaluate my agent", "run evaluation", "test agent locally", "run aeval", "set up evaluation", "evaluate using offline service".
metadata:
  concepts:
    - Aeval framework
    - local evaluation
    - remote evaluation
    - AI Core offline evaluation service
    - MLflow
    - eval setup
    - agent config
---

# SAP Agent Evaluation

Orchestrates agent evaluation using the Aeval framework with two execution modes.

## Instructions

### Step 1: Ask User for Evaluation Method

Use AskUserQuestion to present the evaluation options:

```
Question: "How would you like to run the evaluation?"
Header: "Eval Method"
Options:
1. "CLI (Local Machine)" - Run evaluation on your machine using the aeval CLI. Requires local setup.
2. "Offline Service (AI Core)" - Run evaluation as a job in AI Core using the offline evaluation service.
Multi-select: false
```

### Step 2: Execute Based on Choice

**If "CLI (Local Machine)" selected:**

1. **Check if setup is complete** by verifying these files exist:
   - `aeval/` folder
   - `.venv/` folder with aeval installed
   - `aeval/configs/agent-config.yaml`

2. **If ANY check fails (setup incomplete):**
   - Execute all steps in `references/setup-local-instructions.md`
   
3. **Execute all steps in `references/run-eval-local-instructions.md`**

**If "Offline Service (AI Core)" selected:**

1. **Execute all steps in `references/run-eval-remote-instructions.md`**

## Important Notes

- Setup checks run silently - only trigger setup if files are missing
- Do NOT re-run setup on subsequent evaluations if files already exist
- Each reference file contains complete instructions for its phase
- All script paths are relative to this skill's directory structure
