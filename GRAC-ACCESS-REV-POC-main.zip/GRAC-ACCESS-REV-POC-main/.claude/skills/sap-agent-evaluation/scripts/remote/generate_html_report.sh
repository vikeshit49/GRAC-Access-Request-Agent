#!/bin/bash
# Generate HTML report with embedded data
# Usage: ./generate_html_report.sh <execution_folder>

set -e

EXEC_FOLDER="${1}"

if [ -z "$EXEC_FOLDER" ]; then
  echo "Usage: $0 <execution_folder>"
  echo "Example: $0 aeval/remote-eval/reports/e94dbf73b085f7fa"
  exit 1
fi

if [ ! -d "$EXEC_FOLDER" ]; then
  echo "Error: Folder not found: $EXEC_FOLDER"
  exit 1
fi

if [ ! -f "$EXEC_FOLDER/results.json" ]; then
  echo "Error: results.json not found in $EXEC_FOLDER"
  exit 1
fi

echo "▶ Generating HTML report..."

# Get the skill path
SKILL_PATH=$(find . -type d -name "sap-agent-evaluation" -path "*/.claude/skills/*" 2>/dev/null | head -1)

if [ -z "$SKILL_PATH" ]; then
  echo "Error: Could not find sap-agent-evaluation skill path"
  exit 1
fi

TEMPLATE_FILE="$SKILL_PATH/templates/remote/report.html"

if [ ! -f "$TEMPLATE_FILE" ]; then
  echo "Error: Template not found at $TEMPLATE_FILE"
  exit 1
fi

# Read the template
TEMPLATE=$(cat "$TEMPLATE_FILE")

# Read results.json and escape for JavaScript
RESULTS_JSON=$(cat "$EXEC_FOLDER/results.json" | sed 's/\\/\\\\/g' | sed 's/`/\\`/g' | sed 's/\$/\\$/g')

# Read .eval-state if exists
EVAL_STATE=""
if [ -f "$EXEC_FOLDER/.eval-state" ]; then
  EVAL_STATE=$(cat "$EXEC_FOLDER/.eval-state")
fi

# Create standalone HTML by replacing the fetch calls with embedded data
OUTPUT_FILE="$EXEC_FOLDER/report.html"

# Use Python to do the replacement properly
python3 - "$TEMPLATE_FILE" "$EXEC_FOLDER/results.json" "$EXEC_FOLDER/.eval-state" "$OUTPUT_FILE" << 'PYTHON_SCRIPT'
import sys
import json

template_file = sys.argv[1]
results_file = sys.argv[2]
eval_state_file = sys.argv[3]
output_file = sys.argv[4]

# Read template
with open(template_file, 'r') as f:
    html = f.read()

# Read results.json
with open(results_file, 'r') as f:
    results_json = json.load(f)

# Read .eval-state if exists
eval_state = {}
try:
    with open(eval_state_file, 'r') as f:
        for line in f:
            if '=' in line:
                key, value = line.strip().split('=', 1)
                eval_state[key] = value
except:
    pass

# Embed the data into the HTML
# Replace the loadResults function to use embedded data instead of fetch
results_json_str = json.dumps(results_json)
eval_state_str = json.dumps(eval_state)

# Find and replace the loadResults function
load_results_start = html.find('// Load and display results')
load_results_end = html.find('window.addEventListener(\'DOMContentLoaded\', loadResults);')

if load_results_start == -1 or load_results_end == -1:
    print("Error: Could not find loadResults function markers")
    sys.exit(1)

# Create new loadResults with embedded data
new_load_results = f'''// Load and display results
      // EMBEDDED DATA - Generated from results.json and .eval-state
      const EMBEDDED_RESULTS = {results_json_str};
      const EMBEDDED_EVAL_STATE = {eval_state_str};

      async function loadResults() {{
        try {{
          // Use embedded data instead of fetching
          const results = EMBEDDED_RESULTS;
          const evalState = EMBEDDED_EVAL_STATE;

          const resources = results.resources || [];

          if (resources.length === 0) {{
            throw new Error('No resources found in results.json');
          }}

          const resource = resources[0];
          const customInfo = resource.customInfo || [];
          const metrics = resource.metrics || [];

          // Parse validation data
          const validationData = parseCustomInfo(customInfo);

          // Organize metrics
          const {{ runMetrics, sessionByTestcase }} = organizeMetrics(metrics);

          // Get metric names
          const metricNames = getAllMetricNames(metrics);

          // Get run ID
          const runId = runMetrics.length > 0
            ? getLabelValue(runMetrics[0].labels, 'run_id') || 'unknown'
            : 'unknown';

          // Update UI
          document.getElementById('run-id').textContent = runId;

          // Update configuration section
          document.getElementById('config-run-id').textContent = runId;
          if (evalState.CONFIG_ID) {{
            document.getElementById('config-id').textContent = evalState.CONFIG_ID;
          }}
          if (evalState.EXEC_ID) {{
            document.getElementById('exec-id').textContent = evalState.EXEC_ID;
          }}
          if (evalState.EVAL_NAME) {{
            document.getElementById('eval-name').textContent = evalState.EVAL_NAME;
          }}
          if (evalState.AGENT_BASE_URL) {{
            document.getElementById('agent-url').textContent = evalState.AGENT_BASE_URL;
          }}

          // Render tables
          renderSessionMetricsTable(metricNames, sessionByTestcase);
          renderRunMetricsTable(metricNames, runMetrics, runId);

          // Render validation failures (Section 3)
          renderValidationFailures(validationData);

          // Render per test case results (Section 4)
          renderPerTestCaseResults(validationData, sessionByTestcase, metricNames);

          // Generate summary assessment (Section 5)
          generateSummaryAssessment(runMetrics, validationData);

          // Update timestamp
          document.getElementById('timestamp').textContent =
            `Report generated on ${{formatTimestamp(new Date().toISOString())}}`;

          // Show content, hide loading
          document.getElementById('loading').style.display = 'none';
          document.getElementById('content').style.display = 'block';

        }} catch (error) {{
          console.error('Error loading results:', error);
          document.getElementById('loading').style.display = 'none';
          const errorDiv = document.getElementById('error');
          errorDiv.textContent = `Error loading results: ${{error.message}}`;
          errorDiv.style.display = 'block';
        }}
      }}

      '''

# Replace the section
html = html[:load_results_start] + new_load_results + html[load_results_end:]

# Write output
with open(output_file, 'w') as f:
    f.write(html)

print(f"✓ Generated: {output_file}")

PYTHON_SCRIPT

echo "✓ Report generated at: $OUTPUT_FILE"
echo ""
echo "You can now open this file directly in your browser:"
echo "  open $OUTPUT_FILE"
