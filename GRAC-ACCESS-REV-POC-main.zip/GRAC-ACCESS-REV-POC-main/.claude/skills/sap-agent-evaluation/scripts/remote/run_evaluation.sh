#!/bin/bash

# Script to run agent evaluation
# Usage: ./run_evaluation.sh <agent_base_url> <test_suite_inline_json_file> [eval_name]

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check prerequisites
if ! command -v jq &> /dev/null; then
  echo -e "${RED}✗ Error: jq is not installed${NC}"
  echo "Please install jq: https://stedolan.github.io/jq/"
  exit 1
fi

# Parse arguments
AGENT_BASE_URL="${1}"
TEST_SUITE_INLINE_FILE="${2}"
EVAL_NAME="${3:-eval-$(date +%Y%m%d-%H%M%S)}"

# Validate arguments
if [ -z "$AGENT_BASE_URL" ]; then
  echo -e "${RED}✗ Error: Agent base URL is required${NC}"
  echo "Usage: $0 <agent_base_url> <test_suite_inline_json_file> [eval_name]"
  exit 1
fi

if [ -z "$TEST_SUITE_INLINE_FILE" ] || [ ! -f "$TEST_SUITE_INLINE_FILE" ]; then
  echo -e "${RED}✗ Error: Test suite inline JSON file is required and must exist${NC}"
  echo "Usage: $0 <agent_base_url> <test_suite_inline_json_file> [eval_name]"
  exit 1
fi

# Validate JSON file
if ! jq empty "$TEST_SUITE_INLINE_FILE" 2>/dev/null; then
  echo -e "${RED}✗ Error: Test suite file is not valid JSON${NC}"
  exit 1
fi

# Load test suite inline JSON (properly escaped)
TEST_SUITE_INLINE=$(cat "$TEST_SUITE_INLINE_FILE")

# Load configuration from remote-agent.json
CONFIG_FILE="aeval/remote-eval/remote-agent.json"

if [ ! -f "$CONFIG_FILE" ]; then
  echo -e "${RED}✗ Error: Configuration file not found at $CONFIG_FILE${NC}"
  echo "Please run the setup step first to create the configuration file."
  exit 1
fi

# Extract AI Core credentials from remote-agent.json
apiurl=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE')).get('AICORE_BASE_URL', ''))" 2>/dev/null)
client_id=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE')).get('AICORE_CLIENT_ID', ''))" 2>/dev/null)
auth_url=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE')).get('AICORE_AUTH_URL', ''))" 2>/dev/null)
resourcegroupid=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE')).get('AICORE_RESOURCE_GROUP', ''))" 2>/dev/null)
client_secret=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE')).get('AICORE_CLIENT_SECRET', ''))" 2>/dev/null)

# Extract A2A credentials from remote-agent.json
a2a_auth_url=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE')).get('a2a_auth_url', ''))" 2>/dev/null)
a2a_client_id=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE')).get('a2a_client_id', ''))" 2>/dev/null)
a2a_client_secret=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE')).get('a2a_client_secret', ''))" 2>/dev/null)

# Validate AI Core credentials
if [ -z "$apiurl" ] || [ -z "$client_id" ] || [ -z "$auth_url" ] || [ -z "$resourcegroupid" ] || [ -z "$client_secret" ]; then
  echo -e "${RED}✗ Error: Missing AI Core credentials in $CONFIG_FILE${NC}"
  echo "Please ensure all AICORE_* fields are filled in the configuration file."
  exit 1
fi

# Use placeholder values if A2A credentials are empty
# Note: AI Core offline evaluation requires a generic secret to be created,
# even if the agent doesn't use A2A authentication. If credentials are empty,
# we use placeholder values to satisfy AI Core's requirements.
if [ -z "$a2a_auth_url" ] || [ -z "$a2a_client_id" ] || [ -z "$a2a_client_secret" ]; then
  echo -e "${YELLOW}ℹ️  Using placeholder A2A credentials${NC}"
  echo "Note: Aeval Offline Service requires a generic secret even if your agent doesn't use A2A auth."
  echo ""

  [ -z "$a2a_auth_url" ] && a2a_auth_url="https://placeholder.auth.url"
  [ -z "$a2a_client_id" ] && a2a_client_id="placeholder-client-id"
  [ -z "$a2a_client_secret" ] && a2a_client_secret="placeholder-client-secret"
fi

echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║               AGENT EVALUATION - REMOTE                      ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo "Configuration:"
echo "  Agent URL: $AGENT_BASE_URL"
echo "  Test Suite: $TEST_SUITE_INLINE_FILE"
echo "  Evaluation Name: $EVAL_NAME"
echo ""

# ==============================================================================
# STEP 1: Obtain Access Token
# ==============================================================================

echo -e "${BLUE}▶ Step 1: Obtain Access Token${NC}"

ACCESS_TOKEN=$(curl -s --request POST \
  --url "$auth_url/oauth/token" \
  --header 'content-type: application/x-www-form-urlencoded' \
  --data "grant_type=client_credentials&client_id=$client_id&client_secret=$client_secret" \
  | jq -r '.access_token')

if [ -z "$ACCESS_TOKEN" ] || [ "$ACCESS_TOKEN" = "null" ]; then
  echo -e "${RED}✗ Failed to obtain access token${NC}"
  exit 1
fi

echo -e "${GREEN}✓ Access token obtained${NC}"
echo ""

# ==============================================================================
# STEP 2: Create or Update Generic Secret
# ==============================================================================

echo -e "${BLUE}▶ Step 2: Create or Update Generic Secret${NC}"

A2A_AUTH_URL_B64=$(echo -n "$a2a_auth_url" | base64 | tr -d '\n')
A2A_CLIENT_ID_B64=$(echo -n "$a2a_client_id" | base64 | tr -d '\n')
A2A_CLIENT_SECRET_B64=$(echo -n "$a2a_client_secret" | base64 | tr -d '\n')

SECRET_DATA=$(jq -n \
  --arg a2a_auth_url "$A2A_AUTH_URL_B64" \
  --arg a2a_client_id "$A2A_CLIENT_ID_B64" \
  --arg a2a_client_secret "$A2A_CLIENT_SECRET_B64" \
  '{
    "A2A_AUTH_URL": $a2a_auth_url,
    "A2A_CLIENT_ID": $a2a_client_id,
    "A2A_CLIENT_SECRET": $a2a_client_secret
  }')

RESPONSE=$(curl --http1.1 --silent --write-out "\n%{http_code}" \
  --request POST \
  --url "$apiurl/v2/admin/secrets" \
  --header "ai-resource-group: $resourcegroupid" \
  --header "authorization: Bearer $ACCESS_TOKEN" \
  --header 'content-type: application/json' \
  --data "$(jq -n --argjson data "$SECRET_DATA" '{"name":"aeval-service-secret","data":$data,"labels":[]}')")

HTTP_STATUS=$(echo "$RESPONSE" | tail -n 1)
BODY=$(echo "$RESPONSE" | sed '$d')
MESSAGE=$(echo "$BODY" | jq -r '.message // empty')

if [ "$MESSAGE" = "Secret exists" ] || [ "$HTTP_STATUS" = "409" ]; then
  curl --http1.1 --silent --request PATCH \
    --url "$apiurl/v2/admin/secrets/aeval-service-secret" \
    --header "ai-resource-group: $resourcegroupid" \
    --header "authorization: Bearer $ACCESS_TOKEN" \
    --header 'content-type: application/json' \
    --data "$(jq -n --argjson data "$SECRET_DATA" '{"data":$data,"labels":[]}')" > /dev/null
  echo -e "${GREEN}✓ Secret updated${NC}"
elif [ "$HTTP_STATUS" = "201" ]; then
  echo -e "${GREEN}✓ Secret created${NC}"
else
  echo -e "${RED}✗ Failed to create/update secret${NC}"
  exit 1
fi
echo ""

# ==============================================================================
# STEP 3: Create Evaluation Configuration
# ==============================================================================

echo -e "${BLUE}▶ Step 3: Create Evaluation Configuration${NC}"
CONFIG_RESPONSE=$(jq -n \
  --arg name "$EVAL_NAME" \
  --arg executableId "agent-evaluation-offline" \
  --arg scenarioId "agent-evaluation" \
  --arg agent_base_url "$AGENT_BASE_URL" \
  --argjson test_suite_inline "$TEST_SUITE_INLINE" \
  '{
    name: $name,
    executableId: $executableId,
    scenarioId: $scenarioId,
    parameterBindings: [
      {key: "agent_base_url", value: $agent_base_url},
      {key: "test_suite_inline", value: ($test_suite_inline | tostring)}
    ]
  }' | curl -s --request POST \
  --url "$apiurl/v2/lm/configurations" \
  --header "authorization: Bearer $ACCESS_TOKEN" \
  --header "ai-resource-group: $resourcegroupid" \
  --header "content-type: application/json" \
  --data @-)

# Extract configuration ID
CONFIG_ID=$(echo "$CONFIG_RESPONSE" | jq -r '.id')

if [ -z "$CONFIG_ID" ] || [ "$CONFIG_ID" = "null" ]; then
  echo -e "${RED}✗ Failed to create configuration${NC}"
  echo "API Response: $CONFIG_RESPONSE"
  exit 1
fi

echo -e "${GREEN}✓ Configuration created${NC}"
echo "   Configuration ID: $CONFIG_ID"
echo "   Evaluation Name: $EVAL_NAME"
echo "   Agent URL: $AGENT_BASE_URL"
echo ""

# ==============================================================================
# STEP 4: Trigger Evaluation Execution
# ==============================================================================

echo -e "${BLUE}▶ Step 4: Trigger Evaluation Execution${NC}"

EXEC_RESPONSE=$(curl -s --request POST \
  --url "$apiurl/v2/lm/executions" \
  --header "authorization: Bearer $ACCESS_TOKEN" \
  --header "ai-resource-group: $resourcegroupid" \
  --header "content-type: application/json" \
  --data "{\"configurationId\": \"$CONFIG_ID\"}")

# Extract execution ID
EXEC_ID=$(echo "$EXEC_RESPONSE" | jq -r '.id')

if [ -z "$EXEC_ID" ] || [ "$EXEC_ID" = "null" ]; then
  echo -e "${RED}✗ Failed to start execution${NC}"
  echo "API Response: $EXEC_RESPONSE"
  exit 1
fi

echo -e "${GREEN}✓ Evaluation execution started${NC}"
echo "   Execution ID: $EXEC_ID"
echo "   Status: RUNNING"
echo ""

# ==============================================================================
# STEP 5: Monitor Execution Until Completion
# ==============================================================================

echo -e "${BLUE}▶ Step 5: Monitor Execution Until Completion${NC}"
echo "Polling evaluation run status every 20 seconds..."
echo ""

STATUS="UNKNOWN"
POLL_COUNT=0

while [ "$STATUS" != "COMPLETED" ] && [ "$STATUS" != "DEAD" ]; do
  sleep 20
  POLL_COUNT=$((POLL_COUNT + 1))

  STATUS_RESPONSE=$(curl -s --request GET \
    --url "$apiurl/v2/lm/executions/$EXEC_ID" \
    --header "authorization: Bearer $ACCESS_TOKEN" \
    --header "ai-resource-group: $resourcegroupid")

  STATUS=$(echo "$STATUS_RESPONSE" | jq -r '.status')

  echo -e "  [Poll $POLL_COUNT] Status: ${YELLOW}$STATUS${NC} ($(date +%H:%M:%S))"

  # Warn if taking too long (>10 minutes)
  if [ $POLL_COUNT -ge 30 ]; then
    echo -e "  ${YELLOW}⚠️  Execution taking longer than expected (>10 minutes)${NC}"
  fi
done

echo ""
echo "Final Status: $STATUS"
echo ""

# Handle failure
if [ "$STATUS" = "DEAD" ]; then
  echo -e "${RED}✗ Execution failed${NC}"
  echo ""
  echo "Retrieving error logs..."

  LOGS_RESPONSE=$(curl -s --request GET \
    --url "$apiurl/v2/lm/executions/$EXEC_ID/logs" \
    --header "authorization: Bearer $ACCESS_TOKEN" \
    --header "ai-resource-group: $resourcegroupid" \
    --header "order: asc")

  # Save logs to file
  mkdir -p aeval/remote-eval/reports
  ERROR_LOG_FILE="aeval/remote-eval/reports/error-$(date +%Y%m%d-%H%M%S).log"
  echo "$LOGS_RESPONSE" > "$ERROR_LOG_FILE"

  # Display last 20 log entries
  echo "$LOGS_RESPONSE" | jq -r '.data[-20:][] | "[\(.timestamp)] \(.message)"'

  echo ""
  echo "Full logs saved to: $ERROR_LOG_FILE"
  exit 1
fi

echo -e "${GREEN}✓ Execution finished successfully${NC}"
echo ""

# ==============================================================================
# STEP 6: Retrieve and Save Results
# ==============================================================================

echo -e "${BLUE}▶ Step 6: Retrieve and Save Results${NC}"

# Create execution-specific folder (only after successful metrics fetch)
EXEC_FOLDER="aeval/remote-eval/reports/$EXEC_ID"

# Fetch metrics
METRICS_RESPONSE=$(curl -s --request GET \
  --url "$apiurl/v2/lm/metrics?executionIds=$EXEC_ID" \
  --header "authorization: Bearer $ACCESS_TOKEN" \
  --header "ai-resource-group: $resourcegroupid")

# Validate metrics response
if [ -z "$METRICS_RESPONSE" ] || ! echo "$METRICS_RESPONSE" | jq empty 2>/dev/null; then
  echo -e "${RED}✗ Failed to retrieve valid metrics${NC}"
  exit 1
fi

# Now create folder and save results
mkdir -p "$EXEC_FOLDER"

# Save results to execution folder
echo "$METRICS_RESPONSE" | jq '.' > "$EXEC_FOLDER/results.json"

# Save state
echo "CONFIG_ID=$CONFIG_ID" > "$EXEC_FOLDER/.eval-state"
echo "EXEC_ID=$EXEC_ID" >> "$EXEC_FOLDER/.eval-state"
echo "EVAL_NAME=$EVAL_NAME" >> "$EXEC_FOLDER/.eval-state"
echo "AGENT_BASE_URL=$AGENT_BASE_URL" >> "$EXEC_FOLDER/.eval-state"
echo "TIMESTAMP=$(date +%Y%m%d-%H%M%S)" >> "$EXEC_FOLDER/.eval-state"

echo -e "${GREEN}✓ Results saved${NC}"

echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║          EVALUATION COMPLETED SUCCESSFULLY                   ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo "Results saved to: $EXEC_FOLDER"
echo "  - results.json: Full evaluation metrics"
echo "  - .eval-state: Execution state and configuration"
echo ""
echo "Execution ID: $EXEC_ID"
echo ""
