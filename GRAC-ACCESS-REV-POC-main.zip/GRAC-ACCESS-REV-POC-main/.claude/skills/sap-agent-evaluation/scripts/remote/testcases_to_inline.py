#!/usr/bin/env python3
# /// script
# requires-python = ">=3.9"
# dependencies = [
#     "pyyaml",
# ]
# ///
"""
Convert one or more YAML test case files into a single minified JSON file.

Usage:
    # From a folder (sorted by filename):
    python aeval_testcases_to_inline.py --folder testcases/currency -o out.json

    # From explicit files:
    python aeval_testcases_to_inline.py --files 00.yaml 01.yaml -o out.json

    # Custom quoting:
    python aeval_testcases_to_inline.py --folder testcases/currency -o out.json \\
        --double-quote-escaping-mode unicode \\
        --single-quote-escaping-mode unicode

    # With compression (gzip + base64 encoding):
    python aeval_testcases_to_inline.py --folder testcases/currency -o out.txt \\
        --compress
"""

import argparse
import base64
import gzip
import json
import re
import sys
from pathlib import Path

import yaml

_CONTROL = re.compile(r"[\x00-\x1f\x7f\x80-\x9f]+")


def normalize_strings(obj):
    """Recursively replace runs of control characters in string values with a single space."""
    if isinstance(obj, str):
        return _CONTROL.sub(" ", obj).strip()
    if isinstance(obj, list):
        return [normalize_strings(v) for v in obj]
    if isinstance(obj, dict):
        return {k: normalize_strings(v) for k, v in obj.items()}
    return obj


def load_yaml_files(paths: list[Path]) -> list:
    docs = []
    for p in paths:
        with p.open(encoding="utf-8") as f:
            docs.append(yaml.safe_load(f))
    return docs


def collect_files_from_folder(folder: Path) -> list[Path]:
    files = sorted(folder.glob("*.yaml")) + sorted(folder.glob("*.yml"))
    # deduplicate while preserving order (glob may not overlap, but be safe)
    seen: set[Path] = set()
    result = []
    for f in files:
        if f not in seen:
            seen.add(f)
            result.append(f)
    return sorted(result)


def process(
    docs: list,
    output_path: Path,
    double_quote_mode: str,
    single_quote_mode: str,
    compress: bool = False,
) -> None:
    # Serialize to compact JSON (minified)
    result = json.dumps(docs, separators=(",", ":"), ensure_ascii=False)

    # Double-quote escaping (applied before single-quote escaping so that
    # any \u0022 sequences we emit are never re-processed)
    if double_quote_mode == "backslash":
        result = result.replace('"', '\\"')
    elif double_quote_mode == "unicode":
        result = result.replace('"', r"\u0022")
    # else: "none" — leave as-is

    # Single-quote escaping
    if single_quote_mode == "unicode":
        result = result.replace("'", r"\\u0027")
    # else: "none" — leave as-is

    # Optional compression
    original_length = len(result)
    if compress:
        compressed = gzip.compress(result.encode('utf-8'))
        result = base64.b64encode(compressed).decode('utf-8')
        compression_ratio = len(result) / original_length
        print(f"Written {len(docs)} document(s) to {output_path}")
        print(f"Original JSON length: {original_length} characters")
        print(f"Compressed length: {len(result)} characters")
        print(f"Compression ratio: {compression_ratio:.1%} (saved {100 - compression_ratio * 100:.1f}%)")
    else:
        print(f"Written {len(docs)} document(s) to {output_path}")
        print(f"Output length: {len(result)} characters")

    output_path.write_text(result, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Convert YAML test-case files to a single minified JSON."
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument(
        "--folder",
        metavar="DIR",
        type=Path,
        help="Folder containing .yaml / .yml files (processed in sorted order).",
    )
    source.add_argument(
        "--files",
        metavar="FILE",
        nargs="+",
        type=Path,
        help="Explicit list of YAML files to process (in the order given).",
    )
    parser.add_argument(
        "-o",
        "--output",
        metavar="FILE",
        type=Path,
        required=True,
        help="Path for the output JSON file.",
    )
    parser.add_argument(
        "--double-quote-escaping-mode",
        dest="double_quote_mode",
        choices=["backslash", "unicode", "none"],
        default="backslash",
        help='How to escape double quotes: backslash (→ \\"), unicode (→ \\u0022), or none (default: backslash).',
    )
    parser.add_argument(
        "--single-quote-escaping-mode",
        dest="single_quote_mode",
        choices=["unicode", "none"],
        default="none",
        help="How to escape single quotes: unicode (→ \\u0027) or none (default: none).",
    )
    parser.add_argument(
        "--compress",
        action="store_true",
        help="Compress output with gzip and encode with base64. Useful for large test suites.",
    )
    args = parser.parse_args()

    if args.folder:
        if not args.folder.is_dir():
            sys.exit(f"Error: '{args.folder}' is not a directory.")
        paths = collect_files_from_folder(args.folder)
        if not paths:
            sys.exit(f"Error: no .yaml / .yml files found in '{args.folder}'.")
    else:
        paths = args.files
        missing = [str(p) for p in paths if not p.is_file()]
        if missing:
            sys.exit(f"Error: file(s) not found: {', '.join(missing)}")

    docs = [normalize_strings(d) for d in load_yaml_files(paths)]
    process(docs, args.output, args.double_quote_mode, args.single_quote_mode, args.compress)


if __name__ == "__main__":
    main()