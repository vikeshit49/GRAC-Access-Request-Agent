
# Run Agent Evaluation with Aeval Offline Service

Execute agent evaluation test cases using the Aeval framework for agents hosted on remote servers and view the results.

## Overview

This skill orchestrates a complete evaluation workflow:
1. Gather inputs and setup A2A credentials for the remote agent
2. Convert test cases to inline format
3. Run evaluation (automated script handles config creation, execution, monitoring, and result retrieval)

# Prerequisites

**Configuration File Setup:**

Before running evaluations, you need to configure the remote agent settings in `aeval/remote-eval/remote-agent.json`. This file contains:

- `agent_base_url`: The remote agent base URL to evaluate (e.g., https://mlfstaging-currency-agent.1213.stage.kyma.ondemand.com)
- `test_case_folder`: Location of test case YAML files (default: aeval/testcases)
- `a2a_auth_url`: OAuth token endpoint URL for agent authentication (Optional)
- `a2a_client_id`: Client ID for the remote agent (Optional)
- `a2a_client_secret`: Client secret for the remote agent (Optional)
- `AICORE_BASE_URL`: AI Core base URL for evaluation service
- `AICORE_CLIENT_ID`: AI Core client ID
- `AICORE_AUTH_URL`: AI Core authentication URL
- `AICORE_RESOURCE_GROUP`: AI Core resource group
- `AICORE_CLIENT_SECRET`: AI Core client secret

**About A2A Credentials**: A2A (Agent-to-Agent) authentication is an OAuth-based protocol for secure agent communication. Leave A2A fields empty if your remote agent doesn't require authentication. If your agent does require A2A auth, provide valid credentials. The Aeval offline service requires a generic secret in AI Core; the offline-service script will use placeholder values if credentials are empty.

**Important**:
- The configuration file will be created automatically if it doesn't exist
- AI Core credentials will be automatically copied from `app/.env.local` if available
- You must fill in all required fields before running the evaluation
- Keep the A2A and AI Core credentials secure and do not commit them to version control

# Step by step instructions

## 0: Validate Prerequisites and Setup Configuration

### Setup Configuration File

```bash
mkdir -p aeval/remote-eval

if [ -f "aeval/remote-eval/remote-agent.json" ]; then
  echo "EXISTING_CONFIG_FOUND"
else
  echo "NO_CONFIG_FOUND"
fi
```

**If EXISTING_CONFIG_FOUND**: 
Read config, ask user to choose: 
1) Use existing,
2) Overwrite. 

If '1', skip to validation. 
If '2', continue below.

**If NO_CONFIG_FOUND**: 
Create template and auto-fill AI Core credentials if available:
```bash
SKILL_PATH=$(find . -type d -name "sap-agent-evaluation" -path "*/.claude/skills/*" 2>/dev/null | head -1)
cp "$SKILL_PATH/templates/remote/remote-agent.json" "aeval/remote-eval/remote-agent.json"

# Auto-copy AI Core credentials from app/.env.local if exists
if [ -f "app/.env.local" ]; then
  for key in AICORE_CLIENT_ID AICORE_CLIENT_SECRET AICORE_AUTH_URL AICORE_BASE_URL AICORE_RESOURCE_GROUP; do
    eval "$key=\$(grep \"^$key=\" app/.env.local | cut -d'=' -f2 | sed 's/^[\"'\'']\(.*\)[\"'\'']$/\1/')"
  done
  
  python3 -c "
import json, os
with open('aeval/remote-eval/remote-agent.json', 'r') as f: config = json.load(f)
config.update({k: os.environ.get(k, '') for k in ['AICORE_CLIENT_ID', 'AICORE_CLIENT_SECRET', 'AICORE_AUTH_URL', 'AICORE_BASE_URL', 'AICORE_RESOURCE_GROUP']})
with open('aeval/remote-eval/remote-agent.json', 'w') as f: json.dump(config, f, indent=2)
" && echo "✓ AI Core credentials copied from app/.env.local" || echo "No AI Core credentials found"
fi
```

Inform user to fill in `aeval/remote-eval/remote-agent.json`:
- Required: `agent_base_url`, `test_case_folder`
- Optional: A2A credentials (`a2a_auth_url`, `a2a_client_id`, `a2a_client_secret`)
- AI Core credentials auto-filled if `app/.env.local` exists, otherwise fill manually
- Reply 'done' when ready

**Wait for user confirmation** before proceeding.

### Validate Configuration

```bash
echo "▶ Validating configuration"

# Read configuration
CONFIG_FILE="aeval/remote-eval/remote-agent.json"

# Extract values using python
AGENT_BASE_URL=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['agent_base_url'])" 2>/dev/null)
TEST_CASE_FOLDER=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['test_case_folder'])" 2>/dev/null)

# Validate required fields
if [ -z "$AGENT_BASE_URL" ] || [ "$AGENT_BASE_URL" = "" ]; then
  echo "✗ Error: agent_base_url is not configured"
  exit 1
fi

if [ -z "$TEST_CASE_FOLDER" ] || [ "$TEST_CASE_FOLDER" = "" ]; then
  echo "✗ Error: test_case_folder is not configured"
  exit 1
fi

echo "✓ Configuration validated:"
echo "  - Agent URL: $AGENT_BASE_URL"
echo "  - Test cases: $TEST_CASE_FOLDER"

# Verify test case folder exists
if [ ! -d "$TEST_CASE_FOLDER" ]; then
  echo "✗ Error: Test case folder not found at $TEST_CASE_FOLDER"
  exit 1
fi

# List test files
echo "Found test cases:"
ls -1 "$TEST_CASE_FOLDER"/*.yaml 2>/dev/null || echo "No YAML files found"
```

**If validation fails**:
- Stop skill immediately
- Inform the user about the specific missing or invalid field
- Ask them to fix the configuration file

**If no YAML files are found**:
- Stop skill immediately
- Inform the user: "No test case YAML files found in the configured folder. Please create test cases first or update the test_case_folder in the configuration."

**Success Criteria:**
- Configuration file exists and all required fields are filled
- Test case folder exists and contains YAML files
- User confirms configuration is ready

---

## 1: Convert Test Cases to Inline Format

The Aeval offline service requires test cases as a minified JSON string. This step transforms YAML test files into the required inline format.

```bash
echo "▶ Step 1: Converting test cases to inline format"

# Read configuration
CONFIG_FILE="aeval/remote-eval/remote-agent.json"
TEST_CASE_FOLDER=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['test_case_folder'])")

SKILL_PATH=$(find . -type d -name "sap-agent-evaluation" -path "*/.claude/skills/*" 2>/dev/null | head -1)

# Convert test cases to inline format
python3 "$SKILL_PATH/scripts/remote/testcases_to_inline.py" \
  --folder "$TEST_CASE_FOLDER" \
  --output /tmp/testcases_inline.json \
  --double-quote-escaping-mode none

echo "✓ Converted test cases: $(cat /tmp/testcases_inline.json | wc -c) characters"
```

**If conversion fails**:
- Display the error message
- Stop the skill
- Inform the user to check test case YAML syntax

**Success Criteria:**
- Inline JSON file created at `/tmp/testcases_inline.json`
- File size > 100 characters (prevents empty output)

---

## 2: Run Evaluation

This step automates the complete evaluation process: configuration creation, execution, monitoring, and result retrieval.

```bash
echo "▶ Step 2: Running evaluation"

# Read configuration
CONFIG_FILE="aeval/remote-eval/remote-agent.json"
AGENT_BASE_URL=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['agent_base_url'])")

SKILL_PATH=$(find . -type d -name "sap-agent-evaluation" -path "*/.claude/skills/*" 2>/dev/null | head -1)

# Run the evaluation script
"$SKILL_PATH/scripts/remote/run_evaluation.sh" \
  "$AGENT_BASE_URL" \
  "/tmp/testcases_inline.json" \
  "eval-$(date +%Y%m%d-%H%M%S)"
```

**The script will:**
1. Load A2A credentials from `aeval/remote-eval/remote-agent.json`
2. Obtain OAuth access token using the A2A credentials
3. Create evaluation configuration with provided parameters
4. Trigger execution on the remote evaluation service
5. Poll execution status every 20 seconds until completion
6. Retrieve evaluation metrics and save to `aeval/remote-eval/reports/<EXEC_ID>/`:
   - `results.json`: Full evaluation metrics from API
   - `.eval-state`: Execution configuration and metadata

**If authentication fails**:
- Stop the skill
- Inform the user: "Authentication failed. Please verify A2A credentials in `aeval/remote-eval/remote-agent.json`"

**If execution fails (DEAD status)**:
- Error logs are automatically saved to the execution folder
- Display the last 20 log entries
- Stop the skill

**Success Criteria:**
- Script completes without errors
- Execution status is COMPLETED
- Results saved to `aeval/remote-eval/reports/<EXEC_ID>/`
- Console displays execution ID and folder path

---

## 3: Generate HTML Report and Complete

**If all steps succeeded:**

1. Find the latest execution folder:
```bash
LATEST_EXEC=$(ls -t aeval/remote-eval/reports/ | grep -v "error-" | head -1)
```

2. Generate HTML report with summary assessment:
```bash
# Generate HTML report with embedded data (no dependencies required)
SKILL_PATH=$(find . -type d -name "sap-agent-evaluation" -path "*/.claude/skills/*" 2>/dev/null | head -1)
"$SKILL_PATH/scripts/remote/generate_html_report.sh" "aeval/remote-eval/reports/$LATEST_EXEC"

echo "✓ HTML report generated"
```

The HTML report includes:
- Evaluation details (Configuration ID, Execution ID, Agent URL, Status)
- Overall metrics (Task Success Rate, Output Correctness, Tool Call Correctness, Duration, Token Count)
- Test case breakdown table
- Validation failures (if any)
- Summary assessment based on results

3. Inform user where to find detailed results:
   - Results folder: `aeval/remote-eval/reports/<EXEC_ID>/`
   - HTML Report: `aeval/remote-eval/reports/<EXEC_ID>/report.html` (open in browser - no server needed)
   - Full metrics: `aeval/remote-eval/reports/<EXEC_ID>/results.json`
   - Configuration: `aeval/remote-eval/reports/<EXEC_ID>/.eval-state`

**If any step failed:**
- Display the specific error
- Provide guidance on how to fix it
- Stop the skill

---

## 4: Next Steps

- Review the results in `aeval/remote-eval/reports/<EXEC_ID>/results.json`
- If tests failed, update your agent or test cases
- Re-run evaluation after making changes

---

# Implementation Notes

## Sequential Dependencies
- Prerequisites → Check configuration file requirement
- Step 0 → Creates configuration template if needed → Validates configuration → Wait for user confirmation
- Step 1 → Reads test_case_folder from config → Converts YAML to inline JSON → `/tmp/testcases_inline.json`
- Step 2 → Reads agent_base_url from config → Runs `scripts/run_evaluation.sh` (auth, config, execute, monitor, save) → `aeval/remote-eval/reports/<EXEC_ID>/`
- Step 3 → Generates HTML report with summary assessment
- Step 4 → Next steps guidance

## Key Behaviors
- **Configuration-driven**: All inputs (agent URL, test cases, A2A credentials) are stored in `aeval/remote-eval/remote-agent.json`
- **STOP immediately** if: configuration invalid, test cases missing, credentials not filled, authentication fails, execution status = DEAD
- **Wait for user confirmation** after creating configuration template in Step 0
- **Poll every 20 seconds** during Step 2 execution monitoring
- **Save results** to `aeval/remote-eval/reports/<EXEC_ID>/results.json` and `.eval-state`
- **Save error logs** to `aeval/remote-eval/reports/error-<timestamp>.log` if execution fails

## Error Recovery
- Configuration missing/invalid → Fill in `aeval/remote-eval/remote-agent.json`
- Authentication fails → Check A2A credentials in `aeval/remote-eval/remote-agent.json`
- Test conversion fails → Fix YAML syntax errors
- Execution DEAD → Review error logs, check agent availability and A2A credentials
