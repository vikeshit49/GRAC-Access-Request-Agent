# LangChain / LangGraph Integration

Integration pattern using LangChain with `langchain-mcp-adapters` for MCP tool
support. Includes manual tool filtering (LangChain does not provide built-in
support for this).

MCP tool connections go through the **Agent Gateway** proxy. The agent builds
gateway URLs from the `McpServer`'s `ord_id` and `global_tenant_id`, and
authenticates by calling `AgentGatewayClient.get_user_auth(inbound_token)`
from the SAP Cloud SDK, which returns both the gateway-scoped access token
and the per-tenant Agent Gateway base URL in a single async call.

> **Note**: This reference assumes Phase 2 (Add Telemetry Instrumentation) of the
> `sap-agent-extensibility` skill has been completed, which generates the
> `extension_telemetry/` module with OTEL-instrumented wrappers.

> **Conditionality**: This reference shows the full tools + instructions case.
> When implementing, only include the sections relevant to your configuration:
>
> - **Tools only**: Include MCP server config, tool filtering, and
>   telemetry, but omit the instruction concatenation to the system prompt.
> - **Instructions only**: Include the instruction concatenation to the system
>   prompt, but omit `langchain-mcp-adapters`, `MultiServerMCPClient`, tool
>   filtering/prefixing, and telemetry wrapping entirely. Phase 2 (telemetry)
>   should also have been skipped.

## How MultiServerMCPClient works

`MultiServerMCPClient` from `langchain-mcp-adapters` manages connections to
multiple MCP servers and exposes their tools as LangChain-compatible objects.

Key behavior:
- **Stateless by default** — each tool call creates a fresh session. No
  `async with` context manager is needed for basic usage.
- **Transport options** — supports `"streamable_http"` (remote) and `"stdio"` (local)
- **Authentication** — pass `headers` in the connection config for Bearer tokens

Constructor:
```python
client = MultiServerMCPClient(
    connections={...},           # dict[str, Connection] — server configs
)
```

Getting tools (no context manager needed):
```python
tools = await client.get_tools()
```

## Complete example

```python
import logging

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.prebuilt import create_react_agent

from sap_cloud_sdk.agentgateway import create_client as create_agw_client
from sap_cloud_sdk.extensibility import create_client
from sap_cloud_sdk.ias import parse_token
from extension_telemetry import ExtensionTelemetryInterceptor

logger = logging.getLogger(__name__)

BASE_SYSTEM_PROMPT = "You are a helpful assistant."

# Create extensibility client once at module level
extensibility_client = create_client("<agent_ord_id>")


async def run_agent(query: str, inbound_token: str = "", context=None) -> str:
    """Run the LangChain agent with extensibility support."""

    # Step 1: Extract tenant and fetch extensions. tenant_subdomain comes
    # from the dwc-subdomain HTTP header.
    headers = context.call_context.state.get("headers", {}) if context and context.call_context else {}
    authorization = headers.get("authorization", "")
    tenant_subdomain = headers.get("dwc-subdomain", "")
    claims = parse_token(authorization)
    tenant = claims.app_tid

    ext_impl = extensibility_client.get_extension_capability_implementation(
        tenant=tenant,
        capability_id="default",
    )

    # Step 2: Build system prompt with extended instructions
    system_prompt = BASE_SYSTEM_PROMPT
    if ext_impl.instruction:
        system_prompt += f"\n\n## Extended Instructions\n{ext_impl.instruction}"
        logger.info("Loaded extension instruction (%d chars)", len(ext_impl.instruction))

    # Step 3: Agent Gateway auth — exchange the user token and obtain the
    # per-tenant gateway URL. Created per-request because tenant_subdomain
    # varies per request.
    agw_client = create_agw_client(tenant_subdomain=tenant_subdomain)
    auth = None
    if inbound_token and ext_impl.mcp_servers:
        try:
            auth = await agw_client.get_user_auth(user_token=inbound_token)
        except Exception as e:
            logger.error("Agent Gateway user auth fetch failed: %s", e)

    auth_headers = (
        {"Authorization": f"Bearer {auth.access_token}"}
        if auth
        else {}
    )
    agw_host = auth.gateway_url if auth else ""

    # Step 4: Build MCP server config via Agent Gateway and get tools
    # Load tools from each MCP server individually so one failure
    # doesn't block the others.
    ext_tools = []
    if ext_impl.mcp_servers and agw_host:
        tool_name_to_server = {}
        for server in ext_impl.mcp_servers:
            for name in (server.tool_names or []):
                tool_name_to_server[name] = server

        # If Phase 2 (telemetry) was done, create the interceptor
        interceptor = ExtensionTelemetryInterceptor(ext_impl=ext_impl)

        for server in ext_impl.mcp_servers:
            gateway_url = (
                f"{agw_host}/v1/mcp"
                f"/{server.ord_id}/{server.global_tenant_id}"
            )
            server_key = server.ord_id
            try:
                client = MultiServerMCPClient(
                    {
                        server_key: {
                            "url": gateway_url,
                            "transport": "streamable_http",
                            "headers": auth_headers,
                        }
                    },
                    tool_interceptors=[interceptor],
                )
                mcp_tools = await client.get_tools()

                # Filter to only approved tools
                filtered = [t for t in mcp_tools if t.name in tool_name_to_server]
                ext_tools.extend(filtered)
            except Exception as e:
                logger.warning(
                    "Failed to load MCP tools from %s — skipping: %s",
                    server_key, e,
                )

        logger.info("Found %d extension tool(s)", len(ext_tools))

    # Step 5: Create agent with existing tools + extension tools
    existing_tools = [...]  # your agent's built-in tools
    all_tools = existing_tools + ext_tools
    agent = create_react_agent(model, all_tools)

    result = await agent.ainvoke({
        "messages": [
            SystemMessage(content=system_prompt),
            HumanMessage(content=query),
        ]
    })
    return result["messages"][-1].content
```

## Key points

- **`langchain-mcp-adapters`** provides `MultiServerMCPClient` for connecting to
  multiple MCP servers simultaneously
- **Stateless by default** — no `async with` context manager needed. Each tool
  call opens a fresh session. This means extension tools can be fetched once and
  merged with existing tools without lifecycle concerns.
- MCP connections go through the **Agent Gateway** — URLs are built from
  `auth.gateway_url`, `server.ord_id`, and `server.global_tenant_id`
- Authentication uses the SAP Cloud SDK's
  `AgentGatewayClient.get_user_auth(...)` — the inbound user token is
  exchanged for a gateway-scoped token, and the AGW host URL is returned in
  the same `AuthResult`. `tenant_subdomain` is taken from the `dwc-subdomain`
  HTTP header
- **Per-server isolation**: Each MCP server is loaded individually in its own
  try/except — one unavailable server doesn't block the others
- Extended instructions are appended to the system message
- MCP tools from `client.get_tools()` can be mixed with native LangChain tools
- **Fail-open behavior**: MCP connection per server is wrapped in try/except —
  unavailable extension servers are logged and skipped
- Tools are **filtered** manually to only the subset approved by the extensibility
  service (LangChain has no built-in tool filter)
- `create_client("<agent_ord_id>")` is called once at module level;
  `client.get_extension_capability_implementation(tenant=tenant)` is **synchronous** — no `await`.
  The client has an internal cache (LRU, 10-min TTL) keyed by `(tenant, capability_id)` —
  recreating it per request defeats caching

## How instructions are added

LangChain doesn't have a separate instructions parameter. Append extended
instructions to the system message:

```python
system_prompt = BASE_SYSTEM_PROMPT
if ext_impl.instruction:
    system_prompt += f"\n\n## Extended Instructions\n{ext_impl.instruction}"
```

## How MCP tools are added

`MultiServerMCPClient` is stateless — instantiate it with your server config,
call `get_tools()`, and the returned tools handle their own connections per call.

Load each server individually for per-server isolation:

```python
for server in ext_impl.mcp_servers:
    gateway_url = f"{agw_host}/v1/mcp/{server.ord_id}/{server.global_tenant_id}"
    try:
        client = MultiServerMCPClient({
            server.ord_id: {
                "url": gateway_url,
                "transport": "streamable_http",
                "headers": auth_headers,
            }
        })
        tools = await client.get_tools()
        ext_tools.extend(tools)
    except Exception as e:
        logger.warning("Failed to load MCP tools from %s — skipping: %s", server.ord_id, e)
```

No context manager is required. The tools manage their own session lifecycle.

## How tools are filtered

LangChain does not have a built-in tool filtering mechanism for MCP servers.
Filter the tool list manually after loading all tools from `get_tools()`,
using `server.tool_names` from each `McpServer`:

```python
# Build a lookup from tool name -> server
tool_name_to_server = {}
for server in ext_impl.mcp_servers:
    for name in server.tool_names:
        tool_name_to_server[name] = server

# After loading tools from all servers:
filtered_tools = [t for t in mcp_tools if t.name in tool_name_to_server]
```

## Mixing with native LangChain tools

Extension tools can be combined with `@tool`-decorated functions and other
tool sources. Because `MultiServerMCPClient` is stateless, the tools it
returns are self-contained — no open connection to manage:

```python
from langchain_core.tools import tool

@tool
def my_native_tool(param: str) -> str:
    """A native LangChain tool."""
    return f"Result: {param}"

# ext_tools loaded from extension MCP servers (see above)
all_tools = [my_native_tool] + ext_tools
agent = create_react_agent(model, all_tools)
```

## How telemetry is added

Use the `ExtensionTelemetryInterceptor` from the `extension_telemetry` module
(generated by Phase 2 of the `sap-agent-extensibility` skill). It implements
the `langchain-mcp-adapters` `ToolCallInterceptor` protocol and is passed via
the `tool_interceptors` parameter on `MultiServerMCPClient`. This is the
framework-native extension point.

> **Important**: The SDK's `extension_context()` sets OTel _baggage_ only
> (propagated to downstream services via HTTP headers). It does **not** set
> span attributes on the agent's own spans. `ExtensionTelemetryInterceptor`
> handles both: baggage via `extension_context()` and explicit span attributes
> via `tracer.start_as_current_span()`.

```python
from extension_telemetry import ExtensionTelemetryInterceptor

interceptor = ExtensionTelemetryInterceptor(ext_impl=ext_impl)
client = MultiServerMCPClient(
    {server_name: server_config},
    tool_interceptors=[interceptor],
)
tools = await client.get_tools()
```

This approach:

- Uses the framework-native `tool_interceptors` protocol from
  `langchain-mcp-adapters`
- Intercepts every tool call with both `extension_context` (baggage) and a
  dedicated tracer span (explicit `sap.extension.*` attributes)
- Extension metadata is visible in the agent's own traces, not just propagated
  to downstream services
- Preserves the original tool behavior while adding telemetry
