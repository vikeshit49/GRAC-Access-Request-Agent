"""
Payload-based tests for the Assistant SPII integration.

Each test loads a real request payload captured from formation_n8n.html and
asserts the response matches the corresponding captured response payload.
UUIDs in FragmentNames are generated at runtime, so those are verified by
prefix rather than exact value.

The handler is stateless — no in-memory store is seeded before exercising
unassign.
"""

import json
import os
import re
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from starlette.applications import Starlette
from starlette.testclient import TestClient

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

from api.spii import create_spii_routes
from services.spii_appfnd_assistant import AppFNDAssistantHandler
import services.spii_service as spii_service_module

PAYLOADS = Path(__file__).parent / "payloads" / "assistant"

# Test constants — match the values embedded in the payload files
ASSISTANT_DEST_INSTANCE_ID = "f1c3a8e2-9b47-4d60-b523-7e1a9c5d2f84"
ASSISTANT_AGW_BASE_URL = "https://jupiter.assistant-unit-test-dev-eu12.orbit.auttst.on.dwc.tools.sap"
ASSISTANT_IAS_TOKEN_SERVICE_URL = "https://assistant-unit-test-ias.accounts400.ondemand.com/oauth2/token"

# assignedTenant.globalTenantId from the assign request payload
ASSISTANT_ASSIGNED_GTID = "9e88a0c4-ab32-46d8-b1d3-07cbcac11831"


_UUID_SUFFIX = re.compile(
    r"-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
)


def _strip_uuid_suffix(name: str) -> str:
    """Strip a trailing UUID4 suffix from a FragmentName."""
    return _UUID_SUFFIX.sub("", name)


def load(filename: str) -> dict:
    return json.loads((PAYLOADS / filename).read_text())


@pytest.fixture(autouse=True)
def register_assistant_handler():
    """Register the AppFNDAssistantHandler in the service registry for these tests.

    The ORD template ships with one real dependency (``sap.btpn8n``) plus a
    placeholder a2a dependency that contains literal ``<…>`` bracketed
    namespace prefixes. Those placeholders would otherwise be registered as
    real keys here — harmless for the captured payload tests (which target
    ``sap.btpn8n``), but surprising in any test that sweeps the registry.
    Filter them out so only well-formed namespaces are registered.
    """
    handler = AppFNDAssistantHandler()
    ns = handler.application_namespace
    namespaces = [ns] if isinstance(ns, str) else list(ns)
    namespaces = [n for n in namespaces if "<" not in n and ">" not in n]
    original = dict(spii_service_module._HANDLER_REGISTRY)
    for n in namespaces:
        spii_service_module._HANDLER_REGISTRY[n] = handler
    yield
    spii_service_module._HANDLER_REGISTRY.clear()
    spii_service_module._HANDLER_REGISTRY.update(original)


@pytest.fixture
def client():
    routes = create_spii_routes()
    app = Starlette(routes=routes)
    return TestClient(app)


@pytest.fixture(autouse=True)
def env_vars():
    with patch.dict(os.environ, {
        "INITIATOR_MT_IAS_CLIENT_ID": "test-ias-client-id",
        "AGENT_PUBLIC_URL": ASSISTANT_AGW_BASE_URL,
    }):
        yield


def _mock_read_from_mount(base_volume_mount, base_var_name, module, instance, target):
    """Simulate read_from_mount_and_fallback_to_env_var writing instanceid onto target."""
    assert base_volume_mount == "/etc/secrets/appfnd"
    assert base_var_name == "CLOUD_SDK_CFG"
    assert module == "destination"
    assert instance == "default"
    target.instanceid = ASSISTANT_DEST_INSTANCE_ID


def _make_ias_user_fragment():
    """Build a mock IAS user fragment with known auth properties."""
    frag = MagicMock()
    frag.name = "sap-managed-runtime-agw-subscriber-ias-user-abc123"
    frag.properties = {
        "tokenService.body.resource": "urn:sap:identity:application:provider:name:sap-internal",
        "tokenServiceURL": ASSISTANT_IAS_TOKEN_SERVICE_URL,
        "URL": ASSISTANT_AGW_BASE_URL,
    }
    return frag


@patch(
    "services.sci_app2app_service.read_from_mount_and_fallback_to_env_var",
    side_effect=_mock_read_from_mount,
)
@patch("services.spii_appfnd_assistant.create_fragment_client")
def test_assign_returns_ready_with_fragments(mock_create_client, mock_read_from_mount, client):
    """Assign (both INITIAL) — agent returns READY with connectivity.fragments and openResourceDiscovery."""
    mock_fragment_client = MagicMock()
    mock_fragment_client.list_instance_fragments.return_value = [_make_ias_user_fragment()]
    mock_create_client.return_value = mock_fragment_client

    request = load("request_1_mcp_assign.json")
    expected = load("response_1_mcp_assign.json")

    response = client.patch("/v1/tenantMappings/2423dde2-c17a-42a4-93cb-a8c650868245", json=request)

    assert response.status_code == 200
    data = response.json()
    assert data["state"] == expected["state"]

    fragments = data["configuration"]["connectivity"]["fragments"]
    expected_fragments = expected["configuration"]["connectivity"]["fragments"]
    assert len(fragments) == len(expected_fragments)

    for fragment, exp_fragment in zip(fragments, expected_fragments):
        # FragmentName has a runtime UUID suffix — verify prefix only
        exp_prefix = _strip_uuid_suffix(exp_fragment["FragmentName"])
        assert fragment["FragmentName"].startswith(exp_prefix + "-")

        # Assert every field except FragmentName exactly
        for key, value in exp_fragment.items():
            if key != "FragmentName":
                assert fragment[key] == value, f"Fragment field '{key}' mismatch"

    # openResourceDiscovery must match exactly
    assert (
        data["configuration"]["openResourceDiscovery"]
        == expected["configuration"]["openResourceDiscovery"]
    )


def test_unassign_returns_ready(client):
    """Unassign — agent acknowledges with READY (no side effects)."""
    request = load("request_2_unassign.json")
    expected = load("response_2_unassign.json")

    response = client.patch("/v1/tenantMappings/2423dde2-c17a-42a4-93cb-a8c650868245", json=request)

    assert response.status_code == 200
    assert response.json() == expected


@patch(
    "services.sci_app2app_service.read_from_mount_and_fallback_to_env_var",
    side_effect=_mock_read_from_mount,
)
@patch("services.spii_appfnd_assistant.create_fragment_client")
def test_a2a_assign_returns_ready_with_agent_ord_id(mock_create_client, mock_read_from_mount, client):
    """Assign for an A2A partner agent (sap.agtappfndcg namespace) — the handler must use the
    agentOrdId label value (sap.agtappfndcg:agent:...) instead of the raw apiResource ordId,
    producing an agw-a2a fragment and the correct ordId in openResourceDiscovery."""
    mock_fragment_client = MagicMock()
    mock_fragment_client.list_instance_fragments.return_value = [_make_ias_user_fragment()]
    mock_create_client.return_value = mock_fragment_client

    request = load("request_3_a2a_assign.json")
    expected = load("response_3_a2a_assign.json")

    response = client.patch("/v1/tenantMappings/2423dde2-c17a-42a4-93cb-a8c650868245", json=request)

    assert response.status_code == 200
    data = response.json()
    assert data["state"] == expected["state"]

    fragments = data["configuration"]["connectivity"]["fragments"]
    expected_fragments = expected["configuration"]["connectivity"]["fragments"]
    assert len(fragments) == len(expected_fragments)

    for fragment, exp_fragment in zip(fragments, expected_fragments):
        exp_prefix = _strip_uuid_suffix(exp_fragment["FragmentName"])
        assert fragment["FragmentName"].startswith(exp_prefix + "-")

        for key, value in exp_fragment.items():
            if key != "FragmentName":
                assert fragment[key] == value, f"Fragment field '{key}' mismatch"

    assert (
        data["configuration"]["openResourceDiscovery"]
        == expected["configuration"]["openResourceDiscovery"]
    )
