"""
Unit tests for the AppFND Assistant SPII handler.

Covers:
- Loading (ordId, integrationMode) pairs from the ORD doc.
- Namespace discovery used for SPII routing.
- Per-mode fragment construction (URL suffix, FragmentName infix, label type).
- End-to-end fragment creation with mixed mcp+a2a inputs sharing a single
  IAS-fragment lookup.
- Failure when integrationMode label is missing/unknown.
- ``sap.agt*`` soft fallback (handler routes the namespace and returns READY
  without provisioning fragments when no exact ORD apiResource matches).
"""

import os
import sys
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

from services.spii_appfnd_assistant import (  # noqa: E402
    AppFNDAssistantHandler,
    INTEGRATION_MODE_LABEL,
    IntegrationMode,
    _load_ord_integration_dependencies,
    _load_supported_namespaces,
    _resolve_integration_mode,
)


# ---- ORD loader ----------------------------------------------------------

def test_load_supported_namespaces_includes_both_targets():
    namespaces = _load_supported_namespaces()
    assert "sap.btpn8n" in namespaces
    assert "sap.agtappfndcg" in namespaces


def test_load_ord_integration_dependencies_for_n8n_returns_mcp():
    pairs = _load_ord_integration_dependencies("sap.btpn8n")
    assert pairs == [
        ("sap.btpn8n:apiResource:ManagedN8nMcpServer:v1", IntegrationMode.MCP),
    ]


def test_load_ord_integration_dependencies_for_agta14_returns_a2a():
    pairs = _load_ord_integration_dependencies("sap.agtappfndcg")
    assert pairs == [
        ("sap.agtappfndcg:apiResource:btp-appfnd-agent-test-14:v1", IntegrationMode.A2A),
    ]


def test_load_ord_integration_dependencies_unknown_namespace_is_empty():
    assert _load_ord_integration_dependencies("does.not.exist") == []


# ---- _resolve_integration_mode ------------------------------------------

def test_resolve_integration_mode_accepts_known_values():
    assert _resolve_integration_mode({"labels": {INTEGRATION_MODE_LABEL: ["mcp"]}}) is IntegrationMode.MCP
    assert _resolve_integration_mode({"labels": {INTEGRATION_MODE_LABEL: ["a2a"]}}) is IntegrationMode.A2A


def test_resolve_integration_mode_missing_label_raises():
    with pytest.raises(ValueError, match="integrationMode"):
        _resolve_integration_mode({"ordId": "x", "labels": {}})


def test_resolve_integration_mode_unknown_value_raises():
    with pytest.raises(ValueError, match="integrationMode"):
        _resolve_integration_mode({"ordId": "x", "labels": {INTEGRATION_MODE_LABEL: "rest"}})


def test_resolve_integration_mode_no_labels_key_raises():
    with pytest.raises(ValueError, match="integrationMode"):
        _resolve_integration_mode({"ordId": "x"})


# ---- _build_fragment ----------------------------------------------------

@pytest.fixture
def handler():
    return AppFNDAssistantHandler()


COPIED_PROPS = {
    "tokenService.body.resource": "urn:sap:identity:application:provider:name:sap-internal",
    "tokenServiceURL": "https://example.com/oauth2/token",
}


def test_build_fragment_mcp_uses_mcp_url_and_name(handler):
    fragment = handler._build_fragment(
        ord_id="sap.btpn8n:apiResource:ManagedN8nMcpServer:v1",
        mode=IntegrationMode.MCP,
        copied_properties=COPIED_PROPS,
        agw_base_url="https://agw.example.com",
        gtid="tenant-1",
        instance_id="inst-1",
    )
    assert fragment["URL"] == (
        "https://agw.example.com/v1/mcp/sap.btpn8n:apiResource:ManagedN8nMcpServer:v1/tenant-1"
    )
    assert fragment["FragmentName"].startswith("sap-managed-runtime-agw-mcp-")
    assert fragment["$metadata"]["instanceId"] == "inst-1"
    label_types = [
        v for label in fragment["$metadata"]["labels"]
        if label["key"] == "sap-managed-runtime-type"
        for v in label["values"]
    ]
    assert label_types == ["agw.mcp.server"]


def test_build_fragment_a2a_uses_a2a_url_and_name(handler):
    fragment = handler._build_fragment(
        ord_id="sap.agta14:apiResource:agent-14:v1",
        mode=IntegrationMode.A2A,
        copied_properties=COPIED_PROPS,
        agw_base_url="https://agw.example.com/",  # trailing slash is fine because caller rstrips
        gtid="tenant-1",
        instance_id="inst-1",
    )
    # caller rstrips, but verify the segment regardless
    assert "/v1/a2a/sap.agta14:apiResource:agent-14:v1/tenant-1" in fragment["URL"]
    assert fragment["FragmentName"].startswith("sap-managed-runtime-agw-a2a-")
    label_types = [
        v for label in fragment["$metadata"]["labels"]
        if label["key"] == "sap-managed-runtime-type"
        for v in label["values"]
    ]
    assert label_types == ["agw.a2a.server"]


def test_build_fragment_carries_copied_properties(handler):
    fragment = handler._build_fragment(
        ord_id="sap.x:apiResource:y:v1",
        mode=IntegrationMode.MCP,
        copied_properties=COPIED_PROPS,
        agw_base_url="https://agw.example.com",
        gtid="t",
        instance_id="i",
    )
    for k, v in COPIED_PROPS.items():
        assert fragment[k] == v
    # URL/Authentication must come from the build logic, not from copied props
    assert fragment["URL"].startswith("https://agw.example.com/v1/mcp/")


def test_build_fragment_includes_gtid_and_ord_id_labels(handler):
    fragment = handler._build_fragment(
        ord_id="sap.x:apiResource:y:v1",
        mode=IntegrationMode.A2A,
        copied_properties={},
        agw_base_url="https://agw.example.com",
        gtid="my-tenant",
        instance_id="i",
    )
    labels = {label["key"]: label["values"] for label in fragment["$metadata"]["labels"]}
    assert labels["sap-managed-runtime-gtid"] == ["my-tenant"]
    assert labels["sap-managed-runtime-ordid"] == ["sap.x-apiResource-y-v1"]


# ---- _create_fragments_for_ord_ids --------------------------------------

def _mock_ias_fragment(properties=None, name=None):
    frag = MagicMock()
    frag.name = name or "sap-managed-runtime-agw-subscriber-ias-user-uuid"
    frag.properties = properties or {
        "URL": "https://agw.example.com",
        "Authentication": "OAuth2ClientCredentials",
        "tokenServiceURL": "https://idp.example.com/oauth2/token",
        "tokenService.body.resource": "urn:sap:identity:application:provider:name:sap-internal",
    }
    return frag


@patch("services.spii_appfnd_assistant.create_fragment_client")
def test_create_fragments_for_ord_ids_mixed_modes(mock_factory, handler):
    client = MagicMock()
    client.list_instance_fragments.return_value = [_mock_ias_fragment()]
    mock_factory.return_value = client

    ord_pairs = [
        ("sap.btpn8n:apiResource:ManagedN8nMcpServer:v1", IntegrationMode.MCP),
        ("sap.agtappfndcg:apiResource:btp-appfnd-agent-test-14:v1", IntegrationMode.A2A),
    ]

    fragments = handler._create_fragments_for_ord_ids(
        receiver_gtid="receiver-tenant-1",
        assigned_gtid="tenant-1",
        subdomain="my-subdomain",
        instance_id="inst-1",
        ord_dependencies=ord_pairs,
    )

    assert len(fragments) == 2
    mcp = next(f for f in fragments if "/v1/mcp/" in f["URL"])
    a2a = next(f for f in fragments if "/v1/a2a/" in f["URL"])
    assert mcp["FragmentName"].startswith("sap-managed-runtime-agw-mcp-")
    assert a2a["FragmentName"].startswith("sap-managed-runtime-agw-a2a-")

    # Auth/token props are copied identically to both fragments.
    assert mcp["tokenServiceURL"] == a2a["tokenServiceURL"]
    assert mcp["tokenService.body.resource"] == a2a["tokenService.body.resource"]

    # URL and Authentication from the IAS fragment must NOT bleed into copied_properties.
    assert mcp["URL"] != "https://agw.example.com"
    assert "Authentication" not in mcp


@patch("services.spii_appfnd_assistant.create_fragment_client")
def test_create_fragments_for_ord_ids_missing_gtid_raises(mock_factory, handler):
    with pytest.raises(ValueError, match="globalTenantId"):
        handler._create_fragments_for_ord_ids(
            receiver_gtid="",
            assigned_gtid="assigned-1",
            subdomain="s",
            instance_id="i",
            ord_dependencies=[("sap.x:apiResource:y:v1", IntegrationMode.MCP)],
        )
    mock_factory.assert_not_called()


@patch("services.spii_appfnd_assistant.create_fragment_client")
def test_create_fragments_for_ord_ids_empty_dependencies_raises(mock_factory, handler):
    with pytest.raises(ValueError, match="No ORD IDs"):
        handler._create_fragments_for_ord_ids(
            receiver_gtid="tenant-1",
            assigned_gtid="assigned-1",
            subdomain="s",
            instance_id="i",
            ord_dependencies=[],
        )
    mock_factory.assert_not_called()


@patch("services.spii_appfnd_assistant.create_fragment_client")
def test_create_fragments_for_ord_ids_no_ias_fragment_raises(mock_factory, handler):
    client = MagicMock()
    client.list_instance_fragments.return_value = []
    mock_factory.return_value = client

    with pytest.raises(ValueError, match="No IAS fragment"):
        handler._create_fragments_for_ord_ids(
            receiver_gtid="tenant-1",
            assigned_gtid="assigned-1",
            subdomain="s",
            instance_id="i",
            ord_dependencies=[("sap.x:apiResource:y:v1", IntegrationMode.MCP)],
        )


# ---- sap.agt* fallback --------------------------------------------------

def test_matches_fallback_accepts_sap_agt_prefix(handler):
    assert handler.matches_fallback("sap.agt-anything")
    assert handler.matches_fallback("sap.agtappfndcg")


def test_matches_fallback_rejects_other_namespaces(handler):
    assert not handler.matches_fallback("sap.unknown")
    assert not handler.matches_fallback("sap.joule")
    assert not handler.matches_fallback("")


def test_assign_fallback_returns_ready_without_fragments(handler):
    """sap.agt* namespace with no matching ORD deps → READY, no fragments, no client call."""
    from services.spii_base import AssignmentState

    assignment_id = "assignment-fallback-1"
    notification_data = {
        "context": {
            "uclFormationId": "f-1",
            "uclFormationTypeId": "ft-1",
        },
        "receiverTenant": {
            "globalTenantId": "receiver-gtid",
            "subdomain": "sub",
        },
        "assignedTenant": {
            "globalTenantId": "assigned-gtid",
            "applicationNamespace": "sap.agt-experimental",
        },
    }

    with patch(
        "services.spii_appfnd_assistant._load_ord_integration_dependencies",
        return_value=[],
    ), patch(
        "services.spii_appfnd_assistant.create_fragment_client",
    ) as fragment_client_factory:
        result = handler.handle_assign(
            ucl_assignment_id=assignment_id,
            receiver_state="INITIAL",
            assigned_state="INITIAL",
            assigned_config=None,
            notification_data=notification_data,
            tenant_id="t",
        )

    assert result.state == AssignmentState.READY.value
    assert result.configuration is None
    fragment_client_factory.assert_not_called()
