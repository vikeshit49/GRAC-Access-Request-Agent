"""
SPII Handler for App Foundation Assistant formation type.

Creates Destination Fragments for each ORD integration dependency,
inheriting IAS fragment properties and enriching with assigned tenant
data and ORD metadata. Returns a READY response with the fragment
configuration so UCL can forward it to a Destination Facilitator.

Each integrationDependency declares its integration kind via the
`integrationMode` label (`mcp` or `a2a`); the kind decides only the
URL suffix and naming scheme of the resulting fragment, so both modes
share the same fragment-building code path.
"""

import json
import logging
import re
import uuid
from enum import StrEnum
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple

from sap_cloud_sdk.destination import (
    Label,
    ListOptions,
    create_fragment_client,
)
from services.spii_base import (
    SPIIFormationHandler,
    AssignmentState,
    StatusReport,
)

from services.sci_app2app_service import FragmentLabelKey, FragmentTypeValue, _get_destination_instance_id

logger = logging.getLogger(__name__)

ORD_SYSTEM_TYPE_PATH = Path(__file__).resolve().parent.parent / "ord" / "system_type.json"

INTEGRATION_MODE_LABEL = "integrationMode"

# Assistant accepts any namespace starting with "sap.agt" as a soft fallback:
# if no integrationDependency apiResource matches the request's
# applicationNamespace exactly, but the namespace is in the sap.agt* family,
# we still acknowledge with READY (no fragment created). This lets Assistant
# tenants whose ORD declarations don't (yet) include this agent's dependencies
# proceed without a hard 422.
_ASSISTANT_FALLBACK_PATTERN = re.compile(r"sap\.agt")


class IntegrationMode(StrEnum):
    MCP = "mcp"
    A2A = "a2a"


# Per-mode wiring for fragment URL suffix, FragmentName infix, and the
# `sap-managed-runtime-type` label value. Adding a new mode = one row here.
_INTEGRATION_MODE_CONFIG: Dict[IntegrationMode, Dict[str, str]] = {
    IntegrationMode.MCP: {
        "url_segment": "v1/mcp",
        "name_infix": "agw-mcp",
        "label_type": "agw.mcp.server",
    },
    IntegrationMode.A2A: {
        "url_segment": "v1/a2a",
        "name_infix": "agw-a2a",
        "label_type": "agw.a2a.server",
    },
}


def _iter_integration_dependency_resources() -> Iterator[Tuple[Dict[str, Any], Dict[str, Any]]]:
    """Yield (integrationDependency, apiResource) pairs from the ORD doc."""
    with open(ORD_SYSTEM_TYPE_PATH) as f:
        doc = json.load(f)
    for dep in doc.get("integrationDependencies", []):
        for aspect in dep.get("aspects", []):
            for api_resource in aspect.get("apiResources", []):
                yield dep, api_resource


def _resolve_integration_mode(integration_dependency: Dict[str, Any]) -> IntegrationMode:
    # Per ORD spec, every label value is a list. In the case of the
    # integrationMode, it is a list of strings. We expect exactly one entry — either
    # "mcp" or "a2a".
    raw = (integration_dependency.get("labels") or {}).get(INTEGRATION_MODE_LABEL)
    value = raw[0] if isinstance(raw, list) and len(raw) == 1 else raw
    try:
        return IntegrationMode(value)
    except (ValueError, TypeError) as exc:
        ord_id = integration_dependency.get("ordId", "<unknown>")
        raise ValueError(
            f"integrationDependency {ord_id} is missing or has unknown "
            f"`{INTEGRATION_MODE_LABEL}` label (got {raw!r}); expected a "
            f"single-element list with one of {[m.value for m in IntegrationMode]}"
        ) from exc


def _resolve_effective_ord_id(api_resource: Dict[str, Any]) -> str:
    """Return agentOrdId label value when present, otherwise the ordId field.

    Workaround for ORD requiring the apiResource entity type in aspects while
    A2A agent integrations should use the agent entity type in SPII responses.
    """
    label = (api_resource.get("labels") or {}).get("agentOrdId")
    if isinstance(label, list) and label:
        return label[0]
    return api_resource.get("ordId", "")


def _load_supported_namespaces() -> List[str]:
    """Extract target namespaces from apiResources inside integrationDependency aspects.

    The SPII routing key is the target system's namespace (e.g. sap.btpn8n),
    derived from the ordId of each referenced apiResource.
    """
    namespaces: List[str] = []
    for _dep, api_resource in _iter_integration_dependency_resources():
        namespace = _resolve_effective_ord_id(api_resource).split(":")[0]
        if namespace and namespace not in namespaces:
            namespaces.append(namespace)
    return namespaces


def _load_ord_integration_dependencies(system_type: str) -> List[Tuple[str, IntegrationMode]]:
    """Return (ordId, integrationMode) pairs for apiResources whose namespace matches.

    The mode comes from the parent integrationDependency's `integrationMode`
    label. Missing or unknown values raise ValueError — the ORD doc is the
    source of truth and silent defaults would mask misconfiguration.

    Matching is prefix-aware: ``system_type`` is the incoming
    ``applicationNamespace`` from UCL (e.g. ``sap.sf``), while the ORD doc may
    declare apiResource ordIds under a subnamespace (e.g.
    ``sap.sf.wfs:apiResource:...``). Both the exact namespace and any
    subnamespace of ``system_type`` are accepted.
    """
    pairs: List[Tuple[str, IntegrationMode]] = []
    for dep, api_resource in _iter_integration_dependency_resources():
        ord_id = _resolve_effective_ord_id(api_resource)
        ord_namespace = ord_id.split(":")[0]
        if not (
            ord_id.startswith(system_type + ":")           # exact namespace match
            or ord_namespace.startswith(system_type + ".") # ORD is a subnamespace of incoming
        ):
            continue
        pairs.append((ord_id, _resolve_integration_mode(dep)))
    return pairs


class AppFNDAssistantHandler(SPIIFormationHandler):
    """Handles SPII assign/unassign for the App Foundation Assistant formation type."""

    @property
    def application_namespace(self) -> Sequence[str]:
        return _load_supported_namespaces()

    def matches_fallback(self, application_namespace: str) -> bool:
        """Accept any ``sap.agt*`` namespace as a soft fallback.

        Returning True here tells the Facade to route this notification to us
        even though ``application_namespace`` is not in our declared list. We
        then short-circuit ``handle_assign`` to a fragment-less READY.
        """
        return bool(_ASSISTANT_FALLBACK_PATTERN.match(application_namespace))

    def handle_assign(
        self,
        ucl_assignment_id: str,
        receiver_state: str,
        assigned_state: str,
        assigned_config: Optional[Dict[str, Any]],
        notification_data: Dict[str, Any],
        tenant_id: str,
    ) -> StatusReport:
        receiver_tenant = notification_data.get("receiverTenant", {})
        assigned_tenant = notification_data.get("assignedTenant", {})

        receiver_gtid = receiver_tenant.get("globalTenantId", "")
        assigned_gtid = assigned_tenant.get("globalTenantId", "")
        subdomain = receiver_tenant.get("subdomain", "")
        instance_id = _get_destination_instance_id()

        application_namespace = assigned_tenant.get("applicationNamespace", "")
        ord_dependencies = _load_ord_integration_dependencies(application_namespace)

        # Fallback path: no ORD apiResource ordId matches this namespace, but
        # it's in the sap.agt* family. Acknowledge READY without creating
        # fragments — there's nothing to wire up.
        if not ord_dependencies and _ASSISTANT_FALLBACK_PATTERN.match(application_namespace):
            logger.info(
                f"AppFND Assistant assign: namespace={application_namespace} "
                f"matches sap.agt* fallback — returning READY without fragments"
            )
            return StatusReport(state=AssignmentState.READY)

        created_fragments = self._create_fragments_for_ord_ids(
            receiver_gtid=receiver_gtid,
            assigned_gtid=assigned_gtid,
            subdomain=subdomain,
            instance_id=instance_id,
            ord_dependencies=ord_dependencies,
        )

        configuration = {
            "connectivity": {
                "fragments": created_fragments,
            },
            "openResourceDiscovery": {
                "integrationDependencies": [
                    {"ordId": ord_id} for ord_id, _ in ord_dependencies
                ]
            },
        }

        logger.info(
            f"AppFND Assistant assign: assignment={ucl_assignment_id}, "
            f"tenant={tenant_id}, assigned_gtid={assigned_gtid}, state=READY"
        )

        return StatusReport(state=AssignmentState.READY, configuration=configuration)

    def _create_fragments_for_ord_ids(
        self,
        receiver_gtid: str,
        assigned_gtid: str,
        subdomain: str,
        instance_id: str,
        ord_dependencies: List[Tuple[str, IntegrationMode]],
    ) -> List[Dict[str, Any]]:
        """Create one Destination Fragment per (ordId, integrationMode) pair.

        Looks up the IAS fragment for this tenant, copies its auth properties
        (everything except URL/Authentication), and delegates the per-pair
        fragment construction to `_build_fragment`.
        """
        if not receiver_gtid:
            raise ValueError(
                "receiverTenant.globalTenantId is missing — cannot create IAS fragments"
            )

        if not assigned_gtid:
            raise ValueError(
                "assignedTenant.globalTenantId is missing — cannot create IAS fragments"
            )

        if not ord_dependencies:
            raise ValueError(
                "No ORD IDs found in integrationDependencies — cannot create IAS fragments"
            )

        fragment_client = create_fragment_client(instance="default")

        ias_fragments = fragment_client.list_instance_fragments(
            filter=ListOptions(
                filter_labels=[
                    Label(key=FragmentLabelKey.GTID, values=[receiver_gtid]),
                    Label(key=FragmentLabelKey.TYPE, values=[FragmentTypeValue.SUBSCRIBER_IAS_USER]),
                ]
            ),
            tenant=subdomain,
        )
        ias_fragment = next(iter(ias_fragments), None)
        if not ias_fragment:
            raise ValueError(
                f"No IAS fragment found for receiver_gtid={receiver_gtid} — cannot create destination fragments"
            )

        copied_properties = {
            k: v
            for k, v in (ias_fragment.properties or {}).items()
            if k not in ("URL", "Authentication")
        }
        agw_base_url = (ias_fragment.properties or {}).get("URL", "").rstrip("/")

        return [
            self._build_fragment(
                ord_id=ord_id,
                mode=mode,
                copied_properties=copied_properties,
                agw_base_url=agw_base_url,
                gtid=assigned_gtid,
                instance_id=instance_id,
            )
            for ord_id, mode in ord_dependencies
        ]

    def _build_fragment(
        self,
        ord_id: str,
        mode: IntegrationMode,
        copied_properties: Dict[str, Any],
        agw_base_url: str,
        gtid: str,
        instance_id: str,
    ) -> Dict[str, Any]:
        config = _INTEGRATION_MODE_CONFIG[mode]
        sanitized_ord_id = ord_id.replace(":", "-").replace("/", "-")
        fragment_name = f"sap-managed-runtime-{config['name_infix']}-{uuid.uuid4()}"
        fragment_url = f"{agw_base_url}/{config['url_segment']}/{ord_id}/{gtid}"

        fragment_labels = [
            {"key": FragmentLabelKey.TYPE, "values": [config["label_type"]]},
            {"key": FragmentLabelKey.GTID, "values": [gtid]},
            {"key": FragmentLabelKey.ORD_ID, "values": [sanitized_ord_id]},
        ]

        logger.info(
            f"Fragment created: {fragment_name} for gtid={gtid}, ordId={ord_id}, mode={mode.value}"
        )

        return {
            **copied_properties,
            "FragmentName": fragment_name,
            "URL": fragment_url,
            "$metadata": {
                "labels": fragment_labels,
                "instanceId": instance_id,
            },
        }

    def handle_unassign(
        self,
        ucl_assignment_id: str,
        notification_data: Dict[str, Any],
    ) -> StatusReport:
        logger.info(f"AppFND Assistant unassign: assignment={ucl_assignment_id}")
        return StatusReport(state=AssignmentState.READY)
