# ORD Integration Dependencies — The Source of Truth for Assistant SPII Routing

This reference explains **why and how** the Assistant SPII handler is driven entirely by the agent's ORD `integrationDependencies` declaration.

## The Core Idea

Most SPII handlers in this catalog (`sap-agw-spii-implementation`, `sap-als-spii-implementation`, `sap-joule-spii-implementation`) hard-code a single `applicationNamespace` constant — `sap.agw`, `sap.als`, `sap.joule`. The Assistant handler does not. Its set of accepted namespaces is **whatever the agent's ORD document declares as integration dependencies**, plus a soft fallback for any `sap.agt*` namespace.

This inversion has two consequences:

1. **Adding a new partner system never touches Python.** The developer edits `app/ord/system_type.json`, restarts the agent, and the new namespace is automatically registered with the SPII Facade.
2. **The developer must know the partner's exact ORD IDs.** Wrong `ordId` = SPII notifications for that integration will never reach this handler via exact match (though `sap.agt*` requests may still land here through the fallback path described below). There is no fuzzy matching, no auto-discovery beyond the `sap.agt*` family.

## How the Namespace Prefix Is Derived

Every ORD ID has the shape `<namespace>:<resourceType>:<localId>:<version>`, e.g.:

```
sap.btpn8n:apiResource:ManagedN8nMcpServer:v1
└── ↑ this is the namespace prefix
```

The handler's `_load_supported_namespaces()` walks `integrationDependencies[].aspects[].apiResources[].ordId`, splits on `:`, and collects the first segment of each. So the ORD above produces `["sap.btpn8n"]`. UCL sends `assignedTenant.applicationNamespace = "sap.btpn8n"` for that integration, and the Facade dispatches to the Assistant handler.

### Subnamespace Case

The incoming `applicationNamespace` from UCL may be a **parent namespace** (e.g. `sap.sf`) while the ORD doc declares apiResource ordIds under a **subnamespace** (e.g. `sap.sf.wfs:apiResource:SomeThing:v1`). This is the normal pattern when a product family uses a top-level namespace in UCL but publishes ORD resources under product-specific sub-namespaces.

`_load_supported_namespaces()` registers `sap.sf.wfs` in the handler registry. The Facade's `_resolve_handler` then bridges the gap: after an exact match miss on `sap.sf`, it checks whether any registered key starts with `sap.sf.` — finding `sap.sf.wfs` and routing to the Assistant handler.

`_load_ord_integration_dependencies(system_type)` similarly uses prefix-aware matching: it accepts ordIds whose namespace is exactly `system_type` **or** starts with `system_type + "."`. So passing `sap.sf` as `system_type` matches both `sap.sf:apiResource:...` and `sap.sf.wfs:apiResource:...` ordIds.

## What "Knowing the ORD IDs" Looks Like in Practice

Before adding an integration dependency, the developer must answer:

1. **What partner system is being integrated?** (e.g., the Managed N8N MCP Server)
2. **What is its published ORD ID for the API resource we consume?** (e.g., `sap.btpn8n:apiResource:ManagedN8nMcpServer:v1`)
3. **Does the partner system actually expose that ORD ID?** (i.e., is its ORD document live and reachable, with the resource we expect?)

The right place to look is the partner system's own ORD endpoint (typically `/well-known/open-resource-discovery`). Treat the ORD ID like a URL — copy it exactly, including the version segment. Typos in the namespace, the resource type, the local ID, or the version all break routing.

If the partner system's ORD is not yet published, the integration is not ready to wire up via this handler. Push for the partner to publish their ORD first.

## Adding a New Integration Dependency

Edit `app/ord/system_type.json` and append to `integrationDependencies`:

```json
{
  "ordId": "<vendor-namespace>:integrationDependency:NewPartner:v1",
  "version": "1.0.0",
  "title": "New Partner API",
  "description": "<what this integration enables>",
  "releaseStatus": "active",
  "visibility": "internal",
  "partOfPackage": "<vendor-namespace>:package:<your-agent>:v1",
  "mandatory": false,
  "aspects": [
    {
      "title": "New Partner API Access",
      "mandatory": false,
      "apiResources": [
        { "ordId": "<partner-namespace>:apiResource:NewPartner:v1" }
      ]
    }
  ],
  "labels": {
    "integrationMode": ["mcp"]
  }
}
```

`labels.integrationMode` is **required** and must be a single-element list
containing either `"mcp"` (the partner exposes an MCP server proxied by the
Agent Gateway) or `"a2a"` (the partner is itself an A2A agent). ORD label
values are always lists per spec, so this label follows that convention.
The mode selects the URL segment (`v1/mcp/...` vs `v1/a2a/...`), the
FragmentName infix (`agw-mcp` vs `agw-a2a`), and the
`sap-managed-runtime-type` label (`agw.mcp.server` vs `agw.a2a.server`) on
the resulting Destination Fragment. A missing/unknown value, or a list with
zero or more than one entry, raises `ValueError` from
`_resolve_integration_mode()` rather than silently defaulting — a wrong
mode would publish a fragment wired to the wrong URL.

Also append the dependency's outer ORD ID to the agent's own `integrationDependencies` shorthand list under `agents[0].integrationDependencies` so the agent description stays consistent:

```json
"agents": [
  {
    "integrationDependencies": [
      "<vendor-namespace>:integrationDependency:ManagedN8nMcpServer:v1",
      "<vendor-namespace>:integrationDependency:NewPartner:v1"
    ]
  }
]
```

Restart the agent process. The `_HANDLER_REGISTRY` is rebuilt at startup, the new namespace is picked up, and the next SPII notification for `<partner-namespace>` lands in the Assistant handler.

## Per-ORD-ID Fragment Fan-Out

Once a notification arrives for a matched namespace, the handler calls `_load_ord_integration_dependencies(application_namespace)` to get **only the (ordId, integrationMode) pairs that share that namespace prefix**. Each pair becomes a separate Destination Fragment in the response, with shape selected by the mode:

```
For each (ord_id, mode) in matching pairs:
  url_segment = "v1/mcp" if mode == MCP else "v1/a2a"
  fragment_url = f"{agw_url}/{url_segment}/{ord_id}/{gtid}"
  → one fragment, inheriting auth from the IAS user fragment, labelled with this ord_id
    and `sap-managed-runtime-type` set to `agw.mcp.server` or `agw.a2a.server`
```

This means a single SPII assign can produce **multiple fragments**, each potentially in a different mode — useful when one partner namespace exposes several API resources the agent consumes in the same formation.

## The `sap.agt*` Soft Fallback

If a SPII notification arrives with an `applicationNamespace` that does **not** match any apiResource namespace prefix declared in the ORD, but whose value matches the regex `sap\.agt`, the Assistant handler still accepts it through the Facade's fallback path (`SPIIFormationHandler.matches_fallback`). In that case `handle_assign` short-circuits to a fragment-less `READY` — nothing is built, nothing is stored, the assign is simply acknowledged.

This exists so Assistant tenants whose ORD declarations don't (yet) include this agent's dependencies can be onboarded without a hard 422. It is intentionally narrow: only the `sap.agt*` family bypasses the exact-match check, and even then no fragments are wired up.

The fallback is opt-in per handler. The Assistant handler is the only one that overrides `matches_fallback` today; every other handler (`sap-agw-spii-implementation`, `sap-joule-spii-implementation`, `sap-als-spii-implementation`) keeps the default `return False` and routes by exact match only.

## Common Pitfalls

| Symptom | Cause | Fix |
|---|---|---|
| SPII notification returns HTTP 400 "Unsupported applicationNamespace" | The namespace prefix in the partner's `applicationNamespace` doesn't appear in the agent's ORD and is not in the `sap.agt*` family | Add the partner's `apiResource.ordId` to a new or existing `integrationDependencies[].aspects[].apiResources` entry |
| Incoming parent namespace (e.g. `sap.sf`) returns 400 even though an ordId under `sap.sf.wfs` exists | `_resolve_handler` in `spii_service.py` is missing the subnamespace fallback step (`key.startswith(application_namespace + ".")`) | Ensure `_resolve_handler` includes the step-2 subnamespace check; this is shipped by `sap-agw-spii-implementation` ≥ the version that added subnamespace support |
| Notification dispatches to handler but raises `"No ORD IDs found in integrationDependencies"` | The namespace matches routing but `_load_ord_integration_dependencies` uses strict `startswith(system_type + ":")` and misses subnamespace ordIds | Ensure `_load_ord_integration_dependencies` also checks `ord_namespace.startswith(system_type + ".")` |
| Notification raises `"integrationDependency ... is missing or has unknown integrationMode label"` | The matching integrationDependency has no `labels.integrationMode`, or its value is not a single-element list with `mcp`/`a2a` (e.g. it's a bare string `"mcp"`, an empty list, or a list with two values) | Set `"labels": {"integrationMode": ["mcp"]}` (or `["a2a"]`) — single-element list, no bare string. The mode is mandatory — the handler refuses to guess. |
| Notification raises `"No IAS fragment found for gtid=…"` | The Agent Gateway SPII flow that creates the IAS user fragment has not run yet for this tenant, or the fragment exists but lacks the `TYPE = SUBSCRIBER_IAS_USER` label the Assistant handler filters on | Ensure the Agent Gateway formation is assigned before the Assistant formation, and that `sci_app2app_service.py` writes the `SUBSCRIBER_IAS_USER` TYPE label on the IAS user fragment. |
| `sap.agt*` namespace returns READY but no fragment is created | This is the soft fallback path — no exact ORD match was found, and the handler returned a fragment-less READY by design | If you expected a fragment, the partner's `apiResource.ordId` is missing from `integrationDependencies` — add it. If a fragment-less READY was the intent, there's nothing to fix. |
| Edits to `system_type.json` don't take effect | `_load_supported_namespaces()` runs once at registry-build time | Restart the agent process |

## Why Not Compute Namespaces Dynamically Per Request?

Reading the ORD file on every notification would tolerate hot edits but adds latency, file-IO failure modes, and the surprising property that two simultaneous notifications could see different namespace lists. Reading once at startup matches the deployment lifecycle (config changes ship with restarts) and keeps the dispatch path fast. The cost is the small operational discipline of restarting after ORD edits — acceptable given how rarely integrations change.
