# Testing the Assistant SPII

## Automated Tests

```bash
# From project root — run all Assistant SPII tests including payload-based tests
python3 -m pytest tests/test_spii_assistant_payloads.py tests/test_spii_appfnd_assistant.py -v
```

### Test Organization

| File | What it covers | What it mocks |
|------|----------------|---------------|
| `tests/test_spii_appfnd_assistant.py` | ORD-loader behaviour (namespaces and `(ordId, mode)` pairs from `system_type.json`), `_resolve_integration_mode` accept/reject paths, per-mode `_build_fragment` shape, mixed MCP+A2A `_create_fragments_for_ord_ids` fan-out, and the `sap.agt*` soft-fallback path of `handle_assign` | `create_fragment_client`; selected tests also patch `_load_ord_integration_dependencies` |
| `tests/test_spii_assistant_payloads.py` | **Real captured payloads** — each test sends an exact request JSON and asserts the exact response JSON from `tests/payloads/assistant/` | `create_fragment_client` (IAS fragment lookup); `read_from_mount_and_fallback_to_env_var` (destination instance ID) |

### Unit Tests (`tests/test_spii_appfnd_assistant.py`)

The unit tests exercise the handler at three layers — pure ORD parsing, per-fragment building, and a small end-to-end slice through `_create_fragments_for_ord_ids` — without going through the PATCH route. They read the on-disk `app/ord/system_type.json` for the parser tests; everything else patches the ORD loader. They complement — they do not duplicate — the payload-based tests.

| Group | Tests | What they check |
|-------|-------|-----------------|
| ORD loader | `test_load_supported_namespaces_includes_both_targets`, `test_load_ord_integration_dependencies_for_n8n_returns_mcp`, `test_load_ord_integration_dependencies_for_agta14_returns_a2a`, `test_load_ord_integration_dependencies_unknown_namespace_is_empty` | The loaders walk the template ORD and surface both target namespaces, return the right `(ordId, IntegrationMode)` pair per namespace, and return an empty list for unknown namespaces |
| `_resolve_integration_mode` | `test_resolve_integration_mode_accepts_known_values`, `test_resolve_integration_mode_missing_label_raises`, `test_resolve_integration_mode_unknown_value_raises`, `test_resolve_integration_mode_no_labels_key_raises` | Single-element lists `["mcp"]` / `["a2a"]` accepted; missing/unknown/no-labels variants raise `ValueError` rather than silently defaulting (a wrong mode would publish a fragment wired to the wrong URL) |
| `_build_fragment` | `test_build_fragment_mcp_uses_mcp_url_and_name`, `test_build_fragment_a2a_uses_a2a_url_and_name`, `test_build_fragment_carries_copied_properties`, `test_build_fragment_includes_gtid_and_ord_id_labels` | Each mode produces the right URL segment, FragmentName infix, and `sap-managed-runtime-type` label; `copied_properties` flow through verbatim while `URL`/`Authentication` come from the build logic; `sap-managed-runtime-gtid` and `sap-managed-runtime-ordid` are populated |
| `_create_fragments_for_ord_ids` | `test_create_fragments_for_ord_ids_mixed_modes`, `test_create_fragments_for_ord_ids_missing_gtid_raises`, `test_create_fragments_for_ord_ids_empty_dependencies_raises`, `test_create_fragments_for_ord_ids_no_ias_fragment_raises` | One MCP + one A2A pair produces two fragments sharing the same auth properties but distinct URL/FragmentName shapes; missing `globalTenantId`, empty `ord_dependencies`, and "no IAS fragment found" each raise `ValueError` |
| `sap.agt*` fallback | `test_matches_fallback_accepts_sap_agt_prefix`, `test_matches_fallback_rejects_other_namespaces`, `test_assign_fallback_returns_ready_without_fragments` | `matches_fallback` accepts `sap.agt*` and rejects anything else; `handle_assign` on a fallback namespace short-circuits to `READY` with `configuration is None` and never instantiates the fragment client |

### Payload-Based Tests (`tests/test_spii_assistant_payloads.py`)

These tests use **real payloads captured from a live formation** (`formations-visualization/formation_n8n.html`). Each test loads a request JSON from `tests/payloads/assistant/` and asserts the response matches the corresponding response JSON.

The test constants (`ASSISTANT_DEST_INSTANCE_ID`, `ASSISTANT_AGW_BASE_URL`, `ASSISTANT_IAS_TOKEN_SERVICE_URL`, `ASSISTANT_ASSIGNED_GTID`) must match the values embedded in the payload files.

| Test | Request payload | Response payload | What it checks |
|------|----------------|-----------------|----------------|
| `test_assign_returns_ready_with_fragments` | `request_1_assign.json` | `response_1_assign.json` | INITIAL → READY with exact `connectivity.fragments` and `openResourceDiscovery`; `FragmentName` UUID suffix verified by prefix |
| `test_unassign_returns_ready` | `request_2_unassign.json` | `response_2_unassign.json` | Unassign with empty `assignedTenant` fields → `{"state": "READY"}` |

#### Payload Files (`tests/payloads/assistant/`)

| File | Description |
|------|-------------|
| `request_1_assign.json` | UCL → agent: both INITIAL, `assignedTenant.applicationNamespace=sap.btpn8n` |
| `response_1_assign.json` | Agent → UCL: `state=READY` with one MCP fragment for Destinations Facilitator and `openResourceDiscovery` |
| `request_2_unassign.json` | UCL → agent: `operation=unassign`, `assignedTenant.state=""` and `uclAssignmentId=""` (real-world UCL behaviour) |
| `response_2_unassign.json` | Agent → UCL: `{"state": "READY"}` |

#### Mocking `create_fragment_client`

The assign test mocks `create_fragment_client` to return a fake IAS user fragment with known auth properties. The fragment's `URL` becomes the `agw_base_url` that drives the constructed MCP fragment URL:

```python
def _make_ias_user_fragment():
    frag = MagicMock()
    frag.name = "sap-managed-runtime-agw-subscriber-ias-user-abc123"
    frag.properties = {
        "tokenService.body.resource": "urn:sap:identity:application:provider:name:sap-internal",
        "tokenServiceURL": ASSISTANT_IAS_TOKEN_SERVICE_URL,
        "URL": ASSISTANT_AGW_BASE_URL,
    }
    return frag
```

#### Mocking `read_from_mount_and_fallback_to_env_var`

The assign test also patches `read_from_mount_and_fallback_to_env_var` (in `sci_app2app_service`) to inject the destination instance ID, verifying it is called with correct arguments:

```python
def _mock_read_from_mount(base_volume_mount, base_var_name, module, instance, target):
    assert base_volume_mount == "/etc/secrets/appfnd"
    assert base_var_name == "CLOUD_SDK_CFG"
    assert module == "destination"
    assert instance == "default"
    target.instanceid = ASSISTANT_DEST_INSTANCE_ID

@patch(
    "services.sci_app2app_service.read_from_mount_and_fallback_to_env_var",
    side_effect=_mock_read_from_mount,
)
@patch("services.spii_appfnd_assistant.create_fragment_client")
def test_assign_returns_ready_with_fragments(mock_create_client, mock_read_from_mount, client):
    ...
```

### Test Fixtures

`tests/test_spii_assistant_payloads.py` uses two `autouse` fixtures:

1. **`register_assistant_handler`** — instantiates `AppFNDAssistantHandler`, reads its `application_namespace` (a `Sequence[str]` derived from the ORD), and registers the handler under each well-formed namespace in `_HANDLER_REGISTRY`. Namespaces containing literal `<` or `>` are filtered out, so the placeholder a2a dependency that ships in the ORD template (e.g. `<partner-namespace>:agent:<a2a-partner-agent>:v1`) does not pollute the registry. The fixture restores the original registry on teardown.
2. **`env_vars`** — patches `INITIATOR_MT_IAS_CLIENT_ID` and `AGENT_PUBLIC_URL` for the duration of each test.

No store-clearing fixture is needed — the handler is stateless, so there is
nothing for tests to leak between cases.

`tests/test_spii_appfnd_assistant.py` does **not** use
`register_assistant_handler` or `env_vars` — it calls the handler directly
(no PATCH route, no env vars needed) and patches
`_load_ord_integration_dependencies`/`create_fragment_client` per test where
required. It defines a small `handler` fixture (just
`AppFNDAssistantHandler()`) used by most tests.
