---
name: sap-sdk-python-dms
description: Integrate SAP Document Management Service (DMS) using the Application Foundation Python SDK. Use when the user needs to manage repositories, upload/download documents, create folders, run CMIS queries, manage versions, or control access in a Python application.
---

# DMS (Document Management Service) Integration with Python SDK

This skill provides guidance for integrating SAP Document Management Service using the Application Foundation Python SDK. The DMS module supports repository management, document and folder operations via the CMIS Browser Binding protocol, versioning, access control, and CMIS SQL queries.

## ⚠️ Package Index Policy

All Python packages MUST be installed exclusively from the SAP PyPI proxy:
`https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple`

NEVER use `https://pypi.org/simple` or any other external package index.
NEVER add `--extra-index-url` pointing to PyPI.
If a package is not found in the SAP proxy, report the error — do NOT fall back to PyPI.

## app.yaml Configuration

To use the DMS service, add the following to your `app.yaml` under `spec.requires`:

```yaml
requires:
  - name: default
    service: sdm
    plan: standard
```

**Fields:**
- `name`: Instance name for the DMS service (used in your code with `create_client(instance="default")`)
- `service`: Must be `sdm`
- `plan`: Use `standard` for DMS

## Installation

```bash
# Using uv (recommended)
uv add sap-cloud-sdk --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"

# Using pip
pip install sap-cloud-sdk --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"
```

## Quick Start

```python
from sap_cloud_sdk.dms import create_client

# Load credentials from mounted secrets or environment variables
client = create_client(instance="default")

# List all repositories
repos = client.get_all_repositories()
for repo in repos:
    print(f"{repo.name} — {repo.repository_type} — id={repo.id}")

# Create a folder
folder = client.create_folder(
    repo.cmis_repository_id, root_folder_id, "My Folder"
)

# Upload a document
import io
content = io.BytesIO(b"Hello, World!")
doc = client.create_document(
    repo.cmis_repository_id, folder.object_id,
    "hello.txt", content, mime_type="text/plain"
)
print(f"Created: {doc.name} ({doc.content_stream_length} bytes)")
```

## Imports

```python
from sap_cloud_sdk.dms import create_client, DMSClient
from sap_cloud_sdk.dms import (
    Ace, Acl, ChildrenOptions, ChildrenPage,
    CmisObject, DMSCredentials, Document, Folder,
    QueryOptions, QueryResultPage, UserClaim,
)
from sap_cloud_sdk.dms.model import (
    InternalRepoRequest, UpdateRepoRequest, Repository,
    CreateConfigRequest, UpdateConfigRequest, RepositoryConfig, ConfigName,
    RepositoryType, RepositoryCategory, HashAlgorithm,
)
from sap_cloud_sdk.dms.exceptions import (
    DMSError, DMSObjectNotFoundException, DMSPermissionDeniedException,
    DMSInvalidArgumentException, DMSConflictException,
    DMSConnectionError, DMSRuntimeException,
)
```

## Client Factory

```python
from sap_cloud_sdk.dms import create_client

# Automatic credential resolution from mount/env
client = create_client(instance="default")

# Or provide credentials directly
from sap_cloud_sdk.dms import DMSCredentials

creds = DMSCredentials(
    instance_name="my-instance",
    uri="https://api-sdm-di.cfapps.eu10.hana.ondemand.com",
    client_id="your-client-id",
    client_secret="your-client-secret",
    token_url="https://subdomain.authentication.eu10.hana.ondemand.com/oauth/token",
    identityzone="subdomain",
)
client = create_client(dms_cred=creds)

# Optional timeouts
client = create_client(instance="default", connect_timeout=15, read_timeout=60)
```

## User Identity (UserClaim)

Many operations accept an optional `user_claim` to impersonate a user when the SDK authenticates via `client_credentials` grant:

```python
from sap_cloud_sdk.dms import UserClaim

claim = UserClaim(
    x_ecm_user_enc="john.doe@example.com",
    x_ecm_add_principals=["~GroupA", "~GroupB", "another.user@example.com"],
)

# Pass to any API call
repos = client.get_all_repositories(user_claim=claim)
```

Groups are prefixed with `~`. Omit `user_claim` to use the service identity.

## Admin API — Repository Management

### Onboard a Repository

```python
from sap_cloud_sdk.dms.model import InternalRepoRequest

request = InternalRepoRequest(
    displayName="My Repository",
    description="Main document store",
    isVersionEnabled=True,
    isVirusScanEnabled=True,
)

repo = client.onboard_repository(request)
print(f"Created: {repo.name} (id={repo.id})")
```

### List All Repositories

```python
repos = client.get_all_repositories()

for repo in repos:
    print(f"{repo.name} — {repo.repository_type} — id={repo.id}")
    print(f"  CMIS repo ID: {repo.cmis_repository_id}")
    print(f"  Versioning: {repo.get_param('isVersionEnabled')}")
```

### Get a Single Repository

```python
repo = client.get_repository("repository-uuid")
print(f"{repo.name}: {repo.repository_category}")
```

### Update a Repository

```python
from sap_cloud_sdk.dms.model import UpdateRepoRequest

request = UpdateRepoRequest(
    description="Updated description",
    isVirusScanEnabled=False,
)

repo = client.update_repository("repository-uuid", request)
```

### Delete a Repository

```python
client.delete_repository("repository-uuid")
```

## Admin API — Configuration Management

### Create a Configuration

```python
from sap_cloud_sdk.dms.model import CreateConfigRequest, ConfigName

request = CreateConfigRequest(
    config_name=ConfigName.BLOCKED_FILE_EXTENSIONS,
    config_value="bat,dmg,exe",
)

config = client.create_config(request)
print(f"Config: {config.config_name} = {config.config_value}")
```

### Get All Configurations

```python
configs = client.get_configs()

for cfg in configs:
    print(f"{cfg.config_name} = {cfg.config_value} (id={cfg.id})")
```

### Update a Configuration

```python
from sap_cloud_sdk.dms.model import UpdateConfigRequest

request = UpdateConfigRequest(
    id="config-uuid",
    config_name=ConfigName.BLOCKED_FILE_EXTENSIONS,
    config_value="bat,dmg,exe,msi",
)

config = client.update_config("config-uuid", request)
```

### Delete a Configuration

```python
client.delete_config("config-uuid")
```

## CMIS API — Folder Operations

All CMIS operations require a `repository_id` (the CMIS repository ID from `repo.cmis_repository_id`).

### Create a Folder

```python
folder = client.create_folder(
    repository_id="cmis-repo-id",
    parent_folder_id="parent-folder-object-id",
    folder_name="My Folder",
    description="Optional description",
)

print(f"Created folder: {folder.name} (objectId={folder.object_id})")
```

## CMIS API — Document Operations

### Create a Document

```python
import io

# From in-memory bytes
content = io.BytesIO(b"Hello, World!")
doc = client.create_document(
    repository_id="cmis-repo-id",
    parent_folder_id="parent-folder-id",
    document_name="hello.txt",
    file=content,
    mime_type="text/plain",
)

print(f"Created: {doc.name} ({doc.content_stream_length} bytes)")
print(f"Version: {doc.version_label}")
```

### Upload a File from Disk

```python
with open("/path/to/report.pdf", "rb") as f:
    doc = client.create_document(
        repository_id="cmis-repo-id",
        parent_folder_id="parent-folder-id",
        document_name="report.pdf",
        file=f,
        mime_type="application/pdf",
        description="Q4 financial report",
    )
```

### Download Document Content

```python
response = client.get_content(
    repository_id="cmis-repo-id",
    document_id="document-object-id",
    download="attachment",
)

try:
    with open("downloaded.pdf", "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)
finally:
    response.close()
```

Optional parameters:
- `stream_id` — download a specific rendition (e.g. `"sap:zipRendition"`)
- `filename` — override the filename in the response header

### Append Content Stream

For large file uploads, append content in chunks:

```python
import io

chunk1 = io.BytesIO(b"First chunk of data...")
doc = client.append_content_stream(
    repository_id="cmis-repo-id",
    document_id="document-object-id",
    file=chunk1,
    is_last_chunk=False,
    filename="large-file.dat",
)

chunk2 = io.BytesIO(b"Final chunk of data.")
doc = client.append_content_stream(
    repository_id="cmis-repo-id",
    document_id=doc.object_id,
    file=chunk2,
    is_last_chunk=True,
)
```

## CMIS API — Versioning

Versioning requires a version-enabled repository.

### Check Out a Document

Creates a Private Working Copy (PWC):

```python
pwc = client.check_out(
    repository_id="cmis-repo-id",
    document_id="document-object-id",
)

print(f"PWC objectId: {pwc.object_id}")
print(f"Is PWC: {pwc.is_private_working_copy}")
```

### Check In a Document

Creates a new version from the PWC:

```python
import io

new_content = io.BytesIO(b"Updated content for v2")

doc = client.check_in(
    repository_id="cmis-repo-id",
    document_id=pwc.object_id,
    major=True,
    file=new_content,
    file_name="hello.txt",
    mime_type="text/plain",
    checkin_comment="Version 2.0 — updated content",
)

print(f"New version: {doc.version_label}")
print(f"Is latest: {doc.is_latest_version}")
```

### Cancel Check Out

Discards the PWC without creating a new version:

```python
client.cancel_check_out(
    repository_id="cmis-repo-id",
    document_id=pwc.object_id,
)
```

## CMIS API — Reading Objects

### Get Object by ID

Returns `Folder`, `Document`, or `CmisObject` depending on the base type:

```python
from sap_cloud_sdk.dms import Document

obj = client.get_object(
    repository_id="cmis-repo-id",
    object_id="some-object-id",
    include_acl=True,
)

print(f"Type: {type(obj).__name__}")
print(f"Name: {obj.name}")
print(f"Modified: {obj.last_modification_date}")

if isinstance(obj, Document):
    print(f"MIME: {obj.content_stream_mime_type}")
    print(f"Size: {obj.content_stream_length}")
    print(f"Version: {obj.version_label}")
```

### Update Properties

```python
updated = client.update_properties(
    repository_id="cmis-repo-id",
    object_id="some-object-id",
    properties={
        "cmis:name": "Renamed Document.pdf",
        "cmis:description": "Updated description",
    },
)

print(f"New name: {updated.name}")
```

Use `change_token` for optimistic concurrency control:

```python
updated = client.update_properties(
    repository_id="cmis-repo-id",
    object_id="some-object-id",
    properties={"cmis:name": "New Name"},
    change_token="current-change-token-value",
)
```

### List Children (Pagination)

```python
from sap_cloud_sdk.dms import ChildrenOptions

opts = ChildrenOptions(
    max_items=50,
    skip_count=0,
    order_by="cmis:creationDate ASC",
)

page = client.get_children(
    repository_id="cmis-repo-id",
    folder_id="parent-folder-id",
    options=opts,
)

print(f"Items: {len(page.objects)}, hasMore: {page.has_more_items}, total: {page.num_items}")

for obj in page.objects:
    kind = "Folder" if isinstance(obj, Folder) else "Document"
    print(f"  [{kind}] {obj.name} — {obj.object_id}")
```

Paginate through all children:

```python
from sap_cloud_sdk.dms import ChildrenOptions, Folder

skip = 0
page_size = 100

while True:
    opts = ChildrenOptions(max_items=page_size, skip_count=skip)
    page = client.get_children("cmis-repo-id", "folder-id", options=opts)

    for obj in page.objects:
        print(obj.name)

    if not page.has_more_items:
        break
    skip += page_size
```

## CMIS API — Delete and Restore

### Delete an Object

```python
# Delete a document (all versions by default)
client.delete_object(
    repository_id="cmis-repo-id",
    object_id="document-object-id",
    all_versions=True,
)

# Delete only the current version
client.delete_object(
    repository_id="cmis-repo-id",
    object_id="document-object-id",
    all_versions=False,
)
```

### Restore a Deleted Object

```python
result = client.restore_object(
    repository_id="cmis-repo-id",
    object_id="deleted-object-id",
)
print(result)
```

## CMIS API — Access Control Lists (ACL)

### Get the Current ACL

```python
acl = client.apply_acl(
    repository_id="cmis-repo-id",
    object_id="document-or-folder-id",
)

for ace in acl.aces:
    print(f"{ace.principal_id}: {ace.permissions} (direct={ace.is_direct})")
```

### Add ACE Entries

```python
from sap_cloud_sdk.dms import Ace

acl = client.apply_acl(
    repository_id="cmis-repo-id",
    object_id="document-or-folder-id",
    add_aces=[
        Ace(principal_id="user@example.com", permissions=["cmis:read"]),
        Ace(principal_id="admin@example.com", permissions=["cmis:all"]),
    ],
)
```

### Remove ACE Entries

```python
acl = client.apply_acl(
    repository_id="cmis-repo-id",
    object_id="document-or-folder-id",
    remove_aces=[
        Ace(principal_id="user@example.com", permissions=["cmis:read"]),
    ],
)
```

### ACL Propagation

```python
acl = client.apply_acl(
    repository_id="cmis-repo-id",
    object_id="folder-id",
    add_aces=[Ace(principal_id="team@example.com", permissions=["cmis:read"])],
    acl_propagation="propagate",  # "propagate" | "objectonly" | "repositorydetermined"
)
```

## CMIS API — Query

Run CMIS SQL queries against a repository:

```python
from sap_cloud_sdk.dms import QueryOptions

# Simple query
page = client.cmis_query(
    repository_id="cmis-repo-id",
    statement="SELECT * FROM cmis:document WHERE cmis:name LIKE 'report%'",
)

for obj in page.results:
    print(f"{obj.name} — {obj.object_id}")

# With pagination
opts = QueryOptions(max_items=50, skip_count=0, search_all_versions=False)
page = client.cmis_query("cmis-repo-id", "SELECT * FROM cmis:folder", options=opts)
print(f"Found {page.num_items} folders, hasMore: {page.has_more_items}")
```

## Multi-Tenancy

All operations support an optional `tenant` parameter for subscriber-scoped requests:

```python
# Provider context (default)
repos = client.get_all_repositories()

# Subscriber context
repos = client.get_all_repositories(tenant="subscriber-subdomain")
```

The SDK resolves the token URL by replacing the provider's identity zone with the tenant subdomain.

## Error Handling

```python
from sap_cloud_sdk.dms.exceptions import (
    DMSError,
    DMSObjectNotFoundException,
    DMSPermissionDeniedException,
    DMSInvalidArgumentException,
    DMSConflictException,
    DMSConnectionError,
    DMSRuntimeException,
)

try:
    obj = client.get_object("repo-uuid", "missing-id")
except DMSObjectNotFoundException as e:
    print(f"Not found ({e.status_code}): {e}")
except DMSConflictException as e:
    print(f"Conflict ({e.status_code}): {e}")
except DMSPermissionDeniedException as e:
    print(f"Access denied ({e.status_code}): {e}")
except DMSInvalidArgumentException as e:
    print(f"Bad request ({e.status_code}): {e}")
except DMSConnectionError as e:
    print(f"Network error: {e}")
except DMSRuntimeException as e:
    print(f"Server error ({e.status_code}): {e}")
```

### Exception Hierarchy

| Exception | HTTP Status | Description |
|---|---|---|
| `DMSError` | any | Base exception for all DMS errors |
| `DMSObjectNotFoundException` | 404 | Repository, document, or folder not found |
| `DMSPermissionDeniedException` | 401, 403 | Invalid or expired access token |
| `DMSInvalidArgumentException` | 400 | Invalid request payload or parameters |
| `DMSConflictException` | 409 | Resource state conflict (e.g. duplicate name) |
| `DMSConnectionError` | — | Network failure, timeout, or connection refused |
| `DMSRuntimeException` | 500 | Server-side internal error |

All exceptions carry:
- `status_code`: HTTP status code (when applicable)
- `error_content`: Raw response body for debugging

## Model Reference

### Repository

Fields: `id`, `name`, `cmis_repository_id`, `created_time`, `last_updated_time`, `repository_category`, `repository_params`, `repository_sub_type`, `repository_type`. Has `from_dict()`, `to_dict()`, `get_param(name, default)`.

### InternalRepoRequest

Fields: `displayName` (required), `repositoryType` (default `INTERNAL`), `description`, `repositoryCategory`, `isVersionEnabled`, `isVirusScanEnabled`, `skipVirusScanForLargeFile`, `hashAlgorithms`, `isThumbnailEnabled`, `isEncryptionEnabled`, `externalId`, `isContentBridgeEnabled`, `isAIEnabled`, `repositoryParams`.

### Document (extends CmisObject)

Additional fields: `content_stream_length`, `content_stream_mime_type`, `content_stream_file_name`, `version_series_id`, `version_label`, `is_latest_version`, `is_major_version`, `is_latest_major_version`, `is_private_working_copy`, `checkin_comment`, `is_version_series_checked_out`, `version_series_checked_out_id`.

### Folder (extends CmisObject)

No additional fields beyond `CmisObject`.

### CmisObject (base)

Fields: `object_id`, `name`, `base_type_id`, `object_type_id`, `created_by`, `creation_date`, `last_modified_by`, `last_modification_date`, `change_token`, `parent_ids`, `description`, `properties`.

### ChildrenOptions

Fields: `max_items` (default 100), `skip_count` (default 0), `order_by`, `filter`, `include_allowable_actions` (default False), `include_path_segment` (default False), `succinct` (default True).

### QueryOptions

Fields: `max_items` (default 100), `skip_count` (default 0), `search_all_versions` (default False).

### Enums

- `RepositoryType`: `INTERNAL`, `EXTERNAL`
- `RepositoryCategory`: `COLLABORATION`, `INSTANT`, `FAVORITES`
- `ConfigName`: `BLOCKED_FILE_EXTENSIONS`, `TEMPSPACE_MAX_CONTENT_SIZE`, `IS_CROSS_DOMAIN_MAPPING_ALLOWED`
- `HashAlgorithm`: `MD5`, `SHA1`, `SHA256`

## Cloud Mode Configuration

In cloud mode, credentials are resolved from:

### Mounted Secrets 
```
/etc/secrets/appfnd/sdm/<instance>/
├── uri          # DMS service endpoint URL
└── uaa          # JSON with clientid, clientsecret, url, identityzone
```

### Environment Variables (fallback)
```bash
export CLOUD_SDK_CFG_SDM_DEFAULT_URI="https://api-sdm-di.cfapps.eu10.hana.ondemand.com"
export CLOUD_SDK_CFG_SDM_DEFAULT_UAA='{"clientid":"...","clientsecret":"...","url":"https://subdomain.authentication.eu10.hana.ondemand.com","identityzone":"subdomain"}'
```

Replace `DEFAULT` with your instance name in uppercase if using a non-default instance.
