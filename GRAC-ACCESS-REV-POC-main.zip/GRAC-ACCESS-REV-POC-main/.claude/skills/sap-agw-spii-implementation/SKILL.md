---
name: sap-agw-spii-implementation
description: Implement the foundational UCL SPII v3.0.0 (Service Provider Integration
  Interface) layer for App Foundation agents, plus the Agent Gateway (sap.agw)
  formation handler. Use this skill whenever the user needs to add, fix, modify, or
  understand SPII in an agent — including the shared Facade dispatch by
  applicationNamespace (three-step `_resolve_handler` lookup: exact match in
  `_HANDLER_REGISTRY`, then a subnamespace fallback where a registered key is
  a child of the incoming namespace, then per-handler `matches_fallback`), the
  SPIIFormationHandler ABC (with `application_namespace` and the default
  `matches_fallback = False` opt-in hook for open-ended namespace families),
  stateless handlers that read everything they need from each notification (UCL
  is the source of truth for assignment state — no in-process assignment store,
  no idempotency lock table),
  Pydantic models with empty-string coercion,
  the PATCH /v1/tenantMappings/{tenantId} route, the Starlette
  route injection pattern, the Agent Gateway's SCI App2App oauth2ResourceIndicator
  integration contract, the SCI facilitatorUrl exchange, or the destination
  Fragment lifecycle (IAS fragment creation after SPII Step 2, fragment
  deletion on unassign). Other formation-type skills (Joule, Assistant, ALS)
  build on top of this skill — install this one first.
compatibility: Python 3.10+, Starlette, Pydantic v2, A2A SDK (a2a-sdk[http-server]),
  sap-cloud-sdk (destination module).
metadata:
  author: sap-agw
  version: "8.0.1"
  protocol: spii-v3
  application-namespace: "sap.agw"
---

# Agent Gateway SPII + SPII Foundation

This skill does two things:

1. **It provides the SPII foundation** that every formation-type handler in this
   catalog builds on — the Facade, the `SPIIFormationHandler` ABC, the Pydantic
   models, the PATCH route, and route injection. Handlers are **stateless**:
   UCL carries the assignment lifecycle in every notification, so the agent
   does not maintain its own copy of assignment state. This is what makes the
   agent safe to run as multiple Pods in Kubernetes.
2. **It ships the Agent Gateway (`sap.agw`) handler**, including the SCI App2App
   `oauth2ResourceIndicator` integration contract and the destination Fragment
   lifecycle.

> **Apply this skill first.** The Joule (`sap-joule-spii-implementation`),
> Assistant (`sap-assistant-spii-implementation`), and ALS
> (`sap-als-spii-implementation`) skills assume the foundation pieces below
> already exist — they only ship the formation-specific handler and the line
> that registers it.

## What is SPII?

UCL SPII v3.0.0 (Service Provider Integration Interface) lets BTP applications
participate in UCL formations. When a customer creates a formation that includes
your agent, UCL sends a `PATCH /v1/tenantMappings/{tenantId}` notification.
Your agent responds with state — and, depending on the formation type, a
configuration payload — so the formation can complete.

SPII has at most two steps. Whether a given formation type uses one step or two
is a property of the **handler** for that namespace:

- **Step 1**: Both parties see `INITIAL`. The agent returns its config and goes
  to `CONFIG_PENDING`. (Skipped for single-step handlers like Joule and
  Assistant — they go straight to `READY`.)
- **Step 2**: Agent is `CONFIG_PENDING`, partner is `READY`. The agent receives
  the partner's config, builds the destination fragments from it, and returns
  `READY` with those fragments in the response. Nothing is stored on the agent
  side — the fragments returned to UCL are the entire output of Step 2.

## Architecture: Facade + Per-Namespace Handlers

The SPII implementation is a **Facade** that owns the cross-cutting protocol
work — payload validation, idempotency, the PATCH route — and delegates the
formation-specific behavior to a handler chosen by
`assignedTenant.applicationNamespace`.

```
PATCH /v1/tenantMappings/{tenantId}
        │
        ▼
   SPIIService (Facade)
   ├── validate envelope
   └── dispatch by assignedTenant.applicationNamespace
        ├── "sap.agw"     → AgentGatewayHandler          (this skill)
        ├── "sap.joule"   → JouleHandler                 (sap-joule-spii-implementation)
        ├── ORD-derived   → AppFNDAssistantHandler       (sap-assistant-spii-implementation)
        └── "sap.als.v3"  → AuditLogV3Handler            (sap-als-spii-implementation)
```

Each handler implements `SPIIFormationHandler` (ABC in `spii_base.py`) with two
required methods (`handle_assign` and `handle_unassign`) plus one optional hook
(`matches_fallback`, defaulting to `False`). The handler's
`application_namespace` property tells the Facade which notifications to route
to it — most handlers return a `str`, but a handler may return a `Sequence[str]`
to register itself under multiple namespaces (Assistant uses this to advertise
one namespace per ORD `integrationDependency`). Handlers that need to claim
an open-ended namespace family (Assistant's `sap.agt*`) override
`matches_fallback` to participate in the Facade's three-step lookup; see
*Dispatch — `_resolve_handler`* below.

## File Layout

The foundation pieces (`spii_base.py`, `spii_service.py`, `models/spii.py`,
`api/spii.py`) plus the AGW-specific files:

```
app/
├── main.py                         # Route injection (see below)
├── api/spii.py                     # PATCH /v1/tenantMappings/{tenantId} route
├── models/spii.py                  # Pydantic models for the SPII envelope
└── services/
    ├── spii_base.py                # SPIIFormationHandler ABC, AssignmentState,
    │                                 StatusReport, ValidationError
    ├── spii_service.py             # Facade — validation, dispatch
    ├── spii_agw.py                 # AgentGatewayHandler (this skill)
    └── sci_app2app_service.py      # AGW: SCI App2App config + fragment payload
tests/
├── test_spii.py                    # Facade + AGW protocol tests
├── test_spii_agw_payloads.py       # Real captured payload tests (request→response)
├── test_fragment_lifecycle.py      # Fragment payload tests
└── payloads/agw/
    ├── request_1_assign_step1.json
    ├── response_1_assign_step1.json
    ├── request_2_assign_step2.json
    ├── response_2_assign_step2.json
    ├── request_3_unassign.json
    └── response_3_unassign.json
```

When other formation skills are applied, they add a sibling handler file
(`spii_joule.py`, `spii_appfnd_assistant.py`, ...) and one line in
`spii_service.py`'s `_build_handler_registry()`.

## Endpoint Security

The SPII endpoint is protected at the platform level by **DwC (Deploy with
Confidence)**. DwC's Jupiter terminates TLS, validates UCL's client certificate
per the `sap:cmp-mtls:v1` access strategy, and routes the request to the agent
— the agent itself does not implement endpoint authentication for
`/v1/tenantMappings`.

## Pydantic Models — Empty-String Coercion

Real UCL payloads send `""` (empty string) where the spec suggests an absent
field, especially in unassign operations. The models in `templates/app/models/spii.py`
contain `field_validator`s that coerce empty strings to `None` for:

- `AssignedTenant.state` and `AssignedTenant.uclAssignmentId`
- `TenantInfo.globalTenantId`, `TenantInfo.subdomain`, `TenantInfo.subaccountId`

Without these validators, Pydantic rejects the unassign payloads UCL actually
sends. **Do not remove the validators** — every formation handler in this
catalog relies on them.

See [templates/app/models/spii.py](templates/app/models/spii.py) for the full
implementation.

## The Facade — `SPIIService`

The Facade in `templates/app/services/spii_service.py` does this on every
notification:

1. Pulls `operation`, `uclAssignmentId`, both states, and
   `applicationNamespace` from the payload.
2. Calls `_validate()` (raises `ValidationError` → HTTP 400 for missing
   required fields).
3. **Unassign**: routes to the resolved handler if one exists so handler-
   specific cleanup can run; otherwise simply returns `READY`. Unassigns for
   unknown namespaces are tolerated so UCL can finalize cleanup.
4. **Assign**: resolves the handler by `applicationNamespace` (see *Dispatch
   — `_resolve_handler`* below). If none is found, raises `ValidationError`
   → HTTP 400. Otherwise calls `handler.handle_assign(...)`.

Handlers are stateless. Each notification is processed end-to-end from the
payload it carries — there is no in-process assignment store, no idempotency
lock table, no "get me the previously stored config" lookup. UCL is the
source of truth for assignment state and re-sends the full state on every
retry.

Adding a new formation type is a one-line change to `_build_handler_registry()`:

```python
handlers: List[SPIIFormationHandler] = [
    AgentGatewayHandler(),
    JouleHandler(),                # added by sap-joule-spii-implementation
    AppFNDAssistantHandler(),      # added by sap-assistant-spii-implementation
    # AuditLogV3Handler(),         # added by sap-als-spii-implementation
]
```

The registry builder already supports both `str` and `Sequence[str]` namespaces
— Assistant relies on this.

### Dispatch — `_resolve_handler`

Both branches of the Facade route through the module-level helper
`_resolve_handler(application_namespace)`. The lookup has three steps,
matching a switch with a default branch:

1. **Exact match**: `_HANDLER_REGISTRY.get(application_namespace)` — the
   common case for handlers that declare a fixed namespace (`sap.agw`,
   `sap.als`, `sap.joule`).
2. **Subnamespace fallback**: walk the registry keys and return the first
   handler whose registered key is a *subnamespace* of the incoming
   namespace — i.e. `key.startswith(application_namespace + ".")`. This
   bridges the case where UCL sends a parent namespace (e.g. `sap.sf`)
   but the agent registered a product-specific subnamespace derived from
   its ORD (e.g. `sap.sf.wfs`). The trailing dot guard is important —
   without it, `sap.sf` would spuriously match a hypothetical `sap.sfx`.
3. **Soft fallback**: iterate the registry's handlers and ask each one
   `matches_fallback(application_namespace)`. The first handler that
   returns `True` wins. The default ABC implementation returns `False`,
   so this step is a no-op for every handler that does not opt in. The
   Assistant handler is the one in this catalog that overrides it (to
   accept any `sap.agt*` namespace not already declared in its ORD).

`_resolve_handler` returns `None` if none of the three steps finds a
handler. The Facade then either tolerates the miss (unassign) or raises
`ValidationError` → HTTP 400 (assign).

Handlers that do not need an open-ended namespace family inherit the
default `matches_fallback = False` and are never seen by step 3 — they
keep the cheap `dict.get` path. The three-step design is what lets the
Assistant handler advertise an ORD-derived subnamespace like `sap.sf.wfs`
and still receive parent-namespace notifications, and also advertise
`sap.agt*` as a soft fallback, without forcing every other handler to
know about prefix or regex matching.

See [templates/app/services/spii_service.py](templates/app/services/spii_service.py).

## The PATCH Route

`templates/app/api/spii.py` exposes `PATCH /v1/tenantMappings/{tenantId}` and a
`/health` endpoint. It parses the body into `NotificationPayload`, calls the
Facade, and returns:

- HTTP 200 with the `SPIIResponse` body on success
- HTTP 400 on `ValidationError` / `ValueError`
- HTTP 500 on any other exception (UCL retries on 500)

See [templates/app/api/spii.py](templates/app/api/spii.py).

## Route Injection

The A2A SDK builds a Starlette app with a catch-all route. SPII routes **must
be inserted at index 0** so they win before the catch-all:

```python
spii_routes = create_spii_routes()
app = server.build()  # A2AStarletteApplication.build()

for i, route in enumerate(spii_routes):
    app.routes.insert(i, route)
```

## Idempotency

Idempotency is the responsibility of each handler. The notification carries
the full state of both participants (`receiverTenant.state` +
`assignedTenant.state`) and `uclAssignmentId`; the handler's external
operations (fragment creation/update/delete, etc.) must be safe to re-run
with the same inputs. The Facade does not deduplicate retries — UCL is
expected to retry on HTTP 500 and we want those retries to land on a clean
re-evaluation of the payload, not a cached intermediate state.

This is what makes the agent safe to run as multiple Pods in Kubernetes:
nothing about request handling depends on which Pod served the previous
notification for the same `uclAssignmentId`.

## Error Handling

| Status | When |
|---|---|
| 400 Bad Request | Envelope validation (missing `operation`, `uclAssignmentId`, etc.); unknown `applicationNamespace` on assign; handler-raised `ValueError`/`ValidationError` |
| 500 Internal Server Error | Anything else — UCL retries on 500 |

Handlers should raise `ValueError` (or `ValidationError` from `spii_base`) for
inputs that should yield 400. Anything else falls through to 500.

## Request Payload Structure

```json
{
  "context": {
    "platform": "btp",
    "accountId": "global-account-id",
    "uclFormationId": "uuid",
    "uclFormationName": "my-formation",
    "uclFormationTypeId": "d23d9e9a-fd1b-4dcd-b30b-01c4e86f4f8c",
    "operation": "assign|unassign",
    "operationId": "uuid"
  },
  "receiverTenant": {
    "state": "INITIAL|CONFIG_PENDING|ERROR|DELETING",
    "uclAssignmentId": "uuid",
    "applicationTenantId": "local-tenant-id",
    "applicationNamespace": "ias.initiator",
    "applicationUrl": "https://your-agent.example.com",
    "deploymentRegion": "cf-eu10",
    "uclSystemName": "my-system",
    "uclSystemTenantId": "uuid",
    "globalTenantId": "optional-gtid",
    "subdomain": "optional-subdomain",
    "subaccountId": "optional-uuid",
    "configuration": {
      "facilitatorUrl": "https://customer-sci.accounts.ondemand.com"
    }
  },
  "assignedTenant": {
    "state": "INITIAL|CONFIG_PENDING|READY|ERROR|",
    "applicationTenantId": "partner-tenant-id",
    "applicationNamespace": "sap.agw",
    "applicationUrl": "https://partner.example.com",
    "deploymentRegion": "cf-eu10",
    "uclSystemName": "partner-system",
    "uclSystemTenantId": "uuid",
    "configuration": null
  }
}
```

`assignedTenant.state` is often `""` in real-world unassign payloads — the
Pydantic validator coerces it to `None`.

## Design Note: Stateless Handlers

Handlers are stateless by design. UCL is the source of truth for assignment
state — every notification carries `receiverTenant.state` and
`assignedTenant.state`, so the agent has no reason to maintain its own copy.
This is also what makes the agent safe to run as multiple Pods in Kubernetes:
any Pod can handle any notification without coordinating across instances,
and a rescheduled Pod loses nothing.

Earlier versions of this skill shipped an in-memory `assignments_store` and a
`processing_locks` table inside the Facade. Both were removed because they
duplicated UCL's state in a place that does not survive Pod rescheduling and
the "idempotency lock" was per-Pod, not distributed — so it never actually
protected against concurrent duplicate notifications across replicas. If you
are merging this skill onto a project that still carries those structures
from an older version, delete them along with the handler code that wrote to
them.

---

# Agent Gateway Handler — `sap.agw`

The rest of this skill covers the Agent Gateway-specific handler that routes on
`applicationNamespace == "sap.agw"`.

## What's Specific to AGW

- **Two-step protocol**: AGW is one of the few formation types that uses the
  full `INITIAL → CONFIG_PENDING → READY` exchange because both sides need the
  other's `oauth2ResourceIndicator` config before the gateway can broker A2A
  traffic.
- **Integration contract**: SCI App2App `oauth2ResourceIndicator` (bidirectional)
  — not basic auth.
- **Config input**: `receiverTenant.configuration.facilitatorUrl` from the SCI
  Facilitator (required in Step 1; raises `ValueError` if absent).
- **Fragment lifecycle**: After Step 2 completes, IAS destination fragments are
  declared in `connectivity.fragments` returned in the READY response — the
  **Destinations Facilitator** creates them. AGW does not call the Destination
  Service SDK directly. On unassign, no fragment operations are performed.

## SCI App2App Configuration Contract

### Step 1 — What we send back (CONFIG_PENDING)

Read `facilitatorUrl` from `receiverTenant.configuration.facilitatorUrl` (raise
`ValueError` if absent — this is the SCI token endpoint for the customer's
tenant). Read `INITIATOR_MT_IAS_CLIENT_ID` and `AGENT_PUBLIC_URL` env vars.
Return:

```json
{
  "credentials": {
    "outboundCommunication": {
      "oauth2ResourceIndicator": {
        "url": "<AGENT_PUBLIC_URL>/api/a2a-agent",
        "tokenServiceUrl": "<facilitatorUrl>",
        "clientId": "<INITIATOR_MT_IAS_CLIENT_ID>",
        "protectedResources": ["agent-api-access"]
      }
    },
    "inboundCommunication": {
      "oauth2ResourceIndicator": {
        "clientId": "<INITIATOR_MT_IAS_CLIENT_ID>",
        "protectedResources": ["sap-internal"]
      }
    }
  }
}
```

`agent_url = f"{AGENT_PUBLIC_URL.rstrip('/')}/api/a2a-agent"`.

### Step 2 — What we receive and send back (READY)

The partner's config arrives in `assignedTenant.configuration` with the same
shape. Extract:

- `credentials.outboundCommunication.oauth2ResourceIndicator` (required —
  partner APIs they expose to us)
- `credentials.inboundCommunication.oauth2ResourceIndicator` (optional — partner
  APIs they consume from us)

Build and return `connectivity.fragments` in the READY response using partner
data (see `sci_app2app_service.py`). The Destinations Facilitator reads these
fragments and creates the subscriber IAS destination fragments. Nothing is
persisted on the agent side — the fragments returned to UCL are the entire
output of Step 2.

Fragment format with labels via `$metadata`:

```json
{
  "connectivity": {
    "fragments": [
      {
        "FragmentName": "sap-managed-runtime-agw-subscriber-ias-<uuid>",
        "tokenService.body.resource": "urn:sap:identity:application:provider:name:sap-internal",
        "tokenService.body.app_tid": "<receiverTenant.applicationTenantId>",
        "tokenServiceURL": "<partner tokenServiceUrl>/oauth2/token",
        "URL": "<partner url>",
        "Authentication": "OAuth2ClientCredentials",
        "$metadata": {
          "labels": [
            {"key": "sap-managed-runtime-type", "values": ["subscriber.ias"]},
            {"key": "sap-managed-runtime-gtid", "values": ["<globalTenantId>"]}
          ],
          "instanceId": "<destination instance id>"
        }
      },
      {
        "FragmentName": "sap-managed-runtime-agw-subscriber-ias-user-<uuid>",
        "tokenService.body.resource": "urn:sap:identity:application:provider:name:sap-internal",
        "tokenService.body.app_tid": "<receiverTenant.applicationTenantId>",
        "tokenServiceURL": "<partner tokenServiceUrl>/oauth2/token",
        "URL": "<partner url>",
        "$metadata": {
          "labels": [
            {"key": "sap-managed-runtime-type", "values": ["subscriber.ias.user"]},
            {"key": "sap-managed-runtime-gtid", "values": ["<globalTenantId>"]}
          ],
          "instanceId": "<destination instance id>"
        }
      }
    ]
  }
}
```

Constants for fragment names, label keys, and type values are in
`sci_app2app_service.py`:

- `FRAGMENT_NAME_IAS`, `FRAGMENT_NAME_IAS_USER` — base names; a `uuid.uuid4()`
  is appended at runtime: `f"{FRAGMENT_NAME_IAS}-{uuid.uuid4()}"`
- `TOKEN_SERVICE_BODY_RESOURCE`
- `FragmentLabelKey` (StrEnum): `TYPE`, `GTID`, `ORD_ID`
- `FragmentTypeValue` (StrEnum): `SUBSCRIBER_IAS`, `SUBSCRIBER_IAS_USER`
- `_get_destination_instance_id()` — reads the destination service instance ID
  from mounted secrets (via `sap_cloud_sdk.core.secret_resolver.read_from_mount_and_fallback_to_env_var`,
  base mount `/etc/secrets/appfnd`, env var `CLOUD_SDK_CFG`, module `destination`,
  instance `default`). Used as `$metadata.instanceId` in every destination
  fragment payload. **Reusable helper** — the Assistant handler
  (`sap-assistant-spii-implementation`) imports this directly from
  `services.sci_app2app_service` rather than reimplementing it. Returns `""`
  with a warning log if the secret cannot be resolved.

## AGW State Machine

```
receiverTenant.state | assignedTenant.state | operation | Action
---------------------|----------------------|-----------|-------
INITIAL              | INITIAL / "" / CONFIG_PENDING | assign | Step 1 → CONFIG_PENDING + config
ERROR                | INITIAL / "" / CONFIG_PENDING | assign | Step 1 retry → CONFIG_PENDING + config
CONFIG_PENDING       | READY                | assign    | Step 2 → READY + connectivity.fragments
ERROR                | READY                | assign    | Step 2 retry → READY + connectivity.fragments
any                  | any                  | unassign  | → READY (no-op)
```

## Destination Fragment Lifecycle

| Trigger | What Happens |
|---|---|
| Step 2 (assign, `CONFIG_PENDING` → `READY`) | `connectivity.fragments` returned in READY response; Destinations Facilitator creates IAS fragments. |
| Unassign | No-op acknowledgement. Fragment cleanup is handled by the Destinations Facilitator out-of-band. |

For data flow diagrams and the SAP Cloud SDK API reference, see
[references/fragment-lifecycle.md](references/fragment-lifecycle.md).

## Environment Variables (AGW)

| Variable | Purpose | Required |
|---|---|---|
| `INITIATOR_MT_IAS_CLIENT_ID` | Client ID for the IAS multi-tenant app; sent in both outbound and inbound `oauth2ResourceIndicator.clientId` | Yes |
| `AGENT_PUBLIC_URL` | Public base URL of the agent; used to build `outboundCommunication.url` as `{AGENT_PUBLIC_URL}/api/a2a-agent` | Yes |

## Deployment Configuration

The destination service is provisioned by default in `app.yaml`:

```yaml
spec:
  container:
    env:
      - name: INITIATOR_MT_IAS_CLIENT_ID
        valueFrom:
          secretKeyRef:
            name: identity-service
            key: clientid
```

> **Note:** No `service.apiAuth` block is required. Authentication is enforced at the gateway via mTLS (and SPII for AGW flows), so APIRule-level auth is unnecessary and adding wildcard paths (`/.well-known/*`, `/*`) is rejected by APIRule v2.

## Implementation Files

| File | What it contains |
|---|---|
| [templates/app/models/spii.py](templates/app/models/spii.py) | Pydantic models with empty-string coercion |
| [templates/app/api/spii.py](templates/app/api/spii.py) | PATCH route + 400/500 mapping |
| [templates/app/services/spii_base.py](templates/app/services/spii_base.py) | `SPIIFormationHandler` ABC (with default `matches_fallback`), `AssignmentState`, `StatusReport`, `ValidationError` |
| [templates/app/services/spii_service.py](templates/app/services/spii_service.py) | Facade with the handler registry and `_resolve_handler` three-step lookup (exact match, subnamespace fallback, then `matches_fallback`) |
| [templates/app/services/spii_agw.py](templates/app/services/spii_agw.py) | `AgentGatewayHandler` |
| [templates/app/services/sci_app2app_service.py](templates/app/services/sci_app2app_service.py) | AGW Step 1/Step 2 builders + fragment payload |
| [templates/tests/test_spii_agw_payloads.py](templates/tests/test_spii_agw_payloads.py) | Real captured payload tests — one test per request/response pair |
| [templates/tests/payloads/agw/](templates/tests/payloads/agw/) | 6 JSON files: `request_N_*.json` + `response_N_*.json` for step1, step2, unassign |

## Verification

After applying this skill, run the payload tests to confirm the implementation produces the exact outputs captured from a live formation:

```bash
python3 -m pytest tests/test_spii_agw_payloads.py tests/test_spii.py -v
```

All tests must pass before the skill is considered correctly applied.

## Reference Files

| File | Description |
|------|-------------|
| [references/swagger.yaml](references/swagger.yaml) | OpenAPI spec for SPII v3.0.0 |
| [references/state-machine.md](references/state-machine.md) | Detailed state transition logic |
| [references/testing.md](references/testing.md) | pytest suite + curl examples |
| [references/fragment-lifecycle.md](references/fragment-lifecycle.md) | Fragment lifecycle: data flow, SDK reference, idempotency, edge cases |
