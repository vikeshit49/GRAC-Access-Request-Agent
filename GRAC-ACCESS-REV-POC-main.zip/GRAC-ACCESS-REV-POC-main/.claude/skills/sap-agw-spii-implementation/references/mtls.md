# mTLS Configuration for Agent Gateway SPII

The SPII endpoint is protected by mTLS per `sap:cmp-mtls:v1`. In the App Foundation / AppFnd runtime, TLS termination happens at the platform gateway. The gateway forwards certificate info via headers:

| Header | Description |
|--------|-------------|
| `X-SSL-Client-Subject-DN` | Client certificate Subject DN |
| `X-SSL-Client-Issuer-DN` | Client certificate Issuer DN |
| `X-Forwarded-Client-Cert` | Full certificate (CF format) |

## SAP Cloud Root CA

Import the SAP Cloud Root CA into your system's trust store.

**Download CA Certificate**: [SAP Cloud Root CA](https://help.sap.com/docs/connectivity/sap-btp-connectivity-cf/ca-certificate)

> **Note**: BTP applications using Cloud Foundry or Kyma typically have this pre-configured at the platform level.

## UCL Certificate Subject

UCL exposes its certificate Subject via the `/v1/info` endpoint:

| Environment | URL | Linked To |
|-------------|-----|-----------|
| Dev-main | `https://compass-gateway.cmp-main.dev.kyma.cloud.sap/v1/info` | BTP Staging |
| Dev | `https://compass-gateway.mps.dev.kyma.cloud.sap/v1/info` | BTP Integrate |
| Stage | `https://compass-gateway.mps.stage.kyma.cloud.sap/v1/info` | BTP Canary |
| **Prod** | `https://compass-gateway.mps.kyma.cloud.sap/v1/info` | BTP Live |

Example response field: `"certSubject":"CN=cmp-dev,OU=SAP Cloud Platform Clients,OU=Staging,OU=cmp-cf-us10-staging,O=SAP SE,L=Dev,C=DE"`

## MTLSAuthMiddleware

Located at `app/middleware/mtls_auth.py`. Configured in `main.py`:

```python
app.add_middleware(MTLSAuthMiddleware, path_prefixes=["/v1/tenantMappings"])
```

### Behavior

1. Only activates for paths starting with `/v1/tenantMappings`
2. Reads `X-SSL-Client-Subject-DN` from headers
3. **Dev mode**: if `cert_subject` header is absent AND no `UCL_CLIENT_CERT_*` env vars are set -> allow request with a warning log
4. **Strict mode**: if env vars are set but header is absent -> return 401
5. Validates `UCL_CLIENT_CERT_SUBJECT` (full DN match), then falls back to individual `UCL_CLIENT_CERT_CN` / `UCL_CLIENT_CERT_ORG` checks
6. On success, stores `{subject, issuer, cn, org}` in `request.state.client_cert`

## Environment Variables

```bash
# Option A: Full Subject DN (exact match)
UCL_CLIENT_CERT_SUBJECT="CN=compass-gateway,O=SAP SE,L=Walldorf,ST=Baden-Wuerttemberg,C=DE"

# Option B: Individual components
UCL_CLIENT_CERT_CN="compass-gateway"
UCL_CLIENT_CERT_ORG="SAP SE"
```

## Environment Mapping

Map your deployment environments to UCL environments:

| Your Environment | UCL Environment |
|-----------------|-----------------|
| Development | Dev or Dev-main |
| Staging/QA | Stage (Canary) |
| Production | Prod (Live) |

> **Important**: Coordinate with the UCL team to confirm the correct environment mapping for your application.

## Local Development

Leave all `UCL_CLIENT_CERT_*` env vars unset. The middleware will log a warning and allow all requests. No mTLS cert setup needed locally.

## Security Checklist

- [ ] SAP Cloud Root CA imported to trust store
- [ ] UCL certificate Subject obtained from correct environment's `/v1/info`
- [ ] Gateway configured to pass certificate headers
- [ ] Middleware validates certificate Subject/CN/Org
- [ ] Development environment allows bypass for testing (optional)
- [ ] Logging enabled for authentication failures
