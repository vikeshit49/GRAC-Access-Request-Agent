# Destination Fragment Lifecycle

This document details how destination fragments are provisioned and managed in the Agent Gateway SPII implementation.

## What Are Destination Fragments?

A **destination fragment** is a reusable configuration snippet managed by the SAP BTP Destination Service. Fragments store key-value properties (token service URLs, API endpoint URLs) and can be discovered via **labels** — arbitrary key-value metadata attached to each fragment.

## IAS Subscriber Fragments — Declarative via Destinations Facilitator

After SPII Step 2 completes, the Agent Gateway returns `connectivity.fragments` in the READY response. The **Destinations Facilitator** (a separate UCL formation participant) reads this payload and creates the subscriber IAS destination fragments. The Agent Gateway does **not** call the Destination Service SDK for IAS fragment creation.

Two fragments are declared per tenant. Each fragment name has a `uuid.uuid4()` appended at runtime:

| Fragment base name | Runtime name pattern | Purpose |
|---|---|---|
| `sap-managed-runtime-agw-subscriber-ias` | `sap-managed-runtime-agw-subscriber-ias-<uuid>` | Client credentials flow (OAuth2ClientCredentials) |
| `sap-managed-runtime-agw-subscriber-ias-user` | `sap-managed-runtime-agw-subscriber-ias-user-<uuid>` | User propagation flow (no Authentication property) |

### Fragment Payload (returned in READY response `configuration.fragments`)

```json
{
  "FragmentName": "sap-managed-runtime-agw-subscriber-ias-<uuid>",
  "tokenService.body.resource": "urn:sap:identity:application:provider:name:sap-internal",
  "tokenService.body.app_tid": "<assignedTenant.applicationTenantId>",
  "tokenServiceURL": "<partner tokenServiceUrl>/oauth2/token",
  "URL": "<partner url>",
  "Authentication": "OAuth2ClientCredentials",
  "$metadata": {
    "labels": [
      {"key": "sap-managed-runtime-type", "values": ["subscriber.ias"]},
      {"key": "sap-managed-runtime-gtid", "values": ["<globalTenantId>"]}
    ],
    "instanceId": "<destination instance id>"
  }
}
```

The IAS-user fragment is identical except it omits `Authentication` and uses the `sap-managed-runtime-agw-subscriber-ias-user-<uuid>` name.

### Property Derivation

| Property | Source |
|---|---|
| `FragmentName` | `f"{FRAGMENT_NAME_IAS}-{uuid.uuid4()}"` / `f"{FRAGMENT_NAME_IAS_USER}-{uuid.uuid4()}"` — UUID appended at runtime |
| `tokenService.body.resource` | Constant: `TOKEN_SERVICE_BODY_RESOURCE` = `urn:sap:identity:application:provider:name:sap-internal` |
| `tokenService.body.app_tid` | `assignedTenant.applicationTenantId` from the notification payload |
| `tokenServiceURL` | `partner_config.tokenServiceUrl` with `/oauth2/token` appended and trailing slash stripped |
| `URL` | `partner_config.url` (from `assignedTenant.configuration.credentials.outboundCommunication.oauth2ResourceIndicator.url`) |
| `Authentication` | Hardcoded `OAuth2ClientCredentials` (IAS only; omitted for IAS-user) |
| `$metadata.labels[sap-managed-runtime-gtid]` | `receiverTenant.globalTenantId` |
| `$metadata.instanceId` | `_get_destination_instance_id()` — reads destination service instance ID from mounted secrets |

Built in `sci_app2app_service.handle_config_pending()` and attached to `partner_config["connectivity"]`.

## Unassign

On unassign, the assignment is removed from the in-memory store and `READY` is returned. No fragment operations are performed — fragment lifecycle is managed by the Destinations Facilitator.

## Lifecycle Summary

| Trigger | IAS Fragments | Notes |
|---|---|---|
| Step 2 (READY) | Declared in `connectivity.fragments` — Destinations Facilitator creates them | No SDK calls needed |
| Unassign | No action | Destinations Facilitator manages cleanup |
