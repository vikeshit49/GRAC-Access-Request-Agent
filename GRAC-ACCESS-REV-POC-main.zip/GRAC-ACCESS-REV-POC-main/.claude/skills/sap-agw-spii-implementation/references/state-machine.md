# SPII State Machine

This document details the state transitions and handling logic for UCL SPII tenant mapping notifications.

## Assignment States

| State | Description | Can Transition To |
|-------|-------------|-------------------|
| `INITIAL` | First notification for this assignment | `CONFIG_PENDING`, `READY`, `ERROR` |
| `CONFIG_PENDING` | Awaiting configuration from other party | `READY`, `ERROR` |
| `READY` | Assignment fully configured | - (terminal for assign) |
| `ERROR` | Processing failed, may retry | `CONFIG_PENDING`, `READY` |
| `DELETING` | Unassign in progress | `READY` (confirms deletion) |

## Two-Step Configuration Exchange

The standard SPII flow involves two notifications per participant:

```
+----------------------------------------------------------------+
|                     UCL Formation                              |
+----------------------------------------------------------------+
|                                                                |
|  Step 1: Both parties INITIAL                                  |
|  +----------+                           +----------+           |
|  |  Your    |  receiverTenant.state:    |  Other   |           |
|  |  App     |  INITIAL                  |  Party   |           |
|  |          |  assignedTenant.state:    |          |           |
|  |          |  INITIAL                  |          |           |
|  +----------+                           +----------+           |
|       |                                                        |
|       v                                                        |
|  Send your config, return CONFIG_PENDING                       |
|                                                                |
|  Step 2: You CONFIG_PENDING, Other READY                       |
|  +----------+                           +----------+           |
|  |  Your    |  receiverTenant.state:    |  Other   |           |
|  |  App     |  CONFIG_PENDING           |  Party   |           |
|  |          |  assignedTenant.state:    |          |           |
|  |          |  READY                    |          |           |
|  +----------+                           +----------+           |
|       |                                                        |
|       v                                                        |
|  Store received config, return READY                           |
|  Return connectivity.fragments so Destinations Facilitator     |
|  creates the subscriber IAS destination fragments              |
|                                                                |
+----------------------------------------------------------------+
```

## State Decision Logic

```python
def determine_response(notification: dict) -> dict:
    """Determine SPII response based on current states."""

    operation = notification["context"]["operation"]
    receiver_state = notification["receiverTenant"]["state"]
    assigned_state = notification["assignedTenant"].get("state", "")
    assigned_config = notification["assignedTenant"].get("configuration")

    # Unassign operation — acknowledge with READY (no side effects)
    if operation == "unassign":
        return {"state": "READY"}

    # Assign operation - determine step based on states

    # Step 1: Both INITIAL - send our config
    if receiver_state == "INITIAL" and assigned_state == "INITIAL":
        return {
            "state": "CONFIG_PENDING",
            "configuration": build_our_config()
        }

    # Step 1 (retry): We're in ERROR, assigned still INITIAL/CONFIG_PENDING
    if receiver_state == "ERROR" and assigned_state in ["INITIAL", "CONFIG_PENDING"]:
        return {
            "state": "CONFIG_PENDING",
            "configuration": build_our_config()
        }

    # Step 2: We're CONFIG_PENDING, assigned is READY with config
    if receiver_state == "CONFIG_PENDING" and assigned_state == "READY":
        partner_config = extract_partner_config(assigned_config)
        # Return connectivity.fragments for the Destinations Facilitator
        connectivity = partner_config.get("connectivity")
        ready_config = {"connectivity": connectivity} if connectivity else None
        return {"state": "READY", "configuration": ready_config}

    # Step 2 (retry): We're in ERROR, assigned is READY
    if receiver_state == "ERROR" and assigned_state == "READY":
        partner_config = extract_partner_config(assigned_config)
        connectivity = partner_config.get("connectivity")
        ready_config = {"connectivity": connectivity} if connectivity else None
        return {"state": "READY", "configuration": ready_config}

    # Unexpected state combination
    return {"state": "CONFIG_PENDING"}
```

Note that nothing in this decision logic reads from or writes to an
in-process store. The response is a pure function of the incoming
notification — UCL provides every input the handler needs (`receiver_state`,
`assigned_state`, `assigned_config`).

## Complete Implementation

The canonical implementation lives in the skill's templates — there is one
source of truth, not two:

- [`templates/app/services/spii_base.py`](../templates/app/services/spii_base.py)
  — `AssignmentState`, `StatusReport`, `SPIIFormationHandler` ABC,
  `ValidationError`.
- [`templates/app/services/spii_service.py`](../templates/app/services/spii_service.py)
  — Facade: envelope validation and dispatch by `applicationNamespace`.
- [`templates/app/services/spii_agw.py`](../templates/app/services/spii_agw.py)
  — Agent Gateway handler with the Step 1 / Step 2 logic above.

Both Step 1 and Step 2 are pure functions of the notification payload. The
handler does not keep any state between calls; UCL is the source of truth
for assignment state.

## Handling Retries

UCL may resend notifications when:
- Previous notification returned 500 error
- Previous state was `ERROR`
- Network timeout occurred

Always check `receiverTenant.state` to determine if this is a retry:
- `INITIAL` -> First notification
- `ERROR` -> Retry after failure
- `CONFIG_PENDING` -> Continuation (Step 2)

Side-effect operations (e.g. fragment creation) must be **idempotent** since
the same notification may be retried. The Destinations Facilitator that
consumes the Step 2 `connectivity.fragments` payload is already idempotent,
so re-running Step 2 with the same partner config yields the same outcome.

## Idempotency

Idempotency is the responsibility of each handler. There is no in-process
lock table and no in-memory store — UCL carries the full assignment state on
every notification and the agent runs as multiple Pods in Kubernetes, so any
per-process lock would not coordinate across replicas anyway. The handler's
external operations (fragment payload construction, Destinations Facilitator
input, etc.) must be safe to re-run with the same inputs.

## Common State Scenarios

### Scenario 1: Simple Integration
Both parties exchange oauth2ResourceIndicator configuration. Step 2 returns `connectivity.fragments` for the Destinations Facilitator to create IAS destination fragments.

| Notification | receiverTenant.state | assignedTenant.state | Response |
|--------------|---------------------|---------------------|----------|
| 1 | INITIAL | INITIAL | CONFIG_PENDING + oauth2ResourceIndicator config |
| 2 | CONFIG_PENDING | READY | READY + connectivity.fragments |

### Scenario 2: Retry After Error
First attempt failed, UCL retries. Handler re-runs on the retried payload; downstream operations are idempotent so no duplicate side effects occur.

| Notification | receiverTenant.state | assignedTenant.state | Response |
|--------------|---------------------|---------------------|----------|
| 1 | INITIAL | INITIAL | ERROR (returned 500) |
| 2 | ERROR | CONFIG_PENDING | CONFIG_PENDING + config |
| 3 | CONFIG_PENDING | READY | READY + connectivity.fragments |

### Scenario 3: Unassign
Participant removed from formation. Handler acknowledges with READY.

| Notification | operation | receiverTenant.state | Response |
|--------------|-----------|---------------------|----------|
| 1 | unassign | DELETING | READY |
