# Testing the Agent Gateway SPII

## Automated Tests

```bash
# From project root — run all SPII tests including payload-based tests
python3 -m pytest tests/test_spii.py tests/test_spii_agw_payloads.py tests/test_fragment_lifecycle.py -v
```

### Test Organization

| File | What it covers | What it mocks |
|------|----------------|---------------|
| `tests/test_spii.py` | SPII protocol: state machine, config exchange, validation, formation type gating, Step 2 connectivity.fragments in response | `INITIATOR_MT_IAS_CLIENT_ID`, `AGENT_PUBLIC_URL` env vars |
| `tests/test_spii_agw_payloads.py` | **Real captured payloads** — each test sends an exact request JSON and asserts the exact response JSON from `tests/payloads/agw/` | `INITIATOR_MT_IAS_CLIENT_ID`, `AGENT_PUBLIC_URL` env vars; `read_from_mount_and_fallback_to_env_var` in step 2 |
| `tests/test_fragment_lifecycle.py` | IAS fragment payload built by `sci_app2app_service.handle_config_pending` | None (pure function, no SDK calls) |

### Payload-Based Tests (`tests/test_spii_agw_payloads.py`)

These tests use **real payloads captured from a live formation** (`formations-visualization/formation_agw.html`). Each test loads a request JSON from `tests/payloads/agw/` and asserts the response matches the corresponding response JSON.

The test constants (`AGW_CLIENT_ID`, `AGW_AGENT_PUBLIC_URL`, `AGW_DEST_INSTANCE_ID`) must match the values embedded in the payload files — they are set as env vars and mocked so the agent produces the exact captured output.

| Test | Request payload | Response payload | What it checks |
|------|----------------|-----------------|----------------|
| `test_assign_step1_returns_config_pending` | `request_1_assign_step1.json` | `response_1_assign_step1.json` | Both INITIAL → CONFIG_PENDING with exact `oauth2ResourceIndicator` config |
| `test_assign_step2_returns_ready_with_fragments` | `request_2_assign_step2.json` | `response_2_assign_step2.json` | CONFIG_PENDING → READY with exact `connectivity.fragments`; `FragmentName` UUID suffix verified by prefix |
| `test_unassign_returns_ready` | `request_3_unassign.json` | `response_3_unassign.json` | Unassign with empty `assignedTenant` fields → `{"state": "READY"}` |

#### Payload Files (`tests/payloads/agw/`)

| File | Description |
|------|-------------|
| `request_1_assign_step1.json` | UCL → agent: `assignedTenant.state=INITIAL`, `receiverTenant.state=INITIAL`, includes `facilitatorUrl` |
| `response_1_assign_step1.json` | Agent → UCL: `state=CONFIG_PENDING` with `credentials.outboundCommunication` + `inboundCommunication` |
| `request_2_assign_step2.json` | UCL → agent: `receiverTenant.state=CONFIG_PENDING`, `assignedTenant.state=READY` with AGW's `oauth2ResourceIndicator` config |
| `response_2_assign_step2.json` | Agent → UCL: `state=READY` with `connectivity.fragments` (2 IAS fragments for Destinations Facilitator) |
| `request_3_unassign.json` | UCL → agent: `operation=unassign`, `assignedTenant.state=""` and `uclAssignmentId=""` (real-world UCL behaviour) |
| `response_3_unassign.json` | Agent → UCL: `{"state": "READY"}` |

#### Mocking `read_from_mount_and_fallback_to_env_var`

Step 2 calls `_get_destination_instance_id()` which calls `read_from_mount_and_fallback_to_env_var`. The test patches this at the module level and verifies it is called with the correct arguments:

```python
def _mock_read_from_mount(base_volume_mount, base_var_name, module, instance, target):
    assert base_volume_mount == "/etc/secrets/appfnd"
    assert base_var_name == "CLOUD_SDK_CFG"
    assert module == "destination"
    assert instance == "default"
    target.instanceid = AGW_DEST_INSTANCE_ID

@patch(
    "services.sci_app2app_service.read_from_mount_and_fallback_to_env_var",
    side_effect=_mock_read_from_mount,
)
def test_assign_step2_returns_ready_with_fragments(mock_read_from_mount, client):
    ...
```

### SPII Protocol Tests (`tests/test_spii.py`)

| Test | What it checks |
|------|----------------|
| `test_health_check` | GET /health -> 200 |
| `test_spii_assign_step1_both_initial` | Both INITIAL -> CONFIG_PENDING + oauth2ResourceIndicator config |
| `test_spii_assign_step2_config_pending_to_ready` | CONFIG_PENDING -> READY, connectivity.fragments returned, partner_config stored |
| `test_spii_unassign` | DELETING -> READY, assignment removed from store |
| `test_spii_validation_error_missing_operation` | Missing operation -> 400 |
| `test_spii_retry_from_error_state` | ERROR + CONFIG_PENDING -> CONFIG_PENDING (retry Step 1) |
| `test_spii_unknown_namespace_returns_error` | Unknown applicationNamespace on assign -> 400 |
| `test_spii_missing_facilitator_url` | No facilitatorUrl -> 400 |
| `test_spii_unassign_with_empty_strings` | Unassign with empty assignedTenant fields (real-world payload) -> 200 READY |
| `test_spii_unassign_with_populated_assigned_tenant` | Unassign with populated assignedTenant fields -> 200 READY |

### Fragment Lifecycle Tests (`tests/test_fragment_lifecycle.py`)

Test `sci_app2app_service.handle_config_pending` directly — no mocks needed, pure function:

| Test | What it checks |
|------|----------------|
| `test_connectivity_fragments_built_in_step2` | Two fragments (IAS + IAS-user) returned in result |
| `test_ias_fragment_payload_correct` | IAS fragment: correct name, properties, Authentication, `$metadata.labels` |
| `test_ias_user_fragment_payload_correct` | IAS-user fragment: correct name, properties, no Authentication, `$metadata.labels` |
| `test_fragment_gtid_empty_when_not_in_receiver` | GTID label is empty string when not in receiverTenant |
| `test_token_service_url_trailing_slash_stripped` | Trailing slash stripped before `/oauth2/token` is appended |

### Test Fixtures

All test files use `autouse` fixtures to:
1. Patch env vars: `INITIATOR_MT_IAS_CLIENT_ID` and `AGENT_PUBLIC_URL`

No store-clearing fixtures are needed — the handler is stateless, so tests
never leak in-memory state to one another.

## Manual Testing (curl)

### Start lightweight test server (no AI Core needed)

```bash
export INITIATOR_MT_IAS_CLIENT_ID="my-initiator-mt-ias-client-id"
export AGENT_PUBLIC_URL="http://localhost:9000"

cd app && python -c "
import uvicorn
from starlette.applications import Starlette
from api.spii import create_spii_routes
app = Starlette(routes=create_spii_routes())
uvicorn.run(app, host='0.0.0.0', port=9000)
"
```

### Step 1: INITIAL -> CONFIG_PENDING

```bash
curl -s -X PATCH http://localhost:9000/v1/tenantMappings/tenant-123 \
  -H "Content-Type: application/json" \
  -d '{
  "context": {
    "platform": "btp",
    "accountId": "test-account",
    "uclFormationId": "550e8400-e29b-41d4-a716-446655440000",
    "uclFormationName": "test-formation",
    "uclFormationTypeId": "d23d9e9a-fd1b-4dcd-b30b-01c4e86f4f8c",
    "operation": "assign",
    "operationId": "550e8400-e29b-41d4-a716-446655440001"
  },
  "receiverTenant": {
    "state": "INITIAL",
    "uclAssignmentId": "550e8400-e29b-41d4-a716-446655440003",
    "deploymentRegion": "cf-eu10",
    "applicationNamespace": "ias.initiator",
    "applicationUrl": "https://test.example.com",
    "applicationTenantId": "tenant-123",
    "uclSystemName": "test-system",
    "uclSystemTenantId": "550e8400-e29b-41d4-a716-446655440004",
    "configuration": {
      "facilitatorUrl": "https://customer-sci.accounts.ondemand.com"
    }
  },
  "assignedTenant": {
    "state": "INITIAL",
    "deploymentRegion": "cf-eu10",
    "applicationNamespace": "ias.responder",
    "applicationUrl": "https://partner.example.com",
    "applicationTenantId": "partner-tenant-456",
    "subdomain": "partner-subdomain",
    "uclSystemName": "partner-system",
    "uclSystemTenantId": "550e8400-e29b-41d4-a716-446655440005",
    "configuration": null
  }
}' | python -m json.tool
```

Expected:
```json
{
  "state": "CONFIG_PENDING",
  "configuration": {
    "credentials": {
      "outboundCommunication": {
        "oauth2ResourceIndicator": {
          "url": "http://localhost:9000/api/a2a-agent",
          "tokenServiceUrl": "https://customer-sci.accounts.ondemand.com",
          "clientId": "my-initiator-mt-ias-client-id",
          "protectedResources": ["agent-api-access"]
        }
      },
      "inboundCommunication": {
        "oauth2ResourceIndicator": {
          "clientId": "my-initiator-mt-ias-client-id",
          "protectedResources": ["sap-internal"]
        }
      }
    }
  }
}
```

### Step 2: CONFIG_PENDING -> READY

Use the same `uclAssignmentId` as Step 1:

```bash
curl -s -X PATCH http://localhost:9000/v1/tenantMappings/tenant-123 \
  -H "Content-Type: application/json" \
  -d '{
  "context": {
    "platform": "btp",
    "accountId": "test-account",
    "uclFormationId": "550e8400-e29b-41d4-a716-446655440000",
    "uclFormationName": "test-formation",
    "uclFormationTypeId": "d23d9e9a-fd1b-4dcd-b30b-01c4e86f4f8c",
    "operation": "assign",
    "operationId": "550e8400-e29b-41d4-a716-446655440002"
  },
  "receiverTenant": {
    "state": "CONFIG_PENDING",
    "uclAssignmentId": "550e8400-e29b-41d4-a716-446655440003",
    "deploymentRegion": "cf-eu10",
    "applicationNamespace": "ias.initiator",
    "applicationUrl": "https://test.example.com",
    "applicationTenantId": "tenant-123",
    "globalTenantId": "0131f94a-3fb5-4c18-941c-d8e145f99210",
    "subdomain": "agw-test-subdomain",
    "uclSystemName": "test-system",
    "uclSystemTenantId": "550e8400-e29b-41d4-a716-446655440004",
    "configuration": {
      "credentials": {
        "outboundCommunication": {
          "oauth2ResourceIndicator": {
            "url": "http://localhost:9000/api/a2a-agent",
            "tokenServiceUrl": "https://customer-sci.accounts.ondemand.com",
            "clientId": "my-initiator-mt-ias-client-id",
            "protectedResources": ["agent-api-access"]
          }
        },
        "inboundCommunication": {
          "oauth2ResourceIndicator": {
            "clientId": "my-initiator-mt-ias-client-id",
            "protectedResources": ["sap-internal"]
          }
        }
      }
    }
  },
  "assignedTenant": {
    "state": "READY",
    "deploymentRegion": "cf-eu10",
    "applicationNamespace": "sap.agw-dev",
    "applicationUrl": "https://eu12.access.sapdas-dev.cloud.sap",
    "applicationTenantId": "partner-tenant-456",
    "uclSystemName": "agent-gateway-61f9806a",
    "uclSystemTenantId": "550e8400-e29b-41d4-a716-446655440005",
    "configuration": {
      "credentials": {
        "outboundCommunication": {
          "oauth2ResourceIndicator": {
            "url": "https://partner-api.example.com",
            "tokenServiceUrl": "https://customer-sci.accounts.ondemand.com",
            "clientId": "responder-sci-client-id",
            "protectedResources": ["api3"]
          }
        },
        "inboundCommunication": {
          "oauth2ResourceIndicator": {
            "clientId": "responder-sci-client-id",
            "protectedResources": ["api1"]
          }
        }
      }
    }
  }
}' | python -m json.tool
```

Expected:
```json
{
  "state": "READY",
  "configuration": {
    "fragments": [
      {
        "FragmentName": "sap-managed-runtime-agw-subscriber-ias",
        "tokenService.body.resource": "urn:sap:identity:application:provider:name:sap-internal",
        "tokenServiceURL": "https://customer-sci.accounts.ondemand.com/oauth2/token",
        "URL": "https://partner-api.example.com",
        "Authentication": "OAuth2ClientCredentials",
        "$metadata": { ... }
      },
      {
        "FragmentName": "sap-managed-runtime-agw-subscriber-ias-user",
        ...
      }
    ]
  }
}
```

### Unassign

```bash
curl -s -X PATCH http://localhost:9000/v1/tenantMappings/tenant-123 \
  -H "Content-Type: application/json" \
  -d '{
  "context": {
    "platform": "btp",
    "accountId": "test-account",
    "uclFormationId": "550e8400-e29b-41d4-a716-446655440000",
    "uclFormationName": "test-formation",
    "uclFormationTypeId": "d23d9e9a-fd1b-4dcd-b30b-01c4e86f4f8c",
    "operation": "unassign",
    "operationId": "550e8400-e29b-41d4-a716-446655440007"
  },
  "receiverTenant": {
    "state": "DELETING",
    "uclAssignmentId": "550e8400-e29b-41d4-a716-446655440003",
    "deploymentRegion": "cf-eu10",
    "applicationNamespace": "ias.initiator",
    "applicationUrl": "https://test.example.com",
    "applicationTenantId": "tenant-123",
    "globalTenantId": "0131f94a-3fb5-4c18-941c-d8e145f99210",
    "subdomain": "test-subdomain",
    "uclSystemName": "test-system",
    "uclSystemTenantId": "550e8400-e29b-41d4-a716-446655440004"
  },
  "assignedTenant": {
    "deploymentRegion": "cf-eu10",
    "applicationNamespace": "ias.responder",
    "applicationUrl": "https://partner.example.com",
    "applicationTenantId": "partner-tenant-456",
    "uclSystemName": "partner-system",
    "uclSystemTenantId": "550e8400-e29b-41d4-a716-446655440005"
  }
}' | python -m json.tool
```

Expected: `{"state": "READY"}`

### Unknown Formation Type

Use any UUID other than `d23d9e9a-fd1b-4dcd-b30b-01c4e86f4f8c` -> HTTP 200 `{"state": "READY"}` with no configuration (short-circuits without config exchange).

### Error: Missing facilitatorUrl

Omit `receiverTenant.configuration` or omit `facilitatorUrl` from it -> HTTP 400 with `"receiverTenant.configuration.facilitatorUrl is required for SCI App2App integration"`.
