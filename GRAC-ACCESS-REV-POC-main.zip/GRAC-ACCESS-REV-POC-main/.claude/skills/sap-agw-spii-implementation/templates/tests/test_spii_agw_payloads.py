"""
Payload-based tests for the AGW SPII integration.

Each test loads a real request payload captured from formation_agw.html and
asserts the response matches the corresponding captured response payload.
UUIDs in FragmentNames are generated at runtime, so those are verified by
prefix rather than exact value.

The handler is stateless — each test fires its request independently and
does not depend on previous tests having populated any in-memory state.
"""

import json
import os
import re
import sys
from pathlib import Path
from unittest.mock import patch

import pytest
from starlette.applications import Starlette
from starlette.testclient import TestClient

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

from api.spii import create_spii_routes

PAYLOADS = Path(__file__).parent / "payloads" / "agw"

# Env vars that match the values embedded in the captured payloads
AGW_CLIENT_ID = "a3f7c291-5e84-4b6d-9d02-837f120ce445"
AGW_AGENT_PUBLIC_URL = "https://jupiter.agent-unit-test-dev-eu12.orbit.auttst.on.dwc.tools.sap"
AGW_DEST_INSTANCE_ID = "e2b94d63-7a15-4f08-b3c1-905d682af017"


_UUID_SUFFIX = re.compile(
    r"-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
)


def _strip_uuid_suffix(name: str) -> str:
    """Strip a trailing UUID4 suffix from a FragmentName."""
    return _UUID_SUFFIX.sub("", name)


def load(filename: str) -> dict:
    return json.loads((PAYLOADS / filename).read_text())


@pytest.fixture
def client():
    routes = create_spii_routes()
    app = Starlette(routes=routes)
    return TestClient(app)


@pytest.fixture(autouse=True)
def env_vars():
    with patch.dict(os.environ, {
        "INITIATOR_MT_IAS_CLIENT_ID": AGW_CLIENT_ID,
        "AGENT_PUBLIC_URL": AGW_AGENT_PUBLIC_URL,
    }):
        yield


def test_assign_step1_returns_config_pending(client):
    """Step 1: both INITIAL — agent returns CONFIG_PENDING with oauth2ResourceIndicator config."""
    request = load("request_1_assign_step1.json")
    expected = load("response_1_assign_step1.json")

    response = client.patch("/v1/tenantMappings/2423dde2-c17a-42a4-93cb-a8c650868245", json=request)

    assert response.status_code == 200
    assert response.json() == expected


def _mock_read_from_mount(base_volume_mount, base_var_name, module, instance, target):
    """Simulate read_from_mount_and_fallback_to_env_var writing instanceid onto target."""
    assert base_volume_mount == "/etc/secrets/appfnd"
    assert base_var_name == "CLOUD_SDK_CFG"
    assert module == "destination"
    assert instance == "default"
    target.instanceid = AGW_DEST_INSTANCE_ID


@patch(
    "services.sci_app2app_service.read_from_mount_and_fallback_to_env_var",
    side_effect=_mock_read_from_mount,
)
def test_assign_step2_returns_ready_with_fragments(mock_read_from_mount, client):
    """Step 2: receiver CONFIG_PENDING, AGW READY — agent returns READY with connectivity.fragments."""
    request = load("request_2_assign_step2.json")
    expected = load("response_2_assign_step2.json")

    response = client.patch("/v1/tenantMappings/2423dde2-c17a-42a4-93cb-a8c650868245", json=request)

    assert response.status_code == 200
    data = response.json()
    assert data["state"] == expected["state"]

    fragments = data["configuration"]["connectivity"]["fragments"]
    expected_fragments = expected["configuration"]["connectivity"]["fragments"]
    assert len(fragments) == len(expected_fragments)

    for fragment, exp_fragment in zip(fragments, expected_fragments):
        # FragmentName has a runtime UUID suffix — verify prefix only
        exp_prefix = _strip_uuid_suffix(exp_fragment["FragmentName"])
        assert fragment["FragmentName"].startswith(exp_prefix + "-")

        # Assert every field except FragmentName exactly
        for key, value in exp_fragment.items():
            if key != "FragmentName":
                assert fragment[key] == value, f"Fragment field '{key}' mismatch"


def test_unassign_returns_ready(client):
    """Unassign — agent acknowledges with READY (no side effects)."""
    request = load("request_3_unassign.json")
    expected = load("response_3_unassign.json")

    response = client.patch("/v1/tenantMappings/2423dde2-c17a-42a4-93cb-a8c650868245", json=request)

    assert response.status_code == 200
    assert response.json() == expected
