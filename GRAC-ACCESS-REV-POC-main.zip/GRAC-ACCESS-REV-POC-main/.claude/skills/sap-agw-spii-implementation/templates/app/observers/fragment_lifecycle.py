# app/observers/fragment_lifecycle.py
import logging
import uuid
from typing import Any, Dict

from sap_cloud_sdk.destination import (
    Fragment, Label, Level, ListOptions, create_fragment_client,
)
from observers.base import SPIIObserver

logger = logging.getLogger(__name__)

# The MCP destination fragment will be addressed in a subsequent SPII implementation
# with LoB systems, via a dedicated LoB formation type.


class FragmentLifecycleObserver(SPIIObserver):

    def on_assign_ready(
        self, notification_data: Dict[str, Any], partner_config: Dict[str, Any]
    ) -> None:
        token_service_url = partner_config.get("tokenServiceUrl", "")
        agent_gateway_url = partner_config.get("url", "")
        self._create_ias_fragment(notification_data, token_service_url, agent_gateway_url)

    def on_unassign(self, notification_data: Dict[str, Any]) -> None:
        self._delete_fragments(notification_data)

    # --- Private methods ---

    def _create_ias_fragment(
        self, notification_data: Dict[str, Any], token_service_url: str, agent_gateway_url: str
    ) -> None:
        receiver = notification_data.get("receiverTenant", {})
        gtid = receiver.get("globalTenantId")
        subdomain = receiver.get("subdomain")

        if not gtid:
            logger.warning("receiverTenant.globalTenantId is missing — skipping IAS fragment creation")
            return

        logger.info(f"Creating IAS fragment for gtid={gtid}, tenant={subdomain}")
        fragment_client = create_fragment_client(instance="default")

        existing = fragment_client.list_instance_fragments(
            filter=ListOptions(
                filter_labels=[Label(key="sap-managed-runtime-gtid", values=[gtid])]
            ),
            tenant=subdomain,
        )
        if existing:
            logger.info(
                f"IAS fragment for gtid={gtid} already exists ({existing[0].name}) — skipping creation"
            )
            return

        fragment_id = uuid.uuid4()
        fragment_name = f"sap-managed-runtime-agw-subscriber-ias-{fragment_id}"
        fragment = Fragment(
            name=fragment_name,
            properties={
                "tokenService.body.resource": (
                    "urn:sap:identity:application:provider:name:sap-internal"
                ),
                "tokenServiceURL": f"{token_service_url}/oauth2/token",
                "URL": agent_gateway_url,
                "Authentication": "OAuth2ClientCredentials",
            },
        )

        fragment_client.create_fragment(fragment, level=Level.SERVICE_INSTANCE, tenant=subdomain)

        labels = [
            Label(key="sap-managed-runtime-type", values=["subscriber.ias"]),
            Label(key="sap-managed-runtime-gtid", values=[gtid]),
        ]
        fragment_client.update_fragment_labels(
            fragment_name, labels, level=Level.SERVICE_INSTANCE, tenant=subdomain
        )
        logger.info(f"IAS fragment created: {fragment_name} for gtid={gtid}")

        # User fragment: same as IAS but without Authentication — used for principal propagation
        user_fragment_name = f"sap-managed-runtime-agw-subscriber-ias-user-{fragment_id}"
        user_fragment = Fragment(
            name=user_fragment_name,
            properties={
                "tokenService.body.resource": (
                    "urn:sap:identity:application:provider:name:sap-internal"
                ),
                "tokenServiceURL": f"{token_service_url}/oauth2/token",
                "URL": agent_gateway_url,
            },
        )

        fragment_client.create_fragment(user_fragment, level=Level.SERVICE_INSTANCE, tenant=subdomain)

        user_labels = [
            Label(key="sap-managed-runtime-type", values=["subscriber.ias.user"]),
            Label(key="sap-managed-runtime-gtid", values=[gtid]),
        ]
        fragment_client.update_fragment_labels(
            user_fragment_name, user_labels, level=Level.SERVICE_INSTANCE, tenant=subdomain
        )
        logger.info(f"IAS user fragment created: {user_fragment_name} for gtid={gtid}")

    def _delete_fragments(self, notification_data: Dict[str, Any]) -> None:
        receiver = notification_data.get("receiverTenant", {})
        gtid = receiver.get("globalTenantId")
        subdomain = receiver.get("subdomain")

        if not gtid:
            logger.warning("receiverTenant.globalTenantId is missing — skipping fragment deletion")
            return

        logger.info(f"Deleting fragments for gtid={gtid}, tenant={subdomain}")
        fragment_client = create_fragment_client(instance="default")

        existing = fragment_client.list_instance_fragments(
            filter=ListOptions(
                filter_labels=[Label(key="sap-managed-runtime-gtid", values=[gtid])]
            ),
            tenant=subdomain,
        )
        if not existing:
            logger.info(f"No fragments found for gtid={gtid} — nothing to delete")
            return

        for fragment in existing:
            fragment_client.delete_fragment(
                fragment.name, level=Level.SERVICE_INSTANCE, tenant=subdomain
            )
            logger.info(f"Fragment deleted: {fragment.name} for gtid={gtid}")
