from enum import Enum
from typing import Any, Dict, Literal, Optional, Union
from uuid import UUID

from pydantic import BaseModel, field_validator


class AssignmentState(str, Enum):
    INITIAL = "INITIAL"
    CONFIG_PENDING = "CONFIG_PENDING"
    DELETING = "DELETING"
    ERROR = "ERROR"
    READY = "READY"


class OperationType(str, Enum):
    ASSIGN = "assign"
    UNASSIGN = "unassign"


class Platform(str, Enum):
    BTP = "btp"
    UNIFIED_SERVICES = "unified-services"


class Context(BaseModel):
    platform: Platform
    crmId: Optional[Union[str, int]] = None
    accountId: Union[str, int]
    uclFormationId: UUID
    uclFormationName: str
    uclFormationTypeId: UUID
    operation: OperationType
    operationId: Optional[UUID] = None


class TenantInfo(BaseModel):
    deploymentRegion: str
    applicationNamespace: str
    applicationUrl: str
    applicationTenantId: str
    globalTenantId: Optional[str] = None
    subaccountId: Optional[UUID] = None
    subdomain: Optional[str] = None
    uclSystemName: str
    uclSystemTenantId: UUID
    parameters: Optional[Dict[str, Any]] = None
    configuration: Optional[Dict[str, Any]] = None
    deploymentId: Optional[str] = None
    systemBusinessType: Optional[str] = None
    tenantBusinessType: Optional[str] = None

    @field_validator("globalTenantId", "subdomain", mode="before")
    @classmethod
    def empty_str_to_none(cls, v):
        if v == "":
            return None
        return v

    @field_validator("subaccountId", mode="before")
    @classmethod
    def empty_uuid_to_none(cls, v):
        if v == "":
            return None
        return v


class ReceiverTenant(TenantInfo):
    state: AssignmentState
    uclAssignmentId: UUID


class AssignedTenant(TenantInfo):
    state: Optional[AssignmentState] = None
    uclAssignmentId: Optional[UUID] = None

    @field_validator("state", mode="before")
    @classmethod
    def empty_state_to_none(cls, v):
        if v == "":
            return None
        return v

    @field_validator("uclAssignmentId", mode="before")
    @classmethod
    def empty_assignment_id_to_none(cls, v):
        if v == "":
            return None
        return v


class NotificationPayload(BaseModel):
    context: Context
    receiverTenant: ReceiverTenant
    assignedTenant: AssignedTenant


class SPIIResponse(BaseModel):
    state: Literal["CONFIG_PENDING", "READY"]
    configuration: Optional[Dict[str, Any]] = None


class SPIIErrorResponse(BaseModel):
    error: str
