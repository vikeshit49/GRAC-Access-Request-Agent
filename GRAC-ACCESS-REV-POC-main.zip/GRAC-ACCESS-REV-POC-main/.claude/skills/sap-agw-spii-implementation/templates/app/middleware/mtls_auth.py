import logging
import os
from typing import List, Optional

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

logger = logging.getLogger(__name__)


def parse_dn(dn_string: str) -> dict:
    """Parse X.509 Distinguished Name into components."""
    result = {}
    if not dn_string:
        return result

    parts = []
    current = ""
    i = 0
    while i < len(dn_string):
        if dn_string[i] == "\\" and i + 1 < len(dn_string):
            current += dn_string[i : i + 2]
            i += 2
        elif dn_string[i] == ",":
            parts.append(current.strip())
            current = ""
            i += 1
        else:
            current += dn_string[i]
            i += 1
    if current:
        parts.append(current.strip())

    for part in parts:
        if "=" in part:
            key, value = part.split("=", 1)
            result[key.strip()] = value.strip()

    return result


class MTLSAuthMiddleware(BaseHTTPMiddleware):
    def __init__(
        self,
        app,
        path_prefixes: Optional[List[str]] = None,
        expected_subject_dn: Optional[str] = None,
        expected_cn: Optional[str] = None,
        expected_org: Optional[str] = None,
    ):
        super().__init__(app)
        self.path_prefixes = path_prefixes or ["/v1/tenantMappings"]
        self.expected_subject_dn = expected_subject_dn or os.getenv(
            "UCL_CLIENT_CERT_SUBJECT"
        )
        self.expected_cn = expected_cn or os.getenv("UCL_CLIENT_CERT_CN")
        self.expected_org = expected_org or os.getenv("UCL_CLIENT_CERT_ORG")

        logger.info(
            f"MTLSAuth initialized: prefixes={self.path_prefixes}, "
            f"cn={self.expected_cn}, org={self.expected_org}"
        )

    async def dispatch(self, request: Request, call_next):
        if not any(request.url.path.startswith(p) for p in self.path_prefixes):
            return await call_next(request)

        cert_subject = request.headers.get("X-SSL-Client-Subject-DN")
        cert_issuer = request.headers.get("X-SSL-Client-Issuer-DN")

        if not cert_subject:
            if self.expected_subject_dn or self.expected_cn or self.expected_org:
                logger.error("Client certificate required but not provided")
                return JSONResponse(
                    status_code=401,
                    content={"error": "Client certificate required"},
                )
            logger.warning(
                "No certificate validation configured, allowing request"
            )
            return await call_next(request)

        if self.expected_subject_dn and cert_subject != self.expected_subject_dn:
            logger.error(
                f"Subject DN mismatch: expected={self.expected_subject_dn}, "
                f"got={cert_subject}"
            )
            return JSONResponse(
                status_code=401,
                content={"error": "Invalid client certificate"},
            )

        attrs = parse_dn(cert_subject)

        if self.expected_cn and attrs.get("CN") != self.expected_cn:
            logger.error(
                f"CN mismatch: expected={self.expected_cn}, got={attrs.get('CN')}"
            )
            return JSONResponse(
                status_code=401,
                content={"error": "Invalid client certificate"},
            )

        if self.expected_org and attrs.get("O") != self.expected_org:
            logger.error(
                f"Org mismatch: expected={self.expected_org}, got={attrs.get('O')}"
            )
            return JSONResponse(
                status_code=401,
                content={"error": "Invalid client certificate"},
            )

        logger.info(
            f"Certificate validated: CN={attrs.get('CN')}, O={attrs.get('O')}"
        )

        request.state.client_cert = {
            "subject": cert_subject,
            "issuer": cert_issuer,
            "cn": attrs.get("CN"),
            "org": attrs.get("O"),
        }

        return await call_next(request)
