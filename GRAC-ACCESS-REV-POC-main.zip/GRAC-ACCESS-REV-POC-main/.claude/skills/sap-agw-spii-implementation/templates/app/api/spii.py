import logging

from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from models.spii import NotificationPayload, SPIIResponse
from services.spii_service import SPIIService, ValidationError

logger = logging.getLogger(__name__)


async def handle_tenant_mapping_notification(request: Request) -> JSONResponse:
    tenant_id = request.path_params.get("tenantId")
    x_tenant_id = request.headers.get("x-tenant-id")

    logger.info(f"SPII notification for tenant {tenant_id}, x-tenant-id: {x_tenant_id}")

    try:
        body = await request.json()
        payload = NotificationPayload(**body)

        logger.info(
            f"Operation: {payload.context.operation}, "
            f"Formation: {payload.context.uclFormationName}, "
            f"Assignment: {payload.receiverTenant.uclAssignmentId}"
        )

        spii_service = SPIIService()
        result = await spii_service.handle_notification_sync(
            tenant_id, payload.model_dump()
        )

        if result.error:
            logger.error(f"Processing error: {result.error}")
            return JSONResponse(status_code=200, content={"error": result.error})

        response = SPIIResponse(state=result.state, configuration=result.configuration)
        return JSONResponse(
            status_code=200, content=response.model_dump(exclude_none=True)
        )

    except (ValueError, ValidationError) as e:
        logger.error(f"Validation error: {e}")
        return JSONResponse(status_code=400, content={"error": str(e)})

    except Exception as e:
        logger.exception(f"Server error: {e}")
        return JSONResponse(status_code=500, content={"error": f"Internal error: {e}"})


async def health_check(request: Request) -> JSONResponse:
    return JSONResponse({"status": "healthy"})


def create_spii_routes() -> list[Route]:
    return [
        Route(
            "/v1/tenantMappings/{tenantId}",
            handle_tenant_mapping_notification,
            methods=["PATCH"],
        ),
        Route("/health", health_check, methods=["GET"]),
    ]
