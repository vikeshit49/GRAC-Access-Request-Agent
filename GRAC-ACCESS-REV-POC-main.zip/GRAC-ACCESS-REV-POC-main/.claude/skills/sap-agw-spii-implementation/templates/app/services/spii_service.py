"""
SPII Facade — central entry point for ``PATCH /v1/tenantMappings/{tenantId}``.

Owns shared concerns and delegates formation-specific work to handlers:

- Validation of the notification envelope (``context``, ``receiverTenant``)
- Unassign cleanup (handler-owned, but routed here)
- Dispatch by ``assignedTenant.applicationNamespace``

Handlers are stateless. Idempotency at the handler level is achieved by the
handler's own external operations being safe to re-run with the same inputs —
UCL retries on HTTP 500 and we want those retries to land on a clean state,
not a cached one. UCL is the source of truth for assignment state.

To add a new formation type, write an ``SPIIFormationHandler`` and append it
to ``handlers`` in :func:`_build_handler_registry`. No other change needed in
this file — the Facade picks up the new namespace automatically.
"""

import logging
from typing import Any, Dict, List, Optional, Sequence, Union

from services.spii_agw import AgentGatewayHandler
from services.spii_base import (
    AssignmentState,
    SPIIFormationHandler,
    StatusReport,
    ValidationError,
)

logger = logging.getLogger(__name__)


def _build_handler_registry() -> Dict[str, SPIIFormationHandler]:
    """Build the ``applicationNamespace -> handler`` lookup.

    A handler may declare a single namespace (``str``) or a sequence
    (``Sequence[str]``). The Assistant handler returns a sequence because its
    namespace list is derived from the agent's ORD ``integrationDependencies``
    at runtime.
    """
    handlers: List[SPIIFormationHandler] = [
        AgentGatewayHandler(),
        # Add additional handlers here, e.g.:
        #   JouleHandler(),
        #   AppFNDAssistantHandler(),
        #   AuditLogV3Handler(),
    ]
    registry: Dict[str, SPIIFormationHandler] = {}
    for handler in handlers:
        ns: Union[str, Sequence[str]] = handler.application_namespace
        if isinstance(ns, str):
            registry[ns] = handler
        else:
            for n in ns:
                registry[n] = handler
    return registry


_HANDLER_REGISTRY: Dict[str, SPIIFormationHandler] = _build_handler_registry()


def _resolve_handler(application_namespace: str) -> Optional[SPIIFormationHandler]:
    """Find the handler for ``application_namespace``.

    Three-step lookup, matching a switch with a default branch:
    1. Exact match in the registry — the common case for handlers that
       declare a fixed namespace (``sap.agw``, ``sap.als``, ``sap.joule``).
    2. Subnamespace fallback — a registered key is a *subnamespace* of the
       incoming namespace (i.e. ``key.startswith(application_namespace + ".")``).
       This bridges the case where UCL sends a parent namespace (e.g.
       ``sap.sf``) but the agent registered a product-specific subnamespace
       derived from its ORD (e.g. ``sap.sf.wfs``). The first matching key
       wins; with a single handler per product family this is unambiguous.
    3. Soft fallback: ask each handler whether it claims this namespace via
       ``matches_fallback``. The default ABC implementation returns False;
       handlers like the Assistant override it to recognize an open-ended
       family (e.g. ``sap.agt*``).

    Returns ``None`` if none of the three steps finds a handler — the Facade
    then either tolerates (unassign) or raises ``ValidationError`` (assign).
    """
    handler = _HANDLER_REGISTRY.get(application_namespace)
    if handler is not None:
        return handler
    # Step 2: subnamespace match. A registered key like ``sap.sf.wfs``
    # satisfies an incoming ``sap.sf``. The ``+ "."`` guard prevents
    # accidental prefix collisions (``sap.sfx`` must not match ``sap.sf``).
    prefix = application_namespace + "."
    for key, h in _HANDLER_REGISTRY.items():
        if key.startswith(prefix):
            return h
    # Step 3: iterating .values() yields the same handler under each of its
    # declared namespaces; matches_fallback is a cheap predicate, so the
    # duplicate work is negligible. First match wins.
    for h in _HANDLER_REGISTRY.values():
        if h.matches_fallback(application_namespace):
            return h
    return None


class SPIIService:
    """The Facade. Validates and dispatches."""

    async def handle_notification_sync(
        self, tenant_id: str, notification_data: Dict[str, Any]
    ) -> StatusReport:
        context = notification_data.get("context", {})
        receiver = notification_data.get("receiverTenant", {})
        assigned = notification_data.get("assignedTenant", {})

        operation = context.get("operation")
        ucl_assignment_id = str(receiver.get("uclAssignmentId", ""))
        receiver_state = receiver.get("state")
        assigned_state = assigned.get("state", "")
        assigned_config = assigned.get("configuration")
        application_namespace = assigned.get("applicationNamespace", "")

        self._validate(notification_data)

        if operation == "unassign":
            # Unassign is namespace-tolerant: even unknown namespaces are
            # acknowledged so UCL can finalize cleanup. If the namespace is
            # known, route to its handler so handler-specific cleanup can run.
            handler = _resolve_handler(application_namespace)
            if handler is not None:
                return handler.handle_unassign(ucl_assignment_id, notification_data)
            return StatusReport(state=AssignmentState.READY)

        # Assign: route by namespace.
        handler = _resolve_handler(application_namespace)
        if handler is None:
            raise ValidationError(
                f"Unsupported assignedTenant.applicationNamespace "
                f"'{application_namespace}'"
            )
        return handler.handle_assign(
            ucl_assignment_id=ucl_assignment_id,
            receiver_state=receiver_state,
            assigned_state=assigned_state,
            assigned_config=assigned_config,
            notification_data=notification_data,
            tenant_id=tenant_id,
        )

    def _validate(self, data: Dict[str, Any]) -> None:
        context = data.get("context", {})
        receiver = data.get("receiverTenant", {})

        if not context:
            raise ValidationError("context cannot be empty")
        if not receiver:
            raise ValidationError("receiverTenant cannot be empty")
        if not context.get("operation"):
            raise ValidationError("context.operation is required")
        if context.get("operation") not in ("assign", "unassign"):
            raise ValidationError("context.operation must be 'assign' or 'unassign'")
        if not receiver.get("uclAssignmentId"):
            raise ValidationError("receiverTenant.uclAssignmentId is required")
        if not receiver.get("state"):
            raise ValidationError("receiverTenant.state is required")
