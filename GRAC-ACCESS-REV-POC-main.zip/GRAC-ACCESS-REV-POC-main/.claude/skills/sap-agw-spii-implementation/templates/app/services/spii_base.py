"""
Shared SPII building blocks used by every formation-type handler.

The SPII service follows a Facade pattern: the central ``SPIIService`` owns
validation and dispatch by ``assignedTenant.applicationNamespace``. Each
formation type (sap.agw, sap.joule, sap.als, ORD-driven Assistant namespaces,
...) ships its own ``SPIIFormationHandler`` implementation that the service
routes to. Handlers are stateless — every notification is processed solely
from the payload it carries. UCL is the source of truth for assignment state.

This module is the small piece of code every handler depends on:
- ``AssignmentState`` / ``StatusReport`` — return types from a handler
- ``SPIIFormationHandler`` — the ABC each handler implements
- ``ValidationError`` — raised by handlers for HTTP 400 conditions
"""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Dict, Optional, Sequence, Union


class AssignmentState(str, Enum):
    INITIAL = "INITIAL"
    CONFIG_PENDING = "CONFIG_PENDING"
    DELETING = "DELETING"
    READY = "READY"
    ERROR = "ERROR"


class ValidationError(Exception):
    """Raised by handlers (or the Facade) for inputs that should yield HTTP 400."""


class StatusReport:
    state: str
    configuration: Optional[Dict[str, Any]]
    error: Optional[str]

    def __init__(
        self,
        state: Union[AssignmentState, str],
        configuration: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
    ):
        self.state = state.value if isinstance(state, AssignmentState) else state
        self.configuration = configuration
        self.error = error


class SPIIFormationHandler(ABC):
    """A handler for one (or many) ``applicationNamespace`` values.

    Most handlers map to a single namespace (e.g. ``"sap.agw"``,
    ``"sap.als"``, ``"sap.joule"``). The Assistant handler returns a sequence
    of namespaces derived from the agent's ORD ``integrationDependencies`` —
    the registry builder loops over them so a single instance is registered
    under every declared namespace.
    """

    @property
    @abstractmethod
    def application_namespace(self) -> Union[str, Sequence[str]]:
        """The namespace(s) this handler is responsible for."""

    @abstractmethod
    def handle_assign(
        self,
        ucl_assignment_id: str,
        receiver_state: str,
        assigned_state: str,
        assigned_config: Optional[Dict[str, Any]],
        notification_data: Dict[str, Any],
        tenant_id: str,
    ) -> StatusReport:
        """Handle a SPII assign notification for this formation type."""

    @abstractmethod
    def handle_unassign(
        self,
        ucl_assignment_id: str,
        notification_data: Dict[str, Any],
    ) -> StatusReport:
        """
        Handle a SPII unassign notification for this formation type.

        Responsible for cleaning up any resources created during assign
        (fragments, destinations, etc.). Handlers do not carry assignment
        state across calls — everything they need is in ``notification_data``.
        """

    def matches_fallback(self, application_namespace: str) -> bool:
        """Whether this handler accepts ``application_namespace`` as a fallback.

        Override in handlers that recognize namespaces beyond their exact
        declared list — used by the Facade after an exact registry miss but
        before raising ``ValidationError``. Default: no fallback.
        """
        del application_namespace  # default impl: unused; subclasses inspect it
        return False
