"""
SPII handler for the Agent Gateway (sap.agw) formation type.

This is a two-step handler:

- Step 1 (assign, ``receiverTenant`` is INITIAL/ERROR, ``assignedTenant`` is
  INITIAL/CONFIG_PENDING/""): build our SCI App2App ``oauth2ResourceIndicator``
  config from ``facilitatorUrl`` + env vars and return CONFIG_PENDING.

- Step 2 (assign, ``receiverTenant`` is CONFIG_PENDING/ERROR, ``assignedTenant``
  is READY): extract the partner's ``oauth2ResourceIndicator`` config, build
  the ``connectivity.fragments`` payload, return READY. The Destinations
  Facilitator picks up the fragments and creates the IAS destination fragments.

Unassign is a no-op acknowledgement — fragment cleanup is handled by the
Destinations Facilitator out-of-band.

The handler is stateless: every notification is processed solely from the
payload it carries. UCL retries are safe because Step 1/Step 2 builders are
pure functions of the payload and the Destinations Facilitator is itself
idempotent.
"""

import logging
from typing import Any, Dict, Optional

from services import sci_app2app_service
from services.spii_base import (
    AssignmentState,
    SPIIFormationHandler,
    StatusReport,
)

logger = logging.getLogger(__name__)

APPLICATION_NAMESPACE_AGW = "sap.agw"


class AgentGatewayHandler(SPIIFormationHandler):
    """Handles SPII assign/unassign for the Agent Gateway formation type."""

    @property
    def application_namespace(self) -> str:
        return APPLICATION_NAMESPACE_AGW

    def handle_assign(
        self,
        ucl_assignment_id: str,
        receiver_state: str,
        assigned_state: str,
        assigned_config: Optional[Dict[str, Any]],
        notification_data: Dict[str, Any],
        tenant_id: str,
    ) -> StatusReport:
        # Step 1: receiver INITIAL/ERROR, assigned INITIAL/CONFIG_PENDING/""
        if receiver_state in ("INITIAL", "ERROR") and assigned_state in (
            "INITIAL",
            "CONFIG_PENDING",
            "",
        ):
            config = sci_app2app_service.handle_initial(notification_data)
            logger.info(
                "AGW assign step 1: assignment=%s state=CONFIG_PENDING",
                ucl_assignment_id,
            )
            return StatusReport(
                state=AssignmentState.CONFIG_PENDING, configuration=config
            )

        # Step 2: receiver CONFIG_PENDING/ERROR, assigned READY
        if receiver_state in ("CONFIG_PENDING", "ERROR") and assigned_state == "READY":
            partner_config = sci_app2app_service.handle_config_pending(
                notification_data
            )
            connectivity = partner_config.get("connectivity")
            ready_config = {"connectivity": connectivity} if connectivity else None
            logger.info(
                "AGW assign step 2: assignment=%s state=READY", ucl_assignment_id
            )
            return StatusReport(
                state=AssignmentState.READY, configuration=ready_config
            )

        logger.warning(
            "AGW assign: unexpected state combo receiver=%s assigned=%s — "
            "returning CONFIG_PENDING",
            receiver_state,
            assigned_state,
        )
        return StatusReport(state=AssignmentState.CONFIG_PENDING)

    def handle_unassign(
        self,
        ucl_assignment_id: str,
        notification_data: Dict[str, Any],
    ) -> StatusReport:
        logger.info("AGW unassign: assignment=%s", ucl_assignment_id)
        return StatusReport(state=AssignmentState.READY)
