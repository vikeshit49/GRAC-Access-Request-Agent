import logging
import os
import uuid
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Dict

from sap_cloud_sdk.core.secret_resolver import read_from_mount_and_fallback_to_env_var

logger = logging.getLogger(__name__)

FRAGMENT_NAME_IAS = "sap-managed-runtime-agw-subscriber-ias"
FRAGMENT_NAME_IAS_USER = "sap-managed-runtime-agw-subscriber-ias-user"
TOKEN_SERVICE_BODY_RESOURCE = "urn:sap:identity:application:provider:name:sap-internal"


@dataclass
class _DestinationInstanceConfig:
    instanceid: str = ""


def _get_destination_instance_id() -> str:
    config = _DestinationInstanceConfig()
    try:
        read_from_mount_and_fallback_to_env_var(
            base_volume_mount="/etc/secrets/appfnd",
            base_var_name="CLOUD_SDK_CFG",
            module="destination",
            instance="default",
            target=config,
        )
    except RuntimeError:
        logger.warning("Could not resolve destination instance ID from secrets — instanceId will be empty")
    return config.instanceid


class FragmentLabelKey(StrEnum):
    TYPE = "sap-managed-runtime-type"
    GTID = "sap-managed-runtime-gtid"
    ORD_ID = "sap-managed-runtime-ordid"


class FragmentTypeValue(StrEnum):
    SUBSCRIBER_IAS = "subscriber.ias"
    SUBSCRIBER_IAS_USER = "subscriber.ias.user"


def handle_initial(notification_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle the INITIAL state (Step 1) of the SCI App2App integration.

    Extracts facilitatorUrl from receiverTenant.configuration, builds
    bi-directional oauth2ResourceIndicator configuration.
    """
    receiver = notification_data.get("receiverTenant", {})
    receiver_config = receiver.get("configuration") or {}

    facilitator_url = receiver_config.get("facilitatorUrl")
    if not facilitator_url:
        raise ValueError(
            "receiverTenant.configuration.facilitatorUrl is required "
            "for SCI App2App integration"
        )

    client_id = os.getenv("INITIATOR_MT_IAS_CLIENT_ID", "")
    agent_base_url = os.getenv("AGENT_PUBLIC_URL", "").rstrip("/")
    agent_url = f"{agent_base_url}/api/a2a-agent"

    logger.info(
        f"Building SCI App2App config: facilitatorUrl={facilitator_url}, "
        f"agentUrl={agent_url}"
    )

    return {
        "credentials": {
            "outboundCommunication": {
                "oauth2ResourceIndicator": {
                    "url": agent_url,
                    "tokenServiceUrl": facilitator_url,
                    "clientId": client_id,
                    "protectedResources": ["agent-api-access"],
                }
            },
            "inboundCommunication": {
                "oauth2ResourceIndicator": {
                    "clientId": client_id,
                    "protectedResources": ["sap-internal"],
                }
            },
        }
    }


def handle_config_pending(notification_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle the CONFIG_PENDING state (Step 2) of the SCI App2App integration.

    Extracts the partner's bi-directional oauth2ResourceIndicator configuration
    from assignedTenant.configuration and builds the connectivity.fragments to
    return in the READY response so the Destinations Facilitator creates the
    subscriber IAS destination fragments.

    Returns:
        Dict with extracted partner configuration and connectivity.fragments for
        the READY response. Keys:
          - url, tokenServiceUrl, clientId, protectedResources: partner outbound
          - inbound (optional): partner inbound
          - connectivity: {"fragments": [...]} — IAS fragments for Destinations Facilitator
    """
    receiver = notification_data.get("receiverTenant", {})
    assigned = notification_data.get("assignedTenant", {})
    assigned_config = assigned.get("configuration")
    tenant_id = receiver.get("applicationTenantId", "")

    if not assigned_config:
        raise ValueError(
            "assignedTenant.configuration is required in CONFIG_PENDING step"
        )

    credentials = assigned_config.get("credentials", {})
    outbound = credentials.get("outboundCommunication", {})
    inbound = credentials.get("inboundCommunication", {})

    if "oauth2ResourceIndicator" not in outbound:
        raise ValueError(
            "assignedTenant.configuration.credentials.outboundCommunication"
            ".oauth2ResourceIndicator is required"
        )

    partner_outbound = outbound["oauth2ResourceIndicator"]
    partner_config: Dict[str, Any] = {
        "url": partner_outbound.get("url", ""),
        "tokenServiceUrl": partner_outbound.get("tokenServiceUrl", ""),
        "clientId": partner_outbound.get("clientId", ""),
        "protectedResources": partner_outbound.get("protectedResources", []),
    }

    logger.info(
        f"Partner outbound: url={partner_config['url']}, "
        f"protectedResources={partner_config['protectedResources']}"
    )

    if "oauth2ResourceIndicator" in inbound:
        partner_inbound = inbound["oauth2ResourceIndicator"]
        partner_config["inbound"] = {
            "clientId": partner_inbound.get("clientId", ""),
            "protectedResources": partner_inbound.get("protectedResources", []),
        }
        logger.info(
            f"Partner inbound: protectedResources={partner_inbound.get('protectedResources')}"
        )

    # Build connectivity.fragments for the READY response.
    # The Destinations Facilitator reads these and creates the subscriber IAS
    # destination fragments, so the Agent Gateway no longer needs to call the
    # Destination Service SDK directly for this purpose.
    gtid = receiver.get("globalTenantId", "")
    token_service_url = partner_config["tokenServiceUrl"].rstrip("/")
    agent_gateway_url = partner_config["url"]
    dest_instance_id = _get_destination_instance_id()

    partner_config["connectivity"] = {
        "fragments": [
            {
                "FragmentName": f"{FRAGMENT_NAME_IAS}-{uuid.uuid4()}",
                "tokenService.body.resource": TOKEN_SERVICE_BODY_RESOURCE,
                "tokenService.body.app_tid": tenant_id,
                "tokenServiceURL": f"{token_service_url}/oauth2/token",
                "URL": agent_gateway_url,
                "Authentication": "OAuth2ClientCredentials",
                "$metadata": {
                    "labels": [
                        {"key": FragmentLabelKey.TYPE, "values": [FragmentTypeValue.SUBSCRIBER_IAS]},
                        {"key": FragmentLabelKey.GTID, "values": [gtid]},
                    ],
                    "instanceId": dest_instance_id,
                },
            },
            {
                "FragmentName": f"{FRAGMENT_NAME_IAS_USER}-{uuid.uuid4()}",
                "tokenService.body.resource": TOKEN_SERVICE_BODY_RESOURCE,
                "tokenService.body.app_tid": tenant_id,
                "tokenServiceURL": f"{token_service_url}/oauth2/token",
                "URL": agent_gateway_url,
                "$metadata": {
                    "labels": [
                        {"key": FragmentLabelKey.TYPE, "values": [FragmentTypeValue.SUBSCRIBER_IAS_USER]},
                        {"key": FragmentLabelKey.GTID, "values": [gtid]},
                    ],
                    "instanceId": dest_instance_id,
                },
            },
        ]
    }

    logger.info(
        f"CONFIG_PENDING handling complete — partner config extracted, "
        f"connectivity fragments built for gtid={gtid}"
    )
    return partner_config
