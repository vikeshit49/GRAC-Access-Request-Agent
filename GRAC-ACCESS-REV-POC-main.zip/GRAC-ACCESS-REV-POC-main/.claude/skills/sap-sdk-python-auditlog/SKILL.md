---
name: sap-sdk-python-auditlog
description: Integrate SAP Audit Log Service using the Application Foundation Python SDK. Use when the user needs to log audit events for security, data access, data modification, or configuration changes in a Python application.
---

# Audit Log Integration with Python SDK

This skill provides guidance for integrating the SAP Audit Log Service using the Application Foundation Python SDK. The audit log module supports logging security events, data access events, data modification events, and configuration change events for compliance and auditing purposes.

## ⚠️ Package Index Policy

All Python packages MUST be installed exclusively from the SAP PyPI proxy:
`https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple`

NEVER use `https://pypi.org/simple` or any other external package index.
NEVER add `--extra-index-url` pointing to PyPI.
If a package is not found in the SAP proxy, report the error — do NOT fall back to PyPI.

## app.yaml Configuration

To use the Audit Log service, add the following to your `app.yaml` under `spec.requires`:

```yaml
requires:
  - name: default
    service: auditlog
    plan: oauth2
```

**Fields:**
- `name`: Instance name for the auditlog service (SDK assumes instance name `default` by default)
- `service`: Must be `auditlog`
- `plan`: Use `oauth2` for the OAuth2 plan

## Installation

```bash
# Using uv (recommended)
uv add sap-cloud-sdk --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"

# Using pip
pip install sap-cloud-sdk --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"
```

## Import

```python
from sap_cloud_sdk.core.auditlog import (
    create_client,
    SecurityEvent,
    DataAccessEvent,
    DataModificationEvent,
    ConfigurationChangeEvent,
    DataDeletionEvent,
    ConfigurationDeletionEvent,
    Tenant,
    SecurityEventAttribute,
    DataAccessAttribute,
    ChangeAttribute,
    DeletedAttribute
)
```

## Quick Start

```python
from sap_cloud_sdk.core.auditlog import create_client, SecurityEvent, Tenant

client = create_client()

# Create and log a security event
security_event = SecurityEvent(
    data="User login attempt",
    success=True,
    user="john.doe",
    tenant=Tenant.PROVIDER
)

client.log(security_event)
```

## Event Types

The module supports six types of audit events:

1. **Security Events**: Authentication, authorization, and security-related activities
2. **Data Access Events**: Reading or accessing personal/sensitive data (GDPR compliance)
3. **Data Modification Events**: Creating, updating, or modifying personal/sensitive data
4. **Data Deletion Events**: Deleting personal/sensitive data
5. **Configuration Change Events**: System configuration and settings changes
6. **Configuration Deletion Events**: Deleting system configurations

## Security Events

Record authentication attempts, authorization failures, and security-relevant activities:

```python
from sap_cloud_sdk.core.auditlog import (
    create_client, SecurityEvent, SecurityEventAttribute, Tenant
)

client = create_client()

security_event = SecurityEvent(
    data="User authentication failed",
    success=False,
    user="john.doe",
    tenant=Tenant.PROVIDER,
    identity_provider="SAP ID",
    ip="192.168.1.100",
    attributes=[
        SecurityEventAttribute("login_method", "password"),
        SecurityEventAttribute("failure_reason", "invalid_credentials")
    ]
)

client.log(security_event)
```

**Required fields:**
- `data`: must not be empty
- `success`: must be explicitly set

## Data Access Events

Record when personal or sensitive data is read or accessed (GDPR compliance):

```python
from sap_cloud_sdk.core.auditlog import (
    create_client, DataAccessEvent, DataAccessAttribute, Tenant
)

client = create_client()

data_access = DataAccessEvent(
    success=True,
    object_type="database",
    object_id={"table": "customers", "schema": "public"},
    subject_type="customer",
    subject_id={"customer_id": "12345"},
    subject_role="end_user",
    attributes=[
        DataAccessAttribute("email", successful=True),
        DataAccessAttribute("phone_number", successful=True)
    ],
    user="service-account",
    tenant=Tenant.PROVIDER
)

client.log(data_access)
```

**Required fields:**
- `object_type`, `object_id`: Identify the data object
- `subject_type`, `subject_id`: Identify the data subject
- `attributes`: at least one attribute
- `success`: must be explicitly set

## Data Modification Events

Record when personal or sensitive data is created, updated, or modified:

```python
from sap_cloud_sdk.core.auditlog import (
    create_client, DataModificationEvent, ChangeAttribute, Tenant
)

client = create_client()

data_modification = DataModificationEvent(
    success=True,
    object_type="user_profile",
    object_id={"profile_id": "profile-123"},
    subject_type="user",
    subject_id={"user_id": "user-456"},
    subject_role="customer",
    attributes=[
        ChangeAttribute("email", "new@example.com", "old@example.com"),
        ChangeAttribute("phone", "+0987654321", "+1234567890")
    ],
    user="admin-user",
    tenant=Tenant.PROVIDER
)

client.log(data_modification)
```

## Data Deletion Events

Track when personal or sensitive data is deleted:

```python
from sap_cloud_sdk.core.auditlog import (
    create_client, DataDeletionEvent, DeletedAttribute, Tenant
)

client = create_client()

data_deletion = DataDeletionEvent(
    success=True,
    object_type="user_profile",
    object_id={"profile_id": "profile-123"},
    subject_type="user",
    subject_id={"user_id": "user-456"},
    subject_role="customer",
    attributes=[
        DeletedAttribute("email", "deleted@example.com"),
        DeletedAttribute("phone", "+1234567890")
    ],
    user="admin-user",
    tenant=Tenant.PROVIDER
)

client.log(data_deletion)
```

## Configuration Change Events

Record system configuration and settings changes:

```python
from sap_cloud_sdk.core.auditlog import (
    create_client, ConfigurationChangeEvent, ChangeAttribute, Tenant
)

client = create_client()

config_change = ConfigurationChangeEvent(
    success=True,
    object_type="system_config",
    object_id={"component": "authentication", "setting": "timeout"},
    attributes=[
        ChangeAttribute("session_timeout", "60", "30"),
        ChangeAttribute("max_attempts", "5", "3")
    ],
    user="system-admin",
    tenant=Tenant.PROVIDER
)

client.log(config_change)
```

## Batch Logging

Log multiple events efficiently:

```python
from sap_cloud_sdk.core.auditlog import (
    create_client, SecurityEvent, DataAccessEvent, DataAccessAttribute
)

client = create_client()

events = [
    SecurityEvent(data="User login", success=True),
    DataAccessEvent(
        success=True,
        object_type="user_profile",
        object_id={"id": "123"},
        subject_type="user",
        subject_id={"id": "456"},
        subject_role="user",
        attributes=[DataAccessAttribute("email", successful=True)]
    )
]

failed_messages = client.log_batch(events)

for failed in failed_messages:
    print(f"Failed to log event: {failed.error}")
```

## Error Handling

```python
from sap_cloud_sdk.core.auditlog import create_client, SecurityEvent
from sap_cloud_sdk.core.auditlog.exceptions import AuditLogError

client = create_client()

try:
    client.log(SecurityEvent(data="Login attempt", success=False))
except AuditLogError as e:
    print(f"Failed to log security event: {e}")
```

## Local Development Mode

Enable local mode for development:

```bash
export APPFND_LOCALDEV_AUDITLOG=true
```

In local mode, events are written to `localauditlog.txt` instead of the SAP Audit Log Service.

## Custom Configuration

```python
from sap_cloud_sdk.core.auditlog import create_client, AuditLogConfig

config = AuditLogConfig(
    service_url="https://api.auditlog.cf.example.com/audit-log/oauth2/v2",
    oauth_url="https://example.authentication.com/oauth/token",
    client_id="your-client-id",
    client_secret="your-client-secret"
)

client = create_client(config=config)
```
