---
name: sap-aeval-generate-tool-schema
description: Generate tools schema in json file for an AI agent by analyzing its codebase.
argument-hint: "[code_path] [output_path]"
---

# Generate Tools Schema

Generate tools schema in json file for an AI agent by analyzing its codebase.

## Arguments

Parse `$ARGUMENTS` as: `[code_path] [output_path]`

- `code_path` — path to the root of the agent codebase (optional). If provided, the skill uses this directory as the root instead of the current working directory. If omitted, uses CWD.
- `output_path` — full path where `tools.json` should be saved (optional). If omitted, saves to `tools.json` in the same directory as `code_path` (or CWD if no `code_path` was given).

## Usage

```
/generate_tools_schema
/generate_tools_schema /path/to/agent/repo
/generate_tools_schema /path/to/agent/repo /path/to/output/tools.json
```

Or simply ask: "generate tools schema"

When invoked without arguments, the skill automatically looks for `README.md` in the current working directory. When a `code_path` is provided, it looks for `README.md` in that directory. When an `output_path` is provided, the generated file is written to that exact path instead of the default location.

## Important Guidelines

**DO NOT hallucinate or generate information that is not present in the codebase.**

- Only extract tool schemas from actual function definitions in the code
- Use docstrings and type hints as-is; do not invent parameter descriptions
- If a function lacks a docstring or type annotations, note it as incomplete rather than guessing
- Omit tools that cannot be meaningfully parsed

## Process

When this skill is invoked, follow these steps:

### Step 1: Read the README and Discover Tools

Read `README.md` to identify the project structure and locate the tools directory (typically `app/tools/` or `src/tools/`). List all Python files in that directory.

### Step 2: Extract Tool Schemas

For each tool file found, parse the Python code to extract:
- Function name (the tool name)
- Function docstring (description)
- Function parameters with their types and descriptions
- Return type and description

Build a schema for each tool following this JSON structure:
```json
{
  "name": "tool_name",
  "description": "Tool description from docstring",
  "input-type": ["semantic_type"],
  "output-type": ["semantic_type"],
  "input": {
    "param_name": {
      "type": "string|integer|array|object|boolean",
      "description": "Parameter description"
    }
  },
  "output": {
    "type": "object|array|string",
    "description": "Output description",
    "properties": {}
  }
}
```

### Step 3: Generate tools.json

Combine all tool schemas into a single JSON file:
```json
{
  "tools": [
    { /* tool 1 schema */ },
    { /* tool 2 schema */ }
  ]
}
```

Save to the resolved output path:
- If `output_path` was provided: save to that exact path.
- Else if `code_path` was provided: save to `<code_path>/tools.json`.
- Otherwise: save to `tools.json` in the current working directory.

### Step 4: Report Results

After generating the file, report:
1. Path to generated tools.json
2. Summary of tools discovered
3. List of tools with incomplete schemas (missing docstrings, untyped parameters, etc.)

## Output

- No arguments: saves to `tools.json` in the current working directory
- `code_path` only: saves to `<code_path>/tools.json`
- `code_path` + `output_path`: saves to `output_path`

## Example

Running `/generate_tools_schema` in an agent directory produces:
- `tools.json` - Tool schemas extracted from code

Running `/generate_tools_schema /path/to/agent` produces:
- `/path/to/agent/tools.json` - Tool schemas extracted from that codebase

Running `/generate_tools_schema /path/to/agent /path/to/prd/tools.json` produces:
- `/path/to/prd/tools.json` - Tool schemas saved at the specified output path