# Facade Pattern for Multi-Namespace SPII

## Why a Facade?

A single SPII endpoint (`PATCH /v1/tenantMappings/{tenantId}`) receives notifications for **all** application namespaces your application participates in. Each namespace has different requirements:

- **Agent Gateway** (`sap.agw`): Two-step SCI App2App exchange with IAS fragment creation.
- **Audit Log V3** (`sap.als`): Single-step with Destination + Fragment creation.
- **Future namespaces**: Will have their own logic.

Without a Facade, you end up with a growing chain of `if/elif` blocks in `handle_notification_sync`, each importing different services and touching different infrastructure. The Facade pattern moves each application namespace into its own handler class, keeping the dispatch logic clean and each handler independently testable.

## How the Dispatch Works

The Facade lives in `app/services/spii_service.py`. The handler registry is built once at import time from the list of `SPIIFormationHandler` instances declared in `_build_handler_registry()`:

```python
from services.spii_audit_log import AuditLogV3Handler
from services.spii_base import SPIIFormationHandler

def _build_handler_registry() -> Dict[str, SPIIFormationHandler]:
    handlers: List[SPIIFormationHandler] = [
        AuditLogV3Handler(),
        # AgentGatewayHandler(),       # added by sap-agw-spii-implementation
        # JouleHandler(),              # added by sap-joule-spii-implementation
        # AppFNDAssistantHandler(),    # added by sap-assistant-spii-implementation
    ]
    registry: Dict[str, SPIIFormationHandler] = {}
    for handler in handlers:
        ns = handler.application_namespace
        if isinstance(ns, str):
            registry[ns] = handler
        else:
            for n in ns:
                registry[n] = handler
    return registry


_HANDLER_REGISTRY: Dict[str, SPIIFormationHandler] = _build_handler_registry()
```

A handler may declare a single namespace (`str`) or a sequence (`Sequence[str]`). The Assistant handler returns a sequence because its namespace list is derived from the agent's ORD `integrationDependencies` at runtime.

Inside `SPIIService.handle_notification_sync()`:

```python
application_namespace = assigned.get("applicationNamespace", "")
handler = _HANDLER_REGISTRY.get(application_namespace)
if handler is None:
    raise ValidationError(
        f"Unsupported assignedTenant.applicationNamespace '{application_namespace}'"
    )
return handler.handle_assign(...)
```

## Adding a New Application Namespace

1. Create `app/services/spii_<name>.py` implementing `SPIIFormationHandler`.
2. Define the application namespace constant (e.g., `APPLICATION_NAMESPACE_MY_SERVICE = "sap.myservice"`).
3. Expose it via the `application_namespace` property:
   ```python
   class MyServiceHandler(SPIIFormationHandler):
       @property
       def application_namespace(self) -> str:
           return APPLICATION_NAMESPACE_MY_SERVICE
   ```
4. Add one line to the `handlers` list in `_build_handler_registry()`:
   ```python
   handlers: List[SPIIFormationHandler] = [
       AuditLogV3Handler(),
       MyServiceHandler(),  # new
   ]
   ```

No changes to `handle_notification_sync`, `_validate`, or any existing handler.

## Handler Responsibilities

Each handler is responsible for:

| Concern | Handler's job |
|---------|---------------|
| State transitions | Decide what state to return based on receiver/assigned states |
| Config exchange | Build and return configuration if needed (or not for single-step) |
| Idempotency | Side effects are check-then-write so re-running the same notification on a UCL retry is safe |

The `SPIIService` Facade remains responsible for:
- Payload validation
- Routing to the correct handler by `assignedTenant.applicationNamespace`
- Rejecting unknown namespaces on `assign` (HTTP 400)
- Tolerating unknown namespaces on `unassign` (so UCL can finalize cleanup)

## Unknown Application Namespaces

The Facade treats unknown namespaces asymmetrically:

- **`assign`**: rejected with `ValidationError` → HTTP 400. The application is signaling that it does not handle this namespace, so UCL should not proceed.
- **`unassign`**: tolerated. The Facade returns `READY` without invoking a handler. This lets UCL finalize cleanup even if a handler has been removed since the assignment was created.

## Testing Handlers in Isolation

Because each handler is a standalone class, you can unit-test it without the full SPIIService machinery. Mock the SDK factory functions at the module level:

```python
from unittest.mock import MagicMock, patch
from services.spii_audit_log import AuditLogV3Handler

@patch("services.spii_audit_log.create_fragment_client")
@patch("services.spii_audit_log.create_client")
def test_auditlog_handler_creates_destination(mock_create_client, mock_frag_client):
    dest_client = MagicMock()
    dest_client.get_subaccount_destination.return_value = None
    mock_create_client.return_value = dest_client

    frag_client = MagicMock()
    frag_client.get_subaccount_fragment.return_value = None
    mock_frag_client.return_value = frag_client

    handler = AuditLogV3Handler()
    result = handler.handle_assign(
        ucl_assignment_id="test",
        receiver_state="INITIAL",
        assigned_state="INITIAL",
        assigned_config=None,
        notification_data=sample_notification,
        tenant_id="tenant-1",
    )

    assert result.state == "READY"
    dest_client.create_destination.assert_called_once()
    frag_client.create_fragment.assert_called_once()
```

This isolation is the core benefit — each namespace's logic lives in one file, tested in one test module, without cross-contamination.
