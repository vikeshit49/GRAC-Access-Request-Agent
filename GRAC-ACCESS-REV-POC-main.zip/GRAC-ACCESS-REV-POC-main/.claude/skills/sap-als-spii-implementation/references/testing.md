# Testing the Audit Log V3 SPII

## Automated Tests

```bash
# From project root — run all ALS SPII tests
python3 -m pytest tests/test_spii_als_payloads.py -v
```

### Test Organization

| File                              | What it covers                                                                                                                    | What it mocks                                                              |
| --------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------- |
| `tests/test_spii_als_payloads.py` | **Real captured payloads** — each test sends an exact request JSON and asserts the exact response JSON from `tests/payloads/als/` | `create_client` (Destination SDK); `create_fragment_client` (Fragment SDK) |

### Payload-Based Tests (`tests/test_spii_als_payloads.py`)

These tests use **real payloads captured from a live formation**. Each test loads a request JSON from `tests/payloads/als/` and asserts the response matches the corresponding response JSON.

The ALS handler is single-step — assign goes directly to READY with no configuration block. The SAP Cloud SDK calls are mocked so tests run without a live Destination Service.

| Test                          | Request payload           | Response payload           | What it checks                                                                       |
| ----------------------------- | ------------------------- | -------------------------- | ------------------------------------------------------------------------------------ |
| `test_assign_returns_ready`   | `request_1_assign.json`   | `response_1_assign.json`   | INITIAL → READY; Destination created; Fragment created with `applicationTenantId`    |
| `test_unassign_returns_ready` | `request_2_unassign.json` | `response_2_unassign.json` | Unassign with empty `assignedTenant` fields → `{"state": "READY"}`; Fragment deleted |

#### Payload Files (`tests/payloads/als/`)

| File                       | Description                                                                                                          |
| -------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| `request_1_assign.json`    | UCL → agent: both INITIAL, `assignedTenant.applicationNamespace=sap.als`, deployment coordinates in `receiverTenant` |
| `response_1_assign.json`   | Agent → UCL: `{"state": "READY"}` (no configuration block needed for ALS)                                            |
| `request_2_unassign.json`  | UCL → agent: `operation=unassign`, `assignedTenant.state=""` and `uclAssignmentId=""` (real-world UCL behaviour)     |
| `response_2_unassign.json` | Agent → UCL: `{"state": "READY"}`                                                                                    |

#### Mocking `create_client` and `create_fragment_client`

The assign test patches both SDK factory functions at the module level. `get_subaccount_destination` returns `None` to exercise the creation path; `get_subaccount_fragment` returns `None` to exercise the fragment creation path:

```python
@patch("services.spii_audit_log.create_fragment_client")
@patch("services.spii_audit_log.create_client")
def test_assign_returns_ready(mock_create_client, mock_create_fragment_client, client):
    dest_client = MagicMock()
    dest_client.get_subaccount_destination.return_value = None
    mock_create_client.return_value = dest_client

    frag_client = MagicMock()
    frag_client.get_subaccount_fragment.return_value = None
    mock_create_fragment_client.return_value = frag_client

    response = client.patch("/v1/tenantMappings/<tenant-id>", json=request)

    assert response.json() == {"state": "READY"}
    dest_client.create_destination.assert_called_once()
    frag_client.create_fragment.assert_called_once()
```

The unassign test patches only `create_fragment_client`, returning a mock fragment so the deletion path is exercised:

```python
@patch("services.spii_audit_log.create_fragment_client")
def test_unassign_returns_ready(mock_create_fragment_client, client):
    frag_client = MagicMock()
    frag_client.get_subaccount_fragment.return_value = MagicMock()  # fragment exists
    mock_create_fragment_client.return_value = frag_client

    response = client.patch("/v1/tenantMappings/<tenant-id>", json=request)

    assert response.json() == {"state": "READY"}
    frag_client.delete_fragment.assert_called_once()
```

### Test Fixtures

Both tests use `autouse` fixtures to:
1. Patch `OTEL_EXPORTER_OTLP_ENDPOINT` to a known test value

The handler is stateless, so no store-clearing fixture is needed — tests do
not share any in-memory state to leak.

## Manual Testing (curl)

### Start lightweight test server (no AI Core needed)

```bash
export OTEL_EXPORTER_OTLP_ENDPOINT="http://localhost:4318"

cd app && python -c "
import uvicorn
from starlette.applications import Starlette
from api.spii import create_spii_routes
app = Starlette(routes=create_spii_routes())
uvicorn.run(app, host='0.0.0.0', port=9000)
"
```

### Assign (INITIAL → READY)

```bash
curl -s -X PATCH http://localhost:9000/v1/tenantMappings/c597847d-1b97-4c01-a47f-5858e11b65bd \
  -H "Content-Type: application/json" \
  -d '{
  "context": {
    "platform": "unified-services",
    "accountId": "test-account",
    "uclFormationId": "868fc6bc-6246-41fa-a520-7c21cfc36c31",
    "uclFormationName": "test-formation",
    "uclFormationTypeId": "0d40ee59-c204-4dff-a359-a6931f792d28",
    "operation": "assign",
    "operationId": "470ee8cf-fccf-4a85-a98a-76c0ecff00a1"
  },
  "receiverTenant": {
    "state": "INITIAL",
    "uclAssignmentId": "c6b4ddd7-3aba-44cd-ad1d-39b139e43278",
    "deploymentRegion": "cf-eu12",
    "applicationNamespace": "sap.agta2a",
    "applicationUrl": "https://jupiter.a2aagent-dev-eu12.example.com",
    "applicationTenantId": "c597847d-1b97-4c01-a47f-5858e11b65bd",
    "globalTenantId": "2e70f8b1-96d8-4a68-bab2-ab96506ede79",
    "subaccountId": "c597847d-1b97-4c01-a47f-5858e11b65bd",
    "subdomain": "1780442614",
    "uclSystemName": "level-0",
    "uclSystemTenantId": "ed52fff4-3d09-4287-ac2b-b2c2fb6c521c",
    "configuration": null
  },
  "assignedTenant": {
    "state": "INITIAL",
    "uclAssignmentId": "fc234cde-c49c-4a63-bb99-464de08d8d51",
    "deploymentRegion": "NON",
    "applicationNamespace": "sap.als",
    "applicationUrl": "",
    "applicationTenantId": "4d816e57-6bc6-43ed-954f-67dccaa26b3e",
    "globalTenantId": "4d816e57-6bc6-43ed-954f-67dccaa26b3e",
    "uclSystemName": "alstenant",
    "uclSystemTenantId": "622df1e7-4bb7-410c-b5d1-0d44017dfe57",
    "configuration": null
  }
}' | python -m json.tool
```

Expected: `{"state": "READY"}`

### Unassign

```bash
curl -s -X PATCH http://localhost:9000/v1/tenantMappings/c597847d-1b97-4c01-a47f-5858e11b65bd \
  -H "Content-Type: application/json" \
  -d '{
  "context": {
    "platform": "unified-services",
    "accountId": "test-account",
    "uclFormationId": "868fc6bc-6246-41fa-a520-7c21cfc36c31",
    "uclFormationName": "test-formation",
    "uclFormationTypeId": "0d40ee59-c204-4dff-a359-a6931f792d28",
    "operation": "unassign",
    "operationId": "b1c2d3e4-f5a6-7890-abcd-ef1234567890"
  },
  "receiverTenant": {
    "state": "DELETING",
    "uclAssignmentId": "c6b4ddd7-3aba-44cd-ad1d-39b139e43278",
    "deploymentRegion": "cf-eu12",
    "applicationNamespace": "sap.agta2a",
    "applicationUrl": "https://jupiter.a2aagent-dev-eu12.example.com",
    "applicationTenantId": "c597847d-1b97-4c01-a47f-5858e11b65bd",
    "subdomain": "1780442614",
    "uclSystemName": "level-0",
    "uclSystemTenantId": "ed52fff4-3d09-4287-ac2b-b2c2fb6c521c"
  },
  "assignedTenant": {
    "state": "",
    "uclAssignmentId": "",
    "deploymentRegion": "NON",
    "applicationNamespace": "sap.als",
    "applicationUrl": "",
    "applicationTenantId": "4d816e57-6bc6-43ed-954f-67dccaa26b3e",
    "uclSystemName": "alstenant",
    "uclSystemTenantId": "622df1e7-4bb7-410c-b5d1-0d44017dfe57"
  }
}' | python -m json.tool
```

Expected: `{"state": "READY"}`

### Unknown Formation Type

Set `assignedTenant.applicationNamespace` to any value other than `sap.als` on an assign → HTTP 400 with `"Unsupported assignedTenant.applicationNamespace '...'"`.
