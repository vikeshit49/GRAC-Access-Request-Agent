---
name: sap-als-spii-implementation
description: Implement UCL SPII v3.0.0 for the Audit Log Service (ALS) in an App Foundation
  agent. Use this skill whenever the user needs to add AuditLog provisioning via SPII,
  create the AuditLog destination and fragment lifecycle, integrate Audit Log V3 into an
  existing SPII handler with the Facade pattern,
  or handle the applicationNamespace "sap.als". Also use when the user asks about SPII for
  audit logging, AuditLog destination fragments, AuditLog OTEL endpoint configuration,
  or needs to add a new application namespace handler to an existing SPII service.
compatibility: Python 3.10+, Starlette, Pydantic v2, sap-cloud-sdk>=0.29.1 (destination + auditlog_ng modules).
metadata:
  author: application-foundation/codegenandi
  version: "3.1.0"
  protocol: spii-v3
  application-namespace: "sap.als"
---

# Audit Log Service SPII Implementation

This skill implements the **complete SPII endpoint for Audit Log V3 provisioning**, including the Facade design pattern for multi-formation dispatch. When a customer creates a UCL formation of type Audit Log V3, your agent receives a SPII notification and responds by creating a Destination and Fragment that wire up the OTEL-based audit log pipeline for that tenant.

## What is SPII?

UCL SPII v3.0.0 (Service Provider Integration Interface) lets BTP applications participate in UCL formations. When a customer creates a formation that includes your application, UCL sends a `PATCH /v1/tenantMappings/{tenantId}` notification. Your application responds with its state and optional configuration so the formation can proceed.

## Architecture: Facade Pattern

The SPII service uses the Facade pattern to keep formation-specific logic isolated:

### Facade Pattern (Application Namespace Dispatch)

The `SPIIService.handle_notification_sync()` method acts as a **Facade** — it inspects the `assignedTenant.applicationNamespace` from the notification payload and dispatches to the correct `SPIIFormationHandler` instance via `_HANDLER_REGISTRY`. Each application namespace has its own handler that encapsulates the full assign/unassign logic for that integration.

This means adding a new application namespace never touches existing handler code — you write a new `SPIIFormationHandler` and add one line to `_build_handler_registry()`.

The AuditLog handler is self-contained: Destination and Fragment CRUD are implemented as private methods directly in `AuditLogV3Handler` (`_get_or_create_base_destination`, `_create_or_update_fragment`, `_delete_fragment`), keeping the class easy to read, test, and modify without additional indirection.

## Formation Type Details

| Field | Value |
|-------|-------|
| Application Namespace | `sap.als` |
| Formation Name | Audit Log V3 |
| Protocol Steps | **Single step** — goes directly to READY (no config exchange needed) |
| Side Effects | Creates a Destination + Fragment per tenant |

The Audit Log V3 formation is a single-step flow: the assigned tenant provides deployment coordinates in the first notification, and the receiver goes straight to READY after creating the Destination and Fragment.

## File Layout

After applying this skill, your project will have:

```
app/
├── api/
│   └── spii.py                      # PATCH /v1/tenantMappings/{tenantId} handler
├── models/
│   └── spii.py                      # Pydantic models for SPII payloads
├── services/
│   ├── spii_base.py                 # SPIIFormationHandler ABC, AssignmentState,
│   │                                  StatusReport, ValidationError
│   ├── spii_service.py              # Facade — validation, dispatch
│   └── spii_audit_log.py            # AuditLogV3Handler (this skill)
tests/
├── payloads/
│   └── als/
│       ├── request_1_assign.json
│       ├── response_1_assign.json
│       ├── request_2_unassign.json
│       └── response_2_unassign.json
└── test_spii_als_payloads.py
```

The foundation files (`api/spii.py`, `models/spii.py`, `services/spii_base.py`,
`services/spii_service.py`) are shared with the other formation-type skills
(`sap-agw-spii-implementation`, `sap-joule-spii-implementation`,
`sap-assistant-spii-implementation`). When this skill is layered on top of an
existing SPII implementation, those files must be **merged**, not replaced —
see [Drift Check Before Applying](#drift-check-before-applying) below.

## Drift Check Before Applying

**Read this before copying any template into the project.** This skill ships
templates that overlap with other SPII skills (AGW, Joule, Assistant). If the
project already has SPII files in place — from a previously applied SPII
skill, from manual hand-coding, or from a stale earlier version of this
skill — copying the templates verbatim will silently destroy that work or
introduce subtle correctness bugs (e.g. a stale `spii_service.py` that drops
your other handlers' registry entries when you rewrite the file).

For every template file in this skill, before writing it, check whether the
project already has a file at the same path. If it does, **diff** the existing
file against the template and merge rather than overwrite. The rules:

> **Legacy in-memory store**: earlier versions of every SPII skill shipped a
> module-level `assignments_store: Dict[...]` in `spii_base.py` and a
> `processing_locks` table in `spii_service.py`. Both were removed because
> they duplicated UCL's state in a place that did not survive Pod
> rescheduling, and the "idempotency lock" was per-Pod, not distributed —
> so it never actually protected against concurrent duplicate notifications
> across replicas. If you find either symbol in an existing project file,
> that file is from the legacy version — replace it with the stateless
> template shipped here (do not preserve the legacy storage; it is the bug
> we are fixing). Handlers that wrote to `assignments_store` likewise need
> the writes removed.

### `app/models/spii.py`

This file is shared across all SPII skills. Compare field-by-field.

**Pay special attention to `TenantInfo.deploymentId`.** This skill *requires*
it (the AuditLog handler reads `receiverTenant.deploymentId`). The other SPII
skills (AGW, Joule, Assistant) currently also ship it as `Optional[str] =
None` on `TenantInfo`. **Do NOT add it to the `empty_str_to_none` validator** —
the field deliberately stays as a raw string and the handler applies an
`or ""` fallback at the read site. The validator's `@field_validator(...)`
arg list should remain `("globalTenantId", "subdomain", mode="before")` —
matching what the AGW skill ships.

The reference also includes `systemBusinessType: Optional[str] = None` and
`tenantBusinessType: Optional[str] = None` on `TenantInfo`, and
`Context.operationId` is `Optional[UUID] = None` (not required). Make sure
the existing file matches.

If the existing file diverges from the template in other ways (extra fields,
extra validators, different state enums), preserve the divergent additions and
only add what's missing. Ask the user before removing anything.

### `app/services/spii_base.py`

This file is shared and must be byte-identical across all SPII skills. It
hosts the `SPIIFormationHandler` ABC, `AssignmentState`, `StatusReport`, and
`ValidationError`. Handlers are stateless — there is no in-process
assignment store, no idempotency lock table.

If the existing file is identical, do nothing. If it differs, diff it carefully:

- If the difference is a docstring or comment update, prefer the newer text.
- If the existing file still defines `assignments_store` (or any other
  module-level state), that is the legacy version — replace it with the
  stateless template; the legacy storage is the bug this version of the skill
  fixes.
- If the difference is a different ABC signature, different `AssignmentState`
  enum values, or `StatusReport` signature change, **stop and ask the user**.
  A behavioral change here is a cross-cutting concern that affects every
  formation-type handler.

### `app/services/spii_service.py`

This file is shared and contains the `_HANDLER_REGISTRY` plus dispatch
logic. The body of `_build_handler_registry()` is the **only** part that
legitimately differs between projects — it lists the handlers installed in
this project.

When applying this skill on top of an existing `spii_service.py`:

1. Do not replace the file. Open the existing file and locate
   `_build_handler_registry()`.
2. Add `AuditLogV3Handler()` to the `handlers` list.
3. Add `from services.spii_audit_log import AuditLogV3Handler` to the imports.
4. Leave every other handler entry alone.

If the rest of the file differs from this skill's template, treat it the
same way as `spii_base.py`: legacy `processing_locks` / `assignments_store`
references are bugs from the older version and should be removed along with
the surrounding lock/replay code. Any other unexplained divergence in the
validation or dispatch logic — **stop and ask the user** before making
changes.

### `app/services/spii_audit_log.py`

This file is unique to this skill. If it already exists in the project (e.g.
from a previous run of this skill, or from hand-coded reference work), diff
it for any local customizations the user may have added — then update or
replace as appropriate.

### Mandatory: audit tenant ID derivation across the entire project

**Run this grep now — before writing any files and again after — across every Python file in the project, not just SPII files:**

```bash
grep -rn "dwc-tenant\|dwc-subdomain" .
```

The old pattern can appear in any file: `agent_executor.py`, `agent.py`, `main.py`, middleware, API handlers, or any other module that builds audit log events or passes a tenant ID downstream. Check and fix every match regardless of which file it is in.

`dwc-subdomain` matches are expected and correct **only** when the value is assigned to a variable used as `tenant_subdomain` (for destination resolution). It is a bug if `dwc-subdomain` is used to derive `tenant_id` — the subdomain is not a tenant identifier and must never appear in audit event `tenant_id` fields. Apply the same Case A / Case B check below to any such misuse.

For every match, check whether the same code block also has `claims.app_tid or tenant_id` **after** the `dwc-tenant` read. Two cases:

**Case A — old pattern (must fix):** `dwc-tenant` is read and used directly as `tenant_id` with no JWT parse, or the JWT parse exists but `app_tid` is not used to override `tenant_id`:

```python
# OLD — wrong: dwc-tenant is the only source, JWT is ignored or app_tid not applied
tenant_id = headers.get("dwc-tenant", "")
```

```python
# OLD — wrong: JWT parsed but app_tid result discarded, tenant_id stays as dwc-tenant
tenant_id = headers.get("dwc-tenant", "")
try:
    claims = parse_token(headers.get("authorization", ""))
    user_id = claims.user_uuid or claims.sub or "unknown"
    # missing: tenant_id = claims.app_tid or tenant_id
except IASTokenError:
    pass
```

**Replace every Case A occurrence with the correct pattern:**

```python
# CORRECT: app_tid from the IAS token is authoritative; dwc-tenant is the fallback
tenant_id = headers.get("dwc-tenant", "")
try:
    claims = parse_token(headers.get("authorization", ""))
    user_id = claims.user_uuid or claims.sub or "unknown"
    tenant_id = claims.app_tid or tenant_id
except IASTokenError:
    pass
```

**Case B — correct pattern already present:** `claims.app_tid or tenant_id` appears after the `dwc-tenant` read. No change needed.

This is a **correctness fix**, not a style preference. `app_tid` is the tenant identifier from the authenticated IAS token; `dwc-tenant` is a plain HTTP header that any caller can set. Using `dwc-tenant` as the primary source means the tenant ID in audit events is unverified and can be wrong or spoofed. Report to the user which files were changed and which were already correct.

### `app/api/spii.py`

After the drift check, before making any changes, summarize for the user:

- Which template files are new (will be written verbatim).
- Which template files already exist and are byte-identical (no-op).
- Which template files already exist and differ — list each diff and your
  proposed merge action. Get explicit approval before merging behavioral
  differences.

## Endpoint Security

The SPII endpoint is protected at the platform level by **DwC (Deploy with Confidence)**. DwC's Jupiter terminates TLS, validates UCL's client certificate per the `sap:cmp-mtls:v1` access strategy, and routes the request to the agent — the agent itself does not implement endpoint authentication for `/v1/tenantMappings`.

## Implementation Steps

### 1. Pydantic Models (`app/models/spii.py`)

The models cover the complete SPII v3.0.0 payload. Pay attention to the field validators that coerce empty strings to `None` — UCL sends empty strings for optional fields in real-world payloads (especially in unassign operations).

See [templates/app/models/spii.py](templates/app/models/spii.py) for the full implementation.

The `AssignedTenant` validators are critical — real UCL unassign payloads send `"state": ""` and `"uclAssignmentId": ""` as empty strings rather than omitting the fields. Without these validators, Pydantic would reject those payloads.

### 2. SPII Endpoint (`app/api/spii.py`)

The endpoint handler validates the payload, delegates to the SPII service, and returns the response.

See [templates/app/api/spii.py](templates/app/api/spii.py) for the full implementation.

Route injection is required — SPII routes must be prepended before the A2A SDK's catch-all route:

```python
spii_routes = create_spii_routes()
app = server.build()  # A2AStarletteApplication.build()

for i, route in enumerate(spii_routes):
    app.routes.insert(i, route)
```

### 3. Formation Type Handler Base (`app/services/spii_base.py`)

Define the interface that all formation type handlers implement, plus the
shared `AssignmentState`, `StatusReport`, and `ValidationError`. Handlers
are stateless — there is no in-process assignment store and no idempotency
lock table.

See [templates/app/services/spii_base.py](templates/app/services/spii_base.py) for the full implementation.

Each handler implements `SPIIFormationHandler` (an ABC) and exposes an
`application_namespace` property that the Facade uses for dispatch. Handlers
receive the same arguments and return a `StatusReport`. The handler
encapsulates all logic for its formation type — state transitions, config
exchange (if any), etc.

This file is **shared** across all formation-type skills (`sap-agw`,
`sap-joule`, `sap-assistant`, `sap-als`). It must be byte-identical regardless
of which skill installed it.

### 4. Audit Log Handler (`app/services/spii_audit_log.py`)

The `AuditLogV3Handler` implements single-step assignment: extract deployment
info from `receiverTenant`, create (or reuse) the base Destination and
create/update the per-tenant Fragment, return READY.

See [templates/app/services/spii_audit_log.py](templates/app/services/spii_audit_log.py) for the full implementation.

Key aspects:
- **Single step**: No config exchange needed. On assign, go directly to READY.
- **Self-contained**: Destination and Fragment CRUD are private methods on the
  handler (`_get_or_create_base_destination`, `_create_or_update_fragment`,
  `_delete_fragment`) — no separate class needed.
- **Data extraction**: `deploymentId`, `deploymentRegion`, `applicationNamespace`, `subdomain`, and `applicationTenantId` all come from `receiverTenant` — they describe the consumer tenant being provisioned.
- **Idempotent**: Checks for an existing Destination/Fragment before creating. Updates if already present.
- **Stateless**: UCL is the source of truth for assignment state — the handler
  reads everything it needs from `receiverTenant`, performs the side effects
  (Destination + Fragment), and returns. Re-running the same assign on a UCL
  retry is safe because the Destination/Fragment CRUD methods are
  check-then-write.
- **Null safety**: The Pydantic `empty_str_to_none` validator in `models/spii.py` covers `globalTenantId` and `subdomain` only. `deploymentId` deliberately stays as a raw string from the payload, so the handler applies an `or ""` fallback at the read site for empty-string and `None` cases alike.

### 5. SPII Service Facade (`app/services/spii_service.py`)

The SPII service handles protocol concerns (validation, idempotency, unassign cleanup) and delegates formation-specific logic to handlers via the Facade pattern. Dispatch is keyed on `assignedTenant.applicationNamespace`: the Facade looks up the matching `SPIIFormationHandler` in `_HANDLER_REGISTRY` and routes the call.

See [templates/app/services/spii_service.py](templates/app/services/spii_service.py) for the full implementation.

The Facade approach means:
- The `SPIIService` class stays focused on protocol concerns.
- Each application namespace handler is a self-contained class.
- Adding a new namespace = a new handler class + one line in `_build_handler_registry()`.
- For `assign`, unknown namespaces are rejected with a `ValidationError` → HTTP 400.
- For `unassign`, unknown namespaces are tolerated (the Facade simply returns READY) so UCL can finalize cleanup even when a handler has been removed.

Adding ALS to a project that already has other handlers is a **one-line addition** to the registry:

```python
handlers: List[SPIIFormationHandler] = [
    AgentGatewayHandler(),       # already there from sap-agw-spii-implementation
    AuditLogV3Handler(),         # added by this skill
    # JouleHandler(),            # added by sap-joule-spii-implementation
    # AppFNDAssistantHandler(),  # added by sap-assistant-spii-implementation
]
```

### 6. Wire into main.py

```python
from starlette.applications import Starlette
from starlette.routing import Mount

from api.spii import create_spii_routes

# Create SPII routes
spii_routes = create_spii_routes()

# Build your main app (e.g., A2A SDK app)
app = server.build()

# Insert SPII routes at index 0 (before any catch-all route)
for i, route in enumerate(spii_routes):
    app.routes.insert(i, route)
```

## Environment Variables

| Variable | Purpose | Required |
|----------|---------|----------|
| `OTEL_EXPORTER_OTLP_ENDPOINT` | OTEL collector URL for the AuditLog destination | No (defaults to in-cluster collector) |

The default OTEL endpoint `http://otel-collector-daemonset-collector.observability.svc.cluster.local:4318` works for standard Kyma deployments with the OTEL collector DaemonSet.

## Runtime Request Headers

DwC Jupiter injects these headers into every inbound request routed to your agent:

| Header | Purpose |
|--------|---------|
| `dwc-subdomain` | Tenant subdomain — use this to name the Fragment (`AuditLogV3_Fragment_{subdomain}`) and scope Destination Service calls |
| `dwc-tenant` | Tenant UUID — **fallback only**. Use as the initial value for `tenant_id`, then immediately override it with `claims.app_tid` from the parsed IAS JWT (see Runtime Usage Step 1). Never use `dwc-tenant` as the final `tenant_id` without first attempting the JWT parse. |

In practice, always derive `tenant_id` from `claims.app_tid` (the authenticated IAS token claim) and use `dwc-tenant` only as the fallback value when the token cannot be parsed. `dwc-tenant` is a plain HTTP header — any caller can set it to an arbitrary value, so it must never be the authoritative source for tenant identity in audit events.

## Destination and Fragment Structure

The SAP Destination Service supports **Destination Fragments** — lightweight overlays that attach to a base Destination and provide per-tenant or per-context properties. At consumption time, you merge a Fragment into its base Destination via `ConsumptionOptions`, and the Fragment's properties override matching keys in the base.

For Audit Log V3, this pattern enables:
- **One base Destination** with the shared OTEL endpoint and authentication config
- **One Fragment per tenant** with the tenant-specific deployment coordinates

### Base Destination (`AuditLogV3_Destination`)

Created once per subaccount on first AuditLog assignment:

```json
{
  "name": "AuditLogV3_Destination",
  "type": "HTTP",
  "url": "<OTEL_EXPORTER_OTLP_ENDPOINT[/v1/logs]>",
  "authentication": "NoAuthentication",
  "properties": {
    "deploymentId": "<from receiverTenant>",
    "namespace": "<from receiverTenant.applicationNamespace>",
    "deploymentRegion": "<from receiverTenant>",
    "otlpProtocol": "<grpc|http/protobuf>"
  }
}
```

### Tenant Fragment (`AuditLogV3_Fragment_{subdomain}`)

Created per subscriber tenant:

```json
{
  "name": "AuditLogV3_Fragment_<subdomain>",
  "properties": {
    "deploymentId": "<from receiverTenant>",
    "deploymentRegion": "<from receiverTenant>",
    "applicationTenantId": "<from receiverTenant>"
  }
}
```

Both use `Level.SUB_ACCOUNT` and pass the `tenant=subdomain` parameter for multi-tenant scoping.

## Runtime Usage

At runtime, the SDK resolves connection parameters automatically from the Destination and per-tenant Fragment. You supply the tenant subdomain (required — it activates resolution) plus the destination name/instance and fragment name; the SDK handles the `ConsumptionLevel.SUBACCOUNT` merge internally.

### Step 1 — Resolve the tenant and caller identity

The subscriber tenant **subdomain** comes from the `dwc-subdomain` header injected by DwC Jupiter — this value is what activates destination resolution in Step 2. In an A2A executor these headers live in `context.call_context.state["headers"]`; in a plain HTTP handler use `request.headers`.

```python
# dwc-subdomain is injected by DwC Jupiter into every inbound request
tenant_subdomain = headers.get("dwc-subdomain", "")
```

The caller identity (`user_id`) and application tenant ID (`tenant_id`) that go into the audit event should be taken from the **IAS JWT** the Managed Runtime forwards in the `Authorization` header — the A2A SDK does not populate an authenticated user, so parse the token yourself. Fall back to the `dwc-tenant` header when the token cannot be parsed:

```python
from sap_cloud_sdk.ias import IASTokenError, parse_token

user_id = "unknown"
tenant_id = headers.get("dwc-tenant", "")  # fallback
try:
    claims = parse_token(headers.get("authorization", ""))
    user_id = claims.user_uuid or claims.sub or "unknown"
    tenant_id = claims.app_tid or tenant_id
except IASTokenError:
    pass
```

### Step 2 — Create the audit log client (destination-based, SDK ≥ 0.29.1)

Destination-based resolution is activated by **`tenant`** — the subscriber subaccount **subdomain** from `dwc-subdomain`. Its presence is the switch: the SDK then merges the Destination + per-tenant Fragment at `ConsumptionLevel.SUBACCOUNT` and extracts `endpoint`, `deployment_id`, and `namespace` for you. Omitting `tenant` makes the SDK fall through to the explicit path and raise `ValueError`. Requires `sap-cloud-sdk>=0.29.1` (use the latest available).

ALS NG is strictly tenant-scoped: without a subdomain the SDK cannot resolve the Destination/Fragment, so guard for it and skip emission.

```python
from sap_cloud_sdk.core.auditlog_ng import create_client

if not tenant_subdomain:
    # No dwc-subdomain — nothing to resolve; skip the audit event.
    return

fragment_name = f"AuditLogV3_Fragment_{tenant_subdomain}"

client = create_client(
    tenant=tenant_subdomain,                     # required — activates destination resolution
    destination_name="AuditLogV3_Destination",
    destination_instance="default",
    fragment_name=fragment_name,
    service_name="my-agent",
    batch=True,
)
```

The SDK internally performs the Destination + Fragment merge at `ConsumptionLevel.SUBACCOUNT` and extracts `endpoint` (from `destination.url`), `deployment_id` (from `deploymentId` property, falling back to `deploymentRegion`), and `namespace` from the merged result. You no longer need to call the Destination client directly.

### Step 3 — Send an audit log event and flush

With `batch=True` the OTLP exporter sends asynchronously, so you must flush/close to guarantee delivery — a successful `send()` return does not mean the event left the process.

```python
from sap_cloud_sdk.core.auditlog_ng.gen.sap.auditlog.auditevent.v2 import auditevent_pb2 as pb

event = pb.DataAccess()
event.common.timestamp.FromDatetime(datetime.now(timezone.utc))
event.common.user_initiator_id = user_id            # from the parsed IAS token
event.common.tenant_id = tenant_id                  # app_tid from the token (dwc-tenant fallback)
event.channel_type = "API"
event.channel_id = "my-agent-v1"
event.object_type = "resource"
event.object_id = "record-id"
event.attribute = "content"

event_id = client.send(event)

# batch=True is async — flush before the request handler / process ends.
client.close()
```

## State Machine (Audit Log V3)

```
receiverTenant.state | assignedTenant.state | operation | Action
---------------------|----------------------|-----------|-------
INITIAL / ERROR      | any                  | assign    | Create Dest + Fragment → READY
any                  | any                  | unassign  | Delete Fragment → READY
```

No CONFIG_PENDING step is needed because the AuditLog service provides all required information (deployment coordinates) directly in the first notification.

## Request Payload Structure

```json
{
  "context": {
    "platform": "btp",
    "accountId": "global-account-id",
    "uclFormationId": "uuid",
    "uclFormationName": "my-formation",
    "uclFormationTypeId": "0d40ee59-c204-4dff-a359-a6931f792d28",
    "operation": "assign|unassign",
    "operationId": "uuid"
  },
  "receiverTenant": {
    "state": "INITIAL|CONFIG_PENDING|ERROR|DELETING",
    "uclAssignmentId": "uuid",
    "applicationTenantId": "local-tenant-id",
    "applicationNamespace": "my.app",
    "applicationUrl": "https://your-app.example.com",
    "deploymentRegion": "cf-eu10",
    "deploymentId": "deployment-123",
    "uclSystemName": "my-system",
    "uclSystemTenantId": "uuid",
    "globalTenantId": "optional-gtid",
    "subdomain": "tenant-subdomain",
    "subaccountId": "optional-uuid",
    "configuration": null
  },
  "assignedTenant": {
    "state": "INITIAL|CONFIG_PENDING|READY|ERROR|",
    "applicationTenantId": "auditlog-tenant-id",
    "applicationNamespace": "sap.als",
    "applicationUrl": "https://auditlog.example.com",
    "deploymentRegion": "eu10",
    "uclSystemName": "audit-log-system",
    "uclSystemTenantId": "uuid",
    "configuration": null
  }
}
```

Note: `assignedTenant.state` can be an empty string `""` in real-world unassign payloads — the Pydantic validators coerce this to `None`.

## Error Handling

- **400 Bad Request**: validation errors (`context.operation` missing, required fields absent, unsupported `assignedTenant.applicationNamespace`)
- **500 Internal Server Error**: unexpected server errors — UCL will retry on 500

## Idempotency

Idempotency is the responsibility of the handler. The notification carries
the full state of both participants (`receiverTenant.state` +
`assignedTenant.state`) and `uclAssignmentId`; the handler's Destination /
Fragment operations are check-then-write, so re-running the same assign on a
UCL retry yields the same outcome without creating duplicates. The Facade
does not deduplicate retries — UCL retries on HTTP 500 and we want those
retries to land on a clean re-evaluation of the payload.

This is what makes the agent safe to run as multiple Pods in Kubernetes:
nothing about request handling depends on which Pod served the previous
notification for the same `uclAssignmentId`.

## Testing

The skill ships payload-based tests under `templates/tests/`. These load real JSON fixtures
and exercise the full request/response cycle via `TestClient`. The SAP Cloud SDK calls
(`create_client`, `create_fragment_client`) are mocked at the module level.

See [references/testing.md](references/testing.md) for full test documentation including mock patterns and manual curl examples.

## Reference Files

| File | Description |
|------|-------------|
| [references/facade-pattern.md](references/facade-pattern.md) | Facade dispatch pattern and how to add new formation types |
| [references/testing.md](references/testing.md) | Test organization, mock patterns, and manual curl examples |
