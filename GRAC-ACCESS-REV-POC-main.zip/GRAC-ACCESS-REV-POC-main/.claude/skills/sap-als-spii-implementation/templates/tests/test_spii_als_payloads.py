"""
Payload-based tests for the ALS (Audit Log V3) SPII integration.

Each test loads a real request payload captured from production and asserts
the response matches the corresponding expected response payload.
The ALS handler is single-step: assign goes directly to READY after creating
the Destination and Fragment via the SAP Cloud SDK (mocked in tests).

The handler is stateless — tests do not seed any in-memory store before
exercising unassign.
"""

import json
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from starlette.applications import Starlette
from starlette.testclient import TestClient

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

from api.spii import create_spii_routes

PAYLOADS = Path(__file__).parent / "payloads" / "als"


def load(filename: str) -> dict:
    return json.loads((PAYLOADS / filename).read_text())


@pytest.fixture
def client():
    routes = create_spii_routes()
    app = Starlette(routes=routes)
    return TestClient(app)


@pytest.fixture(autouse=True)
def env_vars():
    with patch.dict(os.environ, {
        "OTEL_EXPORTER_OTLP_ENDPOINT": "http://otel-test-collector:4318",
    }):
        yield


@patch("services.spii_audit_log.create_fragment_client")
@patch("services.spii_audit_log.create_client")
def test_assign_returns_ready(mock_create_client, mock_create_fragment_client, client):
    """Assign (both INITIAL) — ALS handler returns READY and creates Destination + Fragment."""
    dest_client = MagicMock()
    dest_client.get_subaccount_destination.return_value = None
    mock_create_client.return_value = dest_client

    frag_client = MagicMock()
    frag_client.get_subaccount_fragment.return_value = None
    mock_create_fragment_client.return_value = frag_client

    request = load("request_1_assign.json")
    expected = load("response_1_assign.json")

    response = client.patch("/v1/tenantMappings/c597847d-1b97-4c01-a47f-5858e11b65bd", json=request)

    assert response.status_code == 200
    assert response.json() == expected

    dest_client.create_destination.assert_called_once()
    frag_client.create_fragment.assert_called_once()


@patch("services.spii_audit_log.create_fragment_client")
def test_unassign_returns_ready(mock_create_fragment_client, client):
    """Unassign — agent deletes the tenant Fragment and returns READY."""
    frag_client = MagicMock()
    frag_client.get_subaccount_fragment.return_value = MagicMock()
    mock_create_fragment_client.return_value = frag_client

    request = load("request_2_unassign.json")
    expected = load("response_2_unassign.json")

    response = client.patch("/v1/tenantMappings/c597847d-1b97-4c01-a47f-5858e11b65bd", json=request)

    assert response.status_code == 200
    assert response.json() == expected

    frag_client.delete_fragment.assert_called_once()
