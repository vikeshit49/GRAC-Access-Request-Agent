# app/observers/auditlog_lifecycle.py
import logging
import os
from typing import Any, Dict

from sap_cloud_sdk.destination import (
    Destination,
    Fragment,
    Level,
    create_client,
    create_fragment_client,
)

logger = logging.getLogger(__name__)

AUDIT_LOG_V3_DESTINATION_NAME = "AuditLogV3_Destination"
DEFAULT_OTEL_ENDPOINT = (
    "http://otel-collector-daemonset-collector.observability.svc.cluster.local:4318"
)


class AuditLogLifecycleObserver:
    """Manages Destination and Fragment lifecycle for Audit Log V3 SPII.

    On assign: creates (or reuses) a base Destination pointing to the
    OTEL collector, then creates a per-tenant Fragment with deployment
    coordinates.

    On unassign: deletes the tenant-specific Fragment.
    """

    def on_assign_ready(
        self,
        notification_data: Dict[str, Any],
        auditlog_config: Dict[str, str],
    ) -> None:
        deployment_id = auditlog_config["deployment_id"]
        deployment_region = auditlog_config["deployment_region"]
        namespace = auditlog_config["namespace"]
        tenant_subdomain = auditlog_config["tenant_subdomain"]

        self._ensure_base_destination(
            deployment_id=deployment_id,
            deployment_region=deployment_region,
            namespace=namespace,
            tenant_subdomain=tenant_subdomain,
        )

        self._create_or_update_fragment(
            deployment_id=deployment_id,
            deployment_region=deployment_region,
            tenant_subdomain=tenant_subdomain,
        )

    def on_unassign(self, notification_data: Dict[str, Any]) -> None:
        receiver_tenant = notification_data.get("receiverTenant", {})
        tenant_subdomain = receiver_tenant.get("subdomain") or ""

        if not tenant_subdomain:
            logger.warning("receiverTenant.subdomain is missing — skipping fragment deletion")
            return

        fragment_name = f"AuditLogV3_Fragment_{tenant_subdomain}"
        fragment_client = create_fragment_client()

        existing = fragment_client.get_subaccount_fragment(
            fragment_name, tenant=tenant_subdomain
        )
        if existing is not None:
            fragment_client.delete_fragment(
                fragment_name, level=Level.SUB_ACCOUNT, tenant=tenant_subdomain
            )
            logger.info(f"Deleted fragment: {fragment_name}")
        else:
            logger.info(f"Fragment {fragment_name} not found — nothing to delete")

    def _ensure_base_destination(
        self,
        deployment_id: str,
        deployment_region: str,
        namespace: str,
        tenant_subdomain: str,
    ) -> Destination:
        client = create_client()

        existing = client.get_subaccount_destination(
            AUDIT_LOG_V3_DESTINATION_NAME, tenant=tenant_subdomain
        )
        if existing is not None:
            logger.info(f"Base destination already exists: {AUDIT_LOG_V3_DESTINATION_NAME}")
            return existing

        endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT") or DEFAULT_OTEL_ENDPOINT

        destination = Destination(
            name=AUDIT_LOG_V3_DESTINATION_NAME,
            type="HTTP",
            url=endpoint,
            authentication="NoAuthentication",
            properties={
                "deploymentId": deployment_id,
                "namespace": namespace,
                "deploymentRegion": deployment_region,
            },
        )

        client.create_destination(destination, level=Level.SUB_ACCOUNT, tenant=tenant_subdomain)
        logger.info(f"Created destination: {AUDIT_LOG_V3_DESTINATION_NAME} -> {endpoint}")

        return destination

    def _create_or_update_fragment(
        self,
        deployment_id: str,
        deployment_region: str,
        tenant_subdomain: str,
    ) -> None:
        fragment_name = f"AuditLogV3_Fragment_{tenant_subdomain}"
        fragment_client = create_fragment_client()

        fragment = Fragment(
            name=fragment_name,
            properties={
                "deploymentId": deployment_id,
                "deploymentRegion": deployment_region,
            },
        )

        existing = fragment_client.get_subaccount_fragment(
            fragment_name, tenant=tenant_subdomain
        )

        if existing is not None:
            fragment_client.update_fragment(
                fragment, level=Level.SUB_ACCOUNT, tenant=tenant_subdomain
            )
            logger.info(f"Updated fragment: {fragment_name}")
        else:
            fragment_client.create_fragment(
                fragment, level=Level.SUB_ACCOUNT, tenant=tenant_subdomain
            )
            logger.info(f"Created fragment: {fragment_name}")
