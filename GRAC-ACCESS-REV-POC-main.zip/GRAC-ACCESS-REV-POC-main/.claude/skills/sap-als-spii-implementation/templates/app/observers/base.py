# app/observers/base.py
from abc import ABC, abstractmethod
from typing import Any, Dict


class SPIIObserver(ABC):
    @abstractmethod
    def on_assign_ready(
        self, notification_data: Dict[str, Any], partner_config: Dict[str, Any]
    ) -> None:
        """Called after SPII Step 2 completes (CONFIG_PENDING -> READY)."""

    @abstractmethod
    def on_unassign(self, notification_data: Dict[str, Any]) -> None:
        """Called when an unassign operation is processed."""
