"""
SPII handler for the Audit Log V3 (sap.als) formation type.

Single-step flow: ``receiverTenant`` carries the deployment coordinates
(``deploymentId``, ``deploymentRegion``, ``applicationNamespace``,
``subdomain``, ``applicationTenantId``) for the consumer tenant being
provisioned. The handler creates the base Destination (shared per subaccount)
and the per-tenant Fragment, then goes directly to READY.

Unassign deletes the tenant-specific Fragment. The shared base Destination is
left in place — it is reused across tenants in the subaccount.

The handler is stateless: every notification is processed from the payload
alone. ``_get_or_create_base_destination`` and ``_create_or_update_fragment``
are check-then-write so re-running the same assign on a UCL retry is safe.
"""

import logging
import os
from typing import Any, Dict, Optional

from sap_cloud_sdk.destination import (
    Destination,
    Fragment,
    Level,
    create_client,
    create_fragment_client,
)

from services.spii_base import (
    AssignmentState,
    SPIIFormationHandler,
    StatusReport,
)

logger = logging.getLogger(__name__)

APPLICATION_NAMESPACE_AUDIT_LOG = "sap.als"
AUDIT_LOG_V3_DESTINATION_NAME = "AuditLogV3_Destination"
DEFAULT_OTEL_ENDPOINT = (
    "http://otel-collector-daemonset-collector.observability.svc.cluster.local:4318/v1/logs"
)
DEFAULT_OTEL_PROTOCOL = "http/protobuf"


class AuditLogV3Handler(SPIIFormationHandler):
    """Handles SPII assign/unassign for the Audit Log V3 formation type."""

    @property
    def application_namespace(self) -> str:
        return APPLICATION_NAMESPACE_AUDIT_LOG

    def handle_assign(
        self,
        ucl_assignment_id: str,
        receiver_state: str,
        assigned_state: str,
        assigned_config: Optional[Dict[str, Any]],
        notification_data: Dict[str, Any],
        tenant_id: str,
    ) -> StatusReport:
        receiver_tenant = notification_data.get("receiverTenant", {})

        # Deployment coordinates and namespace describe the receiver tenant
        # (the consumer being provisioned). These wire up the Destination +
        # per-tenant Fragment for that tenant.
        deployment_id = receiver_tenant.get("deploymentId") or ""
        deployment_region = receiver_tenant.get("deploymentRegion") or ""
        namespace = receiver_tenant.get("applicationNamespace") or ""
        tenant_subdomain = receiver_tenant.get("subdomain") or ""
        application_tenant_id = receiver_tenant.get("applicationTenantId") or ""

        logger.info(
            "ALS assign: assignment=%s deployment_id=%s deployment_region=%s "
            "namespace=%s tenant_subdomain=%s application_tenant_id=%s",
            ucl_assignment_id,
            deployment_id,
            deployment_region,
            namespace,
            tenant_subdomain,
            application_tenant_id,
        )

        self._get_or_create_base_destination(
            deployment_id, deployment_region, namespace, tenant_subdomain
        )
        self._create_or_update_fragment(
            deployment_id, deployment_region, tenant_subdomain, application_tenant_id
        )

        return StatusReport(state=AssignmentState.READY)

    def handle_unassign(
        self,
        ucl_assignment_id: str,
        notification_data: Dict[str, Any],
    ) -> StatusReport:
        receiver_tenant = notification_data.get("receiverTenant", {})
        tenant_subdomain = receiver_tenant.get("subdomain", "") or ""

        logger.info(
            "ALS unassign: assignment=%s tenant_subdomain=%s",
            ucl_assignment_id,
            tenant_subdomain,
        )

        if not tenant_subdomain:
            logger.warning("receiverTenant.subdomain is missing — skipping fragment deletion")
            return StatusReport(state=AssignmentState.READY)

        self._delete_fragment(tenant_subdomain)

        return StatusReport(state=AssignmentState.READY)

    def _get_or_create_base_destination(
        self,
        deployment_id: str,
        deployment_region: str,
        namespace: str,
        tenant_subdomain: str,
    ) -> Destination:
        client = create_client()

        existing = client.get_subaccount_destination(
            AUDIT_LOG_V3_DESTINATION_NAME, tenant=tenant_subdomain
        )
        if existing is not None:
            logger.info(f"Base destination already exists: {AUDIT_LOG_V3_DESTINATION_NAME}")
            return existing

        endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", DEFAULT_OTEL_ENDPOINT)
        protocol = os.environ.get("OTEL_EXPORTER_OTLP_PROTOCOL", DEFAULT_OTEL_PROTOCOL).lower()

        # The OTel HTTP exporter uses the URL as-is when passed explicitly.
        # Store the full path so consumers can pass destination.url directly.
        if protocol == "http/protobuf":
            endpoint = endpoint.rstrip("/") + "/v1/logs"

        destination = Destination(
            name=AUDIT_LOG_V3_DESTINATION_NAME,
            type="HTTP",
            url=endpoint,
            authentication="NoAuthentication",
            properties={
                "deploymentId": deployment_id,
                "namespace": namespace,
                "deploymentRegion": deployment_region,
                "otlpProtocol": protocol,
            },
        )

        client.create_destination(destination, level=Level.SUB_ACCOUNT, tenant=tenant_subdomain)
        logger.info(f"Created destination: {AUDIT_LOG_V3_DESTINATION_NAME} -> {endpoint}")

        return destination

    def _create_or_update_fragment(
        self,
        deployment_id: str,
        deployment_region: str,
        tenant_subdomain: str,
        application_tenant_id: str,
    ) -> None:
        fragment_name = f"AuditLogV3_Fragment_{tenant_subdomain}"
        fragment_client = create_fragment_client()

        fragment = Fragment(
            name=fragment_name,
            properties={
                "deploymentId": deployment_id,
                "deploymentRegion": deployment_region,
                "applicationTenantId": application_tenant_id,
            },
        )

        existing = fragment_client.get_subaccount_fragment(
            fragment_name, tenant=tenant_subdomain
        )

        if existing is not None:
            fragment_client.update_fragment(
                fragment, level=Level.SUB_ACCOUNT, tenant=tenant_subdomain
            )
            logger.info(f"Updated fragment: {fragment_name}")
        else:
            fragment_client.create_fragment(
                fragment, level=Level.SUB_ACCOUNT, tenant=tenant_subdomain
            )
            logger.info(f"Created fragment: {fragment_name}")

    def _delete_fragment(self, tenant_subdomain: str) -> None:
        fragment_name = f"AuditLogV3_Fragment_{tenant_subdomain}"
        fragment_client = create_fragment_client()

        existing = fragment_client.get_subaccount_fragment(
            fragment_name, tenant=tenant_subdomain
        )
        if existing is not None:
            fragment_client.delete_fragment(
                fragment_name, level=Level.SUB_ACCOUNT, tenant=tenant_subdomain
            )
            logger.info(f"Deleted fragment: {fragment_name}")
        else:
            logger.info(f"Fragment {fragment_name} not found — nothing to delete")
