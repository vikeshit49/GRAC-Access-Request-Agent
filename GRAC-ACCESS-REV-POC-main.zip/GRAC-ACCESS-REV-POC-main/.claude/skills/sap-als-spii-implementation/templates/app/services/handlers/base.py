# app/services/handlers/base.py
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

from services.spii_service import StatusReport


class FormationTypeHandler(ABC):
    """Base class for formation-type-specific SPII handlers.

    Each formation type (Agent Gateway, Audit Log V3, etc.) implements
    this interface. The SPIIService Facade dispatches to the correct
    handler based on the uclFormationTypeId in the notification context.
    """

    @abstractmethod
    def handle_assign(
        self,
        ucl_assignment_id: str,
        receiver_state: str,
        assigned_state: str,
        assigned_config: Optional[Dict[str, Any]],
        notification_data: Dict[str, Any],
        tenant_id: str,
    ) -> StatusReport:
        """Handle an assign operation for this formation type."""

    @abstractmethod
    def handle_unassign(
        self,
        ucl_assignment_id: str,
        notification_data: Dict[str, Any],
    ) -> StatusReport:
        """Handle an unassign operation for this formation type."""
