# app/services/handlers/auditlog.py
import logging
from typing import Any, Dict, Optional

from observers.auditlog_lifecycle import AuditLogLifecycleObserver
from services.handlers.base import FormationTypeHandler
from services.spii_service import AssignmentState, StatusReport

logger = logging.getLogger(__name__)

FORMATION_TYPE_ID_AUDIT_LOG_V3 = "0d40ee59-c204-4dff-a359-a6931f792d28"


class AuditLogHandler(FormationTypeHandler):
    """Handles SPII notifications for the Audit Log V3 formation type.

    Unlike the Agent Gateway (two-step SCI exchange), Audit Log uses a
    single-step flow: the assignedTenant provides deployment coordinates
    in the first notification, and the receiver goes directly to READY
    after creating the Destination and Fragment.
    """

    def __init__(self, observer: AuditLogLifecycleObserver | None = None):
        self._observer = observer or AuditLogLifecycleObserver()

    def handle_assign(
        self,
        ucl_assignment_id: str,
        receiver_state: str,
        assigned_state: str,
        assigned_config: Optional[Dict[str, Any]],
        notification_data: Dict[str, Any],
        tenant_id: str,
    ) -> StatusReport:
        assigned_tenant = notification_data.get("assignedTenant", {})
        receiver_tenant = notification_data.get("receiverTenant", {})

        deployment_id = receiver_tenant.get("deploymentId") or ""
        deployment_region = receiver_tenant.get("deploymentRegion") or ""
        namespace = receiver_tenant.get("applicationNamespace") or ""
        tenant_subdomain = receiver_tenant.get("subdomain") or ""

        logger.info(
            f"Audit Log V3 assign: deployment_id={deployment_id}, "
            f"deployment_region={deployment_region}, namespace={namespace}, "
            f"tenant_subdomain={tenant_subdomain}"
        )

        self._observer.on_assign_ready(
            notification_data=notification_data,
            auditlog_config={
                "deployment_id": deployment_id,
                "deployment_region": deployment_region,
                "namespace": namespace,
                "tenant_subdomain": tenant_subdomain,
            },
        )

        return StatusReport(state=AssignmentState.READY)

    def handle_unassign(
        self,
        ucl_assignment_id: str,
        notification_data: Dict[str, Any],
    ) -> StatusReport:
        receiver_tenant = notification_data.get("receiverTenant", {})
        tenant_subdomain = receiver_tenant.get("subdomain") or ""

        logger.info(f"Audit Log V3 unassign: tenant_subdomain={tenant_subdomain}")

        self._observer.on_unassign(notification_data)

        return StatusReport(state=AssignmentState.READY)
