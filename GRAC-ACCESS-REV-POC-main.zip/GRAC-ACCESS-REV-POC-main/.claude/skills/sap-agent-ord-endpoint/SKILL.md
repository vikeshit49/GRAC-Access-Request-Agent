---
name: sap-agent-ord-endpoint
description: Add an ORD (Open Resource Discovery) endpoint to an App Foundation agent. Use when the user wants to expose their agent's metadata so UMS can discover it before provisioning, or so Joule can recommend it based on conversation context.
---

# ORD Endpoint for App Foundation Agents

Adds an **Open Resource Discovery (ORD)** endpoint to an existing App Foundation agent. ORD is the SAP standard protocol that allows UMS to discover available agents before provisioning and enables Joule to recommend agents based on conversation context.

## What Gets Added

Three new HTTP endpoints on the agent:

| Endpoint                                                     | Description                                                            |
| ------------------------------------------------------------ | ---------------------------------------------------------------------- |
| `GET /.well-known/open-resource-discovery`                   | ORD config — always returns both system-type and system-instance document URLs |
| `GET /open-resource-discovery/v1/documents/system-type`      | Static ORD document — product, packages and tenant-agnostic agent metadata at provider level |
| `GET /open-resource-discovery/v1/documents/system-instance`  | Dynamic ORD document — tenant-aware view; adds tenant-specific entries (agent-card `apiResource`, consumption bundles) and runtime i-deps. Accepts `tenantId` query param or `dwc-tenant` / `x-tenant-id` headers |

All ORD endpoints are accessible without application-level JWT — **the Jupyter gateway protects every endpoint with mTLS at the infrastructure level**, so no additional auth configuration is needed in `app.yaml`.

Three new files are created in the agent project:

```
app/
├── ord/
│   ├── __init__.py                 # ORD endpoint handlers (Python package)
│   ├── system_type.json            # Static ORD document (system-type perspective): product, package, agent, i-deps from skill
│   └── system_instance.json        # Dynamic ORD document (system-instance perspective): package, consumptionBundles, agent, agent-card apiResource, i-deps from skill + extensibility
```

**ORD entity placement rules:**

| ORD Entity | `system_type.json` (static) | `system_instance.json` (dynamic) |
| --- | --- | --- |
| `product` | ✅ here | ❌ not here |
| `packages` | ✅ here | ✅ here |
| `agent` | ✅ here (completeness) | ✅ here (leanIX use case) |
| `consumptionBundles` (for agent-card API) | ❌ not here | ✅ here only |
| `apiResources` — A2A agent card | ❌ not here | ✅ here only (tenant-specific URL) |
| `apiResources` — other (non-tenant-specific) APIs | ✅ allowed here | ✅ allowed here |
| `integrationDependencies` (skill-generated) | ✅ here | ✅ here |
| `integrationDependencies` (extensibility runtime) | ❌ not here | ✅ here only |

**Why the agent-card `apiResource` lives in `system-instance` only:** the agent's runtime URL embeds a **tenant-specific subdomain**, so the `a2a-agent-card` resourceDefinition resolves to a different host per tenant. That makes the agent-card `apiResource` tenant-specific and therefore a `system-instance` resource. Other `apiResources` (those whose endpoints are not tenant-scoped) may still live in `system-type` — the restriction is specifically about the agent card.

Because the agent-card `apiResource` is the only API the templates declare, `consumptionBundles` and the `agents[].exposedApiResources` reference also appear only in `system_instance.json`. For SAP Agents, neither document is a strict subset of the other: `products` belong to `system-type` only; agent-card-related entries (`apiResources`, `consumptionBundles`, `exposedApiResources`) belong to `system-instance` only.

---

## Phase 1: Read Existing Agent Configuration

Before making any changes, read the existing agent files to extract the required values.

```bash
cat app.yaml
cat app/main.py
```

Extract the following values:

| Value                 | Where to find it                              | Example                     |
| --------------------- | --------------------------------------------- | --------------------------- |
| **Agent name**        | `metadata.name` in `app.yaml`                 | `travel-expense-agent`      |
| **Agent title**       | `AgentCard(name=...)` in `app/main.py`        | `Travel Expense Agent`      |
| **Agent description** | `AgentCard(description=...)` in `app/main.py` | `An AI agent that helps...` |

Then ask the developer:

> "What is your **CPA (Cloud Platform Application) namespace**?
>
> This is the ORD namespace registered for your application in the SAP ecosystem (e.g., `sap.appfnd`, `sap.s4`, `customer.mycompany`). It is **not** the Kubernetes namespace from `app.yaml`.
>
> If you are unsure, check with your team or the SAP BTP cockpit where your application namespace was registered."

Use the value provided by the developer as `{{AGENT_NAMESPACE}}`.

If any other value cannot be found, ask the user to provide it.

---

## Phase 1.5: Collect Dependencies

> **What counts as a dependency?** Only external systems/services **outside your subaccount** that are discovered via UMS — e.g., other agents, MCP servers, or cross-account services. Do **not** list infrastructure that is automatically injected at runtime (such as SAP AI Core or Object Store) — those are managed by the platform.
>
> **MCP dependencies require permissions.** For each MCP server dependency, the developer must declare which security permissions the agent needs (`read`, `write`, or both). These are stored in the ORD document at `integrationDependencies[].aspects[].apiResources[].labels.requiredAgentSecurityPermissions`.

Create an example `ord-dependencies.json` file at the project root using `write_to_file`:

```json
{
  "_instructions": "Fill in your agent's integration dependencies below. Only list external systems discovered via UMS (other agents, MCP servers, cross-account services). Do NOT list services automatically injected at runtime (e.g., AI Core, Object Store). If your agent has no external dependencies, set the 'dependencies' array to []. For MCP dependencies, you MUST specify 'permissions' — an array containing 'read', 'write', or both — indicating what level of access the agent requires on that MCP server.",
  "_example": {
    "type": "mcp",
    "name": "My MCP Server",
    "ordId": "sap.example:apiResource:my-mcp-server:v1",
    "permissions": ["read", "write"]
  },
  "dependencies": []
}
```

Then ask the developer:

> "I've created `ord-dependencies.json` in your project root.
>
> Please open the file and add any **external** dependencies your agent has — these are systems/services outside your subaccount that are discovered via UMS (e.g., other agents, MCP servers).
>
> For each dependency, specify:
> - `type` — either `"mcp"` or `"a2a"` (or another integration type)
> - `name` — a human-readable title
> - `ordId` — the ORD ID of the external resource
>
> **For MCP dependencies**, you must also specify:
> - `permissions` — an array with `"read"`, `"write"`, or both (e.g., `["read", "write"]`). This declares what level of access your agent requires on that MCP server.
>
> Do **not** list services like AI Core or Object Store — those are automatically injected at runtime.
>
> If your agent has no external dependencies, leave `"dependencies": []`.
>
> Reply here when you have finished editing the file."

### After the developer confirms

Read the file to get the dependency data:

```bash
cat ord-dependencies.json
```

Parse the `dependencies` array from the file contents. Then delete the `_instructions` and `_example` keys from the file — they are only guides and must not be present in the final JSON used by the ORD endpoint.

For each MCP-type dependency, validate that a `permissions` array is present and contains only valid values (`"read"`, `"write"`, or both). If missing or invalid, ask the developer to provide the required permissions before proceeding.

For **every** dependency (both `mcp` and `a2a`), validate that `type` is present and is exactly `"mcp"` or `"a2a"`. If missing or any other value, ask the developer to correct `ord-dependencies.json` before proceeding — do not guess a default.

This `type` is the single source of truth for the dependency's integration mode. In Phase 2d it becomes `labels.integrationMode: ["<type>"]` (a **single-element list**) on the generated integrationDependency — the derivation is 1:1, so the developer never types the mode twice. The consuming SPII handler (`sap-assistant-spii-implementation`) requires this exact shape and raises `ValueError` if it is missing, a bare string, an empty list, or a list with more than one entry; a wrong mode would wire a Destination Fragment to the wrong URL (`v1/mcp` vs `v1/a2a`).

### If the dependencies array is empty

Note this for Phase 2. The `integrationDependencies` arrays in the JSON files will be left empty.

### If the dependencies array has entries

Note the dependency details for Phase 2. After creating the JSON files, update the `integrationDependencies` arrays using `replace_in_file`.

**Perspective rule for `integrationDependencies`:**

| Dependency source | `system_type.json` | `system_instance.json` |
| --- | --- | --- |
| Collected in Phase 1.5 (skill-generated) | ✅ add here | ✅ add here |
| Injected at runtime by extensibility framework | ❌ not here | ✅ add here (instance-specific) |

The `system-instance` i-deps must be a **superset** of the `system-type` i-deps.

**In `agents[0].integrationDependencies`** in **both** files — add the ORD IDs as strings:

```json
"integrationDependencies": [
  "<namespace>:integrationDependency:<dep-id>:v1",
  "<namespace>:integrationDependency:<dep-id-2>:v1"
]
```

**In the top-level `integrationDependencies`** — add the full dependency objects.

> **`labels.integrationMode` is mandatory on every integrationDependency** and must be a **single-element list** — either `["mcp"]` or `["a2a"]`, derived 1:1 from the dependency's `type` in `ord-dependencies.json`. Never write it as a bare string (`"mcp"`), an empty list, or a list with more than one value. The consuming SPII handler raises `ValueError` and refuses to guess; a wrong or missing mode wires a Destination Fragment to the wrong URL (`v1/mcp` vs `v1/a2a`).

For **non-MCP** dependencies (e.g., A2A agents):

```json
"integrationDependencies": [
  {
    "ordId": "<namespace>:integrationDependency:<dep-id>:v1",
    "title": "<Dependency Title>",
    "shortDescription": "<description>",
    "description": "<description>",
    "version": "1.0.0",
    "visibility": "public",
    "releaseStatus": "active",
    "mandatory": true,
    "partOfPackage": "<namespace>:package:<agent-id>:v0",
    "aspects": [
      {
        "title": "<Aspect Title>",
        "description": "<aspect description>",
        "mandatory": true,
        "apiResources": [
          {
            "ordId": "<external-resource-ord-id>",
            "minVersion": "1.0.0"
          }
        ]
      }
    ],
    "labels": {
      "integrationMode": ["a2a"]
    }
  }
]
```

For **MCP** dependencies — include `labels.requiredAgentSecurityPermissions` inside each `apiResources` entry to declare what access the agent requires, and set `integrationMode` to `["mcp"]`:

```json
"integrationDependencies": [
  {
    "ordId": "<namespace>:integrationDependency:<dep-id>:v1",
    "title": "<Dependency Title>",
    "shortDescription": "<description>",
    "description": "<description>",
    "version": "1.0.0",
    "visibility": "public",
    "releaseStatus": "active",
    "mandatory": true,
    "partOfPackage": "<namespace>:package:<agent-id>:v0",
    "aspects": [
      {
        "title": "<Aspect Title>",
        "description": "<aspect description>",
        "mandatory": true,
        "apiResources": [
          {
            "ordId": "<external-resource-ord-id>",
            "minVersion": "1.0.0",
            "labels": {
              "requiredAgentSecurityPermissions": ["<permissions-from-ord-dependencies>"]
            }
          }
        ]
      }
    ],
    "labels": {
      "integrationMode": ["mcp"]
    }
  }
]
```

The `requiredAgentSecurityPermissions` array must contain `"read"`, `"write"`, or both — matching the permissions the developer declared in `ord-dependencies.json`. This field is **required for MCP dependencies** and must **not** be added to non-MCP dependencies.

> **Note on ORD IDs:** If the developer does not know the exact ORD ID of a dependency, use the best available identifier and note that it should be confirmed with the dependency's owner.

---

## Phase 1.6: Associate with an SAP Product

The `partOfProducts` field associates your agent with a product registered in the SAP Global ORD Registry. In production, this association may be required to identify the SAP product line your agent belongs to.

**Find the ORD ID of your product:**

Browse the registry at [https://github.tools.sap/ORD/global-registry/tree/main/data/products](https://github.tools.sap/ORD/global-registry/tree/main/data/products) and locate the entry for your product. The ORD ID is in the format `sap:product:<ProductName>:` (e.g., `sap:product:SAPS4HANACloud:`).

Most teams already have their product registered. If yours is not in the registry (uncommon — check with your team first), open a registration issue at [https://github.tools.sap/ORD/global-registry/issues/new/choose](https://github.tools.sap/ORD/global-registry/issues/new/choose).

Then ask the developer:

> "What is the ORD ID of the SAP product your agent belongs to? Look it up at https://github.tools.sap/ORD/global-registry/tree/main/data/products.
>
> Reply with the ORD product ID (e.g., `sap:product:SAPS4HANACloud:`), or reply `skip` if you are only running in dev/test and do not need product association yet."

Use the value provided as `{{AGENT_PART_OF_PRODUCT}}`.

### Validation

Before accepting the ORD product ID, verify it is **not** the same as the agent's own ORD ID.

The agent's ORD ID is `{{AGENT_NAMESPACE}}:agent:{{AGENT_ORD_ID}}:v1`. If the developer's reply equals that string, reject it and re-ask:

> ❌ The value you provided is the agent's own ORD ID, not a product ORD ID. `partOfProducts` must reference a **product** entry from the Global ORD Registry (format `sap:product:<ProductName>:`), not the agent itself. Please look up your product at https://github.tools.sap/ORD/global-registry/tree/main/data/products and reply again, or reply `skip`.

Only proceed to Phase 2 once the developer supplies a value that is not the agent's ORD ID, or replies `skip`.

### If the developer replies `skip`

Treat `{{AGENT_PART_OF_PRODUCT}}` as empty for Phase 2 and print this warning to the developer:

> ⚠️  `partOfProducts` will be left empty in `system_type.json`. **Production environments may reject an ORD document without `partOfProducts`.** You can add it later by editing `app/ord/system_type.json` and replacing the empty `partOfProducts` arrays on `packages[0]` and `agents[0]` with `["<your-ord-product-id>"]`.

---

## Phase 2: Create ORD Files

### 2a. Create the `app/ord/` directory and copy JSON templates

**macOS/Linux:**

```bash
mkdir -p app/ord
SKILL_PATH=$(find . -type d -name "sap-agent-ord-endpoint" -path "*/skills/*" 2>/dev/null | head -1)
cp "$SKILL_PATH/templates/app/ord/__init__.py" app/ord/__init__.py
cp "$SKILL_PATH/templates/app/ord/system_type.json" app/ord/system_type.json
cp "$SKILL_PATH/templates/app/ord/system_instance.json" app/ord/system_instance.json
```

**Windows PowerShell:**

```powershell
New-Item -ItemType Directory -Force -Path app/ord
$SkillPath = Get-ChildItem -Path . -Recurse -Directory -Filter "sap-agent-ord-endpoint" | Where-Object { $_.FullName -like "*skills*" } | Select-Object -First 1 -ExpandProperty FullName
Copy-Item "$SkillPath/templates/app/ord/__init__.py" -Destination "app/ord/__init__.py"
Copy-Item "$SkillPath/templates/app/ord/system_type.json" -Destination "app/ord/system_type.json"
Copy-Item "$SkillPath/templates/app/ord/system_instance.json" -Destination "app/ord/system_instance.json"
```

Note: the templates already include the `/.well-known/agent-card.json` reference in `resourceDefinitions`. No further changes to these files are needed for agent card discovery.

### 2b. Replace placeholders in both JSON files

Replace placeholders using the values extracted in Phase 1. Run the same substitution for **both** JSON files:

**macOS (sed -i ''):**

```bash
LAST_UPDATE=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
for file in app/ord/system_type.json app/ord/system_instance.json; do
  sed -i '' \
    -e 's/{{AGENT_ORD_ID}}/<agent-name>/g' \
    -e 's/{{AGENT_NAMESPACE}}/<agent-namespace>/g' \
    -e 's/{{AGENT_TITLE}}/<Agent Title>/g' \
    -e 's/{{AGENT_LONG_DESCRIPTION}}/<agent-long-description>/g' \
    -e 's/{{AGENT_DESCRIPTION}}/<agent-description>/g' \
    -e "s/{{AGENT_LAST_UPDATE}}/$LAST_UPDATE/g" \
    "$file"
done
```

**Linux (sed -i without quotes):**

```bash
LAST_UPDATE=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
for file in app/ord/system_type.json app/ord/system_instance.json; do
  sed -i \
    -e 's/{{AGENT_ORD_ID}}/<agent-name>/g' \
    -e 's/{{AGENT_NAMESPACE}}/<agent-namespace>/g' \
    -e 's/{{AGENT_TITLE}}/<Agent Title>/g' \
    -e 's/{{AGENT_LONG_DESCRIPTION}}/<agent-long-description>/g' \
    -e 's/{{AGENT_DESCRIPTION}}/<agent-description>/g' \
    -e "s/{{AGENT_LAST_UPDATE}}/$LAST_UPDATE/g" \
    "$file"
done
```

**Windows PowerShell:**

```powershell
$lastUpdate = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
foreach ($file in @("app/ord/system_type.json", "app/ord/system_instance.json")) {
  (Get-Content $file) `
    -replace '{{AGENT_ORD_ID}}','<agent-name>' `
    -replace '{{AGENT_NAMESPACE}}','<agent-namespace>' `
    -replace '{{AGENT_TITLE}}','<Agent Title>' `
    -replace '{{AGENT_LONG_DESCRIPTION}}','<agent-long-description>' `
    -replace '{{AGENT_DESCRIPTION}}','<agent-description>' `
    -replace '{{AGENT_LAST_UPDATE}}',$lastUpdate |
    Set-Content $file
}
```

Then apply the `partOfProducts` substitution to `system_type.json` only, using the value collected in Phase 1.6.

Substitute the developer's reply from Phase 1.6 into the sed/PowerShell commands below **before** running them, following the same inline-literal convention used for `<agent-name>` above:

- If a product ORD ID was provided, replace `<agent-part-of-product>` with that value (e.g., `sap:product:SAPS4HANACloud:`).
- If the developer replied `skip` in Phase 1.6, use the **skip** command variant instead — which replaces the placeholder array with `[]`.

**macOS (sed -i '') — value provided:**

```bash
sed -i '' 's|\["{{AGENT_PART_OF_PRODUCT}}"\]|["<agent-part-of-product>"]|g' app/ord/system_type.json
```

**macOS (sed -i '') — skip:**

```bash
sed -i '' 's|\["{{AGENT_PART_OF_PRODUCT}}"\]|[]|g' app/ord/system_type.json
```

**Linux (sed -i without quotes) — value provided:**

```bash
sed -i 's|\["{{AGENT_PART_OF_PRODUCT}}"\]|["<agent-part-of-product>"]|g' app/ord/system_type.json
```

**Linux (sed -i without quotes) — skip:**

```bash
sed -i 's|\["{{AGENT_PART_OF_PRODUCT}}"\]|[]|g' app/ord/system_type.json
```

**Windows PowerShell — value provided:**

```powershell
(Get-Content app/ord/system_type.json) -replace '\["{{AGENT_PART_OF_PRODUCT}}"\]', '["<agent-part-of-product>"]' | Set-Content app/ord/system_type.json
```

**Windows PowerShell — skip:**

```powershell
(Get-Content app/ord/system_type.json) -replace '\["{{AGENT_PART_OF_PRODUCT}}"\]', '[]' | Set-Content app/ord/system_type.json
```

The substitution runs against `system_type.json` only — `system_instance.json` does not contain this placeholder. The `|` delimiter in `sed` avoids escaping the colons in the ORD product ID.

> **Note:** There is no `{{AGENT_BASE_URL}}` placeholder in the JSON files. The `entryPoints` field uses `"/"` (relative), and the `resourceDefinitions.url` is `"/.well-known/agent-card.json"` (relative). No runtime URL injection is needed for these fields.

### 2c. Customize agent labels

Both JSON files contain an `agents[].labels` section with `"sap.ai:interactionMode": ["conversational"]`. Optionally extend this with agent-specific labels using `replace_in_file`:

```json
"labels": {
  "sap.ai:interactionMode": ["conversational"],
  "llmModel": ["anthropic--claude-4.5-sonnet"],
  "framework": ["langgraph"]
}
```

Common label keys:

- `llmModel` — the LLM model used (e.g., `anthropic--claude-4.5-sonnet`, `gpt-4o`)
- `framework` — the agent framework (e.g., `langgraph`, `autogen`, `semantic-kernel`)

Apply the same change to **both** `system_type.json` and `system_instance.json`.

### 2d. Add dependencies (if any from Phase 1.5)

If the `ord-dependencies.json` file contained any entries, update the `integrationDependencies` arrays in **both** `system_type.json` and `system_instance.json` using `replace_in_file` as described in Phase 1.5.

## Placeholder Derivation Rules

| Placeholder                  | Derivation                                                                                                                                                                                                                                                                                                               | Example                                                                                                                                                                  |
| ---------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `{{AGENT_ORD_ID}}`           | Same as `metadata.name` in `app.yaml`                                                                                                                                                                                                                                                                                    | `travel-expense-agent`                                                                                                                                                   |
| `{{AGENT_NAMESPACE}}`        | The CPA (Cloud Platform Application) namespace registered for the application in the SAP ecosystem. **Must be provided by the developer** — it cannot be inferred from project files. Must be lowercase alphanumeric with exactly one dot (e.g., `sap.appfnd`). Do **not** use the Kubernetes namespace from `app.yaml`. | `sap.appfnd`                                                                                                                                                             |
| `{{AGENT_TITLE}}`            | Title-case: replace `-` with space, capitalize each word                                                                                                                                                                                                                                                                 | `Travel Expense Agent`                                                                                                                                                   |
| `{{AGENT_DESCRIPTION}}`      | Same as `AgentCard(description=...)` in `app/main.py`                                                                                                                                                                                                                                                                    | `An AI agent that helps employees manage travel expenses`                                                                                                                |
| `{{AGENT_LONG_DESCRIPTION}}` | A longer description of the agent that expands on its purpose, capabilities, and integration context. Must **not** contain the `{{AGENT_DESCRIPTION}}` text verbatim (required by `sap-ord-description-unique` rule). Write 1–2 sentences describing what the agent does, who uses it, and how it integrates.            | `The Travel Expense Agent automates the submission and approval of employee travel expense reports by integrating with SAP Concur and ERP systems via the A2A protocol.` |
| `{{AGENT_LAST_UPDATE}}`      | Current date in ISO 8601 format. Use today's date when running the skill.                                                                                                                                                                                                                                                | `2026-05-07T00:00:00Z`                                                                                                                                                   |
| `{{AGENT_PART_OF_PRODUCT}}`  | ORD ID of the SAP product this agent belongs to, from the [Global ORD Registry](https://github.tools.sap/ORD/global-registry/tree/main/data/products). Format: `sap:product:<ProductName>:`. Collected in Phase 1.6; may be empty when the developer replies `skip`.                                                    | `sap:product:SAPS4HANACloud:`                                                                                                                                            |

---

## Phase 3: Update `app/main.py`

Add the ORD routes to the agent by modifying `app/main.py`. The ORD routes are mounted alongside the existing A2A application.

### 3a. Add imports

Add these imports near the top of `app/main.py`, after the existing imports:

```python
from starlette.applications import Starlette
from starlette.routing import Mount
from ord import create_ord_routes
```

### 3b. Replace the `uvicorn.run` call

Find the existing `uvicorn.run(server.build(), ...)` line and replace it with:

```python
    # Build A2A app
    a2a_app = server.build()

    # Combine ORD routes with A2A app
    # ORD routes are matched first, then all other requests go to the A2A app
    combined_app = Starlette(
        routes=[
            *create_ord_routes(),
            Mount("/", app=a2a_app),
        ]
    )

    logger.info(f"Starting agent with ORD endpoint at http://{host}:{port}/.well-known/open-resource-discovery")
    uvicorn.run(combined_app, host=host, port=port)
```

---

After completing the code changes, display the following note to the developer:

> **Security Note — Jupyter Gateway & mTLS**
>
> All agent endpoints (including ORD and `.well-known`) are protected by the **Jupyter gateway with mTLS (mutual TLS)** at the infrastructure level. No `apiAuth` configuration is needed in `app.yaml`.
>
> - Every request reaching your agent has already been authenticated by Jupyter via client certificate verification
> - UMS and Joule present valid mTLS certificates when calling your ORD endpoints
> - Unauthorized clients without a valid certificate cannot reach any of your agent's endpoints
>
> The `accessStrategies` field in the ORD documents reflects this: `"type": "sap:cmp-mtls:v1"` indicates that the CMP mTLS authentication is enforced by Jupyter for all discovery and agent-card endpoints.

---

## Phase 4: Test the ORD Endpoint

### Local Testing

Start the agent locally first (see `sap-agent-run-local` skill), then:

```bash
# ORD well-known config (default: system-instance perspective)
curl -s http://localhost:9000/.well-known/open-resource-discovery | python3 -m json.tool

# ORD well-known config (static: system-type perspective)
curl -s -H "ord-perspective: static" http://localhost:9000/.well-known/open-resource-discovery | python3 -m json.tool

# ORD system-type document (static)
curl -s http://localhost:9000/open-resource-discovery/v1/documents/system-type | python3 -m json.tool

# ORD system-instance document (dynamic) — via query param
curl -s "http://localhost:9000/open-resource-discovery/v1/documents/system-instance?tenantId=T1" | python3 -m json.tool

# ORD system-instance document (dynamic) — via header
curl -s -H "dwc-tenant: T1" "http://localhost:9000/open-resource-discovery/v1/documents/system-instance" | python3 -m json.tool
```

**Expected response for well-known endpoint:**

```json
{
  "openResourceDiscoveryV1": {
    "documents": [
      {
        "url": "/open-resource-discovery/v1/documents/system-instance",
        "perspective": "system-instance",
        "accessStrategies": [{ "type": "sap:cmp-mtls:v1" }]
      }
    ]
  }
}
```

**Expected response for ORD system-type document:**

```json
{
  "openResourceDiscovery": "1.14",
  "perspective": "system-type",
  "policyLevels": ["sap:ai:v1"],
  "agents": [
    {
      "ordId": "<namespace>:agent:<agent-id>:v1",
      "title": "<Agent Title>"
    }
  ]
}
```

> **Note:** The agent-card `apiResource` is **not** in `system-type` — it lives in `system-instance` because the agent's URL is tenant-specific (per-tenant subdomain). The `system-type` document still declares the `product`, `packages`, and `agent` metadata that is identical across tenants.

**Expected response for ORD system-instance document:**

```json
{
  "openResourceDiscovery": "1.14",
  "perspective": "system-instance",
  "policyLevels": ["sap:ai:v1"],
  "describedSystemInstance": { "localId": "T1" },
  "agents": [
    {
      "ordId": "<namespace>:agent:<agent-id>:v1",
      "exposedApiResources": [
        { "ordId": "<namespace>:apiResource:<agent-id>-api:v1" }
      ]
    }
  ],
  "apiResources": [
    {
      "ordId": "<namespace>:apiResource:<agent-id>-api:v1",
      "apiProtocol": "a2a",
      "resourceDefinitions": [
        {
          "type": "a2a-agent-card",
          "url": "/.well-known/agent-card.json",
          "accessStrategies": [{ "type": "sap:cmp-mtls:v1" }]
        }
      ]
    }
  ]
}
```

**Verify the ORD documents contain:**

- ✅ `"openResourceDiscovery": "1.14"` in both documents
- ✅ `agents` section with the agent's ORD ID in both documents
- ✅ `system-type` document has `"perspective": "system-type"` and **no** `apiResources` block (agent card is tenant-specific)
- ✅ `system-instance` document has `"perspective": "system-instance"` and `describedSystemInstance.localId` set
- ✅ `system-instance` document has `apiResources` with `"apiProtocol": "a2a"` and `resourceDefinitions` of `"type": "a2a-agent-card"` pointing to `"/.well-known/agent-card.json"`
- ✅ `system-instance` document has `agents[0].exposedApiResources` referencing the agent-card `apiResource`
- ✅ `accessStrategies` with `"type": "sap:cmp-mtls:v1"` on all discovery/agent-card endpoints
- ✅ `integrationDependencies` populated in **both** documents if skill-generated dependencies were provided
- ✅ MCP dependencies have `aspects[].apiResources[].labels.requiredAgentSecurityPermissions` set (if MCP dependencies were provided)
- ✅ Every populated integrationDependency has `labels.integrationMode` as a **single-element list** (`["mcp"]` or `["a2a"]`) — never a bare string, empty list, or multi-value list
- ✅ `system-type` document has `partOfProducts` populated on `packages[0]` and `agents[0]` (if a product ORD ID was provided in Phase 1.6); left as `[]` if the developer replied `skip`
- ✅ **No residual build-time `{{…}}` placeholders remain in either document** (the runtime `{{LOCAL_TENANT_ID}}` in `system_instance.json` is expected — it is substituted per-request by `_inject_tenant_id()`)

### Placeholder-substitution guard

Run this check to confirm no unsubstituted build-time `{{…}}` tokens are left in either ORD document. A residual placeholder would produce syntactically valid JSON but a semantically broken ORD entry (e.g., `partOfProducts: ["{{AGENT_PART_OF_PRODUCT}}"]`) that an ORD validator may silently accept.

> `{{LOCAL_TENANT_ID}}` in `system_instance.json` is intentionally left unsubstituted at build time; it is a runtime placeholder that `_inject_tenant_id()` in `app/ord/__init__.py` replaces on each request. The guard below excludes it for that reason.

**macOS/Linux:**

```bash
if grep -nE '\{\{[A-Z_]+\}\}' app/ord/system_type.json app/ord/system_instance.json | grep -v 'LOCAL_TENANT_ID'; then
  echo "ERROR: unsubstituted build-time placeholder(s) found — rerun Phase 2b"
  exit 1
else
  echo "OK: no residual build-time placeholders (runtime LOCAL_TENANT_ID is expected)"
fi
```

**Windows PowerShell:**

```powershell
$hits = Select-String -Path app/ord/system_type.json,app/ord/system_instance.json -Pattern '\{\{[A-Z_]+\}\}' |
  Where-Object { $_.Line -notmatch 'LOCAL_TENANT_ID' }
if ($hits) {
  $hits | ForEach-Object { Write-Host $_ }
  Write-Error "unsubstituted build-time placeholder(s) found — rerun Phase 2b"
} else {
  Write-Host "OK: no residual build-time placeholders (runtime LOCAL_TENANT_ID is expected)"
}
```

### integrationMode guard

Run this check to confirm every populated integrationDependency carries a valid `labels.integrationMode`. A missing or malformed value produces syntactically valid JSON that the ORD endpoint serves happily, but breaks at **runtime** when the consuming SPII handler (`sap-assistant-spii-implementation`) calls `_resolve_integration_mode()` and raises `ValueError`. Catching it here moves the failure from a live SPII transaction to build time.

The check uses `python3` (already used elsewhere in this phase) for a robust JSON walk rather than a fragile regex. Empty `integrationDependencies: []` arrays pass — the guard only validates dependencies that are actually declared.

**macOS/Linux/Windows (python3):**

```bash
python3 - <<'PY'
import json, sys

VALID = {"mcp", "a2a"}
bad = []
for path in ("app/ord/system_type.json", "app/ord/system_instance.json"):
    with open(path) as f:
        doc = json.load(f)
    for dep in doc.get("integrationDependencies", []):
        ord_id = dep.get("ordId", "<unknown>")
        mode = (dep.get("labels") or {}).get("integrationMode")
        if not (isinstance(mode, list) and len(mode) == 1 and mode[0] in VALID):
            bad.append(f"  {path}: {ord_id} -> integrationMode={mode!r}")

if bad:
    print("ERROR: invalid or missing integrationMode (expected single-element list with 'mcp' or 'a2a'):")
    print("\n".join(bad))
    print("Fix the offending integrationDependency (Phase 1.5/2d) and rerun.")
    sys.exit(1)
print("OK: every populated integrationDependency has a valid integrationMode")
PY
```

### Deployed Testing

After deploying the agent, test without authentication (ORD endpoints are open):

```bash
curl -s "https://<agent-url>/.well-known/open-resource-discovery" | python3 -m json.tool
curl -s "https://<agent-url>/open-resource-discovery/v1/documents/system-type" | python3 -m json.tool
curl -s "https://<agent-url>/open-resource-discovery/v1/documents/system-instance?tenantId=T1" | python3 -m json.tool
```

---

## Reference

- [ORD specification](https://open-resource-discovery.org/spec-v1)
- [SAP ORD policyLevel sap:ai:v1](https://sap.github.io/open-resource-discovery/spec-extensions/)

## Next Steps

After adding the ORD endpoint:

1. **Deploy** — Push to GitHub to trigger CI/CD deployment
2. **Register with UMS** — Provide the static ORD well-known URL to UMS for agent discovery: `https://<agent-url>/.well-known/open-resource-discovery`
3. **Test remotely** — Use the `sap-agent-test-remote` skill to verify the full agent works after deployment
