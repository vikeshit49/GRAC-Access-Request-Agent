# ORD (Open Resource Discovery) Overview

## What is ORD?

**Open Resource Discovery (ORD)** is an SAP standard protocol that enables applications to expose machine-readable metadata about their APIs, events, and capabilities. It allows SAP platform services to automatically discover and catalog what an application offers — without manual registration.

ORD is defined at version **1.14** and is used across SAP BTP to power:

- **UMS (Unified Metadata Service)** — discovers available agents before provisioning, enabling administrators to browse and provision agents
- **Joule** — recommends agents to users based on conversation context, using ORD metadata to understand what each agent can do

---

## How ORD Works for Agents

An agent exposes three HTTP endpoints using a single well-known entry point that branches on the `ord-perspective` header:

```
GET /.well-known/open-resource-discovery                            → ORD config (branches on header)
GET /open-resource-discovery/v1/documents/system-type              → static ORD document (provider level)
GET /open-resource-discovery/v1/documents/system-instance          → dynamic ORD document (tenant level, adds tenant-specific entries)
```

### Two Perspectives

| Perspective       | Purpose                                                                     | Document URL                                                  |
| ----------------- | --------------------------------------------------------------------------- | ------------------------------------------------------------- |
| `system-type`     | Describes the system **type** — same for all deployed instances. Contains: `product`, `packages`, `agent`, skill-generated i-deps. Does **not** contain the agent-card `apiResource` (the agent's URL is tenant-specific). | `/open-resource-discovery/v1/documents/system-type`           |
| `system-instance` | Describes a specific **deployed instance** — tenant-aware data. Adds: agent-card `apiResource`, `consumptionBundles`, `agents[].exposedApiResources`, and extensibility-runtime i-deps. | `/open-resource-discovery/v1/documents/system-instance`       |

The `ord-perspective: static` header in the request to `/.well-known/open-resource-discovery` selects `system-type`; any other value (including no header) returns `system-instance`.

> Neither document is a strict subset of the other: `products` live only in `system-type`; agent-card-related entries (`apiResources`, `consumptionBundles`, `agents[].exposedApiResources`) live only in `system-instance`.

### Discovery Flow

```
UMS / Joule
    │
    ├─► GET /.well-known/open-resource-discovery
    │       Returns: URL of ORD document (system-type or system-instance based on header)
    │
    └─► GET /open-resource-discovery/v1/documents/system-type  (or system-instance)
            Returns: full ORD document with agent metadata
```

---

## ORD Configuration Document

The well-known endpoint returns a single document URL based on the `ord-perspective` header:

```json
{
  "openResourceDiscoveryV1": {
    "documents": [
      {
        "url": "/open-resource-discovery/v1/documents/system-instance",
        "perspective": "system-instance",
        "accessStrategies": [
          {
            "type": "sap:cmp-mtls:v1"
          }
        ]
      }
    ]
  }
}
```

> **Note:** The `openResourceDiscoveryV1` wrapper (not `openResourceDiscovery`) is the correct format for the well-known config endpoint. The `accessStrategies` type is `sap:cmp-mtls:v1` — not `open`.

---

## ORD Document Structure

### system-type document

Describes the agent at the provider/system level. No tenant-specific data — so the agent-card `apiResource` and its `consumptionBundle` are **not** included here.

```json
{
  "openResourceDiscovery": "1.14",
  "$schema": "https://open-resource-discovery.org/spec-v1/interfaces/Document.schema.json",
  "perspective": "system-type",
  "policyLevels": ["sap:ai:v1"],
  "describedSystemVersion": {
    "version": "1.0.0"
  },
  "products": [...],
  "packages": [...],
  "agents": [...],
  "integrationDependencies": []
}
```

### system-instance document

Describes the agent at the instance level. Includes `describedSystemInstance.localId` populated with the tenant ID and the tenant-specific agent-card `apiResource`. `products` are **not** repeated here.

```json
{
  "openResourceDiscovery": "1.14",
  "perspective": "system-instance",
  "policyLevels": ["sap:ai:v1"],
  "describedSystemInstance": {
    "localId": "<tenant-id>"
  },
  "describedSystemVersion": {
    "version": "1.0.0"
  },
  "packages": [...],
  "consumptionBundles": [...],
  "agents": [...],
  "apiResources": [...],
  "integrationDependencies": []
}
```

Tenant ID is resolved (in priority order) from:
1. `tenantId` query parameter
2. `dwc-tenant` request header
3. `x-tenant-id` request header

---

## Agents Section

The `agents` section is the **primary resource type for AI agents** and appears in **both** documents. In `system-type` the entry omits `exposedApiResources` (no agent-card `apiResource` is declared at type level); in `system-instance` it includes the reference to the tenant-specific agent-card `apiResource`:

```json
{
  "ordId": "<namespace>:agent:<agent-id>:v1",
  "localId": "<agent-id>",
  "title": "<Agent Title>",
  "shortDescription": "<description>",
  "description": "<long description>",
  "version": "1.0.0",
  "visibility": "internal",
  "releaseStatus": "active",
  "partOfPackage": "<namespace>:package:<agent-id>:v1",
  "partOfProducts": [],
  "labels": {
    "sap.ai:interactionMode": ["conversational"]
  },
  "tags": ["sap", "ai-agent", "a2a"],
  "exposedApiResources": [
    { "ordId": "<namespace>:apiResource:<agent-id>-api:v1" }
  ],
  "integrationDependencies": []
}
```

---

## API Resources Section

Appears in `system-instance` **only**. The agent-card `apiResource` is tenant-specific because the agent's runtime URL embeds a per-tenant subdomain — so the `a2a-agent-card` resourceDefinition resolves to a different host per tenant, which makes the entire resource a `system-instance` entity. The matching `consumptionBundle` (and the `agents[].exposedApiResources` reference) therefore also live only in `system-instance`.

```json
{
  "ordId": "<namespace>:apiResource:<agent-id>-api:v1",
  "title": "<Agent Title> A2A API",
  "version": "1.0.0",
  "visibility": "internal",
  "releaseStatus": "active",
  "apiProtocol": "a2a",
  "extensible": { "supported": "no" },
  "partOfPackage": "<namespace>:package:<agent-id>:v1",
  "partOfConsumptionBundles": [
    { "ordId": "<namespace>:consumptionBundle:<agent-id>:v1" }
  ],
  "entryPoints": ["/"],
  "resourceDefinitions": [
    {
      "type": "a2a-agent-card",
      "mediaType": "application/json",
      "url": "/.well-known/agent-card.json",
      "accessStrategies": [{ "type": "sap:cmp-mtls:v1" }]
    }
  ],
  "tags": ["a2a", "agent-api"]
}
```

Key points:
- `apiProtocol` must be `"a2a"`
- `entryPoints` uses `"/"` (relative, no base URL)
- `resourceDefinitions.url` uses `"/.well-known/agent-card.json"` (relative, no base URL)
- `accessStrategies` type is `sap:cmp-mtls:v1`
- Lives in `system-instance` only — the tenant-specific subdomain in the agent's URL makes this resource tenant-scoped

> Non-agent-card `apiResources` (e.g. APIs whose endpoints are not tenant-scoped) may still be declared at `system-type` level. The restriction is specifically about the agent card.

---

## ORD IDs

Every ORD resource has a globally unique `ordId`:

```
<namespace>:<resourceType>:<resourceId>:<version>
```

| Component      | Example values                                                                  |
| -------------- | ------------------------------------------------------------------------------- |
| `namespace`    | `sap.appfnd`, `sap.s4`, `customer.mycompany`                                   |
| `resourceType` | `package`, `consumptionBundle`, `product`, `agent`, `apiResource`, `integrationDependency` |
| `resourceId`   | `travel-expense-agent`                                                          |
| `version`      | `v1`                                                                            |

> **Note:** The CPA namespace (e.g. `sap.appfnd`) is different from the Kubernetes namespace in `app.yaml`.

---

## Authentication

All agent endpoints (including ORD and `.well-known`) are protected by the **Jupyter gateway with mTLS** at the infrastructure level. No `apiAuth` configuration is needed in `app.yaml`. The `accessStrategies` in ORD documents use `"type": "sap:cmp-mtls:v1"` to reflect this.

---

## Integration Dependencies

The `integrationDependencies` section declares **external** systems/services outside the subaccount that are discovered via UMS (e.g., other agents, MCP servers). Do not list services automatically injected at runtime (such as AI Core or Object Store).

Dependencies appear in **two places**:

1. **In `agents[0].integrationDependencies`** — list of ORD ID strings (references)
2. **In the top-level `integrationDependencies`** — full dependency objects with `aspects`

```json
{
  "ordId": "<namespace>:integrationDependency:<dep-id>:v1",
  "title": "<Dependency Title>",
  "version": "1.0.0",
  "visibility": "public",
  "releaseStatus": "active",
  "mandatory": true,
  "partOfPackage": "<namespace>:package:<agent-id>:v1",
  "aspects": [
    {
      "title": "<Aspect Title>",
      "mandatory": true,
      "apiResources": [
        { "ordId": "<external-resource-ord-id>", "minVersion": "1.0.0" }
      ]
    }
  ]
}
```

---

## Further Reading

- [SAP ORD Specification](https://sap.github.io/open-resource-discovery/)
- [ORD GitHub Repository](https://github.com/SAP/open-resource-discovery)
