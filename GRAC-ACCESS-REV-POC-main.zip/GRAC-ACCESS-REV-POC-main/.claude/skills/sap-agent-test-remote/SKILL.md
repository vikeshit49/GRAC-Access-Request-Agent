---
name: sap-agent-test-remote
description: Test a deployed App Foundation agent remotely using the A2A protocol over the Unified Gateway (DwC architecture). Use when the user wants to test their agent after deployment to a DwC landscape (Canary Dev, Canary Test, Live Test, or Live Prod).
---

# Testing App Foundation Agent Remotely (DwC / Unified Gateway)

Test deployed App Foundation agents using the A2A protocol over the Unified Gateway.

## Prerequisites

:::warning Required before running this skill
Complete **Level-0 testing setup** first (Steps 1–8 of the Level-0 guide). Specifically:
- ✅ Agent deployed to a DwC landscape via Infraprep
- ✅ Level-0 action run (GitHub Actions `register-level-0.yaml` workflow)
- ✅ Dummy IAS application created with Client ID + Secret (Steps 6–8)
- ✅ Dependency added to the dummy app (Step 7) — note the dependency name
- ✅ Your user assigned to the Authorization Policy (Step 5)
- ✅ `app/.env.deploy` added to `.gitignore` (contains your password)
:::

- **Level-0 guide**: https://pages.github.tools.sap/application-foundation/agent-runtime-domains/level-0-test
- **IAS Tenant (Canary)**: https://appfnd-subscriber.accounts400.ondemand.com/admin/#/applications
- **IAS Tenant (Live)**: https://appfnd-subscriber.accounts.ondemand.com/admin/#/applications

---

## Workflow Overview

1. Ensure `.gitignore` includes `app/.env.deploy`
2. Copy and configure credentials in `app/.env.deploy`
3. Run the test script with desired command
4. Troubleshoot if needed

**Important:** Guide the user through ALL steps. The goal is to successfully communicate with the deployed agent.

---

## Step 1: Protect Credentials

Before anything else, ensure `app/.env.deploy` is gitignored:

```bash
grep -q "app/.env.deploy" .gitignore 2>/dev/null || echo "app/.env.deploy" >> .gitignore
```

---

## Step 2: Configure Credentials

Check if `app/.env.deploy` exists:

```bash
cat app/.env.deploy 2>/dev/null || echo "NOT_FOUND"
```

**If NOT_FOUND**, copy the template:

```bash
SKILL_PATH=$(find . -type d -name "sap-agent-test-remote" -path "*/skills/*" 2>/dev/null | head -1)
cp "$SKILL_PATH/templates/.env.deploy" app/.env.deploy
```

Then guide the user to fill in each variable:

| Variable | Where to find it |
|----------|-----------------|
| `ENVIRONMENT` | The landscape being tested: `canary-dev`, `canary-test`, `live-test`, or `live-prod` |
| `REGION` | DwC dashboard (Amalthea) — e.g. `eu12` |
| `AGENT_NAME` | `metadata.name` in `app.yaml` (auto-read if left empty) |
| `TENANT_SUBDOMAIN` | IAS tenant → Bundled Applications → find `(Level 0: <number>)` → use that number |
| `IAS_CLIENT_ID` | Dummy IAS application → Client Authentication panel (Step 8) |
| `IAS_CLIENT_SECRET` | Dummy IAS application → Secrets section (Step 8) |
| `IAS_DEPENDENCY_NAME` | The name you chose when creating the dependency in Step 7 |
| `IAS_USERNAME` | Your personal login for the `appfnd-subscriber` IAS tenant |
| `IAS_PASSWORD` | Your personal password for the `appfnd-subscriber` IAS tenant |

**Finding TENANT_SUBDOMAIN:**
1. Open the IAS tenant console for your environment (links above)
2. Navigate to **Applications → Bundled Applications**
3. Find the entry named: `<domain>-<agent>-<landscape> (Level 0: <number>)`
4. The `<number>` in parentheses is your `TENANT_SUBDOMAIN`

---

## Step 3: Run Tests

Use `AskUserQuestion` to ask what the user wants to do:

| Command | Description |
|---------|-------------|
| `health` | Full diagnostic: reachability + two-step token exchange + authenticated request |
| `card` | View agent metadata, capabilities, and skills |
| `info` | Full diagnostic (health + card) |
| `"message"` | Send a test message |
| `chat` | Interactive multi-turn chat |

```bash
SKILL_PATH=$(find . -type d -name "sap-agent-test-remote" -path "*/skills/*" 2>/dev/null | head -1)
"$SKILL_PATH/scripts/test-agent.sh" [command]
```

---

## Step 4: Follow-up Questions

**After each action**, use `AskUserQuestion` with these options:
- Health check / Agent card / Send message / Chat / Done testing

**On failure**, read `references/troubleshooting.md` and offer retry or diagnostics.
