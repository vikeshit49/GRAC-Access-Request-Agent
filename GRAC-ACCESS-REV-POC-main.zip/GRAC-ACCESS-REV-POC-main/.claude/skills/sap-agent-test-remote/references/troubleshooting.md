# Troubleshooting Remote Agent Testing (DwC / Unified Gateway)

## Common Errors

### Step 9a fails — password token request returns error

**Symptoms:**
```json
{"error": "invalid_client", "error_description": "..."}
```

**Causes & Solutions:**
1. **Wrong IAS_CLIENT_ID or IAS_CLIENT_SECRET** — re-copy from the dummy application's Client Authentication panel
2. **Wrong IAS tenant URL** — check `ENVIRONMENT` in `.env.deploy` matches where you ran Level-0

---

### Step 9a fails — `grant_type=password` rejected

**Symptoms:**
```json
{"error": "unauthorized_client"}
```

**Cause:** ROPC (Resource Owner Password Credentials) grant may be disabled on the IAS tenant.

**Solution:** Contact the Managed Runtime team. The `appfnd-subscriber` tenant should have this enabled.

---

### Step 9b fails — App2App token exchange returns error

**Symptoms:**
```json
{"error": "invalid_grant"}
```

**Causes & Solutions:**
1. **Wrong IAS_DEPENDENCY_NAME** — must match exactly the name set in Step 7 of Level-0
2. **Dependency not saved** — verify the dependency exists in the dummy application under Application APIs → Dependencies
3. **id_token expired** — tokens are short-lived; re-run Step 9a before retrying

---

### 401 Unauthorized calling the agent

**Symptoms:**
```json
{"error": "Unauthorized", "status": 401}
```

**Causes & Solutions:**
1. **access_token expired** — re-run the full token exchange (Steps 9a + 9b)
2. **Wrong token used** — must use the `access_token` from Step 9b, not the `id_token` from Step 9a

---

### 403 Forbidden calling the agent

**Symptoms:**
```json
{"error": "Forbidden", "status": 403}
```

**Cause:** Your user is not assigned to the Authorization Policy on the subscribed application.

**Solution:** In the IAS tenant, open the subscribed bundled application → Authorization Policies → Access policy → Assignments → add your user. See Level-0 Step 5.

---

### 404 Not Found

**Symptoms:**
```json
{"error": "Not Found", "status": 404}
```

**Causes & Solutions:**
1. **Wrong AGENT_NAME** — must match `metadata.name` in `app.yaml`
2. **Wrong REGION** — check the DwC dashboard (Amalthea) for the correct region
3. **Wrong ENVIRONMENT** — verify the agent is deployed to the target landscape
4. **Wrong TENANT_SUBDOMAIN** — must be the numeric ID from the bundled application name in the IAS console
5. **Deployment still in progress** — wait for Infraprep to complete, then retry

---

### Connection Refused / Timeout

**Symptoms:**
```
curl: (7) Failed to connect
curl: (28) Connection timed out
```

**Causes & Solutions:**
1. **Agent not deployed** — check GitHub Actions and DwC dashboard
2. **Infraprep not completed** — the agent must be promoted via Infraprep, not raw DwC promotion
3. **Network issues** — try from a different network

---

### Finding the TENANT_SUBDOMAIN

1. Open the IAS tenant for your environment:
   - Canary: https://appfnd-subscriber.accounts400.ondemand.com/admin/#/applications
   - Live: https://appfnd-subscriber.accounts.ondemand.com/admin/#/applications
2. Navigate to **Bundled Applications**
3. Find the application named: `<domain>-<agent>-<landscape> (Level 0: <number>)`
4. The `<number>` in parentheses is your `TENANT_SUBDOMAIN`
