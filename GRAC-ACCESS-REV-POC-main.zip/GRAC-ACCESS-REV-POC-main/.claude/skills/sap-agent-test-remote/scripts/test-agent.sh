#!/bin/bash
# ===========================================
# App Foundation Agent Remote Test Script
# DwC / Unified Gateway architecture
# ===========================================
# Tests a deployed agent using the A2A protocol over the Unified Gateway.
# Authentication uses a two-step IAS App2App token exchange.
#
# Usage:
#   ./test-agent.sh [command] [args]
#
# Commands:
#   message [text]  - Send a message (default command)
#   card            - Get agent card (/.well-known/agent-card.json)
#   health          - Check agent health/accessibility
#   info            - Show all agent information
#   chat            - Interactive chat mode
#
# Exit Codes:
#   0 - Success
#   1 - Agent unreachable
#   2 - OAuth Step 9a failed (password token)
#   3 - OAuth Step 9b failed (App2App token exchange)
#   4 - Authentication rejected (401)
#   5 - Access forbidden (403) — check Authorization Policy assignment
#   6 - Endpoint not found (404)
#   7 - Unexpected HTTP response
#   8 - Missing credentials file
#   9 - Missing required variables
#   10 - Message send failed
#
# Reads credentials from app/.env.deploy
# ===========================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$PWD"
while [[ ! -f "$PROJECT_ROOT/app/.env.deploy" && ! -d "$PROJECT_ROOT/app" && "$PROJECT_ROOT" != "/" ]]; do
    PROJECT_ROOT="$(dirname "$PROJECT_ROOT")"
done
# If not found from CWD, retry from SCRIPT_DIR (fallback for direct invocation)
if [[ ! -f "$PROJECT_ROOT/app/.env.deploy" && ! -d "$PROJECT_ROOT/app" ]]; then
    PROJECT_ROOT="$SCRIPT_DIR"
    while [[ ! -f "$PROJECT_ROOT/app/.env.deploy" && ! -d "$PROJECT_ROOT/app" && "$PROJECT_ROOT" != "/" ]]; do
        PROJECT_ROOT="$(dirname "$PROJECT_ROOT")"
    done
fi

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# ===========================================
# Credential loading
# ===========================================

load_credentials() {
  ENV_FILE="$PROJECT_ROOT/app/.env.deploy"
  if [ -f "$ENV_FILE" ]; then
    set -a
    source "$ENV_FILE"
    set +a
  else
    echo -e "${RED}ERROR: $ENV_FILE not found${NC}"
    echo "Copy the template from your skills directory to app/.env.deploy"
    exit 8
  fi
}

validate_credentials() {
  MISSING=()
  [ -z "$ENVIRONMENT" ]        && MISSING+=("ENVIRONMENT")
  [ -z "$REGION" ]             && MISSING+=("REGION")
  [ -z "$TENANT_SUBDOMAIN" ]   && MISSING+=("TENANT_SUBDOMAIN")
  [ -z "$IAS_CLIENT_ID" ]      && MISSING+=("IAS_CLIENT_ID")
  [ -z "$IAS_CLIENT_SECRET" ]  && MISSING+=("IAS_CLIENT_SECRET")
  [ -z "$IAS_DEPENDENCY_NAME" ] && MISSING+=("IAS_DEPENDENCY_NAME")
  [ -z "$IAS_USERNAME" ]       && MISSING+=("IAS_USERNAME")
  [ -z "$IAS_PASSWORD" ]       && MISSING+=("IAS_PASSWORD")

  # AGENT_NAME: fall back to app.yaml if not set in .env.deploy
  if [ -z "$AGENT_NAME" ]; then
    YAML_FILE="$PROJECT_ROOT/app.yaml"
    if [ -f "$YAML_FILE" ]; then
      AGENT_NAME=$(grep -A1 'metadata:' "$YAML_FILE" | grep 'name:' | awk '{print $2}' | tr -d '"')
    fi
  fi
  [ -z "$AGENT_NAME" ] && MISSING+=("AGENT_NAME")

  if [ ${#MISSING[@]} -ne 0 ]; then
    echo -e "${RED}ERROR: Missing required variables in app/.env.deploy:${NC}"
    printf '  - %s\n' "${MISSING[@]}"
    exit 9
  fi

  # Derive IAS tenant URL and agent base URL from ENVIRONMENT
  case "$ENVIRONMENT" in
    canary-dev)
      IAS_TENANT_URL="https://appfnd-subscriber.accounts400.ondemand.com"
      ENV_SUFFIX="-dev"
      DOMAIN="run.ai.dev.sap"
      ;;
    canary-test)
      IAS_TENANT_URL="https://appfnd-subscriber.accounts400.ondemand.com"
      ENV_SUFFIX=""
      DOMAIN="run.ai.dev.sap"
      ;;
    live-test)
      IAS_TENANT_URL="https://appfnd-subscriber.accounts.ondemand.com"
      ENV_SUFFIX="-test"
      DOMAIN="run.ai.cloud.sap"
      ;;
    live-prod)
      IAS_TENANT_URL="https://appfnd-subscriber.accounts.ondemand.com"
      ENV_SUFFIX=""
      DOMAIN="run.ai.cloud.sap"
      ;;
    *)
      echo -e "${RED}ERROR: Unknown ENVIRONMENT '$ENVIRONMENT'${NC}"
      echo "Valid values: canary-dev | canary-test | live-test | live-prod"
      exit 9
      ;;
  esac

  AGENT_BASE_URL="https://${TENANT_SUBDOMAIN}.${AGENT_NAME}${ENV_SUFFIX}.${REGION}.${DOMAIN}/api/${AGENT_NAME}/v1"
}

# ===========================================
# Token exchange (two-step App2App)
# ===========================================

get_token() {
  # Write credentials to a temp file to avoid exposing secrets in process arguments
  local _tmpfile
  _tmpfile=$(mktemp)
  chmod 600 "$_tmpfile"
  printf 'client_id=%s&client_secret=%s&grant_type=password&token_format=jwt&scope=openid' \
    "${IAS_CLIENT_ID}" "${IAS_CLIENT_SECRET}" > "$_tmpfile"

  # Step 9a: password grant → id_token
  TOKEN_RESPONSE_A=$(curl -s -X POST "${IAS_TENANT_URL}/oauth2/token" \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H 'Accept: application/json' \
    --data "@${_tmpfile}" \
    --data-urlencode "username=${IAS_USERNAME}" \
    --data-urlencode "password=${IAS_PASSWORD}")
  rm -f "$_tmpfile"

  ID_TOKEN=$(echo "$TOKEN_RESPONSE_A" | jq -r '.id_token // empty')
  if [ -z "$ID_TOKEN" ] || [ "$ID_TOKEN" = "null" ]; then
    ERROR=$(echo "$TOKEN_RESPONSE_A" | jq -r '.error_description // .error // "Unknown error"')
    echo -e "${RED}ERROR: Step 9a (password token) failed: $ERROR${NC}" >&2
    echo -e "${YELLOW}Check IAS_CLIENT_ID, IAS_CLIENT_SECRET, IAS_USERNAME, IAS_PASSWORD${NC}" >&2
    exit 2
  fi

  # Step 9b: jwt-bearer grant → access_token (App2App)
  local _tmpfile2
  _tmpfile2=$(mktemp)
  chmod 600 "$_tmpfile2"
  printf 'client_id=%s&client_secret=%s&grant_type=urn%%3Aietf%%3Aparams%%3Aoauth%%3Agrant-type%%3Ajwt-bearer&token_format=jwt' \
    "${IAS_CLIENT_ID}" "${IAS_CLIENT_SECRET}" > "$_tmpfile2"

  TOKEN_RESPONSE_B=$(curl -s -X POST "${IAS_TENANT_URL}/oauth2/token" \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H 'Accept: application/json' \
    --data "@${_tmpfile2}" \
    --data-urlencode "assertion=${ID_TOKEN}" \
    --data-urlencode "resource=urn:sap:identity:application:provider:name:${IAS_DEPENDENCY_NAME}")
  rm -f "$_tmpfile2"

  ACCESS_TOKEN=$(echo "$TOKEN_RESPONSE_B" | jq -r '.access_token // empty')
  if [ -z "$ACCESS_TOKEN" ] || [ "$ACCESS_TOKEN" = "null" ]; then
    ERROR=$(echo "$TOKEN_RESPONSE_B" | jq -r '.error_description // .error // "Unknown error"')
    echo -e "${RED}ERROR: Step 9b (App2App token exchange) failed: $ERROR${NC}" >&2
    echo -e "${YELLOW}Check IAS_DEPENDENCY_NAME — must match the dependency created in Level-0 Step 7${NC}" >&2
    exit 3
  fi

  echo "$ACCESS_TOKEN"
}

# ===========================================
# Command: card
# ===========================================

cmd_card() {
  echo -e "${BLUE}=========================================="
  echo "Agent Card"
  echo -e "==========================================${NC}"
  CARD_URL="${AGENT_BASE_URL}/.well-known/agent-card.json"
  echo "URL: $CARD_URL"
  echo ""

  local _card_tmp
  _card_tmp=$(mktemp)
  HTTP_CODE=$(curl -s -o "$_card_tmp" -w "%{http_code}" "$CARD_URL")
  RESPONSE=$(cat "$_card_tmp" 2>/dev/null || echo "{}")
  rm -f "$_card_tmp"

  if [ "$HTTP_CODE" = "200" ]; then
    echo -e "${GREEN}STATUS: SUCCESS (HTTP 200)${NC}"
    echo ""
    echo "$RESPONSE" | jq .

    echo ""
    echo -e "${BLUE}Key Information:${NC}"
    echo "  Name:        $(echo "$RESPONSE" | jq -r '.name // "N/A"')"
    echo "  Description: $(echo "$RESPONSE" | jq -r '.description // "N/A"')"
    echo "  Version:     $(echo "$RESPONSE" | jq -r '.version // "N/A"')"

    SKILLS=$(echo "$RESPONSE" | jq -r '.skills // [] | length')
    echo "  Skills:      $SKILLS"

    if [ "$SKILLS" -gt 0 ]; then
      echo ""
      echo -e "${BLUE}Available Skills:${NC}"
      echo "$RESPONSE" | jq -r '.skills[]? | "  - \(.name // .id): \(.description // "No description")"' 2>/dev/null || true
    fi
    exit 0
  elif [ "$HTTP_CODE" = "401" ]; then
    echo -e "${RED}STATUS: UNAUTHORIZED (HTTP 401)${NC}"
    echo "Response: $RESPONSE"
    exit 4
  elif [ "$HTTP_CODE" = "403" ]; then
    echo -e "${RED}STATUS: FORBIDDEN (HTTP 403)${NC}"
    echo "Response: $RESPONSE"
    echo ""
    echo -e "${YELLOW}Make sure your user is assigned to the Access Authorization Policy${NC}"
    echo "  IAS tenant → Bundled Applications → your app → Authorization Policies → Access → Assignments"
    exit 5
  elif [ "$HTTP_CODE" = "404" ]; then
    echo -e "${RED}STATUS: NOT FOUND (HTTP 404)${NC}"
    echo ""
    echo -e "${YELLOW}Possible causes:${NC}"
    echo "  - Wrong AGENT_NAME, REGION, ENVIRONMENT, or TENANT_SUBDOMAIN"
    echo "  - Deployment / Infraprep not completed yet"
    exit 6
  elif [ "$HTTP_CODE" = "000" ]; then
    echo -e "${RED}STATUS: UNREACHABLE${NC}"
    echo ""
    echo -e "${YELLOW}Possible causes:${NC}"
    echo "  - Agent not deployed or Infraprep not completed"
    echo "  - Network / VPN issues"
    exit 1
  else
    echo -e "${RED}STATUS: UNEXPECTED (HTTP $HTTP_CODE)${NC}"
    echo "Response: $RESPONSE"
    exit 7
  fi
}

# ===========================================
# Command: health
# ===========================================

# When called standalone (CMD=health), exits with status.
_HEALTH_CALLER=""
_HEALTH_RESULT=0

cmd_health() {
  echo -e "${BLUE}=========================================="
  echo "Agent Health Check"
  echo -e "==========================================${NC}"
  echo "Environment:      $ENVIRONMENT"
  echo "Agent:            $AGENT_NAME"
  echo "Region:           $REGION"
  echo "Tenant subdomain: $TENANT_SUBDOMAIN"
  echo "Base URL:         $AGENT_BASE_URL"
  echo "IAS Tenant:       $IAS_TENANT_URL"
  echo ""

  local all_checks_passed=true
  local critical_failure=false
  local failure_reason=""

  # Check 1: Agent card (public endpoint)
  echo -n "1. Agent Card (/.well-known/agent-card.json): "
  CARD_HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 \
    "${AGENT_BASE_URL}/.well-known/agent-card.json" 2>/dev/null || echo "000")
  if [ "$CARD_HTTP_CODE" = "200" ]; then
    echo -e "${GREEN}OK${NC}"
  elif [ "$CARD_HTTP_CODE" = "000" ]; then
    echo -e "${RED}UNREACHABLE${NC}"
    critical_failure=true
    failure_reason="Agent is not reachable"
  elif [ "$CARD_HTTP_CODE" = "403" ]; then
    echo -e "${YELLOW}FORBIDDEN — Authorization Policy not assigned${NC}"
    all_checks_passed=false
  elif [ "$CARD_HTTP_CODE" = "404" ]; then
    echo -e "${YELLOW}NOT FOUND — check URL components${NC}"
    all_checks_passed=false
  else
    echo -e "${YELLOW}HTTP $CARD_HTTP_CODE${NC}"
    all_checks_passed=false
  fi

  # Check 2: Step 9a — password token
  echo -n "2. IAS Password Token (Step 9a): "
  local _tmpfile
  _tmpfile=$(mktemp)
  chmod 600 "$_tmpfile"
  printf 'client_id=%s&client_secret=%s&grant_type=password&token_format=jwt&scope=openid' \
    "${IAS_CLIENT_ID}" "${IAS_CLIENT_SECRET}" > "$_tmpfile"
  TOKEN_RESPONSE_A=$(curl -s -X POST "${IAS_TENANT_URL}/oauth2/token" \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    --data "@${_tmpfile}" \
    --data-urlencode "username=${IAS_USERNAME}" \
    --data-urlencode "password=${IAS_PASSWORD}" 2>/dev/null || echo "{}")
  rm -f "$_tmpfile"
  ID_TOKEN=$(echo "$TOKEN_RESPONSE_A" | jq -r '.id_token // empty' 2>/dev/null)
  if [ -n "$ID_TOKEN" ] && [ "$ID_TOKEN" != "null" ]; then
    echo -e "${GREEN}OK${NC}"
  else
    ERROR=$(echo "$TOKEN_RESPONSE_A" | jq -r '.error // "Unknown"' 2>/dev/null)
    echo -e "${RED}FAILED ($ERROR)${NC}"
    critical_failure=true
    failure_reason="IAS password token failed"
  fi

  # Check 3: Step 9b — App2App token exchange
  APP2APP_OK=false
  if [ -n "$ID_TOKEN" ] && [ "$ID_TOKEN" != "null" ]; then
    echo -n "3. App2App Token Exchange (Step 9b): "
    local _tmpfile2
    _tmpfile2=$(mktemp)
    chmod 600 "$_tmpfile2"
    printf 'client_id=%s&client_secret=%s&grant_type=urn%%3Aietf%%3Aparams%%3Aoauth%%3Agrant-type%%3Ajwt-bearer&token_format=jwt' \
      "${IAS_CLIENT_ID}" "${IAS_CLIENT_SECRET}" > "$_tmpfile2"
    TOKEN_RESPONSE_B=$(curl -s -X POST "${IAS_TENANT_URL}/oauth2/token" \
      -H 'Content-Type: application/x-www-form-urlencoded' \
      --data "@${_tmpfile2}" \
      --data-urlencode "assertion=${ID_TOKEN}" \
      --data-urlencode "resource=urn:sap:identity:application:provider:name:${IAS_DEPENDENCY_NAME}" 2>/dev/null || echo "{}")
    rm -f "$_tmpfile2"
    ACCESS_TOKEN=$(echo "$TOKEN_RESPONSE_B" | jq -r '.access_token // empty' 2>/dev/null)
    if [ -n "$ACCESS_TOKEN" ] && [ "$ACCESS_TOKEN" != "null" ]; then
      echo -e "${GREEN}OK${NC}"
      APP2APP_OK=true
    else
      ERROR=$(echo "$TOKEN_RESPONSE_B" | jq -r '.error // "Unknown"' 2>/dev/null)
      echo -e "${RED}FAILED ($ERROR)${NC}"
      echo -e "  ${YELLOW}→ Check IAS_DEPENDENCY_NAME matches Level-0 Step 7${NC}"
      critical_failure=true
      failure_reason="App2App token exchange failed"
    fi
  fi

  # Check 4: Authenticated request
  if [ "$APP2APP_OK" = true ]; then
    echo -n "4. Authenticated Request: "
    AUTH_HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 \
      -H "Authorization: Bearer $ACCESS_TOKEN" \
      "${AGENT_BASE_URL}/" 2>/dev/null || echo "000")
    if [ "$AUTH_HTTP_CODE" = "200" ] || [ "$AUTH_HTTP_CODE" = "405" ]; then
      echo -e "${GREEN}OK (HTTP $AUTH_HTTP_CODE)${NC}"
    elif [ "$AUTH_HTTP_CODE" = "401" ]; then
      echo -e "${RED}UNAUTHORIZED${NC}"
      critical_failure=true
      failure_reason="Authentication rejected by agent"
    elif [ "$AUTH_HTTP_CODE" = "403" ]; then
      echo -e "${YELLOW}FORBIDDEN — check Authorization Policy assignment in IAS${NC}"
      all_checks_passed=false
    elif [ "$AUTH_HTTP_CODE" = "404" ]; then
      echo -e "${YELLOW}NOT FOUND${NC}"
      all_checks_passed=false
    elif [ "$AUTH_HTTP_CODE" = "000" ]; then
      echo -e "${RED}UNREACHABLE${NC}"
      critical_failure=true
      failure_reason="Agent is not reachable"
    else
      echo -e "${YELLOW}HTTP $AUTH_HTTP_CODE${NC}"
      all_checks_passed=false
    fi
  fi

  echo ""
  echo -e "${BLUE}===========================================${NC}"
  echo -e "${BLUE}Summary:${NC}"

  local _exit_code
  if [ "$critical_failure" = true ]; then
    echo -e "${RED}FAILED: $failure_reason${NC}"
    _exit_code=1
  elif [ "$all_checks_passed" = false ]; then
    echo -e "${YELLOW}PARTIAL: Some checks did not pass — see details above${NC}"
    _exit_code=7
  else
    echo -e "${GREEN}SUCCESS: Agent is healthy and ready for testing${NC}"
    _exit_code=0
  fi

  # When called from cmd_info, store result in global and return 0 (avoids set -e triggering in caller)
  if [ "$_HEALTH_CALLER" = "info" ]; then
    _HEALTH_RESULT="$_exit_code"
    return 0
  fi
  exit "$_exit_code"
}

# ===========================================
# Command: info
# ===========================================

cmd_info() {
  echo -e "${BLUE}=========================================="
  echo "Agent Information"
  echo -e "==========================================${NC}"
  echo ""
  echo -e "${BLUE}Configuration:${NC}"
  echo "  ENVIRONMENT:      $ENVIRONMENT"
  echo "  AGENT_NAME:       $AGENT_NAME"
  echo "  REGION:           $REGION"
  echo "  TENANT_SUBDOMAIN: $TENANT_SUBDOMAIN"
  echo "  Base URL:         $AGENT_BASE_URL"
  echo "  IAS Tenant:       $IAS_TENANT_URL"
  if [ "${#IAS_CLIENT_ID}" -gt 12 ]; then
    echo "  IAS Client ID:    ${IAS_CLIENT_ID:0:8}...${IAS_CLIENT_ID: -4}"
  else
    echo "  IAS Client ID:    (set)"
  fi
  echo "  Dependency:       $IAS_DEPENDENCY_NAME"
  echo ""

  _HEALTH_CALLER="info"
  _HEALTH_RESULT=0
  cmd_health
  _HEALTH_CALLER=""

  echo ""
  if [ $_HEALTH_RESULT -eq 0 ] || [ $_HEALTH_RESULT -eq 7 ]; then
    cmd_card
  fi
}

# ===========================================
# Command: message
# ===========================================

cmd_message() {
  local MESSAGE="${1:-Hello, what can you help me with?}"
  local CONTEXT_ID="$2"

  echo -e "${BLUE}=========================================="
  echo "Sending Message"
  echo -e "==========================================${NC}"
  echo "Agent:   $AGENT_BASE_URL"
  echo "Message: $MESSAGE"
  [ -n "$CONTEXT_ID" ] && echo "Context: $CONTEXT_ID"
  echo ""

  echo "Getting App2App token..."
  TOKEN=$(get_token)
  echo -e "${GREEN}Token obtained${NC}"
  echo ""

  MSG_ID="msg-$(date +%s)-$RANDOM"
  REQ_ID="test-$(date +%s)-$RANDOM"

  if [ -n "$CONTEXT_ID" ]; then
    PAYLOAD=$(jq -n \
      --arg reqId "$REQ_ID" \
      --arg msgId "$MSG_ID" \
      --arg text "$MESSAGE" \
      --arg ctxId "$CONTEXT_ID" \
      '{
        jsonrpc: "2.0",
        method: "message/send",
        id: $reqId,
        params: {
          message: {
            messageId: $msgId,
            role: "user",
            contextId: $ctxId,
            parts: [{kind: "text", text: $text}]
          }
        }
      }')
  else
    PAYLOAD=$(jq -n \
      --arg reqId "$REQ_ID" \
      --arg msgId "$MSG_ID" \
      --arg text "$MESSAGE" \
      '{
        jsonrpc: "2.0",
        method: "message/send",
        id: $reqId,
        params: {
          message: {
            messageId: $msgId,
            role: "user",
            parts: [{kind: "text", text: $text}]
          }
        }
      }')
  fi

  local _resp_tmp
  _resp_tmp=$(mktemp)
  echo "Sending message..."
  HTTP_CODE=$(curl -s -o "$_resp_tmp" -w "%{http_code}" -X POST "${AGENT_BASE_URL}/" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "$PAYLOAD")

  RESPONSE=$(cat "$_resp_tmp" 2>/dev/null || echo "{}")
  rm -f "$_resp_tmp"

  echo ""
  echo -e "${BLUE}===========================================${NC}"
  echo "HTTP Status: $HTTP_CODE"
  echo -e "${BLUE}Response:${NC}"
  echo "$RESPONSE" | jq . 2>/dev/null || echo "$RESPONSE"

  echo ""
  echo -e "${BLUE}===========================================${NC}"

  if [ "$HTTP_CODE" != "200" ]; then
    echo -e "${RED}FAILED: HTTP $HTTP_CODE${NC}"
    if [ "$HTTP_CODE" = "401" ]; then
      echo "Authentication failed — token may have expired, re-run"
      exit 4
    elif [ "$HTTP_CODE" = "403" ]; then
      echo "Access forbidden — check Authorization Policy assignment in IAS"
      exit 5
    elif [ "$HTTP_CODE" = "404" ]; then
      echo "Endpoint not found — check AGENT_NAME, REGION, ENVIRONMENT, TENANT_SUBDOMAIN"
      exit 6
    else
      echo "Unexpected error"
      exit 7
    fi
  fi

  if echo "$RESPONSE" | jq -e '.result' > /dev/null 2>&1; then
    echo -e "${GREEN}SUCCESS: Agent responded${NC}"

    NEW_CONTEXT=$(echo "$RESPONSE" | jq -r '.result.contextId // empty')
    if [ -n "$NEW_CONTEXT" ]; then
      echo ""
      echo -e "${YELLOW}Context ID (for follow-up): $NEW_CONTEXT${NC}"
    fi

    AGENT_TEXT=$(echo "$RESPONSE" | jq -r '.result.artifacts[0].parts[0].text // empty' 2>/dev/null)
    if [ -n "$AGENT_TEXT" ]; then
      echo ""
      echo -e "${BLUE}=========================================="
      echo "Agent Answer:"
      echo -e "==========================================${NC}"
      echo "$AGENT_TEXT"
    fi
    exit 0
  elif echo "$RESPONSE" | jq -e '.error' > /dev/null 2>&1; then
    echo -e "${RED}FAILED: Agent returned error${NC}"
    echo "$RESPONSE" | jq '.error'
    exit 10
  else
    echo -e "${RED}FAILED: Unexpected response format${NC}"
    exit 10
  fi
}

# ===========================================
# Command: chat
# ===========================================

cmd_chat() {
  echo -e "${BLUE}=========================================="
  echo "Interactive Chat Mode"
  echo -e "==========================================${NC}"
  echo "Agent: $AGENT_BASE_URL"
  echo "Type 'exit' or 'quit' to end the session"
  echo "Type 'new' to start a new conversation"
  echo ""

  echo "Getting App2App token..."
  TOKEN=$(get_token)
  echo -e "${GREEN}Token obtained${NC}"
  echo ""

  CONTEXT_ID=""

  while true; do
    echo -n -e "${GREEN}You: ${NC}"
    read -r USER_INPUT

    if [ "$USER_INPUT" = "exit" ] || [ "$USER_INPUT" = "quit" ]; then
      echo "Goodbye!"
      break
    fi

    if [ "$USER_INPUT" = "new" ]; then
      CONTEXT_ID=""
      echo -e "${YELLOW}Starting new conversation...${NC}"
      echo ""
      continue
    fi

    if [ -z "$USER_INPUT" ]; then
      continue
    fi

    MSG_ID="msg-$(date +%s)-$RANDOM"
    REQ_ID="chat-$(date +%s)-$RANDOM"

    if [ -n "$CONTEXT_ID" ]; then
      PAYLOAD=$(jq -n \
        --arg reqId "$REQ_ID" \
        --arg msgId "$MSG_ID" \
        --arg text "$USER_INPUT" \
        --arg ctxId "$CONTEXT_ID" \
        '{
          jsonrpc: "2.0",
          method: "message/send",
          id: $reqId,
          params: {
            message: {
              messageId: $msgId,
              role: "user",
              contextId: $ctxId,
              parts: [{kind: "text", text: $text}]
            }
          }
        }')
    else
      PAYLOAD=$(jq -n \
        --arg reqId "$REQ_ID" \
        --arg msgId "$MSG_ID" \
        --arg text "$USER_INPUT" \
        '{
          jsonrpc: "2.0",
          method: "message/send",
          id: $reqId,
          params: {
            message: {
              messageId: $msgId,
              role: "user",
              parts: [{kind: "text", text: $text}]
            }
          }
        }')
    fi

    echo -e "${YELLOW}Thinking...${NC}"
    CHAT_HTTP_CODE=$(curl -s -o /tmp/_chat_resp_$$.json -w "%{http_code}" -X POST "${AGENT_BASE_URL}/" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      -d "$PAYLOAD")
    RESPONSE=$(cat /tmp/_chat_resp_$$.json 2>/dev/null || echo "{}")
    rm -f /tmp/_chat_resp_$$.json

    # Renew token on 401 (IAS tokens expire after ~1h) and retry once
    if [ "$CHAT_HTTP_CODE" = "401" ]; then
      echo -e "${YELLOW}Token expired, renewing...${NC}"
      TOKEN=$(get_token)
      CHAT_HTTP_CODE=$(curl -s -o /tmp/_chat_resp_$$.json -w "%{http_code}" -X POST "${AGENT_BASE_URL}/" \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d "$PAYLOAD")
      RESPONSE=$(cat /tmp/_chat_resp_$$.json 2>/dev/null || echo "{}")
      rm -f /tmp/_chat_resp_$$.json
    fi

    NEW_CONTEXT=$(echo "$RESPONSE" | jq -r '.result.contextId // empty' 2>/dev/null)
    if [ -n "$NEW_CONTEXT" ]; then
      CONTEXT_ID="$NEW_CONTEXT"
    fi

    AGENT_TEXT=$(echo "$RESPONSE" | jq -r '.result.artifacts[0].parts[0].text // empty' 2>/dev/null)
    if [ -n "$AGENT_TEXT" ]; then
      echo ""
      echo -e "${BLUE}Agent:${NC} $AGENT_TEXT"
      echo ""
    else
      ERROR=$(echo "$RESPONSE" | jq -r '.error.message // "Unknown error"' 2>/dev/null)
      echo -e "${RED}Error: $ERROR${NC}"
      echo ""
    fi
  done
}

# ===========================================
# Main
# ===========================================

main() {
  load_credentials
  validate_credentials

  COMMAND="${1:-message}"

  case "$COMMAND" in
    card)    cmd_card ;;
    health)  cmd_health ;;
    info)    cmd_info ;;
    chat)    cmd_chat ;;
    message|*)
      if [ "$COMMAND" = "message" ]; then
        cmd_message "$2" "$3"
      else
        cmd_message "$1" "$2"
      fi
      ;;
  esac
}

main "$@"
