---
name: sap-agent-project-structure
description: Understand and create the correct Application Foundation project structure for deploying applications to SAP BTP. Use when the user needs to adapt an existing application, create a new project structure, or understand the required files for Application Foundation deployment.
---

# Application Foundation Project Structure

This skill explains the correct project structure for deploying applications to Application Foundation, SAP's managed runtime solution that deploys to SAP BTP Kyma (Kubernetes-based).

## Required Project Structure

Every Application Foundation project must have this structure:

```
my-project/
├── .github/
│   └── workflows/
│       └── dev-ci-cd.yml       # CI/CD pipeline (Required)
├── Dockerfile                   # Container build (Required)
├── app.yaml                     # App Foundation config (Required)
├── app/                         # Your application code
│   └── ...
├── go.mod / package.json / requirements.txt  # Dependencies
└── README.md                    # Documentation
```

## Required Files Overview

### 1. Dockerfile (Required)

Location: Project root (same directory as `app.yaml`)

Your application must be containerized using SAP's base images with multi-stage builds.

**Key Requirements:**
- Use SAP base images from `docker-hub.common.cdn.repositories.cloud.sap`
- EXPOSE port must match `spec.container.port` in app.yaml
- Use multi-stage builds for smaller, secure images

See [Dockerfile Templates](references/dockerfile-templates.md) for language-specific examples (Go, Node.js, Python, Java).

### 2. app.yaml (Required)

Location: Project root

The core configuration for Application Foundation deployments.

**Key Fields:**

| Field | Description |
|-------|-------------|
| `metadata.name` | Unique app name (lowercase, hyphens only) |
| `spec.container.buildPath` | Path to Dockerfile directory |
| `spec.container.port` | Port your app listens on |
| `spec.service.apiAuth` | Authentication configuration |
| `spec.requires` | External services to provision |
| `spec.deployTo` | Target deployment environment |

See [app.yaml Templates](references/app-yaml-templates.md) for WebService, CronJob, and configuration examples.

### 3. CI/CD Workflow (Required)

Location: `.github/workflows/dev-ci-cd.yml`

GitHub Actions workflow for automated builds and deployments.

See [CI/CD Workflow Template](references/ci-cd-workflow.md) for the complete workflow file and setup instructions.

## Step-by-Step Adoption Process

### Step 1: Dockerize Your Application

```bash
# Create Dockerfile (see references/dockerfile-templates.md for your language)
touch Dockerfile

# Test build locally
docker build -t myapp:test .

# Test run locally
docker run -p 8080:8080 myapp:test

# Verify with curl
curl http://localhost:8080
```

### Step 2: Create app.yaml

```bash
# Create in project root
touch app.yaml
```

Choose a unique `metadata.name`:
- Use lowercase letters and hyphens only
- Be descriptive: `user-service`, `payment-api`
- Include team/project: `teamalpha-user-api`

### Step 3: Configure CI/CD

```bash
# Create workflow directory
mkdir -p .github/workflows

# Create workflow file (see references/ci-cd-workflow.md)
```

### Step 4: Test and Deploy

```bash
# Create feature branch
git checkout -b feature/appfnd-adoption

# Stage files
git add Dockerfile app.yaml .github/workflows/dev-ci-cd.yml

# Commit
git commit -m "Add Application Foundation configuration"

# Push
git push origin feature/appfnd-adoption

# Create PR via GitHub UI
```

## Complete Examples

See [Go WebService Example](references/example-go-webservice.md) for a complete working project.

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Workflow not triggering | Ensure file is at `.github/workflows/dev-ci-cd.yml` |
| "Dockerfile not found" | Verify `spec.container.buildPath` in app.yaml |
| "Name conflict" | Choose unique `metadata.name` |
| App not accessible | Ensure Dockerfile EXPOSE matches `spec.container.port` |
| Port mismatch | Ensure port consistency across Dockerfile and app.yaml |

## Deployment Verification

After successful workflow, find your URL in the GitHub Actions logs:

```
https://{metadata.name}.{cluster-id}.stage.kyma.ondemand.com
```

## Pre-Deployment Checklist

- ✅ Dockerfile exists in project root
- ✅ Dockerfile uses SAP base images
- ✅ EXPOSE port matches app.yaml port
- ✅ app.yaml has unique `metadata.name`
- ✅ CI/CD workflow file exists at `.github/workflows/dev-ci-cd.yml`
- ✅ Local Docker build and run works
