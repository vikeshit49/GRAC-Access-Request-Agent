# Dockerfile Templates

This document contains Dockerfile templates for different programming languages, following Application Foundation best practices.

## Key Requirements

- Use SAP base images from `docker-hub.common.cdn.repositories.cloud.sap`
- EXPOSE port must match `spec.container.port` in app.yaml
- Use multi-stage builds for smaller, secure images

---

## Go Application

```dockerfile
# Stage 1: Build
FROM docker-hub.common.cdn.repositories.cloud.sap/golang:1.24-alpine AS builder
WORKDIR /app
COPY . .
RUN CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -mod vendor -a -o myapp ./app

# Stage 2: Runtime
FROM docker-hub.common.cdn.repositories.cloud.sap/alpine:3.22.0
WORKDIR /
COPY --from=builder /app/myapp .
EXPOSE 8080
CMD ["/myapp"]
```

---

## Node.js Application

```dockerfile
# Stage 1: Build
FROM docker-hub.common.cdn.repositories.cloud.sap/node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

# Stage 2: Runtime
FROM docker-hub.common.cdn.repositories.cloud.sap/node:20-alpine
WORKDIR /app
COPY --from=builder /app/node_modules ./node_modules
COPY . .
EXPOSE 8080
CMD ["node", "server.js"]
```

---

## Python Application

```dockerfile
# Stage 1: Build
FROM docker-hub.common.cdn.repositories.cloud.sap/python:3.11-slim AS builder

WORKDIR /app
COPY requirements.txt .
ENV PIP_INDEX_URL=https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple
RUN pip install --no-cache-dir --user -r requirements.txt

# Stage 2: Runtime
FROM docker-hub.common.cdn.repositories.cloud.sap/python:3.11-slim
WORKDIR /app
COPY --from=builder /root/.local /root/.local
COPY . .
ENV PATH=/root/.local/bin:$PATH
EXPOSE 8080
CMD ["python", "app.py"]
```

---

## Java Application (Maven)

```dockerfile
# Stage 1: Build
FROM docker-hub.common.cdn.repositories.cloud.sap/maven:3.9-eclipse-temurin-21 AS builder
WORKDIR /app
COPY pom.xml .
COPY src ./src
RUN mvn clean package -DskipTests

# Stage 2: Runtime
FROM docker-hub.common.cdn.repositories.cloud.sap/eclipse-temurin:21-jre-alpine
WORKDIR /app
COPY --from=builder /app/target/*.jar app.jar
EXPOSE 8080
CMD ["java", "-jar", "app.jar"]
```
