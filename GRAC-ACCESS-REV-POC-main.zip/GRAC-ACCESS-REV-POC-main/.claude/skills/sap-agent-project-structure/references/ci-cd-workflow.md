# CI/CD Workflow Template

This document contains the GitHub Actions workflow template for Application Foundation deployments.

---

## Development CI/CD Workflow

Location: `.github/workflows/dev-ci-cd.yml`

```yaml
name: App Foundation CD deploy to CONHOS
on:
  workflow_dispatch:
  pull_request:
  push:
    branches:
      - "main"

jobs:
  deploy-conhos:
    uses: application-foundation/ci-cd-workflow/.github/workflows/deploy-conhos.yml@main
    secrets: inherit
    permissions:
      contents: write
      id-token: write
```

---

## What This Workflow Does

| Stage | Description |
|-------|-------------|
| `load-app` | Loads your application configuration from app.yaml |
| `build-image` | Builds the container image using your Dockerfile |
| `deploy-dev` | Deploys to the development environment |

---

## Trigger Events

| Event | When |
|-------|------|
| `workflow_dispatch` | Manual trigger via GitHub Actions UI |
| `pull_request` | When a PR is created or updated |
| `push` to `main` | When code is merged to main branch |

---

## Setup Instructions

1. Create the workflow directory:
   ```bash
   mkdir -p .github/workflows
   ```

2. Create the workflow file:
   ```bash
   cat > .github/workflows/dev-ci-cd.yml << 'EOF'
   name: App Foundation CD deploy to CONHOS
   on:
     workflow_dispatch:
     pull_request:
     push:
       branches:
         - "main"

   jobs:
     deploy-conhos:
       uses: application-foundation/ci-cd-workflow/.github/workflows/deploy-conhos.yml@main
       secrets: inherit
       permissions:
         contents: write
         id-token: write
   EOF
   ```

---

## Finding Your Deployment URL

After successful deployment:

1. Go to your repository on GitHub
2. Click the **Actions** tab
3. Select the latest successful workflow run
4. Expand the **deploy-dev** job
5. Find the endpoint URL in the last lines of the deployment logs

**URL format:**
```
https://{metadata-name-from-app-yaml}.{cluster-id}.stage.kyma.ondemand.com
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Workflow not triggering | Ensure file is at `.github/workflows/dev-ci-cd.yml` |
| Build fails: "Dockerfile not found" | Verify `spec.container.buildPath` in app.yaml |
| Build fails: "Permission denied" | Contact platform team to verify GitHub App installation |
| Deployment fails: "Name conflict" | Choose a unique `metadata.name` in app.yaml |
