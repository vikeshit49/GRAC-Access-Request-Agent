# app.yaml Templates

This document contains app.yaml configuration templates for Application Foundation deployments.

---

## WebService (Basic)

For APIs and web applications:

```yaml
apiVersion: workload.appfnd.sap/v1
kind: WebService
metadata:
  name: my-awesome-api          # Unique name, becomes part of URL
spec:
  container:
    buildPath: .                # Directory containing Dockerfile
    port: 8080                  # Port your app listens on
  service:
    apiAuth:
      path: /*
      type: jwt                 # jwt, no_auth, or oauth
  deployTo: dev-*               # Target environment
```

---

## WebService (With External Services)

For applications that need Object Storage, Audit Log, Destination, etc.:

```yaml
apiVersion: workload.appfnd.sap/v1
kind: WebService
metadata:
  name: my-service-with-storage
spec:
  container:
    buildPath: .
    port: 8080
  service:
    apiAuth:
      path: /*
      type: jwt
  requires:
    # Audit Log Service - SDK assumes instance name "default"
    - name: default
      service: auditlog
      plan: oauth2
    # Destination Service
    - name: my-destination
      service: destination
      plan: lite
    # Object Store Service
    - name: my-object-store
      service: objectstore
      plan: standard
  deployTo: dev-*
```

**Note:** The `requires` section has three fields:
- `name`: Instance name that will be created (must match the instance name used in your code)
- `service`: The service type (objectstore, auditlog, destination, etc.)
- `plan`: The service plan to use

---

## WebService (With Environment Variables)

```yaml
apiVersion: workload.appfnd.sap/v1
kind: WebService
metadata:
  name: my-configured-service
spec:
  container:
    buildPath: .
    port: 8080
    env:
      - name: LOG_LEVEL
        value: info
      - name: FEATURE_FLAG
        value: "true"
  service:
    apiAuth:
      path: /*
      type: jwt
  deployTo: dev-*
```

---

## WebService (Public API - No Auth)

```yaml
apiVersion: workload.appfnd.sap/v1
kind: WebService
metadata:
  name: my-public-api
spec:
  container:
    buildPath: .
    port: 8080
  service:
    apiAuth:
      path: /*
      type: no_auth             # No authentication required
  deployTo: dev-*
```

---

## CronJob (Scheduled Tasks)

For batch jobs, scheduled tasks, or periodic data processing:

```yaml
apiVersion: workload.appfnd.sap/v1
kind: Cronjob
metadata:
  name: data-sync-job
spec:
  schedule: "0 2 * * *"         # Cron expression (daily at 2 AM)
  restartPolicy: OnFailure      # OnFailure or Never
  container:
    buildPath: .
    port: 8080
  deployTo: dev-*
```

---

## CronJob (With External Services)

```yaml
apiVersion: workload.appfnd.sap/v1
kind: Cronjob
metadata:
  name: data-export-job
spec:
  schedule: "0 0 * * 0"         # Weekly on Sunday at midnight
  restartPolicy: OnFailure
  container:
    buildPath: .
    port: 8080
  requires:
    - name: my-object-store
      service: objectstore
      plan: standard
  deployTo: dev-*
```

---

## Key Fields Reference

| Field | Description |
|-------|-------------|
| `metadata.name` | Unique app name (lowercase, hyphens only). Becomes part of URL. |
| `spec.container.buildPath` | Path to directory containing Dockerfile |
| `spec.container.port` | Port your application listens on |
| `spec.container.env` | Environment variables for the container |
| `spec.service.apiAuth.type` | Authentication: `jwt`, `no_auth`, or `oauth` |
| `spec.requires` | External services to provision and bind (each with name, service, plan) |
| `spec.deployTo` | Target deployment environment (e.g., `dev-*`) |
| `spec.schedule` | Cron expression (CronJob only) |
| `spec.restartPolicy` | `OnFailure` or `Never` (CronJob only) |

---

## Cron Expression Examples

| Expression | Description |
|------------|-------------|
| `0 2 * * *` | Daily at 2:00 AM |
| `0 0 * * 0` | Weekly on Sunday at midnight |
| `0 */6 * * *` | Every 6 hours |
| `0 0 1 * *` | Monthly on the 1st at midnight |
| `*/15 * * * *` | Every 15 minutes |
