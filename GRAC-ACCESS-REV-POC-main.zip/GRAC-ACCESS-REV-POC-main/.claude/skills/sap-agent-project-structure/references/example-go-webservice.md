# Go WebService Example

A complete example of a Go webservice project structure for Application Foundation.

---

## Project Structure

```
my-webservice/
├── .github/
│   └── workflows/
│       └── dev-ci-cd.yml
├── Dockerfile
├── app/
│   ├── main.go
│   └── handlers/
│       └── health.go
├── go.mod
├── go.sum
└── app.yaml
```

---

## Dockerfile

```dockerfile
# Stage 1: Build the Go binary
FROM docker-hub.common.cdn.repositories.cloud.sap/golang:1.24-alpine AS builder

WORKDIR /app
COPY . .
RUN CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -mod vendor -a -o webservice ./app

# Stage 2: Create minimal runtime image
FROM docker-hub.common.cdn.repositories.cloud.sap/alpine:3.22.0

WORKDIR /
COPY --from=builder /app/webservice .
EXPOSE 8080
CMD ["/webservice"]
```

---

## app.yaml

```yaml
apiVersion: workload.appfnd.sap/v1
kind: WebService
metadata:
  name: my-webservice
spec:
  container:
    buildPath: .
    port: 8080
  service:
    apiAuth:
      path: /*
      type: jwt
  deployTo: dev-*
```

---

## app/main.go

```go
package main

import (
    "my-webservice/app/handlers"
    "github.com/gin-gonic/gin"
)

func main() {
    r := gin.Default()
    r.GET("/health", handlers.HealthHandler)
    r.GET("/healthz", handlers.HealthHandler)
    r.Run() // listens on :8080
}
```

---

## app/handlers/health.go

```go
package handlers

import (
    "net/http"
    "github.com/gin-gonic/gin"
)

func HealthHandler(c *gin.Context) {
    c.JSON(http.StatusOK, gin.H{
        "status":  "healthy",
        "service": "my-webservice",
    })
}
```

---

## go.mod

```go
module my-webservice

go 1.24

require github.com/gin-gonic/gin v1.9.1
```

---

## .github/workflows/dev-ci-cd.yml

```yaml
name: App Foundation CD deploy to CONHOS
on:
  workflow_dispatch:
  pull_request:
  push:
    branches:
      - "main"

jobs:
  deploy-conhos:
    uses: application-foundation/ci-cd-workflow/.github/workflows/deploy-conhos.yml@main
    secrets: inherit
    permissions:
      contents: write
      id-token: write
```

---

## Testing After Deployment

```bash
# Health check (requires JWT token)
curl -H "Authorization: Bearer <access_token>" \
  https://my-webservice.{cluster-id}.stage.kyma.ondemand.com/health

# Expected response:
# {
#   "status": "healthy",
#   "service": "my-webservice"
# }
```
