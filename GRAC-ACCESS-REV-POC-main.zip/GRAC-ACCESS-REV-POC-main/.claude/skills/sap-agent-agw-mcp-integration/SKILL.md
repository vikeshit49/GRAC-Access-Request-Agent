---
name: sap-agent-agw-mcp-integration
description: Integrate an App Foundation agent with MCP Servers via Agent Gateway. Use when the user wants to connect their agent to MCP Servers. For MCP Servers created on MCP Builder, it optionally adds a local testing setup. 
---

# MCP Server Integration via Agent Gateway

> **IMPORTANT FOR CODING AGENTS:** This skill has conditional steps. You MUST ask the user whether their MCP Servers were created on MCP Builder BEFORE starting. See "Determining Whether Local Mode Applies" below. Do NOT add local mode files without confirmation.

This skill adds MCP Server integration to an App Foundation agent using the **Agent Gateway** module (`sap_cloud_sdk.agentgateway` — part of Cloud SDK).

> **Note:** This skill is tailored for agents built with **LangGraph/LangChain**. For **PydanticAI** agents, the `get_mcp_tools()` functions from `mcp_providers` return LangChain tools — you can either convert them using [`tool_from_langchain`](https://pydantic.dev/docs/ai/api/pydantic-ai/ext/#pydantic_ai.ext.langchain.tool_from_langchain), or rewrite the provider modules to use PydanticAI-native tooling directly.

**Local testing mode** (optional) is available when the MCP Servers were created on **MCP Builder**. It bypasses the Agent Gateway and connects directly to MCP Builder via the Destination Service, allowing you to locally test your agent and validate that it works correctly with the MCP Servers before deployment. If the MCP Servers were NOT created on MCP Builder, local mode does not apply — skip all steps marked with **(LOCAL MODE ONLY)**.

## Prerequisites

### Code Prerequisites

- **Existing App Foundation agent project** with `agent_executor.py`, `agent.py`, and a working `main.py` entrypoint

### Setup Prerequisites

These are required **before running the agent locally**. The skill generates code but does not create BTP subscriptions, service instances, or destinations.

**Required for local testing with MCP Builder** (LOCAL MODE ONLY):

- **MCP Builder subscription** — your subaccount needs access to MCP Builder
- **MCP_HUB destination** — a destination pointing to MCP Builder's MCP Service
- **MCP Server ID(s)** — found in the MCP Builder UI under server details
- **Destination Service instance** — required for MCP Builder connectivity when running locally
- **AI Core instance** — required for LLM access

> For detailed setup instructions, see the [System Integration documentation](https://pages.github.tools.sap/application-foundation/agent-runtime-domains/integration/system).

## Overview

The skill always creates the **Agent Gateway provider** (`mcp_providers/agw.py`). If the user's MCP Servers are on MCP Builder, it also creates a **local provider** (`mcp_providers/local.py`) for testing without the Agent Gateway.

| Mode | Provider | How it works |
|------|----------|--------------|
| **Deployed** (always) | `mcp_providers/agw.py` | Agent Gateway module → token exchange → MCP tools |
| **Local** (MCP Builder only) | `mcp_providers/local.py` | Destination Service → MCP Builder → direct MCP connection |

When local mode is enabled, the presence of `LOCAL_MCP_SERVERS` env var switches between them at import time.

```text
┌─────────────────────────────────────────────────────────────────────┐
│                        agent_executor.py                             │
│                                                                     │
│  LOCAL_MCP_SERVERS set        │  LOCAL_MCP_SERVERS unset (default)  │
│  ┌────────────────────┐       │  ┌────────────────────┐            │
│  │ mcp_providers/     │       │  │ mcp_providers/     │            │
│  │   local.py         │       │  │   agw.py           │            │
│  └────────┬───────────┘       │  └────────┬───────────┘            │
│            │                  │            │                        │
│            ▼                  │            ▼                        │
│  ┌────────────────────┐       │  ┌────────────────────┐            │
│  │ Destination Svc    │       │  │ Agent Gateway     │            │
│  │ → MCP Builder      │       │  │ → Token Exchange   │            │
│  └────────────────────┘       │  └────────────────────┘            │
└─────────────────────────────────────────────────────────────────────┘
```

## Determining Whether Local Mode Applies

> **⛔ STOP — YOU MUST ASK THE USER BEFORE PROCEEDING ⛔**
>
> Before executing ANY steps below, ask the user:
>
> _"Were your MCP Servers created using MCP Builder (SAP's MCP Builder UI)? This determines whether local testing mode can be enabled."_
>
> - If the user answers **YES** → include all steps marked **(LOCAL MODE ONLY)**
> - If the user answers **NO**, is **unsure**, or does **not respond** → **SKIP all steps marked (LOCAL MODE ONLY)**
>
> **DO NOT assume local mode applies. DO NOT skip this question. The local provider ONLY works with MCP Servers created on MCP Builder.**

---

## Step 1: Add Dependencies to requirements.txt

Add these dependencies to `./requirements.txt` (project root). Use the existing virtual environment — do **not** create a new one.

```text
sap-cloud-sdk==0.25.0
langchain-mcp-adapters==0.2.2
```

> **⚠️ `langgraph` version:** Do NOT use `langgraph==1.0.10` — `langgraph==1.0.10` seems to have a mismatch issue with `langgraph-prebuilt=1.0.10` - `langgraph-prebuilt` 1.0.10 tries to import `ExecutionInfo` and `ServerInfo` from `langgraph.runtime`, but these don't exist in `langgraph` 1.0.10's runtime module. Use both `langgraph` and `langgraph-prebuilt` to `==1.0.6`.

See `references/requirements.txt` for a complete known-good set of pinned dependencies.

Then install in the existing virtual environment:
```bash
pip install -r requirements.txt
```

## Step 2: Create app/mcp_providers/ folder

Create the `app/mcp_providers/` folder.

**Run the setup script:**
```bash
bash "$(find . -type d -name sap-agent-agw-mcp-integration -path '*/skills/*' | head -1)/scripts/setup_agw_mode.sh"
```

The script above copies the AGW provider and middleware templates. It creates:

**`agw.py`** (uses the Agent Gateway module):
- Reads tenant subdomain and user token from request context (set by middleware)
- Creates an Agent Gateway client for the tenant
- Discovers MCP tools and converts them to LangChain format

**(LOCAL MODE ONLY)** Also run the local mode setup:
```bash
bash "$(find . -type d -name sap-agent-agw-mcp-integration -path '*/skills/*' | head -1)/scripts/setup_local_mode.sh"
```

The script above copies the local provider and test file. It creates:

**`local.py`** (connects directly to MCP Builder):
- Uses `sap_cloud_sdk.destination` to resolve `MCP_HUB` at the **subaccount** level (`ConsumptionLevel.SUBACCOUNT`)
- Reads MCP Server IDs from `LOCAL_MCP_SERVERS` env var (comma-separated `id:name` pairs)
- Resolves each server's URL via BTP Destination Service
- Connects via `MultiServerMCPClient` with streamable HTTP transport

## Step 3: Modify app/agent_executor.py

**Add** at the top of `agent_executor.py` (after other imports):

**(LOCAL MODE ONLY)** — If local mode applies, use the conditional import:

```python
import os

LOCAL_MCP_SERVERS = os.environ.get("LOCAL_MCP_SERVERS", "").strip()

if LOCAL_MCP_SERVERS:
    from mcp_providers.local import get_mcp_tools
else:
    from mcp_providers.agw import get_mcp_tools
```

**Without local mode** — If local mode does NOT apply, just import AGW directly:

```python
from mcp_providers.agw import get_mcp_tools
```

**Modify** the `execute()` method to fetch tools before calling the agent.

> **Note:** The code below is a guide showing the key changes needed. Read the existing `execute()` method first and integrate the MCP tool-fetching logic into it — do not overwrite the entire method blindly.

```python
async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
    query = context.get_user_input()
    task = context.current_task
    if not task:
        task = new_task(context.message)
        await event_queue.enqueue_event(task)

    # Fetch MCP tools from Agent Gateway or local MCP Builder
    tools = None
    try:
        tools = await get_mcp_tools()
        logger.info(f"Loaded {len(tools)} MCP tool(s)")
        tools = tools or None
    except Exception as e:
        logger.warning(f"Failed to load MCP tools: {e}. Continuing without tools.")

    updater = TaskUpdater(event_queue, task.id, task.context_id)
    try:
        async for item in self.agent.stream(query, task.context_id, tools=tools or None):
            if not item["is_task_complete"] and not item["require_user_input"]:
                await updater.update_status(
                    TaskState.working,
                    new_agent_text_message(item["content"], task.context_id, task.id),
                )
            elif item["require_user_input"]:
                await updater.update_status(
                    TaskState.input_required,
                    new_agent_text_message(item["content"], task.context_id, task.id),
                    final=True,
                )
                break
            else:
                await updater.add_artifact(
                    [Part(root=TextPart(text=item["content"]))], name="agent_result"
                )
                await updater.complete()
                break
    except Exception as e:
        logger.exception("Agent execution error")
        raise ServerError(error=InternalError()) from e
```

## Step 4: Modify app/agent.py to Accept Tools

The agent must accept a `tools` parameter. **Add** `_build_graph_with_tools` and modify `stream()`/`invoke()`.

> **Note:** The code below is a guide showing the pattern. Read the existing `agent.py` first and adapt it — preserve any custom logic, additional methods, or agent-specific behavior already present.

```python
from typing import Sequence
from langchain_core.tools import BaseTool
from langgraph.graph import END
from langgraph.prebuilt import ToolNode

class SampleAgent:
    ...

    def _build_graph_with_tools(self, tools: Sequence[BaseTool]):
        llm_with_tools = self.llm.bind_tools(tools)

        async def call_model(state: MessagesState):
            response = await llm_with_tools.ainvoke(state["messages"])
            return {"messages": [response]}

        def should_continue(state: MessagesState):
            return "tools" if state["messages"][-1].tool_calls else END

        builder = StateGraph(MessagesState)
        builder.add_node("model", call_model)
        builder.add_node("tools", ToolNode(list(tools), handle_tool_errors=True))
        builder.add_edge(START, "model")
        builder.add_conditional_edges("model", should_continue)
        builder.add_edge("tools", "model")
        return builder.compile()

    async def stream(
        self,
        query: str,
        _context_id: str,
        tools: Sequence[BaseTool] | None = None,
    ) -> AsyncGenerator[dict, None]:
        yield {"is_task_complete": False, "require_user_input": False, "content": "Processing..."}
        try:
            graph = self._build_graph_with_tools(tools) if tools else self.graph
            messages = [SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=query)]
            result = await graph.ainvoke({"messages": messages})
            response = result["messages"][-1].content
            yield {"is_task_complete": True, "require_user_input": False, "content": response}
        except Exception as e:
            logger.exception("Agent stream error")
            yield {"is_task_complete": True, "require_user_input": False, "content": f"Error: {e}"}
```

See `references/agent_example.md` for the complete modified `agent.py`.

## Step 5: Create Middleware (Request Context + Logging)

The Agent Gateway module needs the tenant subdomain and user token from request headers. Create the middleware package if it doesn't exist:

The `setup_agw_mode.sh` script (run in Step 2) already copies the middleware templates. If you skipped it, run it now:
```bash
bash "$(find . -type d -name sap-agent-agw-mcp-integration -path '*/skills/*' | head -1)/scripts/setup_agw_mode.sh"
```

**`request_context.py`** extracts:
- `dwc-subdomain` header → `tenant_subdomain_var`
- `authorization` Bearer token → `authorization_var`

**`request_logging.py`** logs all incoming headers (redacts sensitive ones).

Then **register both middleware** in `app/main.py` (after building the app):
```python
from middleware.request_context import RequestContextMiddleware
from middleware.request_logging import RequestLoggingMiddleware

# Add after building the Starlette app:
app.add_middleware(RequestLoggingMiddleware)
app.add_middleware(RequestContextMiddleware)
```

> **Note:** Middleware executes in reverse registration order. Before adding these, check if `main.py` already has other middleware registered. If it does, analyze the existing middleware stack to determine the correct placement — `RequestContextMiddleware` should run before any middleware that depends on tenant or auth context, and `RequestLoggingMiddleware` should run early enough to log incoming requests.

## Step 6: Add Environment Variables to app/.env.local (LOCAL MODE ONLY)

> **Skip this step** if the MCP Servers are NOT on MCP Builder.

**Add** the MCP server list and Destination Service credentials (SAP Cloud SDK format):

```ini
# MCP Servers to connect to (comma-separated id:name pairs)
# If set, enables local mode — agent connects directly to MCP Builder instead of Agent Gateway
# Get IDs from MCP Builder UI → select server → copy ID from URL or details panel
LOCAL_MCP_SERVERS=<your-mcp-server-id>:<your-server-name>

# Destination Service credentials (SAP Cloud SDK format — used by sap_cloud_sdk.destination)
CLOUD_SDK_CFG_DESTINATION_DEFAULT_CLIENTID='<from-destination-service-key: clientid>'
CLOUD_SDK_CFG_DESTINATION_DEFAULT_CLIENTSECRET='<from-destination-service-key: clientsecret>'
CLOUD_SDK_CFG_DESTINATION_DEFAULT_URL=<from-destination-service-key: url>
CLOUD_SDK_CFG_DESTINATION_DEFAULT_URI=<from-destination-service-key: uri>
CLOUD_SDK_CFG_DESTINATION_DEFAULT_IDENTITYZONE=<from-destination-service-key: identityzone>

# AI Core credentials (already required by the agent — ensure they are present)
AICORE_CLIENT_ID='<from-aicore-service-key>'
AICORE_CLIENT_SECRET='<from-aicore-service-key>'
AICORE_AUTH_URL=<from-aicore-service-key>
AICORE_BASE_URL=<from-aicore-service-key>
AICORE_RESOURCE_GROUP=<your-resource-group>
```

> **Quoting:** Values containing special characters (`!`, `|`, `$`) **must** be wrapped in single quotes to prevent zsh from interpreting them (e.g., `AICORE_CLIENT_ID='sb-xxx!b123|xsuaa_std!b9'`).

> **`LOCAL_MCP_SERVERS` format:** Comma-separated `id:name` pairs with no spaces. Examples:
> - Single server: `LOCAL_MCP_SERVERS=8c7c4cab-f032-460c-8041-71863b3950a9:Northwind`
> - Multiple servers: `LOCAL_MCP_SERVERS=server-id-1:Northwind,server-id-2:Products`
> - Name is optional (auto-generated if omitted): `LOCAL_MCP_SERVERS=8c7c4cab-f032-460c-8041-71863b3950a9`

## Step 7: Create `test_agent.http` for Local Testing (LOCAL MODE ONLY)

> **Skip this step** if the MCP Servers are NOT on MCP Builder.

**Copy the template** to the project root (already done if you ran `setup_local_mode.sh` in Step 2):

```bash
SKILL_PATH=$(find . -type d -name sap-agent-agw-mcp-integration -path '*/skills/*' | head -1)
cp "$SKILL_PATH/templates/test_agent.http" test_agent.http
```

This file contains pre-built HTTP requests to test the agent locally — one to list all available tools and one to query MCP Server functionality.

> **Requires the [REST Client](https://marketplace.visualstudio.com/items?itemName=humao.rest-client) VS Code extension.** Click "Send Request" above each `###` block to invoke the agent directly from the editor.

## Step 8: Add Skill Disclaimer to README

**Add** a note to the project's `README.md` so that future developers or coding agents know this skill was applied.

> **Important:** This skill introduces new environment variables in `app/.env.local` (such as `LOCAL_MCP_SERVERS`, `CLOUD_SDK_CFG_DESTINATION_DEFAULT_*`) — besides any already required by the agent (e.g. `AICORE_*`) — that must be loaded when running the agent locally, regardless of which skill or method is used to start it. Any local run command must ensure these variables are present in the environment.

**If local mode was enabled:**
```markdown
> This agent uses the `sap-agent-agw-mcp-integration` skill for MCP Server integration via the Agent Gateway module, with local testing support against MCP Builder.
```

**If local mode was NOT enabled:**
```markdown
> This agent uses the `sap-agent-agw-mcp-integration` skill for MCP Server integration via the Agent Gateway module.
```

## Step 9: Run and Test Locally (LOCAL MODE ONLY)

> **Skip this step** if the MCP Servers are NOT on MCP Builder. Without local mode, the agent can only be tested after deployment.

## Files Added/Modified by This Skill

```text
my-agent/
├── requirements.txt      # MODIFIED: Added MCP dependencies
├── test_agent.http       # NEW: REST Client test requests (LOCAL MODE ONLY)
└── app/
    ├── .env.local        # MODIFIED: Added LOCAL_MCP_SERVERS, CLOUD_SDK_CFG_DESTINATION_DEFAULT_* (LOCAL MODE ONLY)
    ├── agent_executor.py # MODIFIED: Tool fetching in execute() (+ LOCAL_MCP_SERVERS dispatch if local mode)
    ├── agent.py          # MODIFIED: Accept tools parameter, tool-enabled graph
    ├── main.py           # MODIFIED: Registered middleware
    ├── mcp_providers/
    │   ├── __init__.py   # NEW: Package init
    │   ├── agw.py        # NEW: Agent Gateway provider (deployed)
    │   └── local.py      # NEW: Local MCP Builder provider (LOCAL MODE ONLY)
    └── middleware/
        ├── __init__.py       # NEW (if missing)
        ├── request_context.py  # NEW: Context vars for tenant + token
        └── request_logging.py  # NEW: Header logging for debugging
```

## How It Works at Runtime

Both modes produce the same behavior — the agent discovers and invokes the same MCP tools in the same way. The local provider simply allows testing the integration locally before deployment, without requiring the Agent Gateway and formation setup.

### Deployed Mode (default)
1. Request arrives with JWT → middleware extracts tenant subdomain and user token into contextvars
2. `AgentExecutor.execute()` calls `get_mcp_tools()` from `mcp_providers.agw`
3. The Agent Gateway module discovers and connects to MCP tools based on the existing formation (which defines the MCP Servers available to the agent)
4. Tools are converted to LangChain format and passed to `agent.stream()`
5. Agent uses tools during conversation via `call_mcp_tool`

### Local Mode (LOCAL_MCP_SERVERS set) — MCP Builder only
1. `AgentExecutor.execute()` calls `get_mcp_tools()` from `mcp_providers.local`
2. Connects directly to MCP Builder via BTP Destination Service, bypassing the Agent Gateway
3. MCP Server URLs resolved via Destination Service using the `MCP_HUB` destination
4. Direct streamable HTTP connection to MCP Builder servers listed in `LOCAL_MCP_SERVERS`
5. Tools returned to the agent in the same LangChain format as deployed mode

> **Note:** Local mode only works when MCP Servers were created on MCP Builder. If your MCP Servers are third-party or external, local mode is not applicable — the agent can only be tested after deployment through Agent Gateway.

## Troubleshooting

For troubleshooting, load `references/troubleshooting.md`.

## Reference Files

```
sap-agent-agw-mcp-integration/
├── SKILL.md (this file)
├── references/
│   ├── agent_executor_example.md  - Complete agent_executor.py after this skill
│   ├── agent_example.md           - Complete agent.py after this skill
│   ├── requirements.txt           - Known-good pinned dependencies
│   └── troubleshooting.md         - Common errors and fixes
├── scripts/
│   ├── setup_agw_mode.sh            - Sets up AGW provider + middleware
│   └── setup_local_mode.sh        - Sets up local provider + test file (LOCAL MODE ONLY)
└── templates/
    ├── agw.py                     - AGW tool provider (copy to app/mcp_providers/)
    ├── local.py                   - Local tool provider (copy to app/mcp_providers/)
    ├── request_context.py         - Request context middleware
    ├── request_logging.py         - Request logging middleware
    └── test_agent.http            - REST Client test file (copy to project root)
```
