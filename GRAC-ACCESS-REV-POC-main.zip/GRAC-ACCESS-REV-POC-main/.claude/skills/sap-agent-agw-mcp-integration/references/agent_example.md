# Complete agent.py Example

This is the complete `agent.py` with support for dynamically-provided MCP tools.

```python
import logging
from dataclasses import dataclass
from typing import AsyncGenerator, Literal, Sequence

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.tools import BaseTool
from langchain_litellm import ChatLiteLLM
from langgraph.graph import END, START, MessagesState, StateGraph
from langgraph.prebuilt import ToolNode

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are Agent to test the onboarding flow. Help users with their requests."""


@dataclass
class AgentResponse:
    status: Literal["input_required", "completed", "error"]
    message: str


class SampleAgent:
    SUPPORTED_CONTENT_TYPES = ["text", "text/plain"]

    def __init__(self):
        self.llm = ChatLiteLLM(model="sap/anthropic--claude-4.5-sonnet")
        self.graph = self._build_graph()

    def _build_graph(self):
        async def call_model(state: MessagesState):
            response = await self.llm.ainvoke(state["messages"])
            return {"messages": [response]}

        builder = StateGraph(MessagesState)
        builder.add_node("model", call_model)
        builder.add_edge(START, "model")
        return builder.compile()

    def _build_graph_with_tools(self, tools: Sequence[BaseTool]):
        llm_with_tools = self.llm.bind_tools(tools)

        async def call_model(state: MessagesState):
            response = await llm_with_tools.ainvoke(state["messages"])
            return {"messages": [response]}

        def should_continue(state: MessagesState):
            return "tools" if state["messages"][-1].tool_calls else END

        builder = StateGraph(MessagesState)
        builder.add_node("model", call_model)
        builder.add_node("tools", ToolNode(list(tools), handle_tool_errors=True))
        builder.add_edge(START, "model")
        builder.add_conditional_edges("model", should_continue)
        builder.add_edge("tools", "model")
        return builder.compile()

    async def stream(
        self,
        query: str,
        _context_id: str,
        tools: Sequence[BaseTool] | None = None,
    ) -> AsyncGenerator[dict, None]:
        yield {"is_task_complete": False, "require_user_input": False, "content": "Processing..."}
        try:
            graph = self._build_graph_with_tools(tools) if tools else self.graph
            messages = [SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=query)]
            result = await graph.ainvoke({"messages": messages})
            response = result["messages"][-1].content
            yield {"is_task_complete": True, "require_user_input": False, "content": response}
        except Exception as e:
            logger.exception("Agent stream error")
            yield {"is_task_complete": True, "require_user_input": False, "content": f"Error: {e}"}

    def invoke(
        self,
        query: str,
        _context_id: str,
        tools: Sequence[BaseTool] | None = None,
    ) -> AgentResponse:
        import asyncio
        try:
            graph = self._build_graph_with_tools(tools) if tools else self.graph
            messages = [SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=query)]
            result = asyncio.run(graph.ainvoke({"messages": messages}))
            response = result["messages"][-1].content
            return AgentResponse(status="completed", message=response)
        except Exception as e:
            return AgentResponse(status="error", message=f"Error: {e}")
```

## Key Points

- `_build_graph_with_tools` uses `handle_tool_errors=True` to prevent tool failures from crashing the agent.
- `stream()` accepts an optional `tools` parameter — if tools are provided, it builds a tool-enabled graph; otherwise falls back to the basic graph.
- The agent itself is tool-source agnostic — it doesn't know whether tools come from Agent Gateway or local MCP.
```

## Key Changes from Base Agent

| Change | Description |
|--------|-------------|
| Import `BaseTool` | For type annotation of tools parameter |
| Import `END` from langgraph | For conditional edge routing |
| Import `ToolNode` | For tool execution node |
| `_build_graph_with_tools()` | New method that creates a graph with tool nodes |
| `stream()` signature | Added `tools: Sequence[BaseTool] \| None = None` parameter |
| `stream()` body | Selects graph based on whether tools are provided |
| `invoke()` signature | Added matching `tools` parameter |
| `invoke()` body | Selects graph based on whether tools are provided |

## Design Notes

- **Tools are per-request**: The executor passes tools on each call because available tools may differ per tenant via Agent Gateway
- **Graph is built per-request when tools are present**: This ensures the correct tools are bound to the LLM
- **Fallback graph**: The basic graph (no tools) is compiled once in `__init__` for efficiency when no MCP tools are available
- **No lazy initialization**: Unlike the local MCP Builder approach, tools come from the executor, not from internal initialization
