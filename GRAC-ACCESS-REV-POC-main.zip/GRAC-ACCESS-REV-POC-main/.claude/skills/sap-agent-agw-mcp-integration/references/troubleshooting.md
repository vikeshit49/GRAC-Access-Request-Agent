# Troubleshooting

## "Destination credentials not found" / "failed to load destination configuration" (Local — MCP Builder only)

Ensure all `CLOUD_SDK_CFG_DESTINATION_DEFAULT_*` variables are set in `app/.env.local`:
```bash
grep CLOUD_SDK_CFG_DESTINATION app/.env.local
```

## "LOCAL_MCP_SERVERS not set" or "no valid entries" (Local — MCP Builder only)

Verify `LOCAL_MCP_SERVERS` is set in `app/.env.local` as comma-separated `id:name` pairs:
```bash
grep LOCAL_MCP_SERVERS app/.env.local
```
