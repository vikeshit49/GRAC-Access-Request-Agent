# Complete agent_executor.py Example

This is the complete `agent_executor.py` after applying this skill.

```python
import logging
import os

from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.tasks import TaskUpdater
from a2a.types import InternalError, Part, TaskState, TextPart, UnsupportedOperationError
from a2a.utils import new_agent_text_message, new_task
from a2a.utils.errors import ServerError

from agent import SampleAgent

LOCAL_MCP_SERVERS = os.environ.get("LOCAL_MCP_SERVERS", "").strip()

if LOCAL_MCP_SERVERS:
    from mcp_providers.local import get_mcp_tools
else:
    from mcp_providers.agw import get_mcp_tools

logger = logging.getLogger(__name__)


class AgentExecutor(AgentExecutor):
    def __init__(self):
        self.agent = SampleAgent()

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        query = context.get_user_input()
        task = context.current_task
        if not task:
            task = new_task(context.message)
            await event_queue.enqueue_event(task)

        # Fetch MCP tools from Agent Gateway or local MCP Builder
        tools = None
        try:
            tools = await get_mcp_tools()
            logger.info(f"Loaded {len(tools)} MCP tool(s)")
            tools = tools or None
        except Exception as e:
            logger.warning(f"Failed to load MCP tools: {e}. Continuing without tools.")

        updater = TaskUpdater(event_queue, task.id, task.context_id)
        try:
            async for item in self.agent.stream(query, task.context_id, tools=tools or None):
                if not item["is_task_complete"] and not item["require_user_input"]:
                    await updater.update_status(
                        TaskState.working,
                        new_agent_text_message(item["content"], task.context_id, task.id),
                    )
                elif item["require_user_input"]:
                    await updater.update_status(
                        TaskState.input_required,
                        new_agent_text_message(item["content"], task.context_id, task.id),
                        final=True,
                    )
                    break
                else:
                    await updater.add_artifact(
                        [Part(root=TextPart(text=item["content"]))], name="agent_result"
                    )
                    await updater.complete()
                    break
        except Exception as e:
            logger.exception("Agent execution error")
            raise ServerError(error=InternalError()) from e

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise ServerError(error=UnsupportedOperationError())
```

## Key Points

- `LOCAL_MCP_SERVERS` env var (when set) switches between `mcp_providers/local.py` (development) and `mcp_providers/agw.py` (deployed).
- Tools are fetched **per request** because available tools may differ per tenant.
- The `tools or None` pattern ensures the agent falls back to its basic graph when no MCP tools are available.
