#!/bin/bash
# Sets up local testing mode (MCP Builder only).
# Run from the project root. Only run if MCP Servers were created on MCP Builder.

set -euo pipefail

SKILL_PATH=$(find . -type d -name "sap-agent-agw-mcp-integration" -path "*/skills/*" 2>/dev/null | head -1)
if [[ -z "$SKILL_PATH" ]]; then
  echo "ERROR: Could not find sap-agent-agw-mcp-integration skill directory" >&2
  exit 1
fi

echo "Setting up local MCP Builder provider..."
mkdir -p app/mcp_providers
cp "$SKILL_PATH/templates/local.py" app/mcp_providers/local.py
echo "  ✓ Copied local.py"

echo "Setting up test file..."
cp "$SKILL_PATH/templates/test_agent.http" test_agent.http
echo "  ✓ Copied test_agent.http"

echo "Done. Remember to configure app/.env.local with LOCAL_MCP_SERVERS and CLOUD_SDK_CFG_DESTINATION_DEFAULT_* variables."
