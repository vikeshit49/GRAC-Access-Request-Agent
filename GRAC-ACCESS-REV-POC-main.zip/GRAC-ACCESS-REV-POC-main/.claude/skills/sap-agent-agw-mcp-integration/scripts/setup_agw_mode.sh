#!/bin/bash
# Sets up the MCP providers package and middleware templates.
# Run from the project root.

set -euo pipefail

SKILL_PATH=$(find . -type d -name "sap-agent-agw-mcp-integration" -path "*/skills/*" 2>/dev/null | head -1)
if [[ -z "$SKILL_PATH" ]]; then
  echo "ERROR: Could not find sap-agent-agw-mcp-integration skill directory" >&2
  exit 1
fi

echo "Setting up MCP providers..."
mkdir -p app/mcp_providers && touch app/mcp_providers/__init__.py
cp "$SKILL_PATH/templates/agw.py" app/mcp_providers/agw.py
echo "  ✓ Copied agw.py"

echo "Setting up middleware..."
mkdir -p app/middleware && touch app/middleware/__init__.py
cp "$SKILL_PATH/templates/request_context.py" app/middleware/request_context.py
cp "$SKILL_PATH/templates/request_logging.py" app/middleware/request_logging.py
echo "  ✓ Copied request_context.py and request_logging.py"

echo "Done."
