"""MCP tools provider for local development — connects directly to MCP Builder via Destination Service.

This module is used when LOCAL_MCP_SERVERS is set. In deployed mode, mcp_providers/agw.py is used instead.
Both expose the same interface: `async def get_mcp_tools() -> list[BaseTool]`

Uses the SAP Cloud SDK destination module to resolve the MCP_HUB destination,
then connects to MCP Builder servers using streamable HTTP.
"""

import logging
import os
from typing import Any

import jwt
from httpx import Auth, Request
from langchain_core.tools import BaseTool
from langchain_mcp_adapters.client import MultiServerMCPClient
from sap_cloud_sdk.destination import create_client
from sap_cloud_sdk.destination.client import ConsumptionLevel

logger = logging.getLogger(__name__)

DESTINATION_NAME = "MCP_HUB"


def _resolve_destination() -> tuple[str, str]:
    """Resolve MCP_HUB destination via SDK and return (base_url, access_token)."""
    client = create_client()
    dest = client.get_destination(DESTINATION_NAME, level=ConsumptionLevel.SUBACCOUNT)

    if not dest:
        raise RuntimeError(f"Destination '{DESTINATION_NAME}' does not exist")

    token = dest.auth_tokens[0].value
    return dest.url, token


class MCPBearerTokenAuth(Auth):
    """httpx Auth that injects a bearer token and auto-refreshes on expiry."""

    def __init__(self):
        self.base_url, self.token = _resolve_destination()

    @property
    def _is_token_expired(self) -> bool:
        try:
            jwt.decode(
                self.token,
                algorithms=["RS256"],
                options={"verify_exp": True, "verify_signature": False},
            )
            return False
        except jwt.ExpiredSignatureError:
            return True
        except Exception:
            return False

    def auth_flow(self, request: Request):
        if self._is_token_expired:
            self.base_url, self.token = _resolve_destination()
        request.headers["Authorization"] = f"Bearer {self.token}"
        yield request


async def get_mcp_client() -> MultiServerMCPClient:
    """
    Initialize MCP client for local development.

    Reads MCP Server list from LOCAL_MCP_SERVERS env var (comma-separated id:name pairs),
    resolves each server's URL via BTP Destination Service (using SAP Cloud SDK),
    and returns a connected MultiServerMCPClient.

    Format: id1:Name1,id2:Name2
    """
    logger.info("Initializing MCP client (local mode) using SAP Cloud SDK destination")

    raw = os.environ.get("LOCAL_MCP_SERVERS", "").strip()
    if not raw:
        raise ValueError(
            "LOCAL_MCP_SERVERS env var is not set. "
            "Set it to comma-separated id:name pairs, e.g.: "
            "LOCAL_MCP_SERVERS=<server-id>:<ServerName>,<server-id-2>:<ServerName2>"
        )

    # Parse comma-separated id:name pairs
    servers: list[dict[str, str]] = []
    for entry in raw.split(","):
        entry = entry.strip()
        if not entry:
            continue
        parts = entry.split(":", 1)
        server_id = parts[0].strip()
        server_name = parts[1].strip() if len(parts) > 1 else f"mcp_server_{len(servers) + 1}"
        if server_id:
            servers.append({"id": server_id, "name": server_name})

    if not servers:
        raise ValueError(
            "LOCAL_MCP_SERVERS has no valid entries. "
            "Format: <server-id>:<ServerName>,<server-id-2>:<ServerName2>"
        )

    # Resolve MCP_HUB destination once to get the base URL
    mcp_base_url, _ = _resolve_destination()
    mcp_base_url = mcp_base_url.rstrip("/")

    logger.info(f"Found {len(servers)} MCP Server(s) in LOCAL_MCP_SERVERS")

    mcp_config: dict[str, dict[str, Any]] = {}
    auth = MCPBearerTokenAuth()

    for server in servers:
        server_id = server["id"]
        server_name = server["name"]
        server_url = f"{mcp_base_url}/{server_id}"

        mcp_config[server_name] = {
            "url": server_url,
            "transport": "streamable_http",
            "auth": auth,
        }
        logger.info(f"  - {server_name} (ID: {server_id}): {server_url}")

    if not mcp_config:
        raise ValueError("No MCP Servers could be configured")

    client = MultiServerMCPClient(mcp_config)
    logger.info(f"MCP client initialized with {len(mcp_config)} server(s)")
    return client


async def get_mcp_tools() -> list[BaseTool]:
    """Fetch MCP tools from MCP Builder via Destination Service (local mode).

    This is the public interface — same signature as mcp_tools_agw.get_mcp_tools().
    """
    client = await get_mcp_client()
    tools = await client.get_tools()
    logger.info(f"Loaded {len(tools)} MCP tool(s) from MCP Builder (local mode)")
    return tools