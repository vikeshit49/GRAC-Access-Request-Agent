"""
Request Logging Middleware.

Logs all incoming request headers for debugging purposes.
"""

import logging

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

logger = logging.getLogger(__name__)


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """
    Middleware to log all incoming request headers.

    Logs all headers for every request, with sensitive headers redacted.
    """

    # Headers that should be redacted for security
    SENSITIVE_HEADERS = {"authorization", "cookie", "x-api-key", "api-key"}

    async def dispatch(self, request: Request, call_next):
        logger.info(f"Request to {request.method} {request.url.path} - All headers:")
        for header_name, header_value in request.headers.items():
            if header_name.lower() in self.SENSITIVE_HEADERS:
                logger.info(f"  {header_name}: [REDACTED]")
            else:
                logger.info(f"  {header_name}: {header_value}")

        return await call_next(request)
