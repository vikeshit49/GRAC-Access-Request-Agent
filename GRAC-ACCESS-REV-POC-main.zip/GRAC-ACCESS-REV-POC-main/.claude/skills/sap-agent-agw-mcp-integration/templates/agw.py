"""MCP tools provider — uses the Agent Gateway module for tool discovery and invocation.

Exposes `async def get_mcp_tools() -> list[BaseTool]` which discovers MCP tools
via BTP Destination Service fragments and converts them to LangChain tools.

The Agent Gateway module handles service discovery, token exchange, and MCP protocol
communication automatically. Tools are fetched per-request (may vary per tenant).
"""

import logging

from langchain_core.tools import BaseTool
from middleware.request_context import authorization_var, tenant_subdomain_var
from sap_cloud_sdk.agentgateway import create_client
from sap_cloud_sdk.agentgateway.converters import mcp_tool_to_langchain

logger = logging.getLogger(__name__)


def _get_user_token() -> str:
    return authorization_var.get()


def _get_tenant_subdomain() -> str:
    return tenant_subdomain_var.get()


async def get_mcp_tools() -> list[BaseTool]:
    """Fetch MCP tools via Agent Gateway (deployed mode).

    This is the public interface — same signature as mcp_tools_local.get_mcp_tools().
    """
    agw_client = create_client(tenant_subdomain=_get_tenant_subdomain)
    mcp_tools = await agw_client.list_mcp_tools(user_token=_get_user_token)

    tools = [
        mcp_tool_to_langchain(t, agw_client.call_mcp_tool, _get_user_token)
        for t in mcp_tools
    ]

    logger.info(f"Loaded {len(tools)} MCP tool(s) from Agent Gateway (deployed mode)")
    return tools
