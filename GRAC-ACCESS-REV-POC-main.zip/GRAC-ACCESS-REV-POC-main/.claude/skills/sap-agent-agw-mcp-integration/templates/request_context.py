"""Request context middleware — captures tenant subdomain and user token from headers.

The Agent Gateway forwards tenant info via the `dwc-subdomain` header
and user identity via the `authorization` Bearer token. These context vars
are consumed by mcp_providers/agw.py to scope SDK calls per-tenant/per-user.
"""

import logging

from contextvars import ContextVar

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

tenant_subdomain_var: ContextVar[str] = ContextVar("tenant_subdomain", default="")
authorization_var: ContextVar[str] = ContextVar("authorization", default="")

logger = logging.getLogger(__name__)


class RequestContextMiddleware(BaseHTTPMiddleware):
    """Extracts tenant subdomain and authorization from request headers."""

    async def dispatch(self, request: Request, call_next):
        self.save_tenant_subdomain(request)
        self.save_authorization(request)
        return await call_next(request)

    def save_tenant_subdomain(self, request):
        tenant = request.headers.get("dwc-subdomain", "")
        tenant_subdomain_var.set(tenant)
        logger.info("RequestContext: tenant_subdomain=%r", tenant)

    def save_authorization(self, request):
        auth = request.headers.get("authorization", "")
        authorization_var.set(auth[7:] if auth.lower().startswith("bearer ") else auth)
        logger.info("RequestContext: authorization saved, length=%d", len(auth))

