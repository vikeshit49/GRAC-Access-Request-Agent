---
name: sap-agent-devcontainer
description: Set up a VS Code devcontainer for App Foundation agent development. Use when the user wants to develop their agent in a containerized environment with proper dependencies pre-configured.
---

# App Foundation Agent Devcontainer Setup

Sets up a VS Code devcontainer for App Foundation agent development with Python 3.13, SAP Artifactory, pre-installed extensions, and automatic dependency installation.

## ⚠️ Package Index Policy

All Python packages MUST be installed exclusively from the SAP PyPI proxy:
`https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple`

NEVER use `https://pypi.org/simple` or any other external package index.
NEVER add `--extra-index-url` pointing to PyPI.
If a package is not found in the SAP proxy, report the error — do NOT fall back to PyPI.

## Prerequisites

1. **Docker Desktop** installed and running
2. **VS Code** with [Dev Containers extension](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-containers)

## Step 1: Create .devcontainer/Dockerfile

Copy the template file from this skill's templates directory to `.devcontainer/Dockerfile` in the user's project:

**Template location:** `templates/Dockerfile` (relative to this skill)

## Step 2: Create .devcontainer/devcontainer.json

Copy the template file from this skill's templates directory to `.devcontainer/devcontainer.json` in the user's project:

**Template location:** `templates/devcontainer.json` (relative to this skill)

## Step 3: Open in Devcontainer

1. Open project in VS Code
2. Click **"Reopen in Container"** when prompted (or use Command Palette: `Dev Containers: Reopen in Container`)
3. Wait for container to build

## Step 4: Create Environment File

Copy the `.env.local` template and fill in your AI Core credentials:

```bash
SKILL_PATH=$(find . -type d -name "sap-agent-run-local" -path "*/skills/*" 2>/dev/null | head -1)
cp "$SKILL_PATH/templates/.env.local" app/.env.local
```

Then edit `app/.env.local` with your actual credentials.

## Step 5: Run and Test

**Run the agent:**
```bash
export $(grep -v '^#' app/.env.local | xargs) && python app/main.py --host 0.0.0.0 --port 9000
```

**Verify running:**
```bash
curl http://localhost:9000/.well-known/agent.json
```

**Send test message:**
```bash
curl -X POST http://localhost:9000/ -H 'content-type: application/json' -d '{
  "jsonrpc": "2.0", "method": "message/send", "id": "test-1",
  "params": { "message": { "messageId": "msg-001", "role": "user",
    "parts": [{"kind": "text", "text": "Hello, what can you help me with?"}] }}
}'
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Reopen in Container" missing | Install Dev Containers extension, ensure Docker is running, restart VS Code |
| Port 9000 not accessible | Check `forwardPorts` in config, try `127.0.0.1:9000`, check port conflicts |
| Dependencies not installed | Run `pip install --no-cache-dir -r requirements.txt --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"` manually |
| Rebuild needed | Command Palette → `Dev Containers: Rebuild Container` |
| View container logs | Command Palette → `Dev Containers: Show Container Log` |

## Project Structure

```
./
├── .devcontainer/
│   ├── devcontainer.json
│   └── Dockerfile
├── app/
│   ├── .env.local
│   └── ...
└── requirements.txt
```

## Next Steps

- **Run agent**: Use `appfnd-agent-run-local` skill
- **Test remote**: Use `appfnd-agent-test-remote` skill
- **Add instrumentation**: Use `appfnd-agent-instrumentation` skill