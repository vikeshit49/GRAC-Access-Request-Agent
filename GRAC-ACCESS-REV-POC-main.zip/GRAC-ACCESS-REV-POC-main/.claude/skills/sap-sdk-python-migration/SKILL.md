---
name: sap-sdk-python-migration
description: Migrate Python projects from the internal Application Foundation Python SDK to the open source SAP Cloud SDK.
---

## ⚠️ Package Index Policy

All Python packages MUST be installed exclusively from the SAP PyPI proxy:
`https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple`

NEVER use `https://pypi.org/simple` or any other external package index.
NEVER add `--extra-index-url` pointing to PyPI.
If a package is not found in the SAP proxy, report the error — do NOT fall back to PyPI.

## Skill Purpose

This skill automates the migration of Python projects from the internal `application-foundation-sdk-python` (hosted on SAP Artifactory) to the open source `sap-cloud-sdk` (available on PyPI).

## What This Skill Does

1. **Updates dependency files** - Replaces internal SDK dependency with open source version in `requirements.txt` and/or `pyproject.toml`
2. **Updates all import statements** - Converts old import paths to new package structure
3. **Updates Dockerfile** - Updates index URL to the new PyPI proxy (no authentication required)
4. **Updates CI/CD workflows** - Removes Artifactory secrets (no longer needed)
5. **Validates changes** - Checks for any remaining references to old SDK

## Migration Steps Performed

### 1. Update Dependency Files

The skill updates dependency declarations in both `requirements.txt` and `pyproject.toml` (if present).

#### requirements.txt

**Before:**
```txt
application-foundation-sdk-python>=1.4.1
```

**After:**
```txt
sap-cloud-sdk>=0.2.0
```

#### pyproject.toml (PEP 621 format)

**Before:**
```toml
[project]
dependencies = [
    "application-foundation-sdk-python>=1.4.1"
]
```

**After:**
```toml
[project]
dependencies = [
    "sap-cloud-sdk>=0.2.0"
]
```

#### pyproject.toml (Poetry format)

**Before:**
```toml
[tool.poetry.dependencies]
application-foundation-sdk-python = "^1.4.1"
```

**After:**
```toml
[tool.poetry.dependencies]
sap-cloud-sdk = "^0.2.0"
```

### 2. Update Import Statements

The skill updates all Python files with the new import paths:

| Old Import | New Import |
|------------|------------|
| `from application_foundation.auditlog` | `from sap_cloud_sdk.core.auditlog` |
| `from application_foundation.destination` | `from sap_cloud_sdk.destination` |
| `from application_foundation.objectstore` | `from sap_cloud_sdk.objectstore` |
| `from application_foundation.common.secret_resolver` | `from sap_cloud_sdk.core.secret_resolver` |
| `from application_foundation.common.telemetry` | `from sap_cloud_sdk.core.telemetry` |

### 3. Update Dockerfile

**Files Updated:**
- `Dockerfile` - Updates --index-url to use the new PyPI proxy and removes Artifactory authentication

**Before (Dockerfile):**
```dockerfile
ARG ARTIFACTORY_USER
ARG ARTIFACTORY_TOKEN

RUN pip install -r requirements.txt \
    --index-url "https://${ARTIFACTORY_USER}:${ARTIFACTORY_TOKEN}@common.repositories.cloud.sap/artifactory/api/pypi/application-foundation-sdk-python/simple" \
    --extra-index-url "https://pypi.org/simple"
```

**After (Dockerfile):**
```dockerfile
RUN pip install -r requirements.txt \
    --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"
```

### 4. Update CI/CD Workflows

Remove `ARTIFACTORY_USER` and `ARTIFACTORY_TOKEN` secrets and build args from GitHub Actions workflows **only where they are used to install the old SDK** (e.g., `--index-url` build args passed to `docker build` or `pip install` steps). These are no longer needed since the new PyPI proxy does not require authentication.

**Do NOT remove** Artifactory secrets from workflows that use them for **publishing** packages to Artifactory (e.g., `uv publish`, `twine upload`, or `curl` upload steps). Those are unrelated to SDK consumption and must be preserved.

## Validation Steps

After migration, the skill automatically validates:

1. No remaining references to `application-foundation-sdk-python` in dependency files, and no remaining `from application_foundation` or `import application_foundation` statements in Python files
2. All imports updated to `sap_cloud_sdk.*`
3. Dependencies updated in `requirements.txt` and/or `pyproject.toml`
4. `--index-url` points to the new PyPI proxy (not the old `application-foundation-sdk-python` repository)
5. Dependencies can be installed: `pip install -r requirements.txt --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"` or `pip install -e . --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"`

## Post-Migration Testing

The skill guides users to test their migrated application:

### Local Testing
```bash
# Install dependencies (choose based on your project setup)
pip install -r requirements.txt --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"  # For requirements.txt
# OR
pip install -e . --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"                 # For pyproject.toml

# Run application
python app/main.py

# Verify functionality
# - Test all SDK integrations
# - Check logs for import errors
# - Verify telemetry collection
```

### Docker Testing
```bash
# Build image
docker build -t my-app:migrated .

# Run container
docker run -p 8080:8080 my-app:migrated
```

## Migration Checklist

The skill provides an interactive checklist:

- [ ] Updated `requirements.txt` and/or `pyproject.toml`
- [ ] Updated all import statements
- [ ] Updated index URL to new PyPI proxy
- [ ] Updated Dockerfile (removed Artifactory auth)
- [ ] Updated CI/CD workflows (removed Artifactory secrets)
- [ ] Tested locally
- [ ] Tested Docker build
- [ ] Deployed to dev environment
- [ ] Verified telemetry
