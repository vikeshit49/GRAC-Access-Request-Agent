---
name: mcphub-integrate-server
description: Add MCP client integration to an AI agent to connect to MCP Servers on MCP Hub. Use as the FINAL step after creating MCP Servers and the base agent - this skill integrates them together.
---

# MCP Client Integration for AI Agents

This skill adds MCP client integration to connect an agent to MCP Servers hosted on MCP Hub.

> **Workflow Order:** This skill is the **final step** when building an MCP-enabled agent:
> 1. **mcphub-create-server** - Create or retrieve MCP Server IDs
> 2. **appfnd-agent-bootstrap** - Create the base App Foundation agent
> 3. **mcphub-integrate-server** (this skill) - Add MCP Hub integration to the agent
>
> This skill assumes you have already:
> - Created MCP Server(s) using `mcphub-create-server` and have the server ID(s)
> - Created an App Foundation agent project using `appfnd-agent-bootstrap`
>
> The instructions below show what to **ADD or MODIFY** on top of the existing project structure.

## Prerequisites

- **MCP Server ID(s)** from MCP Hub (created/retrieved via `mcphub-create-server` skill)
- **Existing App Foundation agent project** created with `appfnd-agent-bootstrap` skill
- BTP Destination named `MCP_HUB` pointing to MCP Hub
- Destination Service instance in your BTP subaccount

## Step 1: Add MCP Dependencies to requirements.txt

**Add** these packages to your existing `requirements.txt` (created by `appfnd-agent-bootstrap`):

```text
# MCP Hub Integration
langchain-mcp-adapters
pyjwt
pyyaml
```

> **Note:** The `appfnd-agent-bootstrap` skill already includes `mcp` and `httpx` in requirements.txt. You only need to add the packages listed above.
>
> If you encounter `ImportError: cannot import name 'ElicitationFnT' from 'mcp.client.session'`, upgrade the `mcp` package to version `1.10.0` or higher by changing the line in requirements.txt from `mcp==1.9.3` to `mcp>=1.10.0`.

## Step 2: Update app.yaml

Your `app.yaml` was created by the `appfnd-agent-bootstrap` skill. You need to **add** the following sections to enable MCP Hub integration.

### Add Destination Service to spec.requires

**Add** the destination service entry to your existing `spec.requires` section (create the section if it doesn't exist):

```yaml
  requires:
  - name: my-destination-instance    # Name of your BTP Destination Service instance
    service: destination
    plan: lite
```

### Add MCP Server Configuration

**Add** a new `spec.servers` section to configure MCP Servers:

```yaml
  servers:
  - id: 8c7c4cab-f032-460c-8041-71863b3950a9   # MCP Server ID from MCP Hub
    name: Northwind                            # Friendly name (for logging)
    enabled: true                              # Set to false to disable
  - id: another-server-id
    name: AnotherService
    enabled: true
```

### Example: app.yaml with MCP Hub additions

Starting from the base `app.yaml` created by `appfnd-agent-bootstrap`, add the highlighted sections:

```yaml
apiVersion: workload.appfnd.sap/v1
kind: Agent
metadata:
  name: sample-agent           # Your existing agent name
  namespace: sample-agent
spec:
  # --- ADD THIS SECTION ---
  requires:
  - name: my-destination-instance
    service: destination
    plan: lite
  # --- END ADDITION ---
  container:
    buildPath: .
    port: 5000
  resources:
    requests:
      memory: "256Mi"
      cpu: "50m"
    limits:
      memory: "512Mi"
      cpu: "200m"
  service:
    apiAuth:
      path: /*
      type: jwt
  models:
  - executableId: aws-bedrock
    name: anthropic--claude-4.5-sonnet
    version: latest
  # --- ADD THIS SECTION ---
  servers:
  - id: 8c7c4cab-f032-460c-8041-71863b3950a9
    name: Northwind
    enabled: true
  # --- END ADDITION ---
```

## Step 3: Create app/mcp_client.py (New File)

Create a **new file** `app/mcp_client.py` that handles authentication and connection to MCP Servers. This file does not exist in the base `appfnd-agent-bootstrap` project:

```python
"""MCP Client initialization and configuration for streamable HTTP transport."""

import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

import httpx
import jwt
import yaml
from httpx import Auth, Request
from langchain_mcp_adapters.client import MultiServerMCPClient

logger = logging.getLogger(__name__)


def read_destination_binding(destination_instance_name: str, binding_base_path: str = "/etc/secrets/appfnd/destination") -> Dict[str, str]:
    """
    Read destination service binding from the mounted volume or environment variables.
    
    Binding should contain:
    - clientid: OAuth client ID
    - clientsecret: OAuth client secret
    - url: OAuth token endpoint (e.g., https://xxx.authentication.xxx)
    - uri: API base URL (e.g., https://destination-service.cfapps.xxx)
    
    Falls back to environment variables if binding files are not found:
    - DESTINATION_CLIENT_ID
    - DESTINATION_CLIENT_SECRET
    - DESTINATION_AUTH_URL (OAuth URL)
    - DESTINATION_BASE_URL (API base URL)
    
    Args:
        destination_instance_name: Name of the destination service instance
        binding_base_path: Base path to the destination service bindings directory
        
    Returns:
        Dictionary with destination service credentials (keys: clientid, clientsecret, url, uri)
        
    Raises:
        ValueError: If neither binding files nor environment variables are available
    """
    binding_path = f"{binding_base_path}/{destination_instance_name}"
    binding_dir = Path(binding_path)
    binding_data = {}
    
    # Try to read from binding files first
    if binding_dir.exists():
        required_files = ["clientid", "clientsecret", "url", "uri"]
        all_files_exist = all((binding_dir / f).exists() for f in required_files)
        
        if all_files_exist:
            for file_name in required_files:
                file_path = binding_dir / file_name
                with open(file_path, 'r') as f:
                    binding_data[file_name] = f.read().strip()
            
            logger.info(f"Read destination service binding from {binding_path}")
            return binding_data
        else:
            logger.warning(f"Binding path exists but some required files are missing")
    
    # Fallback to environment variables
    logger.info("Binding files not found, reading from environment variables")
    
    client_id = os.getenv("DESTINATION_CLIENT_ID")
    client_secret = os.getenv("DESTINATION_CLIENT_SECRET")
    auth_url = os.getenv("DESTINATION_AUTH_URL")
    base_url = os.getenv("DESTINATION_BASE_URL")
    
    if not all([client_id, client_secret, auth_url, base_url]):
        raise ValueError(
            "Destination credentials not found. Either mount destination service binding at "
            f"{binding_path} or set environment variables: DESTINATION_CLIENT_ID, "
            "DESTINATION_CLIENT_SECRET, DESTINATION_AUTH_URL, DESTINATION_BASE_URL"
        )
    
    binding_data = {
        "clientid": client_id,
        "clientsecret": client_secret,
        "url": auth_url,
        "uri": base_url,
    }
    
    logger.info("Read destination service credentials from environment variables")
    return binding_data


def get_destination_token(binding_data: Dict[str, str]) -> str:
    """
    Get OAuth token from destination service.
    
    Args:
        binding_data: Destination service binding data with url (OAuth endpoint)
        
    Returns:
        Access token for destination service API
    """
    token_url = f"{binding_data['url']}/oauth/token"
    
    with httpx.Client() as client:
        response = client.post(
            token_url,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type": "client_credentials",
                "client_id": binding_data["clientid"],
                "client_secret": binding_data["clientsecret"],
            },
        )
        response.raise_for_status()
        access_token = response.json()["access_token"]
        logger.info("Successfully obtained destination service token")
        return access_token


def get_base_url_and_access_token_for(destination_name: str, binding_data: Dict[str, str], dest_token: str) -> tuple[str, str]:
    """
    Fetch destination configuration and extract URL and auth token.
    
    The destination service provides pre-generated auth tokens for the target service,
    eliminating the need to handle certificates and OAuth token generation.
    
    Args:
        destination_name: Name of the destination to retrieve
        binding_data: Destination service binding data with uri (API base URL)
        dest_token: Access token for destination service API
        
    Returns:
        Tuple of (base_url, access_token) for the MCP service
    """
    destination_url = f"{binding_data['uri']}/destination-configuration/v1/destinations/{destination_name}"
    
    with httpx.Client() as client:
        response = client.get(
            destination_url,
            headers={"Authorization": f"Bearer {dest_token}"},
        )
        
        if not response.is_success:
            raise RuntimeError(f"Failed to get destination: {response.status_code} - {response.text}")
        
        dest_config = response.json()
        
        # Extract the auth token provided by destination service
        auth_tokens = dest_config.get("authTokens", [])
        if not auth_tokens:
            raise RuntimeError(f"No auth tokens found in destination '{destination_name}'")
        
        token = auth_tokens[0]["value"]
        
        # Extract the base URL
        dest_config_props = dest_config.get("destinationConfiguration", {})
        base_url = dest_config_props.get("URL")
        
        if not base_url:
            raise RuntimeError(f"No URL found in destination '{destination_name}'")
        
        logger.info(f"Successfully retrieved destination configuration for '{destination_name}'")
        return base_url, token


class MCPBearerTokenAuth(Auth):
    """Custom auth handler for MCP streamable HTTP with bearer token and auto-refresh."""

    def __init__(self, destination_name: str, destination_instance_name: str, binding_base_path: str = "/etc/secrets/appfnd/destination"):
        """
        Initialize auth handler and fetch token from destination service.
        
        Args:
            destination_name: Name of the destination containing MCP credentials
            destination_instance_name: Name of the destination service instance
            binding_base_path: Base path to destination service bindings directory
        """
        self.destination_name = destination_name
        self.destination_instance_name = destination_instance_name
        self.binding_base_path = binding_base_path
        self.base_url, self.token = self._fetch_mcp_credentials()

    def _fetch_mcp_credentials(self) -> tuple[str, str]:
        """Fetch MCP base URL and token through destination service."""
        try:
            binding_data = read_destination_binding(self.destination_instance_name, self.binding_base_path)
            dest_token = get_destination_token(binding_data)
            base_url, token = get_base_url_and_access_token_for(self.destination_name, binding_data, dest_token)
            return base_url, token
        except Exception as e:
            logger.error(f"Failed to fetch MCP credentials: {e}")
            raise

    @property
    def __is_token_expired(self) -> bool:
        """Check if the current token is expired."""
        try:
            jwt.decode(
                self.token,
                algorithms=["RS256"],
                options={"verify_exp": True, "verify_signature": False},
            )
            return False
        except jwt.ExpiredSignatureError:
            return True
        except Exception:
            return False

    def __get_token(self) -> str:
        """Get token, refreshing if expired."""
        if self.__is_token_expired:
            self.base_url, self.token = self._fetch_mcp_credentials()
        return self.token

    def auth_flow(self, request: Request):
        """Add Authorization header with fresh token."""
        request.headers["Authorization"] = f"Bearer {self.__get_token()}"
        yield request


async def get_mcp_client() -> MultiServerMCPClient:
    """
    Initialize and return an MCP client configured with streamable HTTP transport.
    
    Reads configuration from app.yaml:
    1. Gets destination instance name from spec.requires (service: destination)
    2. Gets MCP Server list from spec.servers
    3. For each MCP Server, fetches credentials via destination service
    4. Initializes MultiServerMCPClient with all configured servers
    
    Returns:
        MultiServerMCPClient: Configured client with tools from all accessible MCP Servers
    """
    binding_base_path = "/etc/secrets/appfnd/destination"
    
    logger.info("Initializing MCP client using destination service")
    
    app_yaml_path = Path(__file__).parent.parent / "app.yaml"
    mcp_config: dict[str, dict[str, Any]] = {}
    destination_instance_name: Optional[str] = None
    
    if not app_yaml_path.exists():
        raise ValueError(f"app.yaml not found at {app_yaml_path}")
    
    logger.info(f"Reading MCP Server configuration from {app_yaml_path}")
    
    with open(app_yaml_path, 'r') as f:
        app_config = yaml.safe_load(f)
    
    # Extract destination instance name from requires section
    requires = app_config.get("spec", {}).get("requires", [])
    for req in requires:
        if req.get("service") == "destination":
            destination_instance_name = req.get("name")
            logger.info(f"Found destination instance name: {destination_instance_name}")
            break
    
    if not destination_instance_name:
        raise ValueError("No destination service instance found in app.yaml spec.requires")
    
    # Read destination service binding
    binding_data = read_destination_binding(destination_instance_name, binding_base_path)
    dest_token = get_destination_token(binding_data)
    
    # Process each MCP Server
    servers = app_config.get("spec", {}).get("servers", [])
    if not servers:
        raise ValueError("No MCP Servers configured in app.yaml spec.servers")
    
    logger.info(f"Found {len(servers)} MCP Server(s) in app.yaml")
    
    for idx, server in enumerate(servers):
        server_id = server.get("id")
        destination_name = server.get("destination", "MCP_HUB")
        enabled = server.get("enabled", True)
        
        if not enabled:
            logger.info(f"MCP Server {idx + 1} (ID: {server_id}) is disabled, skipping")
            continue
        
        if not server_id:
            logger.warning(f"MCP Server {idx + 1} missing 'id', skipping")
            continue
        
        try:
            mcp_base_url, _ = get_base_url_and_access_token_for(destination_name, binding_data, dest_token)
            mcp_base_url = mcp_base_url.rstrip("/")
            
            server_name = server.get("name", f"mcp_server_{idx + 1}")
            server_url = f"{mcp_base_url}/{server_id}"
            
            mcp_config[server_name] = {
                "url": server_url,
                "transport": "streamable_http",
                "auth": MCPBearerTokenAuth(destination_name, destination_instance_name, binding_base_path),
            }
            logger.info(f"  - {server_name} (ID: {server_id}): {server_url}")
        except Exception as e:
            logger.error(f"Failed to configure MCP Server {server_id}: {e}")
            continue
    
    if not mcp_config:
        raise ValueError("No MCP Servers could be configured")
    
    client = MultiServerMCPClient(mcp_config)
    logger.info(f"MCP client initialized with {len(mcp_config)} MCP Server(s)")
    return client
```

## Step 4: Modify app/agent.py to Use MCP Tools

The `appfnd-agent-bootstrap` skill creates a basic `agent.py`. You need to **modify** it to load and use MCP tools. Below are the specific changes to make.

### 4.1 Add New Imports

**Add these imports** at the top of your existing `agent.py`:

```python
from langchain_core.tools import StructuredTool
from langgraph.prebuilt import ToolNode

from mcp_client import get_mcp_client
```

### 4.2 Update SYSTEM_PROMPT

**Modify** the `SYSTEM_PROMPT` to mention MCP tools:

```python
SYSTEM_PROMPT = """You are a helpful AI assistant built with Application Foundation.
You can help users with general questions and tasks. Be friendly, concise, and helpful.

You have access to MCP tools that can help you retrieve information from connected services."""
```

### 4.3 Modify SampleAgent Class

**Replace** the `SampleAgent` class `__init__` and add new methods. The key changes are:

1. Add `tools` list and `_initialized` flag to `__init__`
2. Remove immediate graph building from `__init__`
3. Add `initialize()` async method to load MCP tools
4. Modify `_build_graph()` to include tools when available
5. Call `await self.initialize()` at the start of `stream()` and `invoke()`

Here is the **complete modified `SampleAgent` class**:

```python
class SampleAgent:
    SUPPORTED_CONTENT_TYPES = ["text", "text/plain"]

    def __init__(self):
        self.llm = ChatLiteLLM(model="sap/anthropic--claude-4.5-sonnet")
        self.tools: list[StructuredTool] = []
        self.graph = None
        self._initialized = False

    async def initialize(self):
        """Initialize the agent with MCP tools. Called once on first request."""
        if self._initialized:
            return

        logger.info("Initializing agent with MCP tools...")
        try:
            # Get MCP client and tools
            client = await get_mcp_client()
            
            try:
                mcp_tools = await client.get_tools()
                
                # Filter for StructuredTool instances
                self.tools = [
                    tool for tool in mcp_tools 
                    if isinstance(tool, StructuredTool)
                ]
                
                logger.info(f"Loaded {len(self.tools)} MCP tools: {[tool.name for tool in self.tools]}")
            except* Exception as eg:
                # Handle ExceptionGroup - some servers may have failed
                logger.warning(f"Some MCP Servers failed to load tools: {eg}")
                self.tools = []
                    
        except Exception as e:
            logger.exception(f"Failed to initialize MCP client: {e}")
            self.tools = []

        # Build the graph with tools
        self.graph = self._build_graph()
        self._initialized = True
        logger.info("Agent initialization complete")

    def _build_graph(self):
        """Build LangGraph with MCP tools."""
        builder = StateGraph(MessagesState)

        if self.tools:
            # Bind tools to LLM for function calling
            llm_with_tools = self.llm.bind_tools(self.tools)

            async def call_model(state: MessagesState):
                response = await llm_with_tools.ainvoke(state["messages"])
                return {"messages": [response]}

            async def should_continue(state: MessagesState):
                messages = state["messages"]
                last_message = messages[-1]
                if hasattr(last_message, "tool_calls") and last_message.tool_calls:
                    return "tools"
                return "__end__"

            builder.add_node("model", call_model)
            builder.add_node("tools", ToolNode(self.tools, handle_tool_errors=True))

            builder.add_edge(START, "model")
            builder.add_conditional_edges("model", should_continue, ["tools", "__end__"])
            builder.add_edge("tools", "model")
        else:
            # Fallback: no tools available
            async def call_model(state: MessagesState):
                response = await self.llm.ainvoke(state["messages"])
                return {"messages": [response]}

            builder.add_node("model", call_model)
            builder.add_edge(START, "model")

        return builder.compile()

    async def stream(self, query: str, context_id: str) -> AsyncGenerator[dict, None]:
        """Stream response to user query."""
        await self.initialize()  # <-- ADD THIS LINE
        
        yield {"is_task_complete": False, "require_user_input": False, "content": "Processing..."}
        try:
            messages = [SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=query)]
            result = await self.graph.ainvoke({"messages": messages})
            response = result["messages"][-1].content
            yield {"is_task_complete": True, "require_user_input": False, "content": response}
        except Exception as e:
            logger.exception("Error in agent stream")
            yield {"is_task_complete": True, "require_user_input": False, "content": f"Error: {e}"}

    def invoke(self, query: str, context_id: str) -> AgentResponse:
        """Synchronous invocation of the agent."""
        import asyncio
        
        async def async_invoke():
            await self.initialize()  # <-- ADD THIS LINE
            messages = [SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=query)]
            result = await self.graph.ainvoke({"messages": messages})
            return result["messages"][-1].content
        
        try:
            response = asyncio.run(async_invoke())
            return AgentResponse(status="completed", message=response)
        except Exception as e:
            logger.exception("Error in agent invoke")
            return AgentResponse(status="error", message=f"Error: {e}")
```

### Summary of Changes to agent.py

| Change         | What to do                                                                 |
| -------------- | -------------------------------------------------------------------------- |
| Imports        | Add `StructuredTool`, `ToolNode`, and `get_mcp_client`                     |
| SYSTEM_PROMPT  | Update to mention MCP tools                                                |
| `__init__`     | Add `self.tools = []`, `self.graph = None`, `self._initialized = False`    |
| `_build_graph` | Modify to handle tools (tool binding, conditional edges)                   |
| `initialize`   | Add new async method to load MCP tools                                     |
| `stream`       | Add `await self.initialize()` at the start                                 |
| `invoke`       | Add `await self.initialize()` inside `async_invoke()`                      |

## Step 5: Update Dockerfile to Include app.yaml

The `Dockerfile` created by `appfnd-agent-bootstrap` already copies the `app/` directory. You need to **add** a line to also copy `app.yaml` so the MCP client can read the server configuration at runtime.

**Add this line** to your Dockerfile, before the `COPY app/ ./app/` line:

```dockerfile
COPY app.yaml .
```

Your Dockerfile's COPY section should look like:

```dockerfile
# ... existing Dockerfile content from appfnd-agent-bootstrap ...

COPY app.yaml .    # <-- ADD THIS LINE
COPY app/ ./app/

# ... rest of Dockerfile ...
```

## Step 6: Update Environment Variables for Local Development

The `appfnd-agent-bootstrap` skill creates `app/.env.example` as a template and you use `app/.env.local` for actual credentials during local development (as described in `appfnd-agent-run-local` skill).

### Add to app/.env.local

**Add these variables to your existing `app/.env.local`** (alongside the AICORE_* variables already there):

```ini
# Destination Service Configuration (for MCP Hub access)
DESTINATION_CLIENT_ID=<your-client-id>
DESTINATION_CLIENT_SECRET=<your-client-secret>
DESTINATION_AUTH_URL=https://your-subdomain.authentication.eu12.hana.ondemand.com
DESTINATION_BASE_URL=https://destination-configuration.cfapps.eu12.hana.ondemand.com
```

### Update app/.env.example (Optional)

**Add these template entries to `app/.env.example`** for documentation:

```ini
# Destination Service Configuration (for MCP Hub access)
# DESTINATION_CLIENT_ID=
# DESTINATION_CLIENT_SECRET=
# DESTINATION_AUTH_URL=
# DESTINATION_BASE_URL=
```

> **Note:** The `.gitignore` created by `appfnd-agent-bootstrap` already excludes `.env` and `app/.env`. Ensure `app/.env.local` is also excluded - if not, add it.

## Files Added/Modified by This Skill

This skill adds or modifies the following files in your existing App Foundation agent project (created by `appfnd-agent-bootstrap`):

```text
my-agent/
├── app.yaml              # MODIFIED: Added requires.destination and servers sections
├── requirements.txt      # MODIFIED: Added MCP dependencies
├── Dockerfile            # MODIFIED: Added COPY app.yaml line
└── app/
    ├── .env.local        # MODIFIED: Added DESTINATION_* variables
    ├── agent.py          # MODIFIED: Added MCP tool integration
    └── mcp_client.py     # NEW: MCP client module
```

All other files (`main.py`, `agent_executor.py`, `__init__.py`, `.github/workflows/`, etc.) remain unchanged from `appfnd-agent-bootstrap`.

## Troubleshooting

### ImportError: cannot import name 'ElicitationFnT' from 'mcp.client.session'

This error occurs when `langchain-mcp-adapters` requires a newer version of the `mcp` package than what's installed by `appfnd-agent-bootstrap`.

**Solution:** Update the `mcp` version in your `requirements.txt`:

```text
mcp>=1.10.0
```

Then reinstall dependencies following the `appfnd-agent-run-local` skill instructions.

### MCP Tools Not Loading

If the agent starts but no MCP tools are available:

1. **Check app.yaml:** Verify `spec.servers` section has correct MCP Server IDs
2. **Check destination credentials:** Verify `DESTINATION_*` variables in `app/.env.local`
3. **Check logs:** Look for errors during "Initializing agent with MCP tools..."

### Destination Service Errors

If you see "Destination credentials not found":

1. **Local development:** Ensure all `DESTINATION_*` variables are set in `app/.env.local`
2. **Deployed:** Ensure `spec.requires` includes the destination service with correct instance name

### For Other Issues

For issues related to the base agent (AI Core, Artifactory, etc.), refer to the troubleshooting section in the `appfnd-agent-run-local` skill.