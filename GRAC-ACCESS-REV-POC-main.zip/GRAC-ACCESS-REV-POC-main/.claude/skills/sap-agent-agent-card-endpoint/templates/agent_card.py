import json
import os
from pathlib import Path
from typing import Any, Dict

from starlette.requests import Request
from starlette.responses import JSONResponse


def _derive_base_url(request: Request) -> str:
    """Derive the base URL from environment variable or request headers."""
    env_url = os.getenv("AGENT_PUBLIC_URL", "").strip().rstrip("/")
    if env_url:
        return env_url
    scheme = request.url.scheme
    host = request.headers.get("host", "")
    return f"{scheme}://{host}".rstrip("/")


def load_and_enrich_agent_card(request: Request):
    """Load the Agent Card JSON and enrich it with the actual base URL.
    
    This function reads the agent card from .well-known/agent.json and
    dynamically updates the supportedInterfaces URLs to reflect the
    actual deployment URL.
    """
    # Locate .well-known/agent.json at repo root
    file_path = Path(__file__).resolve().parent.parent / ".well-known" / "agent.json"
    with file_path.open("r", encoding="utf-8") as f:
        card: Dict[str, Any] = json.load(f)

    base_url = _derive_base_url(request)

    # Update supportedInterfaces URLs with the actual base URL
    # Per A2A v1.0.0 spec, supportedInterfaces is a required array of AgentInterface
    supported_interfaces = card.get("supportedInterfaces", [])
    for interface in supported_interfaces:
        if isinstance(interface, dict):
            # If the URL contains a placeholder or needs to be updated
            current_url = interface.get("url", "")
            if not current_url or "{{" in current_url:
                # Set the URL to the base URL (the A2A endpoint)
                interface["url"] = base_url

    card["supportedInterfaces"] = supported_interfaces

    return JSONResponse(card)