---
name: sap-agent-agent-card-endpoint
description: Add an authenticated A2A (Agent-to-Agent) Agent Card endpoint to an App Foundation agent and wire it into existing ORD documents for discovery.
---

# A2A Agent Card Endpoint for App Foundation Agents

Adds an authenticated Agent Card endpoint for the A2A protocol and integrates it with existing ORD documents so orchestrators and catalogs can discover the agent’s contract.

Main expectations:
- Agent card endpoint must be exposed — provides GET /agent-card (primary) and GET /.well-known/agent.json (canonical)
- Agent card endpoint must be authenticated — app.yaml config enforces JWT for both endpoints
- Agent card endpoint must be informed in the ORD — resourceDefinitions include type "a2a-agent-card" pointing to /agent-card

Notes:
- ORD endpoints stay open (no_auth) per spec.
- Agent Card endpoints are JWT-protected (auth required).
- The A2A chat API remains protected and is not opened by this skill.

---

## What Gets Added

Two HTTP endpoints on the agent:
- GET /agent-card — full Agent Card for external consumption (primary, authenticated)
- GET /.well-known/agent.json — minimal Agent Card at canonical path (authenticated)

New/updated files in the agent project:
```
.            # repo root
├── .well-known/
│   └── agent.json             # Full, public A2A Agent Card (rich metadata)
└── app/
    ├── agent_card.py          # Starlette route to serve and enrich /agent-card
    ├ main.py                # Updated to mount /agent-card
    ├── ord.py                 # If present (from ORD skill), extend to serve /.well-known/agent.json
    └── ord/
        └── agent.json         # Minimal A2A Agent Card aligned with internal types
```

ORD documents (if present, from sap-agent-ord-endpoint skill) are updated to reference `/agent-card` as a resourceDefinition of type `a2a-agent-card`.

---

## Phase 1: Read Existing Agent Configuration

Gather values from the current project to populate Agent Card files.

Run these reads (or open the files):
```bash
cat app.yaml || true
cat app/main.py || true
cat pyproject.toml || cat package.json || true
cat README.md || true
```

Extract (with fallbacks):
- Agent Title (name)
  - Prefer: AgentCard(name=...) in app/main.py
  - Else: metadata.name in app.yaml transformed to Title Case (e.g., travel-expense-agent → Travel Expense Agent)
  - Else: repository directory name transformed to Title Case
- Description
  - Prefer: AgentCard(description=...) in app/main.py
  - Else: first paragraph of README.md
  - Else: "Agent that provides AI capabilities."
- Version
  - Prefer: internal AgentCard version or framework value
  - Else: pyproject.toml/package.json version
  - Else: "1.0.0"
- Default input/output modes (REQUIRED per A2A v1.0.0)
  - Prefer: from internal AgentCard/framework
  - Else: ["text/plain", "application/json"]
- Capabilities (per A2A v1.0.0)
  - streaming: boolean (default: true)
  - pushNotifications: boolean (default: false)
  - extendedAgentCard: boolean (default: false)
  - extensions: array of AgentExtension (default: [])
- Skills (REQUIRED per A2A v1.0.0 - must have at least one)
  - Each skill requires: id, name, description, tags
  - Prefer: framework-provided skills listing
  - Else: create a default skill based on agent name/description

If any value cannot be inferred, use a sensible placeholder and add a TODO comment inside the JSON (e.g., "TODO: set homepage").

---

## Phase 2: Create Agent Card Files

Create both card files with initial content (you may refine later based on runtime introspection or developer edits).

### 2a. Create `app/ord/agent.json` (full internal Agent Card)

Copy the template file for the full agent card into `app/ord/agent.json`:

**macOS/Linux:**

```bash
mkdir -p app/ord
SKILL_PATH=$(find . -type d -name "sap-agent-agent-card-endpoint" -path "*/skills/*" 2>/dev/null | head -1)
cp "$SKILL_PATH/templates/agent-card-full.json" app/ord/agent.json
```

**Windows PowerShell:**

```powershell
New-Item -ItemType Directory -Force -Path app/ord
$SkillPath = Get-ChildItem -Path . -Recurse -Directory -Filter "sap-agent-agent-card-endpoint" | Where-Object { $_.FullName -like "*skills*" } | Select-Object -First 1 -ExpandProperty FullName
Copy-Item "$SkillPath/templates/agent-card-full.json" -Destination "app/ord/agent.json"
```

Important:
- Do not try to hardcode BASE_URL in this file. It will be injected dynamically at request time by `app/agent_card.py` (Phase 3).
- Edit the resulting JSON file to replace the other placeholders for which you have the correct value, and which are not explicitly indicated to not be changed.
- Arrays can remain empty for the initial version. The developer can fill skills/examples later.

### 2b. Create `.well-known/agent.json` (minimal public Agent card)

Copy the template file for the minimal agent card into `.well-known/agent.json`:

**macOS/Linux:**

```bash
mkdir -p app/ord
SKILL_PATH=$(find . -type d -name "sap-agent-agent-card-endpoint" -path "*/skills/*" 2>/dev/null | head -1)
cp "$SKILL_PATH/templates/agent-card-minimal.json" .well-known/agent.json
```

**Windows PowerShell:**

```powershell
New-Item -ItemType Directory -Force -Path app/ord
$SkillPath = Get-ChildItem -Path . -Recurse -Directory -Filter "sap-agent-agent-card-endpoint" | Where-Object { $_.FullName -like "*skills*" } | Select-Object -First 1 -ExpandProperty FullName
Copy-Item "$SkillPath/templates/agent-card-minimal.json" -Destination ".well-known/agent.json"
```

Important:
- Edit the resulting JSON file to replace the placeholders for which you have the correct value.

Note:
- The minimal Agent Card aligns to the internal AgentCard used by the A2A runtime (name, description, url, version, default modes, capabilities, skills).

---

## Phase 3: Expose the Endpoints

### 3a. Add `app/agent_card.py` to serve GET /agent-card (authenticated)

Copy the `templates/agent_card.py` file to `app/agent_card.py`:

**macOS/Linux:**

```bash
mkdir -p app/ord
SKILL_PATH=$(find . -type d -name "sap-agent-agent-card-endpoint" -path "*/skills/*" 2>/dev/null | head -1)
cp "$SKILL_PATH/templates/agent_card.py" app/agent_card.py
```

**Windows PowerShell:**

```powershell
New-Item -ItemType Directory -Force -Path app/ord
$SkillPath = Get-ChildItem -Path . -Recurse -Directory -Filter "sap-agent-agent-card-endpoint" | Where-Object { $_.FullName -like "*skills*" } | Select-Object -First 1 -ExpandProperty FullName
Copy-Item "$SkillPath/templates/agent_card.py" -Destination "app/agent_card.py"
```

Mount this route in `app/main.py` (or equivalent server entrypoint). For example, if you are already combining routes (e.g., with ORD):

```python
# app/main.py
import uvicorn
import logging
from starlette.applications import Starlette
from starlette.routing import Mount, Route

from agent_card import load_and_enrich_agent_card

logger = logging.getLogger(__name__)

def build_app(a2a_app):
    # Add /agent-card before mounting the A2A app
    routes = [
        Route("/agent-card", endpoint=load_and_enrich_agent_card, methods=["GET"]),
        Mount("/", app=a2a_app),
    ]
    return Starlette(routes=routes)

if __name__ == "__main__":
    host = "0.0.0.0"
    port = int(os.getenv("PORT", "5000"))

    # Build your existing A2A app via your framework code
    # a2a_app = server.build()  # example; existing code
    a2a_app = server.build()  # keep your current build invocation

    combined_app = build_app(a2a_app)
    logger.info(f"Starting agent with Agent Card at http://{host}:{port}/agent-card")
    uvicorn.run(combined_app, host=host, port=port)
```

Adjust import paths or combination to match your codebase. If you already combined with ORD per the ORD skill, simply include `Route("/agent-card", ...)` alongside `*create_ord_routes()` and `Mount("/", app=a2a_app)`.

### 3b. Serve GET /.well-known/agent.json (publich, minimal card)

If you have `app/ord.py` from the ORD skill, append a route that returns the minimal card:

```python
# app/ord.py  (append within this module)
from starlette.routing import Route
from starlette.responses import JSONResponse

def _serve_minimal_agent_card(request):
    p = Path(__file__).resolve().parent / "ord" / "agent.json"
    with p.open("r", encoding="utf-8") as f:
        data = json.load(f)
    return JSONResponse(data)

def create_ord_routes():
    # ... existing ORD routes ...
    routes = [
        # existing ORD routes added here...
        Route("/.well-known/agent.json", _serve_minimal_agent_card, methods=["GET"]),
    ]
    return routes
```

If you don’t have `app/ord.py`, you can expose this directly in `app/main.py` similarly to `/agent-card`, pointing to `app/ord/agent.json`.

---

## Phase 4: Authentication in `app.yaml`

Ensure the Agent Card endpoints are JWT-protected, and ORD remains open:

For a basic agent (single rule initially):
```yaml
service:
  apiAuth:
    - path: /agent-card
      type: jwt
    - path: /.well-known/agent.json
      type: no_auth
    # Keep ORD open (if installed)
    - path: /open-resource-discovery/{**}
      type: no_auth
    - path: /.well-known/open-resource-discovery
      type: no_auth
    # Fallback for the rest
    - path: /*
      type: jwt
```

Notes:
- Ordering matters. Specific routes must appear before the catch-all.
- Do not open `/api/v1/a2a/chat`. It remains JWT-protected via the fallback `/` rule or more specific rules in your project.

---

## Phase 5: Reference the Agent Card from ORD

If you have the ORD documents from the `sap-agent-ord-endpoint` skill (`app/ord/document-system-version.json` and `app/ord/document-system-instance.json`), ensure they reference the primary `/agent-card`.

If you have ORD documents, it is likely that they already contain some information about agent card. This information needs to be updated with what this skill provides. If the information does not exist, it should be created.

Within each JSON file’s `apiResources[]` element for your agent’s A2A API, use this snippet as reference:

```json
{
  "apiResources": [
    // ...
    // Previously existing apiResources here
    // ...
    {
      "ordId": "{{AGENT_NAMESPACE}}:apiResource:{{AGENT_ORD_ID}}-api:v1",
      "title": "{{AGENT_TITLE}}",
      "apiProtocol": "a2a",  // Indicates this is an A2A protocol API
      "resourceDefinitions": [
        {
          "type": "a2a-agent-card",
          "mediaType": "application/json",
          "url": "/agent-card",
          "accessStrategies": [{ "type": "open" }]
        }
      ],
      // Which Entity Types does this agent API expose?
      "exposedEntityTypes": [
        { "ordId": "{{AGENT_NAMESPACE}}:entityType:EntityA:v1" },
        { "ordId": "{{AGENT_NAMESPACE}}:entityType:EntityB:v1" }
      ],
      // ...
    }
  ]
}
```

- If `apiResources[]` does not exist, add a new entry following your project’s pattern.
- If `apiResources[]` already exists, either update the entry with same "title" and "apiProtocol" or add a new entry following the template above.
- Ensure that `resourceDefinitions.url` do not contain a double slash at the end, such as `<prefix>//agent-card`. It should end with a single slash for the endpoint: `<prefix>/agent-card`.
- If your governance requires documenting access strategies, note (optionally) via a custom description that the endpoint is protected by JWT at the gateway.

---

## Phase 6: Provider vs. Subscriber Tenants

- The JSON payload is typically tenant-agnostic. If you need tenant-aware card differences, you may inspect JWT claims in the handler and adjust labels or telemetry. Do not change schema shape.
- The `AGENT_PUBLIC_URL` environment variable (when set in the environment) is used by `agent_card.py` to render absolute communication.endpoint. If not set, the handler derives the base URL from the incoming request’s Host/Scheme. This ensures correctness for both provider and subscriber hosts.

---

## Phase 7: Test Locally

Start the agent locally (see your run-local flow). Then:

```bash
# Replace <JWT> with a valid token if your local gateway is enforcing JWT locally;
# otherwise, remove the header for local-only testing if your dev setup permits.
curl -s -H "Authorization: Bearer <JWT>" http://localhost:5000/agent-card | python3 -m json.tool

curl -s -H "Authorization: Bearer <JWT>" http://localhost:5000/.well-known/agent.json | python3 -m json.tool
```

Verify:
- 200 responses with valid JSON
- Full card contains (per A2A v1.0.0):
  - `supportedInterfaces` array with at least one interface containing `url`, `protocolBinding`, `protocolVersion`
  - `supportedInterfaces[0].url` equals http://localhost:5000 (if AGENT_PUBLIC_URL not set)
  - `capabilities` object with `streaming`, `pushNotifications` fields
  - `defaultInputModes` and `defaultOutputModes` arrays
  - `skills` array with at least one skill containing `id`, `name`, `description`, `tags`
- Minimal card contains name/description/version/supportedInterfaces/capabilities/defaultInputModes/defaultOutputModes/skills

If ORD docs exist:
```bash
jq '.apiResources[]?.resourceDefinitions[]? | select(.type=="a2a-agent-card")' app/ord/document-system-version.json
jq '.apiResources[]?.resourceDefinitions[]? | select(.type=="a2a-agent-card")' app/ord/document-system-instance.json
```

---

## Phase 8: Deployed Testing

These steps happen after the agent is deployed. You should inform the developer that they can perform such steps, but do not attempt to run them yourself.

After deployment:
```bash
# Provider tenant
curl -s -H "Authorization: Bearer <PROVIDER_JWT>" "https://<provider-host>/agent-card" | python3 -m json.tool
curl -s -H "Authorization: Bearer <PROVIDER_JWT>" "https://<provider-host>/.well-known/agent.json" | python3 -m json.tool

# Subscriber tenant
curl -s -H "Authorization: Bearer <SUBSCRIBER_JWT>" "https://<subscriber-host>/agent-card" | python3 -m json.tool
curl -s -H "Authorization: Bearer <SUBSCRIBER_JWT>" "https://<subscriber-host>/.well-known/agent.json" | python3 -m json.tool
```

Expect:
- 200 with authenticated access
- `supportedInterfaces[0].url` reflects the correct host (based on AGENT_PUBLIC_URL or request Host)

For ORD (if installed):
```bash
# ORD endpoints are open (no token required)
curl -s "https://<agent-url>/.well-known/open-resource-discovery" | python3 -m json.tool
curl -s "https://<agent-url>/open-resource-discovery/v1/documents/system-version" | python3 -m json.tool
curl -s "https://<agent-url>/open-resource-discovery/v1/documents/system-instance" | python3 -m json.tool
```
Check that the A2A resource definition points to `/agent-card`.

---

## Phase 9: Empower developer

After implementing everything described, you should finish the interaction by providing the developer with clear and concise information on how to pick up ownership of the development.

You should inform the files that were created or edited.

You should inform which fields used dummy values and should be updated with specific information about the project, and where to make the changes.

You should inform the developer to use this reference documentation in case of any doubts, or to understand the process better: https://pages.github.tools.sap/CentralEngineering/open-resource-discovery-specification/spec-v1/concepts/ai-agents-and-protocols 

You should also add a section in the AGENTS.md (or equivalent agentic instructions guidelines the project has, such as CLAUDE.md, etc.) and README.md with a brief comment that this project uses ORD and A2A protocol, and include this link for further reference: https://pages.github.tools.sap/CentralEngineering/open-resource-discovery-specification/spec-v1/concepts/ai-agents-and-protocols 

---

## Placeholder Derivation Rules

| Placeholder               | Derivation                                                                 | Example                                 |
| ------------------------- | -------------------------------------------------------------------------- | --------------------------------------- |
| {{AGENT_TITLE}}           | AgentCard(name=...) or Title Case of app.yaml metadata.name or repo dir    | Travel Expense Agent                     |
| {{AGENT_DESCRIPTION}}     | AgentCard(description=...) or README first paragraph or dummy              | Agent that provides AI capabilities.     |
| {{VERSION}}               | Internal AgentCard or pyproject/package.json version or "1.0.0"           | 1.0.0                                    |
| {{BASE_URL}}              | Dynamically injected at runtime from AGENT_PUBLIC_URL or request Host      | https://agent.example.com                |
| {{AGENT_ICON_URL_OR_EMPTY}}     | If known icon URL else ""                                             | ""                                       |
| {{AGENT_DOCUMENTATION_URL_OR_EMPTY}} | If known documentation URL else ""                               | ""                                       |
| {{PUBLISHER_NAME_OR_SAP_SE}}    | Organization name or "SAP SE"                                        | SAP SE                                   |
| {{PUBLISHER_URL_OR_SAP}}        | Organization URL or "https://www.sap.com"                            | https://www.sap.com                      |
| {{SKILL_ID}}              | Derived from agent name (kebab-case) or "default-skill"                    | travel-expense-submission                |
| {{SKILL_NAME}}            | Derived from agent name or "Default Skill"                                 | Travel Expense Submission                |
| {{SKILL_DESCRIPTION}}     | Derived from agent description or "Primary capability of this agent"       | Submit and track travel expenses         |
| {{SKILL_TAG_1}}, {{SKILL_TAG_2}} | Keywords from agent description or generic tags                      | expenses, travel                         |

---

## Implementation Notes and Options

- Using runtime AgentCard: If your framework provides an internal AgentCard object, you may generate `/agent-card` from it at request time rather than relying on the static `.well-known/agent.json`. Keep `/.well-known/agent.json` minimal and static.
- Health checks: If you want to add a container health check, you can probe `/.well-known/agent.json`.
- Labels and metadata: The developer can expand the full Agent Card with domains, skills, examples, and integrations over time. The initial version may keep arrays empty for speed of onboarding.
- Security: Do not expose the A2A chat endpoint without auth. The gateway rules protect it via `/` catch-all or an explicit rule.

---

## Quick Checklist (What this skill expects to complete)

- Create .well-known/agent.json (minimal) and app/ord/agent.json (full)
- Add app/agent_card.py and mount GET /agent-card route
- Serve GET /.well-known/agent.json from app/ord.py (or main) using minimal card
- Update app.yaml to require JWT for `/agent-card`
- Ensure that ORD endpoints already exist - if they do not, run `sap-agent-ord-endpoint` skill and clearly inform the user that this extra step was done
- Keep ORD endpoints open (no_auth)
- Update ORD documents to include resourceDefinitions of type `a2a-agent-card` pointing to `/agent-card`
- Inform the user that if a deploy has already been done, the `version` field of the agent card `apiResources` entry should be incremented, otherwise UMS will not update the resource
- Test locally and after deployment for both provider and subscriber tenants
- Write a clear, concise and informative message to the user describing what has been done, and including the references (links, etc.) you have, as well as anything that is explicitly said in this skill you should tell the developer, and what other skills were used during the process with the reasoning for that
- Finish with a short checklist of what the developer should double check for correctness and completeness, including double checking if the endpoints are protected as expected, if the URLs in agent card and ORD endpoints are correct, and if more capabilities can already be included beyond the mininal version that was created

---

## Reference

- A2A Agent Card Schema: https://sap.github.io/ai-sdk-js/schemas/agent-card-v1.schema.json
- ORD Agents and Protocols (provided in resources): see `resources/ord-agents-and-protocols.txt`
- Example cards (provided in resources):
  - `.well-known/agent.json` — minimal public card
  - `app/ord/agent.json` — full internal-aligned card
- Related skill: `sap-agent-ord-endpoint` for ORD endpoints and documents
