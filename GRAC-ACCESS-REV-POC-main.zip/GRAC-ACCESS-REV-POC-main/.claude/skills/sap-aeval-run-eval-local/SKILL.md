---
name: aeval-run-eval
description:  Runs agent evaluation tests locally using the Aeval framework and MLflow tracking. Use when the user wants to run evaluations or view evaluation results. 
---
# Run Agent Evaluation with Aeval

Execute agent evaluation test cases using the Aeval framework and view the results.

> **Note:** This skill contains macOS-optimized commands. The AI assistant should detect the current OS and adjust commands accordingly for Linux or Windows environments. 

## Prerequisites

**This skill requires Aeval to be set up first.** If you haven't run the `aeval-set-up` skill yet, do that before continuing.

You should have:
- **Aeval framework installed** - Virtual environment with Aeval and Agent dependencies
- **Agent configuration file** - `agent-config.yaml` with agent details
- **Test cases** - YAML files in the test cases directory
- **Environment file** - `.env.local` or `.env` with required credentials

If any of these are missing, stop and run the `aeval-set-up` skill to set up the evaluation framework before proceeding.

# Step by step instructions

## 0: Validate Prerequisites
- Check if `aeval` folder exists
```bash
find . -type d -name "aeval" -maxdepth 1
```
**If the folder is NOT found:** Stop skill immediately and inform the user: "The aeval folder is missing. Please run aeval-set-up first."

- Check if `.venv` exists
```bash
find . -maxdepth 3 -name ".venv" -type d
```
**If not found:** Stop skill immediately and inform the user: "No virtual environment found. Please run aeval-set-up first."
**If found:*** Use the <venv_path> to run the rest of the commands in this skill.

- Check if aeval library is installed in the virtual environment
```bash
<venv_path>/bin/aeval --version
```
**If version is not returned:** Stop skill immediately and inform user: "aeval is not installed. Please run aeval-set-up first." 


## 1: Review Agent Configuration

Read the current configuration and confirm it with the user:

```bash
cat aeval/configs/agent-config.yaml
```
The configuration should contain:
- **agent_base_url**: Where the agent server runs (e.g., `http://127.0.0.1:9000`)
- **mlflow.tracking_uri**: Where MLflow runs (e.g., `http://127.0.0.1:3333`)
- **experiment_id**: MLflow experiment ID (usually `0` or `my-experiment`)

**IMPORTANT - Local Host Configuration:**
- **Always use `127.0.0.1` instead of `localhost`** for local hosting
- This ensures consistent networking behavior and avoids DNS resolution issues
- Verify that both `agent-config.yaml` and `app/.env.local` use `127.0.0.1`

Show the user these configuration values and ask whether the user would like to proceed with these values or if the user would like to change any one of them.

### a. Update Configuration
If the user has provided a different value for any of the configuration values, update `agent-config.yaml` and `.env.local` accordingly.

## 3: Ensure Servers Are Running

### a. Check and Start MLflow [if needed]

- Extract port from `mlflow.tracking_uri` (e.g., `3333` from `http://127.0.0.1:3333`)
- Kill any existing process on the MLflow port to ensure clean restart.
```bash
lsof -ti :<port> | xargs kill
```
- Activate the virtual environment, <venv_path>
- Start MLflow server in the background
```bash
# change directory to where mlflow server db should be run
cd $(find . -type d -path "*/aeval/mlflow" | head -1) 

# Start MLflow server
mlflow server --port <port> --allowed-hosts "localhost:*,host.docker.internal:*,127.0.0.1:*" 
```
- Wait for MLflow to be ready before starting agent server

**Important**: Keep the MLflow server terminal running as it is required for trace export during evaluation. You should see output indicating that the server is running and listening on the specified port.


**Critical**: Ensure the mlflow server is running successfuly before starting the agent server, otherwise the agent will start with instrumentation disabled which will cause eval failure.

### b.Check and Start Agent Server (In a separate terminal)
**Determine how the agent is running:**
 - Check the `OTEL_EXPORTER_OTLP_ENDPOINT` in `app/.env.local`:
 ```bash
 grep OTEL_EXPORTER_OTLP_ENDPOINT app/.env.local
 ```           
  - If it contains `host.docker.internal`:
    - Agent runs inside a Docker container
  - If 127.0.0.1 is present:
    - Agent runs directly on host (native Python process)
  - If variable is missing or unclear:
  ```
  Question: "How do you run your agent locally: directly with Python, or in a Docker container?"
  Options:
  1. "Python Virtual Environment"
  2. "Docker"
  ```
- Extract port from `agent_base_url` (e.g., `9000` from `http://127.0.0.1:9000`)

**If using Python Virtual Environment:**
- Kill any existing process on the agent port to ensure clean restart for local set up.
```bash
lsof -ti :<port> | xargs kill
```
- Activate the virtual environment, <venv_path>
- Start Agent Server in the background
```bash
export $(grep -v '^#' app/.env.local | xargs) && python app/main.py --port <port>
```

**If using Docker:**:

Check if a docker container is already running on the required port. If not, identify and start the correct container.
- Check what's running on the agent port (e.g., 9000) and extract <container_name>
  ```bash
  docker ps --filter "publish=<port>" --format "table {{.Names}}\t{{.Ports}}\t{{.Image}}\t{{.Status}}"
  ```
- **Critical:** If cannot connect to the Docker daemon, inform the user to start Docker and re-run this command. Do not proceed until Docker is running and the command can be executed successfully.

- **If a container is found:**
  ```
  Question: "Agent running in container: '<container_name>', image: '<image_name>' on port '<port>'. Is this correct?"
  Options:["Yes","No"]
  ```
  - **If "Yes":** proceed with verifying logs

- **If no container is found:**
  - List all containers for user
  ```bash
  docker ps -a
  ```
  ```
  Question: "Which container name should I use to start the agent?" 
  ```

- Re-start the docker container
  ```bash
  docker restart <container_name>
  ```
- Verify successful start ups from logs
```bash
docker logs <container-name> --tail 10
```
  - **Important:** If logs indicates "OTEL_EXPORTER_OTLP_ENDPOINT not set. Instrumentation will be disabled."
    - Stop and re-run the container with updated env variables
      - Extract agent port number from `agent_base_url ` in `app/.env.local` 
      ``` bash
      docker stop <container_name>
      docker rm <container_name>
      docker run --name <container_name> -p <port>:<port> --env-file app/.env.local <image_name>
      ```

## 4: Lint Test Cases

Before running evaluation, lint the test cases to check for errors. 
Ensure the bash directory is in the `aeval` folder and <venv_path> is activated.

```bash
cd $(find . -type d -path "*/aeval" | head -1) && aeval lint "/testcases"
```
### a. Lint Results Handling
| Result | Action |
|--------|--------|
| ✅ All test cases pass linting | Proceed to Step 5 |
| ⚠️ Some test cases have errors | Fix the errors, re-run lint,then proceed to Step 5 |
| ❌ All test cases fail linting | **TERMINATE** - Cannot proceed with evaluation |

## 5: Run Evaluation
Follow the command below to execute evaluation tests and generate reports. 
- Ensure the bash directory is in the `aeval` folder and <venv_path> activated, you have the correct paths and configuration before running.
```bash
cd $(find . -type d -path "*/aeval/" | head -1) && \
aeval --debug \
  --config="configs/agent-config.yaml" \
  --env-file="../app/.env.local" \
  run \
  --report-path="reports" \
  "testcases" \
  --include-html-report 
```

## 6: If eval run failed, troubleshoot

```bash
ls -la aeval/logs/
```
- Open the most recent log file and review the error messages to identify the cause of failure.
- Attempt to resolve the issue based on the error messages.
- If unable to resolve, revert to the initial failed state.

## 7: If eval run succeeded, review the generated reports
- Check the `aeval/reports` directory for the generated report files.
```bash
ls -la aeval/reports/
```
- Open the most recent HTML report in the browser.

## 8: Report Summary

If eval run is successful, provide evaluation summary to the user.
- summary of results
- any failed test cases
- next steps for improving agent performance based on results

If eval run is fail, read the log and provide failure summary to the user
- which aeval version 
- which mlflow version
- error messages from the log
- possible causes and next steps to fix the issue
- if possible cause is related to environment variable misconfiguration, inform user to run `aeval-set-up` skill to fix the environment variable configuration before running eval again.
