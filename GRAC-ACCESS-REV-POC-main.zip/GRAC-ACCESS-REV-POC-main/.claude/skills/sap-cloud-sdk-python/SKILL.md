---
name: sap-cloud-sdk-python
description: Integrate SAP BTP services into a Python app using the open-source SAP Cloud SDK for Python. Use when adding or wiring objectstore, destination, DMS, auditlog (v2 or NG), agent memory, IAS token parsing, AI Core, or other BTP service integrations on App Foundation. An additional usage is migration from older SAP Cloud SDK for Python versions.
---

# SAP Cloud SDK for Python — Integration Guide

## Overview

The [SAP Cloud SDK for Python](https://github.com/SAP/cloud-sdk-python) is the open-source SDK for integrating BTP services from Python applications. This skill covers the **App Foundation wiring pattern** common to all modules. For detailed API usage, follow the per-module user guides linked below — they are the authoritative source.

> The legacy internal Application Foundation Python SDK is deprecated. Concepts that existed there but **do not exist** in the open-source SDK include `APPFND_LOCALDEV_*` local-mode env vars, `RuntimeContext().is_local()`, and a `subscription_manager` module. **Do NOT introduce them.**

## Installation

The package is published as `sap-cloud-sdk` on PyPI. All packages MUST be installed from SAP's internal PyPI proxy. Never use `pypi.org/simple` or `--extra-index-url`.
If a package is not found on the SAP proxy, report the error — **do NOT fall** back to public PyPI.

## Common App Foundation Wiring Pattern

All `sap-cloud-sdk` integrations and/or wirings should be declared on the app.yaml file, at the root of the project, following the pattern:

### 1. Declare the service in `app.yaml`

```yaml
requires:
  - name: <instance-name>
    service: <service-type>
    plan: <plan>
```

The `name` field becomes the instance identifier used in code (`create_client(instance="<instance-name>")`). The `service` field is the technical service name (e.g., `destination`, `objectstore`, `sdm` for DMS, etc.). The `plan` field depends on the service and your subscription. Always refer to the specific module's user guide for the correct `service` name and any additional required parameters.

> **Note — Some services are NOT provisioned via `requires`.** Before adding a `requires` entry, check the table below. If your service appears there, follow its specific provisioning mechanism instead.

| Service | SDK module | Provisioning on Managed Runtime | Reference |
|---------|------------|---------------------------------|-----------|
| Audit Log NG (v3) | `core.auditlog_ng` | The platform automatically mounts the mTLS certificate out-of-the-box. No `requires` entry and no `app.yaml` change needed. You must implement a SPII endpoint in code to receive the formation and persist the deployment ID. | [Audit Log Service v3 docs](https://pages.github.tools.sap/application-foundation/agent-runtime-domains/agent-code/auditlog-service-v3/) |
| Agent Memory | `agent_memory` | Add `spec.hanaAgentMemoryEnabled: true` to your `app.yaml` (not a `requires` entry). Infrastructure must be requested first via a support ticket. | [HANA Agent Memory docs](https://pages.github.tools.sap/application-foundation/agent-runtime-domains/agent-code/hana-agent-memory/) |
| Agent Gateway | `agentgateway` | SPII formation protocol — no `app.yaml` flag required. You must implement the SPII endpoint (`PATCH /v1/tenantMappings/{tenantId}`) in your agent code. | [Agent Gateway docs](https://pages.github.tools.sap/application-foundation/agent-runtime-domains/agent-code/integration/) |

### 2. Create a client

```python
from sap_cloud_sdk.<module> import create_client

client = create_client(instance="<instance-name>")
```

### 3. Credential resolution

The SDK resolves credentials in this priority order — no manual configuration is needed when bindings are set up correctly:

1. **Mounted secrets** (Kubernetes/servicebinding.io): by default, the resolver looks for secrets under `/etc/secrets/appfnd/<module>/<instance>/<field>`. You can override this base path by setting the `SERVICE_BINDING_ROOT` environment variable. For LoB agents, `SERVICE_BINDING_ROOT` is not needed.
2. **Environment variables**: `CLOUD_SDK_CFG_<MODULE>_<INSTANCE>_<FIELD>` — uppercased, hyphens replaced with underscores. Useful for local development by exporting credentials directly.

Example for the destination service, instance `default`:
```bash
export CLOUD_SDK_CFG_DESTINATION_DEFAULT_CLIENTID="..."
export CLOUD_SDK_CFG_DESTINATION_DEFAULT_CLIENTSECRET="..."
export CLOUD_SDK_CFG_DESTINATION_DEFAULT_URL="https://auth.region.hana.ondemand.com"
export CLOUD_SDK_CFG_DESTINATION_DEFAULT_URI="https://destination.cf.region.hana.ondemand.com"
export CLOUD_SDK_CFG_DESTINATION_DEFAULT_IDENTITYZONE="<subdomain>"
```

## Module Reference

Each module has its own user guide in the repo — always consult it for current APIs and types.

| Module | `service` in app.yaml | User guide |
|--------|----------------------|------------|
| `objectstore` | `objectstore` | [objectstore](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/objectstore/user-guide.md) |
| `destination` | `destination` | [destination](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/destination/user-guide.md) |
| `dms` | `sdm` | [dms](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/dms/user-guide.md) |
| `core.auditlog` | `auditlog` | [auditlog](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/core/auditlog/user-guide.md) |
| `core.auditlog_ng` | (mTLS, see guide) | [auditlog_ng](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/core/auditlog_ng/user-guide.md) |
| `ias` | (token parsing, no binding) | [ias](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/ias/user-guide.md) |
| `aicore` | `aicore` | [aicore](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/aicore/user-guide.md) |
| `agentgateway` | per guide | [agentgateway](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/agentgateway/user-guide.md) |
| `agent_memory` | `hana-agent-memory` | [agent_memory](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/agent_memory/user-guide.md) |
| `agent_decorators` | n/a | [agent_decorators](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/agent_decorators/user-guide.md) |
| `extensibility` | per guide | [extensibility](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/extensibility/user-guide.md) |
| `core.telemetry` | n/a | [telemetry](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/core/telemetry/user-guide.md) |
| `core.secret_resolver` | n/a | [secret_resolver](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/core/secret_resolver/user-guide.md) |

### Auditlog

For new integrations, use **Auditlog NG (v3)** via `sap_cloud_sdk.core.auditlog_ng`. It uses OTLP/gRPC with mTLS and supports both protobuf and JSON payloads. See the [auditlog_ng user guide](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/core/auditlog_ng/user-guide.md) for endpoint, deployment ID, and certificate configuration.

The legacy v2 module (`sap_cloud_sdk.core.auditlog`) is still available for existing integrations — see its [user guide](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/core/auditlog/user-guide.md) if needed.

### Agent Memory

`sap_cloud_sdk.agent_memory` provides persistent agent memory backed by SAP HANA Cloud. Data is scoped by `agent_id` (the agent owning the data) and `invoker_id` (the user/caller).

**app.yaml configuration:**

Set this flag in your `app.yaml` to enable the service binding. The platform will provision the volume mount at `/etc/secrets/appfnd/hana-agent-memory/default`.

```yaml
spec:
  hanaAgentMemoryEnabled: true
```

**Imports and client:**
```python
from sap_cloud_sdk.agent_memory import (
    create_client,
    AgentMemoryConfig,
    Memory,
    Message,
    MessageRole,
    SearchResult,
)

with create_client() as client:
    ...
```

For explicit credentials (not recommended in production):
```python
config = AgentMemoryConfig(
    base_url="https://<service-host>",
    token_url="https://<tenant>.authentication.<region>/oauth/token",
    client_id="<client-id>",
    client_secret="<client-secret>",
)
client = create_client(config=config)
```

**Memory operations** — long-lived facts:
```python
memory = client.add_memory(
    agent_id="my-agent",
    invoker_id="user-123",
    content="The user prefers dark mode and metric units.",
    metadata={"source": "preferences"},
)

client.get_memory(memory_id=memory.id)
client.update_memory(memory_id=memory.id, content="Updated content")
client.delete_memory(memory_id=memory.id)

memories = client.list_memories(agent_id="my-agent", invoker_id="user-123", limit=20)

results = client.search_memories(  # semantic / cosine-similarity search
    agent_id="my-agent",
    invoker_id="user-123",
    query="What are the user's display preferences?",
    threshold=0.6,
    limit=5,
)
```

**Message operations** — conversation turns grouped by `message_group`:
```python
client.add_message(
    agent_id="my-agent",
    invoker_id="user-123",
    message_group="conv-001",
    role=MessageRole.USER,        # USER | ASSISTANT | SYSTEM | TOOL
    content="What is the weather like today?",
)

messages = client.list_messages(
    agent_id="my-agent",
    invoker_id="user-123",
    message_group="conv-001",
    role=MessageRole.USER,
    limit=50,
)
```

**Errors**, in the context of `AgentMemoryError`, are subclasses of  (`AgentMemoryConfigError`, `AgentMemoryValidationError`, `AgentMemoryHttpError`, `AgentMemoryNotFoundError`). All model objects expose `to_dict()`.

See the [agent_memory user guide](https://github.com/SAP/cloud-sdk-python/blob/main/src/sap_cloud_sdk/agent_memory/user-guide.md) for retention configuration and the full API.

## IAS Token Parsing

`sap_cloud_sdk.ias` extracts claims from IAS-issued JWTs. It does **not** validate signatures — verification must already have been performed by your framework's middleware.

```python
from sap_cloud_sdk.ias import parse_token

claims = parse_token(request.headers["Authorization"])
```

## Migration from the legacy internal SDK

When porting code from the deprecated internal Application Foundation Python SDK:

- Replace internal package imports with `from sap_cloud_sdk.<module> import ...`
- **Remove** any `APPFND_LOCALDEV_*` env vars and `RuntimeContext().is_local()` checks — the open-source SDK has no local-mode toggle. Local dev relies on the standard `CLOUD_SDK_CFG_*` env-var fallback.
- **Remove** `sap_cloud_sdk.subscription_manager` usage — it does not exist in the open-source SDK. For multi-tenant subscription lifecycle, use the appropriate BTP service directly (e.g., SaaS Provisioning callbacks implemented as your own HTTP endpoints).
- Credential resolution from `/etc/secrets/appfnd/...` and the `CLOUD_SDK_CFG_*` pattern is unchanged.

Always cross-check the [SAP/cloud-sdk-python](https://github.com/SAP/cloud-sdk-python) repository — the per-module user guides there are the source of truth.
