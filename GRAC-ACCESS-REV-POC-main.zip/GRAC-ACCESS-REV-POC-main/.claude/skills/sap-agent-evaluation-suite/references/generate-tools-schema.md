# Generate Tools Schema

Internal procedure used by the `sap-agent-evaluation-suite` skill (Step 2, Case B) when it needs to derive `tools.json` from a codebase.

## Inputs

- `code_path` — root of the agent codebase to inspect
- `output_path` — full path where `tools.json` should be saved (set by the caller; for the suite skill this is `<prd_dir>/tools.json`)

## Important guidelines

**DO NOT hallucinate or generate information that is not present in the codebase.**

- Only extract tool schemas from actual function definitions in the code
- Use docstrings and type hints as-is; do not invent parameter descriptions
- If a function lacks a docstring or type annotations, note it as incomplete rather than guessing
- Omit tools that cannot be meaningfully parsed

## Step 1 — Read the README and discover tools

Read `README.md` in `code_path` to identify the project structure and locate the tools directory (typically `app/tools/` or `src/tools/`). List all Python files in that directory.

## Step 2 — Extract tool schemas

For each tool file found, parse the Python code to extract:
- Function name (the tool name)
- Function docstring (description)
- Function parameters with their types and descriptions
- Return type and description

Build a schema for each tool following this JSON structure:

```json
{
  "name": "tool_name",
  "description": "Tool description from docstring",
  "input-type": ["semantic_type"],
  "output-type": ["semantic_type"],
  "input": {
    "param_name": {
      "type": "string|integer|array|object|boolean",
      "description": "Parameter description"
    }
  },
  "output": {
    "type": "object|array|string",
    "description": "Output description",
    "properties": {}
  }
}
```

## Step 3 — Generate `tools.json`

Combine all tool schemas into a single JSON file:

```json
{
  "tools": [
    { /* tool 1 schema */ },
    { /* tool 2 schema */ }
  ]
}
```

Save it to `output_path` exactly.

## Step 4 — Report results

After generating the file, report:
1. Path to the generated `tools.json`
2. Summary of tools discovered
3. List of tools with incomplete schemas (missing docstrings, untyped parameters, etc.)
