---
name: sap-sdk-python-destination
description: Integrate SAP BTP Destination Service using the Application Foundation Python SDK. Use when the user needs to manage destinations, fragments, or certificates for HTTP connections in a Python application.
---

# Destination Service Integration with Python SDK

This skill provides guidance for integrating the SAP BTP Destination Service using the Application Foundation Python SDK. The destination module provides three specialized clients for managing destinations, fragments, and certificates at subaccount and service instance levels.

## ⚠️ Package Index Policy

All Python packages MUST be installed exclusively from the SAP PyPI proxy:
`https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple`

NEVER use `https://pypi.org/simple` or any other external package index.
NEVER add `--extra-index-url` pointing to PyPI.
If a package is not found in the SAP proxy, report the error — do NOT fall back to PyPI.

## app.yaml Configuration

To use the Destination service, add the following to your `app.yaml` under `spec.requires`:

```yaml
requires:
  - name: my-destination
    service: destination
    plan: lite
```

**Fields:**
- `name`: Instance name for the destination service (used in your code with `create_client(instance="my-destination")`)
- `service`: Must be `destination`
- `plan`: Use `lite` for the lite plan

## Installation

For the latest features including V2 Runtime API and Transparent Proxy support, ensure you install the latest version:

```bash
# Using uv (recommended) - latest version
uv add sap-cloud-sdk --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"

# Using pip - latest version
pip install --upgrade sap-cloud-sdk --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"

# Or specify minimum version for V2 API and Transparent Proxy features
pip install "sap-cloud-sdk>=0.2.0" --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"
```

📋 **SDK Version Note:** V2 Runtime API and Transparent Proxy features require `sap-cloud-sdk>=0.2.0`. Always use the latest version to access all available features.

## Quick Start

```python
from sap_cloud_sdk.destination import (
    create_client,
    create_fragment_client,
    create_certificate_client,
    Level,
    AccessStrategy,
    ConsumptionOptions
)

# Create clients (auto-detects local vs cloud mode)
client = create_client(instance="default")
fragment_client = create_fragment_client(instance="default")
certificate_client = create_certificate_client(instance="default")

# Instance-level read
dest = client.get_instance_destination("my-destination")
fragment = fragment_client.get_instance_fragment("my-fragment")
cert = certificate_client.get_instance_certificate("my-cert")

# Subaccount-level read: provider only (no tenant required)
dest = client.get_subaccount_destination("my-destination", access_strategy=AccessStrategy.PROVIDER_ONLY)

# Subaccount-level read: subscriber-first (tenant required), fallback to provider
dest = client.get_subaccount_destination("my-destination", access_strategy=AccessStrategy.SUBSCRIBER_FIRST, tenant="tenant-subdomain")

# V2 Runtime API - Get destination with automatic token retrieval
dest = client.get_destination("my-api")
# With options for fragment and tenant context
options = ConsumptionOptions(fragment_name="production", tenant="tenant-1")
dest = client.get_destination("my-api", options=options)
```

## Concepts

### Level
- `SERVICE_INSTANCE`: Operates on instance destinations
- `SUB_ACCOUNT`: Operates on subaccount destinations

### AccessStrategy (for subaccount reads)
- `SUBSCRIBER_ONLY`: Only subscriber (tenant required)
- `PROVIDER_ONLY`: Only provider (no tenant)
- `SUBSCRIBER_FIRST`: Try subscriber, fallback to provider (tenant required)
- `PROVIDER_FIRST`: Try provider, fallback to subscriber (tenant required)

## Destination Client

### V1 Admin API (Traditional Operations)

```python
from sap_cloud_sdk.destination import create_client, Destination, Level, AccessStrategy

client = create_client(instance="default")

# Get destinations
dest = client.get_instance_destination("my-destination")
dest = client.get_subaccount_destination("my-destination", access_strategy=AccessStrategy.PROVIDER_ONLY)

# With tenant for subscriber access
dest = client.get_subaccount_destination(
    "my-destination", 
    access_strategy=AccessStrategy.SUBSCRIBER_FIRST, 
    tenant="tenant-subdomain"
)

# List destinations
all_dests = client.list_instance_destinations()
sub_dests = client.list_subaccount_destinations(access_strategy=AccessStrategy.PROVIDER_ONLY)

# Create destination
new_dest = Destination(
    name="my-http-dest",
    type="HTTP",
    url="https://api.example.com",
    proxy_type="Internet",
    authentication="NoAuthentication"
)
client.create_destination(new_dest, level=Level.SUB_ACCOUNT)

# Update destination
new_dest.description = "Updated description"
client.update_destination(new_dest, level=Level.SUB_ACCOUNT)

# Delete destination
client.delete_destination("my-http-dest", level=Level.SUB_ACCOUNT)
```

### V2 Runtime API (Destination Consumption)

⚠️ **Requires SDK ≥0.2.0** - The V2 API is designed for runtime consumption with automatic token retrieval:

```python
from sap_cloud_sdk.destination import create_client, Level, ConsumptionOptions

client = create_client(instance="default")

# Basic destination consumption, searching on instance level as default
dest = client.get_destination("my-api")

# With fragment and tenant context
options = ConsumptionOptions(fragment_name="production", tenant="tenant-1")
dest = client.get_destination("my-api", options=options)

# Search only at specific level for optimized lookup
dest = client.get_destination("my-api", level=Level.SERVICE_INSTANCE)  # Instance only
dest = client.get_destination("my-api", level=Level.SUB_ACCOUNT)       # Subaccount only

# The V2 API returns destinations with populated auth_tokens and certificates
if dest and dest.auth_tokens:
    for token in dest.auth_tokens:
        print(f"Token type: {token.type}")
        print(f"Headers: {token.http_header}")
        if token.expires_in:
            print(f"Expires in: {token.expires_in}")
```

## Transparent Proxy Support

⚠️ **Requires SDK ≥0.2.0** - The destination client supports routing requests through a transparent proxy, enabling access to on-premise systems and private network resources through a proxy deployed in your Kubernetes cluster.

### Configuration Options

#### 1. Client-Level Default (Recommended)

Enable proxy by default for all destination lookups:

```python
from sap_cloud_sdk.destination import create_client

# Enable transparent proxy by default (uses APPFND_CONHOS_TRANSP_PROXY env var)
client = create_client(instance="default", use_default_proxy=True)

# All get operations will use proxy by default
dest = client.get_instance_destination("my-destination")
# Returns TransparentProxyDestination
```

Set the environment variable with format `{proxy_name}.{namespace}`:

```bash
export APPFND_CONHOS_TRANSP_PROXY="connectivity-proxy.my-namespace"
```

#### 2. Explicit Proxy Configuration

Set custom proxy configuration after client creation:

```python
from sap_cloud_sdk.destination import create_client, TransparentProxy

# Create client first
client = create_client(instance="default")

# Set custom proxy configuration
transparent_proxy = TransparentProxy(proxy_name="connectivity-proxy", namespace="my-namespace")
client.set_proxy(transparent_proxy)
```

#### 3. Per-Request Override

Override the client's default proxy setting for individual requests:

```python
# Client with proxy enabled by default
client = create_client(instance="default", use_default_proxy=True)

# Override to NOT use proxy for this specific request
dest = client.get_instance_destination("my-destination", proxy_enabled=False)
# Returns regular Destination

# Or explicitly enable proxy (even if client default is False)
client2 = create_client(instance="default", use_default_proxy=False)
dest2 = client2.get_instance_destination("my-destination", proxy_enabled=True)
# Returns TransparentProxyDestination
```

### Proxy Usage Examples

```python
from sap_cloud_sdk.destination import create_client, TransparentProxy, ConsumptionOptions, Level

# Example 1: Using environment variable with default proxy
client = create_client(instance="default", use_default_proxy=True)
dest = client.get_instance_destination("my-destination")
# Uses proxy from APPFND_CONHOS_TRANSP_PROXY

# Example 2: V2 API with proxy support
client = create_client(instance="default", use_default_proxy=True)
dest = client.get_destination("my-api", proxy_enabled=True)
# Returns TransparentProxyDestination

# Example 3: V2 API with ConsumptionOptions and proxy disabled
client = create_client(instance="default", use_default_proxy=True)
options = ConsumptionOptions(fragment_name="production", tenant="tenant-1")
dest = client.get_destination("my-api", options=options, proxy_enabled=False)
# Returns regular Destination with merged fragment and tenant context

# Example 4: Subaccount destinations with proxy
dest = client.get_subaccount_destination(
    "my-destination", 
    access_strategy=AccessStrategy.PROVIDER_ONLY,
    proxy_enabled=True
)
# Returns TransparentProxyDestination
```

### TransparentProxyDestination

When proxy is enabled, methods return a `TransparentProxyDestination`:

```python
# TransparentProxyDestination properties:
client = create_client(instance="default", use_default_proxy=True)
proxy_dest = client.get_instance_destination("my-destination")

print(proxy_dest.name)      # "my-destination" 
print(proxy_dest.url)       # "http://connectivity-proxy.my-namespace"
print(proxy_dest.headers)   # {"X-destination-name": "my-destination"}

# Use with HTTP requests
import requests
response = requests.get(proxy_dest.url + "/api/data", headers=proxy_dest.headers)
```

### Important Notes

- Transparent proxy is **only available in cloud mode** (not in local development)
- Proxy configuration is required when using `proxy_enabled=True`
- The proxy service retrieves the actual destination configuration
- Available for all get methods: `get_instance_destination()`, `get_subaccount_destination()`, and `get_destination()`

## Fragment Client

Manage destination fragments (reusable configuration snippets):

```python
from sap_cloud_sdk.destination import create_fragment_client, Fragment, Level

fragment_client = create_fragment_client(instance="default")

# Get fragments
fragment = fragment_client.get_instance_fragment("my-fragment")
fragment = fragment_client.get_subaccount_fragment("my-fragment", access_strategy=AccessStrategy.PROVIDER_ONLY)

# List fragments
all_fragments = fragment_client.list_instance_fragments()

# Create fragment
new_fragment = Fragment(
    name="api-override",
    properties={"URL": "https://api-staging.example.com"}
)
fragment_client.create_fragment(new_fragment, level=Level.SUB_ACCOUNT)

# Update fragment
new_fragment.properties["Authentication"] = "OAuth2ClientCredentials"
fragment_client.update_fragment(new_fragment, level=Level.SUB_ACCOUNT)

# Delete fragment
fragment_client.delete_fragment("api-override", level=Level.SUB_ACCOUNT)
```

## Certificate Client

Manage certificates for mTLS and authentication:

```python
from sap_cloud_sdk.destination import create_certificate_client, Certificate, Level

certificate_client = create_certificate_client(instance="default")

# Get certificates
cert = certificate_client.get_instance_certificate("my-cert")
cert = certificate_client.get_subaccount_certificate("my-cert", access_strategy=AccessStrategy.PROVIDER_ONLY)

# List certificates
all_certs = certificate_client.list_instance_certificates()

# Create certificate (content should be base64-encoded)
import base64
with open("cert.pem", "rb") as f:
    cert_content = base64.b64encode(f.read()).decode()

new_cert = Certificate(
    name="my-cert.pem",
    content=cert_content,
    type="PEM"
)
certificate_client.create_certificate(new_cert, level=Level.SUB_ACCOUNT)

# Delete certificate
certificate_client.delete_certificate("my-cert.pem", level=Level.SUB_ACCOUNT)
```

## Models

```python
from sap_cloud_sdk.destination import (
    Destination,
    Fragment,
    Certificate,
    ConsumptionOptions,
    AuthToken,
    TransparentProxy,
    TransparentProxyDestination,
    ListOptions,
    PagedResult,
    PaginationInfo
)

# Destination model (V1 API and V2 API with auth_tokens/certificates populated)
dest = Destination(
    name="my-dest",
    type="HTTP",
    url="https://api.example.com",
    proxy_type="Internet",
    authentication="NoAuthentication",
    description="My HTTP destination",
    properties={"custom_key": "custom_value"},
    auth_tokens=[],  # Populated by V2 API
    certificates=[]  # Populated by V2 API
)

# ConsumptionOptions for V2 API
options = ConsumptionOptions(
    fragment_name="production",  # Optional: fragment to merge
    tenant="tenant-1"            # Optional: tenant context
)

# AuthToken model (returned by V2 API)
auth_token = AuthToken(
    type="Bearer",
    value="eyJhbGciOiJIUzI1NiIs...",
    http_header={"Authorization": "Bearer eyJhbGciOiJIUzI1NiIs..."},
    expires_in="3600",
    error=None,
    scope="read write",
    refresh_token="refresh_token_value"
)

# Fragment model
fragment = Fragment(
    name="my-fragment",
    properties={"URL": "https://override.example.com"}
)

# Certificate model (content is base64-encoded)
cert = Certificate(
    name="my-cert.pem",
    content="LS0tLS1CRUdJTi...",
    type="PEM"  # PEM, JKS, P12, etc.
)

# TransparentProxy configuration
transparent_proxy = TransparentProxy(
    proxy_name="connectivity-proxy",
    namespace="my-namespace"
)

# TransparentProxyDestination (returned when proxy_enabled=True)
proxy_dest = TransparentProxyDestination(
    name="my-destination",
    url="http://connectivity-proxy.my-namespace",
    headers={"X-destination-name": "my-destination"}
)

# Pagination with ListOptions
options = ListOptions(name="api", skip=0, top=10)
results = client.list_instance_destinations(filter=options)

for dest in results.items:
    print(f"{dest.name}: {dest.url}")

if results.pagination and results.pagination.next_cursor:
    print(f"More results available")
```

### Model Details

**Destination:**
- `auth_tokens` and `certificates` fields are populated by the V2 consumption API
- Unknown string-valued fields are captured in `properties` dict
- Non-string unknown fields are ignored

**ConsumptionOptions:**
- Used with V2 `get_destination()` method
- `fragment_name`: Name of fragment to merge with destination
- `tenant`: Tenant context for multi-tenant scenarios

**AuthToken:**
- Returned by V2 API with ready-to-use HTTP headers
- `http_header` dict contains headers like `{"Authorization": "Bearer token"}`
- `expires_in` indicates token validity period

**TransparentProxyDestination:**
- Returned when `proxy_enabled=True`
- `url` points to the proxy endpoint
- `headers` contains required proxy headers like `X-destination-name`

## Error Handling

```python
from sap_cloud_sdk.destination import (
    DestinationError,
    ClientCreationError,
    ConfigError,
    HttpError,
    DestinationOperationError,
    DestinationNotFoundError
)

try:
    dest = client.get_instance_destination("missing-dest")
except DestinationNotFoundError:
    print("Destination not found")
except DestinationOperationError as e:
    print(f"Operation failed: {e}")
except HttpError as e:
    print(f"HTTP error {e.status_code}: {e.response_text}")
```

## Local Development Mode

Enable local mode for development:

```bash
export APPFND_LOCALDEV_DESTINATION=true
```

### Local Mock Files

Create mock files in your project root:

**mocks/destination.json:**
```json
{
  "subaccount": [
    { "Name": "sub-http", "Type": "HTTP", "URL": "https://example.com", "ProxyType": "Internet", "Authentication": "NoAuthentication" }
  ],
  "instance": [
    { "Name": "inst-http", "Type": "HTTP", "URL": "https://provider.example.com" }
  ]
}
```

**mocks/fragments.json:**
```json
{
  "subaccount": [
    { "FragmentName": "api-override", "URL": "https://api-staging.example.com" }
  ],
  "instance": []
}
```

**mocks/certificates.json:**
```json
{
  "subaccount": [
    { "Name": "cert1.pem", "Content": "base64-encoded-content", "Type": "PEM" }
  ],
  "instance": []
}
```

## Cloud Mode Configuration

In cloud mode, credentials are resolved from:
- Mounted secrets at `/etc/secrets/appfnd/destination/{instance}/`
- Environment variables: `APPFND_CFG_DESTINATION_{INSTANCE}_{FIELD}`

Required fields: `clientid`, `clientsecret`, `url`, `uri`, `identityzone`
