---
name: sap-agent-bootstrap-pydanticai
description: Bootstrap a complete App Foundation agent project using PydanticAI. Use when the user wants to create a new AI agent with PydanticAI instead of LangGraph, for a lighter-weight alternative with lower RAM usage.
---
# App Foundation Agent Bootstrap (PydanticAI)

Creates a ready-to-deploy AI agent for SAP App Foundation with A2A protocol, PydanticAI, SAP AI Core integration, and GitHub Actions CI/CD.

## Instructions

Follow these 3 phases in order:

### Phase 1: Collect User Input

Ask the user to provide exactly 2 values BEFORE any file operations:

```
Question 1: "Please enter your agent name (e.g., expense-tracker-agent):"
Question 2: "Please enter your agent description (e.g., 'An AI agent that tracks business expenses'):"
```

**Example interaction:**
- User wants: "Create an agent to help with travel expenses"
- Agent name: `travel-expense-agent`
- Agent description: `An AI agent that helps employees manage and submit travel expenses`

### Phase 2: Copy Templates (Deterministic)

Run the appropriate shell command based on user's OS:

**macOS/Linux:**
```bash
mkdir -p app .github/workflows
SKILL_PATH=$(find . -type d -name "sap-agent-bootstrap-pydanticai" -path "*/skills/*" 2>/dev/null | head -1)
cp -r "$SKILL_PATH/templates/." ./
```

**Windows PowerShell:**
```powershell
New-Item -ItemType Directory -Force -Path app, .github/workflows
$SkillPath = Get-ChildItem -Path . -Recurse -Directory -Filter "sap-agent-bootstrap-pydanticai" | Where-Object { $_.FullName -like "*skills*" } | Select-Object -First 1 -ExpandProperty FullName
Get-ChildItem "$SkillPath/templates" -Force | Copy-Item -Destination "./" -Recurse -Force
```

### Phase 3: Replace Placeholders (Deterministic)

Use shell commands to replace all placeholders. Derive values from the 2 inputs collected in Phase 1.

**macOS/Linux:**

Use multiple `-e` flags per file to ensure all replacements are applied atomically:

```bash
# Replace in app.yaml
sed -i '' \
  -e 's/{{AGENT_NAME}}/<agent-name>/g' \
  -e 's/{{AGENT_NAMESPACE}}/<agent-name>/g' \
  app.yaml

# Replace in README.md
sed -i '' \
  -e 's/{{AGENT_TITLE}}/<Agent Title>/g' \
  -e 's/{{AGENT_DESCRIPTION}}/<agent-description>/g' \
  README.md

# Replace in app/main.py
sed -i '' \
  -e 's/{{AGENT_ID}}/<agent-name>/g' \
  -e 's/{{AGENT_NAME}}/<agent-name>/g' \
  -e 's/{{AGENT_SKILL_DESCRIPTION}}/<agent-description>/g' \
  -e 's/{{AGENT_CARD_DESCRIPTION}}/<agent-description>/g' \
  -e 's/{{AGENT_TAGS}}/<tags-list>/g' \
  -e 's/{{AGENT_EXAMPLES}}/<examples-list>/g' \
  app/main.py

# Replace in app/agent.py
sed -i '' \
  -e 's/{{SYSTEM_PROMPT}}/<system-prompt>/g' \
  app/agent.py
```

**Note for Linux:** Use `sed -i` instead of `sed -i ''` (no empty quotes after `-i`).

**Windows PowerShell:**
```powershell
# Replace in app.yaml
(Get-Content app.yaml) -replace '{{AGENT_NAME}}','<agent-name>' | Set-Content app.yaml
(Get-Content app.yaml) -replace '{{AGENT_NAMESPACE}}','<agent-name>' | Set-Content app.yaml

# Replace in README.md
(Get-Content README.md) -replace '{{AGENT_TITLE}}','<Agent Title>' | Set-Content README.md
(Get-Content README.md) -replace '{{AGENT_DESCRIPTION}}','<agent-description>' | Set-Content README.md

# Replace in app/main.py
(Get-Content app/main.py) -replace '{{AGENT_ID}}','<agent-name>' | Set-Content app/main.py
(Get-Content app/main.py) -replace '{{AGENT_NAME}}','<agent-name>' | Set-Content app/main.py
(Get-Content app/main.py) -replace '{{AGENT_SKILL_DESCRIPTION}}','<agent-description>' | Set-Content app/main.py
(Get-Content app/main.py) -replace '{{AGENT_CARD_DESCRIPTION}}','<agent-description>' | Set-Content app/main.py
(Get-Content app/main.py) -replace '{{AGENT_TAGS}}','<tags-list>' | Set-Content app/main.py
(Get-Content app/main.py) -replace '{{AGENT_EXAMPLES}}','<examples-list>' | Set-Content app/main.py

# Replace in app/agent.py
(Get-Content app/agent.py) -replace '{{SYSTEM_PROMPT}}','<system-prompt>' | Set-Content app/agent.py
```

## Placeholder Derivation Rules

Derive all 10 placeholders from the 2 user inputs:

| Placeholder | Derivation | Example Value |
|-------------|------------|---------------|
| `{{AGENT_NAME}}` | Direct from input | `travel-expense-agent` |
| `{{AGENT_NAMESPACE}}` | Same as AGENT_NAME | `travel-expense-agent` |
| `{{AGENT_ID}}` | Same as AGENT_NAME | `travel-expense-agent` |
| `{{AGENT_TITLE}}` | Title-case: replace `-` with space, capitalize | `Travel Expense Agent` |
| `{{AGENT_TAGS}}` | Split AGENT_NAME by `-` into Python list | `["travel", "expense", "agent"]` |
| `{{AGENT_DESCRIPTION}}` | Direct from input | `An AI agent that helps employees manage and submit travel expenses` |
| `{{AGENT_SKILL_DESCRIPTION}}` | Same as AGENT_DESCRIPTION | `An AI agent that helps employees manage and submit travel expenses` |
| `{{AGENT_CARD_DESCRIPTION}}` | Same as AGENT_DESCRIPTION | `An AI agent that helps employees manage and submit travel expenses` |
| `{{SYSTEM_PROMPT}}` | Template: `You are {AGENT_DESCRIPTION}. Help users with their requests.` | `You are an AI agent that helps employees manage and submit travel expenses. Help users with their requests.` |
| `{{AGENT_EXAMPLES}}` | Generate 2 example prompts based on description | `["Help me submit a travel expense", "What are the expense policies?"]` |

## Project Structure

```
./
├── .github/workflows/dev-ci-cd.yml
├── app.yaml
├── Dockerfile
├── requirements.txt
├── .gitignore
├── README.md
└── app/
    ├── __init__.py
    ├── main.py
    ├── agent_executor.py
    └── agent.py
```

## Optional: External Services

Add to `app.yaml` under `spec.requires`:

```yaml
  requires:
    - name: default
      service: auditlog
      plan: oauth2
    - name: my-destination
      service: destination
      plan: lite
    - name: my-object-store
      service: objectstore
      plan: standard
```

## Customization

- **Model**: Change in `app.yaml` (models list) and `agent.py` (LiteLLMModel)
- **Tools**: Add PydanticAI tools in `agent.py`
- **Skills**: Add `AgentSkill` definitions in `main.py`

## ⚠️ Package Index Policy

All Python packages MUST be installed exclusively from the SAP PyPI proxy:
`https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple`

NEVER use `https://pypi.org/simple` or any other external package index.
NEVER add `--extra-index-url` pointing to PyPI.
If a package is not found in the SAP proxy, report the error — do NOT fall back to PyPI.

The project includes a `pip.conf` that enforces this. Do not override or bypass it.

## ⚠️ Important: Dependencies

**Note:** Dependencies listed in `requirements.txt` are NOT installed during the bootstrap process. They will be installed:
- **Locally**: When you run the agent using the `sap-agent-run-local` skill
- **In the cluster**: Automatically during the deployment process via CI/CD pipeline

The bootstrap process only creates the project structure and configuration files. No local Python environment setup is performed at this stage.

## Next Steps

After presenting all the above information, ask the user how they would like to proceed:

```
"How would you like to proceed with your agent?"

Options:
1. "🚀 Deploy remotely - Commit and push to trigger CI/CD"
2. "💻 Run locally - Set up and run the agent on my machine"
3. "📚 Tell me more about the project structure"
```

Based on the user's choice:

- **Option 1 (Deploy remotely)**:
  1. First, ask if the user wants to customize key parts before deploying:
     ```
     "Before deploying, would you like to edit any of these key files?"

     Options:
     - "✏️ Edit system prompt (app/agent.py)"
     - "✏️ Edit agent skills/description (app/main.py)"
     - "✏️ Edit model configuration (app.yaml)"
     - "✅ No changes needed - deploy now"
     ```
  2. If user chooses to edit, help them make the changes and ask again.
  3. When user selects "No changes needed - deploy now", execute:
     ```bash
     git add -A
     git commit -m "feat: bootstrap <agent-name> agent"
     git push origin main
     ```
  4. After push succeeds, inform: "Code pushed! CI/CD pipeline is deploying your agent. Check GitHub Actions for progress."
  5. Then ask: "Would you like to test the deployed agent once it's ready?" - If yes, activate `sap-agent-test-remote` skill.

- **Option 2 (Run locally)**: Immediately invoke the `sap-agent-run-local` skill. Do NOT just mention the skill - actually load and execute it.

- **Option 3 (More info)**: Provide detailed explanations about the files and architecture
