import logging
from dataclasses import dataclass
from typing import AsyncGenerator, Literal

from pydantic_ai import Agent
from pydantic_ai_litellm import LiteLLMModel

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """{{SYSTEM_PROMPT}}"""


@dataclass
class AgentResponse:
    status: Literal["input_required", "completed", "error"]
    message: str


class SampleAgent:
    SUPPORTED_CONTENT_TYPES = ["text", "text/plain"]

    def __init__(self):
        self.model = LiteLLMModel("sap/anthropic--claude-4.5-sonnet")
        self.agent = Agent(self.model, system_prompt=SYSTEM_PROMPT)

    async def stream(self, query: str, context_id: str) -> AsyncGenerator[dict, None]:
        yield {"is_task_complete": False, "require_user_input": False, "content": "Processing..."}
        try:
            result = await self.agent.run(query)
            response = result.output
            yield {"is_task_complete": True, "require_user_input": False, "content": response}
        except Exception as e:
            yield {"is_task_complete": True, "require_user_input": False, "content": f"Error: {e}"}

    def invoke(self, query: str, context_id: str) -> AgentResponse:
        import asyncio
        try:
            result = asyncio.run(self.agent.run(query))
            response = result.output
            return AgentResponse(status="completed", message=response)
        except Exception as e:
            return AgentResponse(status="error", message=f"Error: {e}")
