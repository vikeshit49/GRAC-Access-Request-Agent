# Prebuilt Nodes & Features Catalog

Reference documentation for all prebuilt components available in this skill.
Each component is adapted from the [CAB Agent Template](https://github.tools.sap/AI-HUB-LOB/cab-agent-template).

---

## Prebuilt Nodes

### Context Management

**File**: `nodes/context_management.py`
**Factory**: `make_context_management_node(llm, strategy, ...)`
**Position**: Before agent node

Keeps conversations within the LLM's context window by either summarizing
older messages into a running summary or trimming to the N most recent.

**Strategies**:
- `summarize` (default): Uses LLM to create/extend a running summary when token
  usage exceeds `context_pressure_threshold * max_context_length`
- `trim`: Keeps only the last `max_messages` messages

**State extension required**: `context: dict[str, Any]` with default:
```python
{
    "running_summary": "",
    "last_summarized_index": -1,
    "num_tokens_in_running_summary": 0,
    "num_tokens_in_new_messages": 0,
    "total_tokens": 0,
}
```

**Parameters**:
| Parameter | Default | Description |
|-----------|---------|-------------|
| `strategy` | `"summarize"` | `"summarize"` or `"trim"` |
| `max_messages` | `30` | For trim: max messages to keep |
| `max_context_length` | `50000` | For summarize: token budget |
| `context_pressure_threshold` | `0.75` | Fraction that triggers summarization |

---

### Task Planning

**File**: `nodes/task_planning.py`
**Factory**: `make_task_planning_node(llm)`
**Position**: Before agent node (after context management, if present)

Creates a step-by-step execution plan based on the user's query and available
tools. The plan guides the agent on which tools to call and in what order.

**State extension required**: `tools_schema: Optional[dict]`

**Prompt**: `prompts/prompt_planning.txt` — planning expert prompt with tool awareness

---

### Query Decomposition

**File**: `nodes/query_decomposition.py`
**Factory**: `make_query_decomposition_node(llm)`
**Position**: Before agent node

Breaks complex multi-part queries into ordered sub-questions. Each sub-question
can then be addressed independently.

**No state extension required.**

**Prompt**: `prompts/prompt_query_decomposition.txt`

---

### Direct Instruction

**File**: `nodes/direct_instruction.py`
**Factory**: `make_direct_instruction_node(llm)`
**Position**: Before agent node

Transforms vague user queries into clear, actionable instructions.
For example: "I need a recipe" → "Respond with a recipe for a chocolate cake"

**No state extension required.**

**Prompt**: `prompts/prompt_query_enhancement.txt`

---

### Refinement

**File**: `nodes/refinement.py`
**Factory**: `make_refinement_node(llm)`
**Position**: After agent node (before END)

Refines the agent's response into well-structured Markdown format.

**No state extension required.**

**Prompt**: `prompts/prompt_refinement.txt`

---

### Format Node

**File**: `nodes/format_node.py`
**Factory**: `make_format_node(llm)`
**Position**: After agent node (before END)

Formats responses according to a template. Can be combined with structured
output for JSON schema enforcement.

**No state extension required.**

**Prompt**: `prompts/prompt_format.txt`

---

## Prebuilt Features

### Concurrent Tool Executor

**File**: `features/tool_executor.py`
**Class**: `ConcurrentToolExecutor`

Drop-in replacement for LangGraph's `ToolNode` with:
- **Parallel execution**: All tool calls run via `asyncio.gather()`
- **Response caching**: Optional in-memory cache (per tool name + args hash)
- **Response summarization**: Optional LLM summarization of long responses

```python
from features.tool_executor import ConcurrentToolExecutor

executor = ConcurrentToolExecutor(
    tools=my_tools,
    enable_caching=True,
    tools_to_summarize={"long_response_tool"},
    summarization_llm=llm,
)
builder.add_node("tools", executor.ainvoke)
```

---

### MCP Tools Integration

**File**: `features/mcp_tools.py`
**Functions**: `load_mcp_tools()`, `load_mcp_tools_from_list()`

Connect to MCP servers and get LangChain `BaseTool` instances.

**Requires**: `langchain-mcp-adapters` in requirements.txt

```python
from features.mcp_tools import load_mcp_tools

tools = await load_mcp_tools({
    "my_server": {
        "url": "http://localhost:8000/mcp",
        "transport": "streamable_http",
    }
})
llm_with_tools = llm.bind_tools(tools)
```

---

### Structured Output

**File**: `features/structured_output.py`
**Function**: `json_schema_to_pydantic(schema, model_name)`

Convert JSON Schema → Pydantic model → wrap LLM with `with_structured_output()`.

```python
from features.structured_output import json_schema_to_pydantic

schema = {
    "type": "object",
    "properties": {"summary": {"type": "string"}, "score": {"type": "number"}},
    "required": ["summary"],
}
ResponseModel = json_schema_to_pydantic(schema, "Response")
structured_llm = llm.with_structured_output(ResponseModel)
```

---

### Multi-Agent Orchestration

**File**: `features/multi_agent.py`
**Functions**: `add_sub_agent_node()`, `build_sub_agent()`
**Class**: `BaseStateMapper`

Compose sub-agents as nodes in a parent graph.

**Modes**:
- **Shared state** (default): Sub-agent operates directly on parent state
- **Isolated state**: Use `BaseStateMapper` to transform state at boundaries
- **Async execution**: Fire-and-forget for background tasks

```python
from features.multi_agent import add_sub_agent_node, build_sub_agent

sub_graph = build_sub_agent(
    state_class=AgentState,
    nodes=[("agent", agent_fn), ("tools", tool_executor.ainvoke)],
    edges=[("__start__", "agent"), ("tools", "agent")],
    conditional_edges=[("agent", tools_condition, {"tools": "tools", "__end__": "__end__"})],
)
add_sub_agent_node(main_builder, "data_retrieval", sub_graph)
```

---

## Common Graph Patterns

### Pattern 1: Basic Agent with Context Management
```
START → context_management → call_model → END
```

### Pattern 2: Planning Pipeline
```
START → context_management → direct_instruction → query_decomposition → task_planning → call_model ⟷ tools → END
```

### Pattern 3: Full Pipeline with Refinement
```
START → context_management → direct_instruction → task_planning → call_model ⟷ tools → refinement → END
```

### Pattern 4: Multi-Agent Orchestrator
```
START → context_management → routing_node → [condition] → sub_agent_a / sub_agent_b → format → END
```
