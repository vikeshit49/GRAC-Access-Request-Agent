"""Structured Output — Enforce JSON schema on LLM responses.

Converts a JSON Schema dict into a Pydantic model at runtime, then wraps
an LLM with ``with_structured_output()`` to enforce the schema.

Adapted from cab-agent-template (AI-HUB-LOB/cab-agent-template).
"""

import logging
from typing import Any, Optional

from pydantic import BaseModel, create_model

logger = logging.getLogger(__name__)

_SUPPORTED_PRIMITIVE_TYPES = {"string", "integer", "number", "boolean"}


def _get_python_type(json_type: str) -> type:
    mapping = {
        "string": str,
        "integer": int,
        "number": float,
        "boolean": bool,
    }
    if json_type not in mapping:
        raise ValueError(f"Unsupported JSON Schema type: '{json_type}'")
    return mapping[json_type]


def _convert_property(
    prop_name: str,
    prop_schema: dict,
    required_fields: list[str],
    parent_model_name: str = "DynamicModel",
) -> tuple[Any, Any]:
    """Convert a JSON Schema property to a Pydantic field definition."""
    prop_type = prop_schema.get("type", "string")
    is_required = prop_name in required_fields

    if prop_type == "object":
        nested_model = json_schema_to_pydantic(
            prop_schema,
            model_name=f"{parent_model_name}_{prop_name.title()}",
        )
        return (nested_model, ...) if is_required else (Optional[nested_model], None)

    elif prop_type == "array":
        items_schema = prop_schema.get("items", {})
        items_type = items_schema.get("type", "string")
        if items_type == "object":
            item_model = json_schema_to_pydantic(
                items_schema,
                model_name=f"{parent_model_name}_{prop_name.title()}Item",
            )
            return (list[item_model], ...) if is_required else (Optional[list[item_model]], None)
        else:
            item_type = _get_python_type(items_type)
            return (list[item_type], ...) if is_required else (Optional[list[item_type]], None)

    else:
        python_type = _get_python_type(prop_type)
        return (python_type, ...) if is_required else (Optional[python_type], None)


def json_schema_to_pydantic(
    schema: dict,
    model_name: str = "DynamicModel",
) -> type[BaseModel]:
    """Convert a JSON Schema to a Pydantic model.

    Args:
        schema: JSON Schema dict with ``type``, ``properties``, and ``required`` fields.
        model_name: Name for the generated Pydantic model class.

    Returns:
        A dynamically created Pydantic ``BaseModel`` subclass.

    Supports: string, integer, number, boolean, array, nested object.
    Does NOT support: $ref, allOf, anyOf, oneOf, enum, const.

    Usage::

        schema = {
            "type": "object",
            "properties": {
                "summary": {"type": "string"},
                "confidence": {"type": "number"},
                "tags": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["summary"],
        }
        ResponseModel = json_schema_to_pydantic(schema, "AgentResponse")
        structured_llm = llm.with_structured_output(ResponseModel)
        response = await structured_llm.ainvoke(messages)
        # response is a ResponseModel instance
    """
    properties = schema.get("properties", {})
    required_fields = schema.get("required", [])

    field_definitions = {}
    for prop_name, prop_schema in properties.items():
        field_definitions[prop_name] = _convert_property(
            prop_name, prop_schema, required_fields, parent_model_name=model_name
        )

    return create_model(model_name, **field_definitions)
