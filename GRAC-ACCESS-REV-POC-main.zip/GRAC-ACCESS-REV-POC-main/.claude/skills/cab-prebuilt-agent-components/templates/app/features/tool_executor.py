"""Concurrent Tool Executor — Parallel tool execution with caching and summarization.

Drop-in replacement for LangGraph's ``ToolNode`` that provides:
- **Concurrent execution**: Tools run in parallel via ``asyncio.gather()``
- **Response caching**: Optional in-memory cache to skip redundant tool calls within a session
- **Response summarization**: Optional LLM summarization of long tool responses

Adapted from cab-agent-template (AI-HUB-LOB/cab-agent-template).
"""

import asyncio
import hashlib
import json
import logging
from typing import Any, Optional

from langchain_core.language_models import BaseLanguageModel
from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.tools import BaseTool

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# In-memory tool response cache
# ---------------------------------------------------------------------------

_tool_cache: dict[str, Any] = {}


def _cache_key(tool_name: str, args: dict) -> str:
    """Create a deterministic cache key from tool name and arguments."""
    raw = json.dumps({"tool": tool_name, "args": args}, sort_keys=True)
    return hashlib.sha256(raw.encode()).hexdigest()


# ---------------------------------------------------------------------------
# Summarization helper
# ---------------------------------------------------------------------------

SUMMARIZE_PROMPT = """You are a helpful assistant that summarizes tool outputs.
Summarize the following tool response concisely while preserving all important information.

Tool Name: {tool_name}
Tool Arguments: {tool_args}

Tool Response:
{tool_response}

Provide a concise summary:"""


async def _summarize(
    llm: BaseLanguageModel, tool_name: str, tool_args: dict, result: str
) -> str:
    """Summarize a tool response using the provided LLM."""
    from langchain_core.messages import SystemMessage

    truncated = result[:50000]
    if len(result) > 50000:
        truncated += "\n... [truncated]"
    prompt = SUMMARIZE_PROMPT.format(
        tool_name=tool_name, tool_args=str(tool_args), tool_response=truncated
    )
    try:
        response = await llm.ainvoke([SystemMessage(content=prompt)])
        return response.content
    except Exception as e:
        logger.warning("Summarization failed for %s: %s", tool_name, e)
        return result


# ---------------------------------------------------------------------------
# Main executor
# ---------------------------------------------------------------------------


class ConcurrentToolExecutor:
    """Execute tool calls from the latest AIMessage concurrently.

    Usage::

        from features.tool_executor import ConcurrentToolExecutor

        tools = [my_tool_a, my_tool_b]
        executor = ConcurrentToolExecutor(tools)
        # Use as a LangGraph node:
        builder.add_node("tools", executor.ainvoke)

    Args:
        tools: List of LangChain ``BaseTool`` instances.
        enable_caching: If True, cache tool responses in-memory per session.
        tools_to_summarize: Set of tool names whose responses should be
            summarized by an LLM before being returned to the agent.
        summarization_llm: LLM to use for summarization (required if
            ``tools_to_summarize`` is non-empty).
    """

    def __init__(
        self,
        tools: list[BaseTool],
        enable_caching: bool = False,
        tools_to_summarize: Optional[set[str]] = None,
        summarization_llm: Optional[BaseLanguageModel] = None,
    ):
        self.tools = tools
        self.tool_map: dict[str, BaseTool] = {t.name: t for t in tools}
        self.enable_caching = enable_caching
        self.tools_to_summarize = tools_to_summarize or set()
        self.summarization_llm = summarization_llm

    async def ainvoke(self, state: dict, **kwargs) -> dict:
        """Execute all pending tool calls concurrently.

        Reads tool calls from the last ``AIMessage`` in ``state["messages"]``,
        runs them in parallel, and returns ``ToolMessage`` results.
        """
        latest = state["messages"][-1]
        if not isinstance(latest, AIMessage) or not latest.tool_calls:
            return {"messages": []}

        tool_calls = latest.tool_calls

        async def _run_one(tc: dict) -> ToolMessage:
            tool_name = tc["name"]
            tool_id = tc["id"]
            args = tc.get("args") or {}

            tool = self.tool_map.get(tool_name)
            if tool is None:
                return ToolMessage(
                    content=f"Unknown tool: {tool_name}",
                    tool_call_id=tool_id,
                    name=tool_name,
                )

            # Check cache
            if self.enable_caching:
                key = _cache_key(tool_name, args)
                if key in _tool_cache:
                    logger.debug("Cache hit for %s", tool_name)
                    return ToolMessage(
                        content=str(_tool_cache[key]),
                        tool_call_id=tool_id,
                        name=tool_name,
                    )

            # Execute tool
            try:
                result = await tool.ainvoke(args)
            except Exception as e:
                logger.error("Tool %s failed: %s", tool_name, e)
                return ToolMessage(
                    content=f"Error executing {tool_name}: {e}",
                    tool_call_id=tool_id,
                    name=tool_name,
                )

            result_str = str(result)

            # Cache result
            if self.enable_caching:
                key = _cache_key(tool_name, args)
                _tool_cache[key] = result

            # Summarize if configured
            if tool_name in self.tools_to_summarize and self.summarization_llm:
                result_str = await _summarize(
                    self.summarization_llm, tool_name, args, result_str
                )

            return ToolMessage(
                content=result_str, tool_call_id=tool_id, name=tool_name
            )

        # Run all tool calls concurrently
        messages = await asyncio.gather(*[_run_one(tc) for tc in tool_calls])

        return {"messages": list(messages)}
