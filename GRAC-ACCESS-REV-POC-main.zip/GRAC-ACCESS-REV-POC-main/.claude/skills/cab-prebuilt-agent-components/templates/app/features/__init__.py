# Prebuilt features for LangGraph agents
# Adapted from the CAB Agent Template (https://github.tools.sap/AI-HUB-LOB/cab-agent-template)
