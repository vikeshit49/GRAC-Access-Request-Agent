"""Multi-Agent Orchestration — Compose sub-agents as graph nodes.

Helpers for building multi-agent systems where a main orchestrator graph
delegates to sub-agent graphs. Sub-agents can share state with the parent
or run with isolated state via a state mapper.

Adapted from cab-agent-template (AI-HUB-LOB/cab-agent-template).
"""

import logging
from typing import Any, Optional

from langchain_core.runnables import RunnableLambda
from langgraph.graph import StateGraph, START, END
from langgraph.graph.state import CompiledStateGraph
from langgraph.checkpoint.memory import MemorySaver

logger = logging.getLogger(__name__)


class BaseStateMapper:
    """Base class for mapping state between parent and sub-agent graphs.

    Override ``map_input`` and ``map_output`` to transform state when
    sub-agents use isolated state (different TypedDict than the parent).

    Example::

        class MyMapper(BaseStateMapper):
            def map_input(self, parent_state: dict) -> dict:
                return {
                    "messages": parent_state["messages"],
                    "agent_id": parent_state["agent_id"],
                }

            def map_output(self, parent_state: dict, sub_result: dict) -> dict:
                return {"messages": sub_result["messages"]}
    """

    def map_input(self, parent_state: dict) -> dict:
        """Map parent state to sub-agent input state."""
        return parent_state

    def map_output(self, parent_state: dict, sub_result: dict) -> dict:
        """Map sub-agent output back to parent state update."""
        return sub_result


def add_sub_agent_node(
    parent_builder: StateGraph,
    node_name: str,
    sub_agent_graph: CompiledStateGraph,
    state_mapper: Optional[BaseStateMapper] = None,
    async_execution: bool = False,
):
    """Add a compiled sub-agent graph as a node in the parent graph.

    Args:
        parent_builder: The parent ``StateGraph`` builder.
        node_name: Name for the sub-agent node in the parent graph.
        sub_agent_graph: A compiled sub-agent ``StateGraph``.
        state_mapper: Optional mapper for isolated state. If None, the sub-agent
            shares state directly with the parent (default behavior).
        async_execution: If True, the sub-agent runs fire-and-forget (the parent
            continues without waiting for the result). Useful for background tasks.

    Usage — shared state (default)::

        sub_graph = build_my_sub_agent()  # Returns CompiledStateGraph
        add_sub_agent_node(main_builder, "data_retrieval", sub_graph)

    Usage — isolated state::

        class DataMapper(BaseStateMapper):
            def map_input(self, parent_state):
                return {"messages": [parent_state["messages"][-1]]}
            def map_output(self, parent_state, sub_result):
                return {"messages": sub_result["messages"]}

        add_sub_agent_node(main_builder, "data_retrieval", sub_graph,
                          state_mapper=DataMapper())
    """
    if state_mapper is not None:
        # Isolated state — map parent ↔ sub-agent state
        async def mapped_node(state: dict) -> dict:
            sub_input = state_mapper.map_input(state)
            sub_result = await sub_agent_graph.ainvoke(sub_input)
            return state_mapper.map_output(state, sub_result)

        parent_builder.add_node(node_name, RunnableLambda(mapped_node))

    elif async_execution:
        # Fire-and-forget — kick off sub-agent without awaiting
        import asyncio

        async def async_node(state: dict) -> dict:
            asyncio.create_task(sub_agent_graph.ainvoke(state))
            return state

        parent_builder.add_node(node_name, RunnableLambda(async_node))

    else:
        # Shared state (default) — sub-agent operates directly on parent state
        parent_builder.add_node(node_name, sub_agent_graph)


def build_sub_agent(
    state_class: type,
    nodes: list[tuple[str, Any]],
    edges: list[tuple[str, str]],
    conditional_edges: Optional[list[tuple[str, Any, dict]]] = None,
    checkpointer: bool = True,
) -> CompiledStateGraph:
    """Build and compile a sub-agent graph.

    Convenience helper for constructing sub-agent graphs with a consistent
    pattern.

    Args:
        state_class: The TypedDict state class for the sub-agent.
        nodes: List of (name, function_or_runnable) tuples.
        edges: List of (from_node, to_node) tuples for fixed edges.
            Use ``"__start__"`` and ``"__end__"`` for START/END.
        conditional_edges: Optional list of (from_node, condition_fn, path_map) tuples.
        checkpointer: If True, use in-memory checkpointer.

    Returns:
        A compiled ``CompiledStateGraph``.

    Usage::

        from langgraph.prebuilt import tools_condition

        sub_graph = build_sub_agent(
            state_class=AgentState,
            nodes=[
                ("agent", agent_fn),
                ("tools", tool_executor.ainvoke),
            ],
            edges=[
                ("__start__", "agent"),
                ("tools", "agent"),
            ],
            conditional_edges=[
                ("agent", tools_condition, {"tools": "tools", "__end__": "__end__"}),
            ],
        )
    """
    builder = StateGraph(state_class)

    edge_map = {"__start__": START, "__end__": END}

    for name, fn in nodes:
        builder.add_node(name, fn)

    for from_node, to_node in edges:
        builder.add_edge(
            edge_map.get(from_node, from_node),
            edge_map.get(to_node, to_node),
        )

    for from_node, condition_fn, path_map in (conditional_edges or []):
        sanitized = {k: edge_map.get(v, v) for k, v in path_map.items()}
        builder.add_conditional_edges(
            edge_map.get(from_node, from_node), condition_fn, sanitized
        )

    if checkpointer:
        return builder.compile(checkpointer=MemorySaver())
    return builder.compile()
