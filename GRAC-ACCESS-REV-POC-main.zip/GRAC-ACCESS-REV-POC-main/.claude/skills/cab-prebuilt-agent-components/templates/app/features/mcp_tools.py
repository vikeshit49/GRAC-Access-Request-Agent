"""MCP Tools Integration — Connect to MCP servers and load tools.

Connects to one or more MCP (Model Context Protocol) servers and returns
LangChain ``BaseTool`` instances ready for ``llm.bind_tools()``.

Supports both stdio and streamable HTTP transports.

Adapted from cab-agent-template (AI-HUB-LOB/cab-agent-template).
"""

import logging
from typing import Optional

from langchain_core.tools import BaseTool

logger = logging.getLogger(__name__)


async def load_mcp_tools(
    server_config: dict,
    tool_filter: Optional[list[str]] = None,
) -> list[BaseTool]:
    """Load tools from MCP servers.

    Args:
        server_config: MCP server configuration dict. Keys are server names,
            values contain connection parameters. Example::

                {
                    "math_server": {
                        "command": "python",
                        "args": ["math_server.py"],
                        "transport": "stdio",
                    },
                    "api_server": {
                        "url": "http://localhost:8000/mcp",
                        "transport": "streamable_http",
                    },
                }

        tool_filter: Optional list of tool names to include. If None, all
            tools from all servers are returned.

    Returns:
        List of LangChain ``BaseTool`` instances.

    Requirements:
        - ``langchain-mcp-adapters`` must be installed
        - Add to requirements.txt: ``langchain-mcp-adapters``

    Usage::

        from features.mcp_tools import load_mcp_tools

        tools = await load_mcp_tools({
            "my_server": {
                "url": "http://localhost:8000/mcp",
                "transport": "streamable_http",
            }
        })
        llm_with_tools = llm.bind_tools(tools)
    """
    try:
        from langchain_mcp_adapters.client import MultiServerMCPClient
    except ImportError:
        raise ImportError(
            "langchain-mcp-adapters is required for MCP tools integration. "
            "Add 'langchain-mcp-adapters' to your requirements.txt."
        )

    client = MultiServerMCPClient(server_config)
    tools = await client.get_tools()

    if tool_filter is not None:
        allowed = set(tool_filter)
        tools = [t for t in tools if t.name in allowed]
        loaded_names = {t.name for t in tools}
        missing = allowed - loaded_names
        if missing:
            logger.warning("MCP tools not found: %s", missing)

    logger.info("Loaded %d MCP tools: %s", len(tools), [t.name for t in tools])
    return tools


async def load_mcp_tools_from_list(
    servers: list[dict],
) -> list[BaseTool]:
    """Load tools from a list of MCP server configurations.

    Convenience wrapper for loading from multiple servers with per-server
    tool filtering.

    Args:
        servers: List of server config dicts, each with keys:
            - ``server_name``: str — identifier for the server
            - ``server_parameters``: dict — connection parameters (url, transport, etc.)
            - ``tools``: Optional[list[str]] — tool names to include (None = all)

    Returns:
        Combined list of LangChain ``BaseTool`` instances from all servers.

    Usage::

        tools = await load_mcp_tools_from_list([
            {
                "server_name": "hcm",
                "server_parameters": {
                    "url": "https://example.com/mcp",
                    "transport": "streamable_http",
                },
                "tools": ["get_employee", "get_goals"],
            },
        ])
    """
    all_tools: list[BaseTool] = []
    for server in servers:
        name = server["server_name"]
        params = server["server_parameters"]
        tool_filter = server.get("tools")
        tools = await load_mcp_tools({name: params}, tool_filter=tool_filter)
        all_tools.extend(tools)
    return all_tools
