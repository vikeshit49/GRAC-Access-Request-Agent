"""Format Node — Format and structure agent responses.

Converts the agent's response into a specific format. Can be combined
with structured output to enforce a JSON schema on the response.

Adapted from cab-agent-template (AI-HUB-LOB/cab-agent-template).
"""

import os

from langchain_core.language_models import BaseLanguageModel
from langchain_core.prompts import ChatPromptTemplate


def _read_prompt(filename: str) -> str:
    prompts_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "prompts")
    filepath = os.path.join(prompts_dir, filename)
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()


def make_format_node(llm: BaseLanguageModel):
    """Create a format node function.

    Args:
        llm: Language model used for formatting. Can be wrapped with
            ``with_structured_output()`` for JSON schema enforcement.

    Returns:
        An async function compatible with LangGraph ``StateGraph.add_node()``.

    State requirements:
        - ``messages``: ``Annotated[list, add_messages]``

    Example with structured output::

        from features.structured_output import json_schema_to_pydantic

        schema = {"type": "object", "properties": {"summary": {"type": "string"}}, "required": ["summary"]}
        model = json_schema_to_pydantic(schema, "ResponseFormat")
        structured_llm = llm.with_structured_output(model)
        format_fn = make_format_node(structured_llm)
    """
    system_prompt = _read_prompt("prompt_format.txt")
    chat_prompt = ChatPromptTemplate([("system", system_prompt), ("user", "")])

    async def format_node(state: dict) -> dict:
        prompt = chat_prompt.format_messages(text=state["messages"][-1])
        response = await llm.ainvoke(prompt)

        # Handle structured output (Pydantic model) vs regular AIMessage
        if hasattr(response, "content"):
            return {"messages": [response]}
        else:
            from langchain_core.messages import AIMessage
            import json

            content = response.model_dump_json() if hasattr(response, "model_dump_json") else json.dumps(str(response))
            return {"messages": [AIMessage(content=content)]}

    return format_node
