"""Direct Instruction Node — Enhance and clarify user queries.

Transforms vague or incomplete user queries into clear, direct instructions
before passing them to the main agent. Helps the agent produce more
accurate and relevant responses.

Adapted from cab-agent-template (AI-HUB-LOB/cab-agent-template).
"""

import os

from langchain_core.language_models import BaseLanguageModel
from langchain_core.prompts import ChatPromptTemplate


def _read_prompt(filename: str) -> str:
    prompts_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "prompts")
    filepath = os.path.join(prompts_dir, filename)
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()


def _format_history(state: dict) -> str:
    history_parts = []
    for msg in state.get("messages", [])[:-1]:
        role = getattr(msg, "type", "unknown")
        content = getattr(msg, "content", str(msg))
        history_parts.append(f"{role}: {content}")
    return "\n".join(history_parts) if history_parts else "No previous history."


def make_direct_instruction_node(llm: BaseLanguageModel):
    """Create a direct instruction node function.

    Args:
        llm: Language model used for query enhancement.

    Returns:
        An async function compatible with LangGraph ``StateGraph.add_node()``.

    State requirements:
        - ``messages``: ``Annotated[list, add_messages]``
    """
    system_prompt = _read_prompt("prompt_query_enhancement.txt")
    chat_prompt = ChatPromptTemplate([("system", system_prompt), ("user", "")])

    async def direct_instruction(state: dict) -> dict:
        prompt = chat_prompt.format_messages(
            history=_format_history(state),
            query=state["messages"][-1],
        )
        response = await llm.ainvoke(prompt)
        return {"messages": [response]}

    return direct_instruction
