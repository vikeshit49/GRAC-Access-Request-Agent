"""Refinement Node — Refine agent responses.

Takes the agent's raw response and refines it into well-structured
Markdown output. Useful as a post-processing step to ensure consistent
formatting.

Adapted from cab-agent-template (AI-HUB-LOB/cab-agent-template).
"""

import os

from langchain_core.language_models import BaseLanguageModel
from langchain_core.prompts import ChatPromptTemplate


def _read_prompt(filename: str) -> str:
    prompts_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "prompts")
    filepath = os.path.join(prompts_dir, filename)
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()


def make_refinement_node(llm: BaseLanguageModel):
    """Create a refinement node function.

    Args:
        llm: Language model used for refinement.

    Returns:
        An async function compatible with LangGraph ``StateGraph.add_node()``.

    State requirements:
        - ``messages``: ``Annotated[list, add_messages]``
    """
    system_prompt = _read_prompt("prompt_refinement.txt")
    chat_prompt = ChatPromptTemplate([("system", system_prompt), ("user", "")])

    async def refinement(state: dict) -> dict:
        prompt = chat_prompt.format_messages(message=state["messages"][-1])
        response = await llm.ainvoke(prompt)
        return {"messages": [response]}

    return refinement
