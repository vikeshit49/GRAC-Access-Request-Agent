"""Task Planning Node — Create tool-aware execution plans.

Analyzes the user's query along with available tool schemas to generate
a step-by-step execution plan. Useful for complex queries that require
multiple tool calls.

Adapted from cab-agent-template (AI-HUB-LOB/cab-agent-template).
"""

import json
import os
from datetime import datetime

from langchain_core.language_models import BaseLanguageModel
from langchain_core.prompts import ChatPromptTemplate


def _read_prompt(filename: str) -> str:
    """Read a prompt template from the prompts directory."""
    prompts_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "prompts")
    filepath = os.path.join(prompts_dir, filename)
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()


def _format_history(state: dict) -> str:
    """Format message history as a string for prompt injection."""
    history_parts = []
    for msg in state.get("messages", [])[:-1]:
        role = getattr(msg, "type", "unknown")
        content = getattr(msg, "content", str(msg))
        history_parts.append(f"{role}: {content}")
    return "\n".join(history_parts) if history_parts else "No previous history."


def make_task_planning_node(llm: BaseLanguageModel):
    """Create a task planning node function.

    Args:
        llm: Language model used for planning.

    Returns:
        An async function compatible with LangGraph ``StateGraph.add_node()``.

    State requirements:
        - ``messages``: ``Annotated[list, add_messages]``
        - ``tools_schema``: ``Optional[dict]`` — tool schemas for planning context
    """
    system_prompt = _read_prompt("prompt_planning.txt")
    chat_prompt = ChatPromptTemplate([("system", system_prompt), ("user", "")])

    async def task_planning(state: dict) -> dict:
        today_date = datetime.today().strftime("%Y-%m-%d")
        tools_schema = state.get("tools_schema", {})

        tools_names = []
        for _, tools in tools_schema.items():
            if isinstance(tools, dict):
                tools_names.extend(list(tools.keys()))

        prompt = chat_prompt.format_messages(
            date=today_date,
            tools_schema=json.dumps(tools_schema),
            tool_names=tools_names,
            history=_format_history(state),
            query=state["messages"][-1],
        )
        response = await llm.ainvoke(prompt)
        return {"messages": [response]}

    return task_planning
