"""Context Management Node — Summarize or trim conversation history.

Keeps conversations within context window limits by either:
- **Summarize**: Uses LLM to create a running summary of older messages
- **Trim**: Keeps only the N most recent messages

Adapted from cab-agent-template (AI-HUB-LOB/cab-agent-template).
"""

from typing import Any, Literal

from langchain_core.language_models import BaseLanguageModel
from langchain_core.messages.utils import count_tokens_approximately
from langchain_core.prompts import ChatPromptTemplate


DEFAULT_INITIAL_SUMMARY_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("placeholder", "{messages}"),
        ("user", "Create a summary of the conversation above:"),
    ]
)

DEFAULT_EXISTING_SUMMARY_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("placeholder", "{messages}"),
        (
            "user",
            "This is summary of the conversation so far: {existing_summary}\n\n"
            "Extend this summary by taking into account the new messages above:",
        ),
    ]
)


def make_auto_compact_node(
    llm: BaseLanguageModel,
    strategy: Literal["summarize", "trim"] = "summarize",
    max_messages: int = 30,
    max_context_length: int = 50000,
    context_pressure_threshold: float = 0.75,
):
    """Create a context management node function.

    Args:
        llm: Language model used for summarization.
        strategy: "summarize" to compress history, "trim" to keep recent messages only.
        max_messages: For trim strategy — max number of messages to keep.
        max_context_length: For summarize strategy — token budget for the context.
        context_pressure_threshold: For summarize strategy — fraction of budget that
            triggers summarization (e.g., 0.75 means summarize at 75% capacity).

    Returns:
        An async function compatible with LangGraph ``StateGraph.add_node()``.

    State requirements:
        - ``messages``: ``Annotated[list, add_messages]``
        - ``context``: ``dict[str, Any]`` with keys:
            ``running_summary``, ``last_summarized_index``,
            ``num_tokens_in_running_summary``, ``num_tokens_in_new_messages``,
            ``total_tokens``
    """

    async def auto_compact(state: dict) -> dict:
        if strategy == "trim":
            state["messages"] = state["messages"][-max_messages:]
            return {}

        # --- Summarize strategy ---
        context: dict[str, Any] = state.get("context", {})
        num_tokens_in_running_summary = context.get("num_tokens_in_running_summary", 0)
        last_summarized_index = context.get("last_summarized_index", -1)
        num_tokens_in_new_messages = count_tokens_approximately(
            state["messages"][last_summarized_index + 1 :]
        )
        total_tokens = num_tokens_in_running_summary + num_tokens_in_new_messages

        # Check if summarization is needed
        if total_tokens < int(max_context_length * context_pressure_threshold):
            return {
                "context": {
                    "running_summary": context.get("running_summary", ""),
                    "last_summarized_index": last_summarized_index,
                    "num_tokens_in_running_summary": num_tokens_in_running_summary,
                    "num_tokens_in_new_messages": num_tokens_in_new_messages,
                    "total_tokens": total_tokens,
                }
            }

        # Build summary prompt
        if last_summarized_index == -1:
            summary_prompt = DEFAULT_INITIAL_SUMMARY_PROMPT.format_messages(
                messages=state["messages"]
            )
        else:
            summary_prompt = DEFAULT_EXISTING_SUMMARY_PROMPT.format_messages(
                messages=state["messages"][last_summarized_index + 1 : -1],
                existing_summary=context.get("running_summary", ""),
            )

        summary = await llm.ainvoke(summary_prompt)

        new_num_tokens = count_tokens_approximately([summary])
        new_last_summarized = len(state["messages"]) - 2

        return {
            "context": {
                "running_summary": summary.content,
                "last_summarized_index": new_last_summarized,
                "num_tokens_in_running_summary": new_num_tokens,
                "num_tokens_in_new_messages": 0,
                "total_tokens": new_num_tokens,
            }
        }

    return auto_compact
