---
name: cab-prebuilt-agent-components
description: Add prebuilt nodes and features to a LangGraph agent from the Custom-Agent-Builder (CAB) Agent Template. Use when the user wants to extend their agent with auto compact, task planning, query decomposition, refinement, concurrent tool calling, tool caching, MCP tools, structured output, or multi-agent orchestration.
metadata:
  author: sap
  version: "1.0"
---

# CAB Prebuilt Nodes & Features

Add production-ready components to an existing LangGraph agent. Each component
is self-contained — no framework migration required.

Read [references/prebuilt-nodes-catalog.md](references/prebuilt-nodes-catalog.md)
for detailed API documentation and usage examples.

## Instructions

Follow these 6 phases in order.

---

### Phase 1: Collect User Input

Use appropriate question and answer tools, if available, to present the component catalog as a multi-select:

```
"Which prebuilt components would you like to add to your agent?"

Options:
--- Pre-processing Nodes ---
1. "Auto Compact — Summarize/trim conversation history to stay within context limits"
2. "Direct Instruction — Enhance user queries into clear, actionable instructions"
3. "Query Decomposition — Break complex queries into ordered sub-questions"
4. "Task Planning — Create tool-aware execution plans"

--- Post-processing Nodes ---
5. "Refinement — Refine agent responses into structured Markdown"
6. "Format — Format responses (with optional structured output via JSON schema)"

--- Tool Features (require at least one tool registered in the agent) ---
7. "Concurrent Tool Calling — Run tool calls in parallel via asyncio.gather"
8. "Tool Response Caching — Cache tool results in-memory to skip redundant calls"
9. "MCP Tools — Connect to MCP servers and load their tools"

--- Architecture Features ---
10. "Structured Output — Enforce JSON schema on LLM responses"
11. "Multi-Agent Orchestration — Compose sub-agents as graph nodes"
```

Allow the user to select multiple components. Also ask:

**If Auto Compact is selected:**
```
"Which context management strategy?"
Options: ["Summarize (recommended)", "Trim"]
```

**If MCP Tools is selected:**
```
"What is the MCP server URL and transport type?"
```
Collect: server name, URL, transport (streamable_http or stdio), and optional tool name filter.

**If Structured Output is selected:**
```
"Do you have a JSON schema file, or should I generate a basic schema?"
```

**If Multi-Agent is selected:**
```
"How many sub-agents do you need?"
```
Collect: sub-agent names and descriptions.

---

### Phase 2: Copy Templates

Copy the selected component files into the agent project. Run the appropriate
shell command based on user's OS:

**macOS/Linux:**
```bash
SKILL_PATH=$(find . -type d -name "cab-prebuilt-agent-components" -path "*/skills/*" 2>/dev/null | head -1)
```

**Windows PowerShell:**
```powershell
$SkillPath = Get-ChildItem -Path . -Recurse -Directory -Filter "cab-prebuilt-agent-components" | Where-Object { $_.FullName -like "*\skills\*" } | Select-Object -First 1 -ExpandProperty FullName
```

Then copy selected files:

**For each selected node (e.g., auto_compact):**

**macOS/Linux:**
```bash
mkdir -p app/nodes app/prompts
cp "$SKILL_PATH/templates/app/nodes/__init__.py" app/nodes/
cp "$SKILL_PATH/templates/app/nodes/auto_compact.py" app/nodes/
```

**Windows PowerShell:**
```powershell
New-Item -ItemType Directory -Force -Path app/nodes, app/prompts
Copy-Item "$SkillPath/templates/app/nodes/__init__.py" -Destination app/nodes/
Copy-Item "$SkillPath/templates/app/nodes/auto_compact.py" -Destination app/nodes/
```

**For each selected feature (e.g., tool_executor):**

**macOS/Linux:**
```bash
mkdir -p app/features
cp "$SKILL_PATH/templates/app/features/__init__.py" app/features/
cp "$SKILL_PATH/templates/app/features/tool_executor.py" app/features/
```

**Windows PowerShell:**
```powershell
New-Item -ItemType Directory -Force -Path app/features
Copy-Item "$SkillPath/templates/app/features/__init__.py" -Destination app/features/
Copy-Item "$SkillPath/templates/app/features/tool_executor.py" -Destination app/features/
```

**Copy prompt files for selected nodes that need them:**

| Node | Prompt File |
|------|-------------|
| task_planning | `prompt_planning.txt` |
| query_decomposition | `prompt_query_decomposition.txt` |
| direct_instruction | `prompt_query_enhancement.txt` |
| refinement | `prompt_refinement.txt` |
| format_node | `prompt_format.txt` |

**macOS/Linux:**
```bash
cp "$SKILL_PATH/templates/app/prompts/prompt_planning.txt" app/prompts/
# ... for each selected node's prompt
```

**Windows PowerShell:**
```powershell
Copy-Item "$SkillPath/templates/app/prompts/prompt_planning.txt" -Destination app/prompts/
# ... for each selected node's prompt
```

---

### Phase 3: Extend State

Read `app/agent.py` to understand the current state definition.

**If the agent uses `MessagesState`** (from bootstrap), replace it with an
extended state class based on selected components:

```python
from typing import Annotated, Any, Optional
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages

class AgentState(TypedDict):
    messages: Annotated[list, add_messages]
```

Add fields based on selected components:

| Component | State Field | Default |
|-----------|-------------|---------|
| Auto Compact | `context: dict[str, Any]` | `{"running_summary": "", "last_summarized_index": -1, "num_tokens_in_running_summary": 0, "num_tokens_in_new_messages": 0, "total_tokens": 0}` |
| Task Planning | `tools_schema: Optional[dict]` | `None` |
| Tool Caching | `short_term_memory: Optional[dict]` | `{}` |

Update the `StateGraph` initialization:

**Before:**
```python
builder = StateGraph(MessagesState)
```

**After:**
```python
builder = StateGraph(AgentState)
```

---

### Phase 4: Wire Nodes into Graph

This is the most important phase. Read the current `app/agent.py` and modify
the graph construction to integrate selected components.

**Before wiring**, identify the existing node names in the graph (e.g., by
reading `add_node(...)` calls). The main LLM node may not be called `"agent"` —
it could be `"call_model"`, `"chatbot"`, `"assistant"`, etc. Use the actual
node name found in the code throughout the steps below.

#### 4a. Add Imports

Add imports for selected components at the top of `app/agent.py`:

```python
# Pre-processing nodes
from nodes.auto_compact import make_auto_compact_node
from nodes.direct_instruction import make_direct_instruction_node
from nodes.query_decomposition import make_query_decomposition_node
from nodes.task_planning import make_task_planning_node

# Post-processing nodes
from nodes.refinement import make_refinement_node
from nodes.format_node import make_format_node

# Features
from features.tool_executor import ConcurrentToolExecutor
from features.mcp_tools import load_mcp_tools
from features.structured_output import json_schema_to_pydantic
from features.multi_agent import add_sub_agent_node, build_sub_agent
```

Only add imports for selected components.

#### 4b. Create Node Functions

Inside the agent class or build method, create the node functions using the
factory functions. Each factory takes an LLM and returns an async function:

```python
# Example: create node functions
context_mgmt = make_auto_compact_node(self.llm, strategy="summarize")
direct_inst = make_direct_instruction_node(self.llm)
query_decomp = make_query_decomposition_node(self.llm)
planning = make_task_planning_node(self.llm)
refine = make_refinement_node(self.llm)
```

**For concurrent tool executor** (replaces the basic ToolNode):
```python
executor = ConcurrentToolExecutor(
    tools=tools,
    enable_caching=True,  # if tool caching selected
    tools_to_summarize=set(),  # add tool names if needed
    summarization_llm=self.llm,
)
```

**For MCP tools:**
```python
# In an async context (e.g., async build method or __init__ with asyncio.run)
mcp_tools = await load_mcp_tools({
    "server_name": {
        "url": "http://...",
        "transport": "streamable_http",
    }
})
all_tools = tools + mcp_tools  # combine with existing tools
```

#### 4c. Add Nodes to Graph

Add nodes to the `StateGraph` in the correct order.

**Pre-processing nodes** go between START and the main agent:
```python
builder.add_node("auto_compact", context_mgmt)
builder.add_node("direct_instruction", direct_inst)
builder.add_node("query_decomposition", query_decomp)
builder.add_node("task_planning", planning)
```

**Agent node** (existing call_model or similar):
```python
builder.add_node("agent", call_model)  # existing node
```

**Tool node** (replace with concurrent executor if selected):
```python
builder.add_node("tools", executor.ainvoke)  # concurrent executor
# OR keep existing: builder.add_node("tools", ToolNode(tools=tools))
```

**Post-processing nodes** go between agent and END:
```python
builder.add_node("refinement", refine)
builder.add_node("format", format_fn)
```

#### 4d. Add Edges

Wire the nodes together with edges. The exact wiring depends on which nodes
are selected. Follow these rules:

1. **START** connects to the first pre-processing node (or agent if none)
2. **Pre-processing nodes** chain sequentially
3. **Last pre-processing node** connects to the agent
4. **Agent** has a conditional edge for tools (if tools exist)
5. **Tools** loop back to agent
6. **Agent's non-tool exit** connects to the first post-processing node (or END)
7. **Post-processing nodes** chain sequentially to END

**Example with auto_compact + task_planning + refinement:**
```python
from langgraph.prebuilt import tools_condition

builder.add_edge(START, "auto_compact")
builder.add_edge("auto_compact", "task_planning")
builder.add_edge("task_planning", "agent")
builder.add_conditional_edges("agent", tools_condition, {
    "tools": "tools",
    "__end__": "refinement",
})
builder.add_edge("tools", "agent")
builder.add_edge("refinement", END)
```

**For multi-agent**, use the helper to add sub-agents:
```python
from features.multi_agent import add_sub_agent_node, build_sub_agent

sub_graph = build_sub_agent(
    state_class=AgentState,
    nodes=[("agent", sub_agent_fn), ("tools", sub_tool_executor.ainvoke)],
    edges=[("__start__", "agent"), ("tools", "agent")],
    conditional_edges=[("agent", tools_condition, {"tools": "tools", "__end__": "__end__"})],
)
add_sub_agent_node(builder, "data_retrieval_agent", sub_graph)
```

#### 4e. Initialize tools_schema (if task planning is selected)

After creating tools, extract their schemas and store in state initialization:

```python
tools_schema = {}
for tool in tools:
    tools_schema[tool.name] = {
        "name": tool.name,
        "description": tool.description,
        "schema": tool.args_schema.model_json_schema() if tool.args_schema else "No schema",
    }
```

Pass `tools_schema` in the initial state when invoking the graph.

---

### Phase 5: Update Dependencies

Check `requirements.txt` and add any missing dependencies:

| Component | Dependency |
|-----------|------------|
| MCP Tools | `langchain-mcp-adapters` |
| Structured Output | `pydantic` (no version — avoid SAP AI Core conflicts) |
| All nodes | `langchain-core` (already present from bootstrap) |
| All nodes | `langchain-litellm` (already present from bootstrap) |

---

### Phase 6: Verify & Next Steps

#### Verify:
1. All selected node files exist in `app/nodes/`
2. All selected feature files exist in `app/features/`
3. Prompt files exist in `app/prompts/` for nodes that need them
4. `app/agent.py` imports and wires all selected components correctly
5. State is extended with required fields
6. `requirements.txt` includes any new dependencies

#### Show the user the resulting graph structure:
```
Graph: START → [pre-processing nodes] → agent ⟷ tools → [post-processing nodes] → END
```

#### Suggest next steps:
```
"Your agent has been extended with the selected components. How would you like to proceed?"

Options:
1. "Run locally — test the agent with sap-agent-run-local"
2. "Add more nodes — select additional components"
3. "Deploy — commit and push to trigger CI/CD"
```

Based on the user's choice:
- **Run locally**: Activate the `sap-agent-run-local` skill
- **Add more nodes**: Re-run Phase 1 with the remaining components
- **Deploy**: Guide through git add, commit, push

---

## Quick Reference

### Node Factory Signatures

```python
make_auto_compact_node(llm, strategy="summarize", max_messages=30,
                       max_context_length=50000, context_pressure_threshold=0.75)
make_direct_instruction_node(llm)
make_query_decomposition_node(llm)
make_task_planning_node(llm)
make_refinement_node(llm)
make_format_node(llm)
```

### Feature Constructors

```python
ConcurrentToolExecutor(tools, enable_caching=False, tools_to_summarize=set(),
                       summarization_llm=None)
load_mcp_tools(server_config, tool_filter=None)
json_schema_to_pydantic(schema, model_name="DynamicModel")
add_sub_agent_node(parent_builder, node_name, sub_graph, state_mapper=None,
                   async_execution=False)
build_sub_agent(state_class, nodes, edges, conditional_edges=None, checkpointer=True)
```

### MCP Server for Additional Information and Functionalities

Check out the CAB MCP server for more details and functionalities of how to build CAB agent. This MCP server can be directly called via steamable-http.

```
"mcpServers": {
  "cab-agent-builder": {
    "type": "http",
    "url": "https://cabmcp.cfapps.us10.hana.ondemand.com/mcp"
  }
}
```
