---
name: sap-sdk-python-subscriptionmanager
description: Integrate SAP Subscription Manager Service using the Application Foundation Python SDK. Use when the user needs to manage subscriptions, list dependencies, or implement subscription callbacks in a multi-tenant Python application.
---

# Subscription Manager Integration with Python SDK

This skill provides guidance for integrating the SAP Subscription Manager Service using the Application Foundation Python SDK. The subscription manager module provides utilities for listing subscriptions, discovering XSUAA dependencies, and implementing subscription callbacks for multi-tenant applications.

## ⚠️ Package Index Policy

All Python packages MUST be installed exclusively from the SAP PyPI proxy:
`https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple`

NEVER use `https://pypi.org/simple` or any other external package index.
NEVER add `--extra-index-url` pointing to PyPI.
If a package is not found in the SAP proxy, report the error — do NOT fall back to PyPI.

## app.yaml Configuration

To use the Subscription Manager service, add the following to your `app.yaml` under `spec.requires`:

```yaml
requires:
  - name: subscription-manager
    service: saas-registry
    plan: application
```

**Fields:**
- `name`: Instance name for the subscription manager service (used in your code with `create_client("subscription-manager")`)
- `service`: Must be `saas-registry`
- `plan`: Use `application` for application plan

## Installation

```bash
# Using uv (recommended)
uv add sap-cloud-sdk --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"

# Using pip
pip install sap-cloud-sdk --index-url "https://int.repositories.cloud.sap/artifactory/api/pypi/proxy-3rd-party-pypi/simple"
```

## Quick Start

```python
from sap_cloud_sdk.subscription_manager import create_client

# Automatically detects local vs cloud mode
client = create_client("my-instance")

# List subscriptions
subs = client.list_subscriptions()

# List XSUAA dependencies (Container Hosting only)
deps = client.list_dependencies()
```

## Listing Subscriptions

```python
from sap_cloud_sdk.subscription_manager import create_client, Pagination

client = create_client("my-instance")

# List all subscriptions
subs = client.list_subscriptions()

# With filtering parameters
subs = client.list_subscriptions(
    tenant_sub_domain="customer1",
    tenant_id="tenant-uuid",
    ias_service_instance_id="ias-instance-id"
)

# With pagination
pagination = Pagination(cursor=None, top=20, count=False)
subs = client.list_subscriptions(pagination=pagination)

for sub in subs:
    print(f"Tenant: {sub.subscriber.subdomain}")
```

## Detecting Dependencies

The `list_dependencies()` method discovers XSUAA dependencies from mounted secrets in Container Hosting environments:

```python
from sap_cloud_sdk.subscription_manager import create_client

client = create_client("my-instance")

# List XSUAA dependencies
deps = client.list_dependencies()

print(f"Found {len(deps)} dependencies")
for dependency in deps:
    print(f"- {dependency.xs_app_name}")
```

**Note:** This method only works in Container Hosting environments where service credentials are mounted at `/etc/secrets/appfnd/`.

## Implementing Subscription Callbacks

When integrating with the Subscription Management Service, implement these callbacks:

### Import Callback Models

```python
from sap_cloud_sdk.subscription_manager import (
    SubscriptionRequest,
    SubscriptionResponse,
    UnsubscriptionResponse,
    DependenciesResponse,
    Dependency,
    CallbackErrorResponse
)
```

### Subscribe Callback (Flask Example)

```python
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/<tenant_id>', methods=['PUT'])
def subscription_handler(tenant_id: str):
    try:
        request_data = request.get_json()

        # Parse the subscription request
        try:
            subscription_req = SubscriptionRequest(**request_data)
        except Exception as e:
            error = CallbackErrorResponse(
                code=400,
                messageForCustomer="Invalid request format",
                errorDetails=f"Failed to parse JSON payload: {str(e)}"
            )
            return jsonify(error.model_dump(by_alias=True)), 400

        # Your subscription logic here
        # - Provision tenant resources
        # - Create database schema
        # - Configure tenant-specific settings

        response = SubscriptionResponse(application_url="https://your-app.example.com")
        return jsonify(response.model_dump(by_alias=True))

    except Exception as e:
        error = CallbackErrorResponse(
            code=500,
            messageForCustomer="Subscription processing failed",
            errorDetails="Internal server error during subscription processing"
        )
        return jsonify(error.model_dump(by_alias=True)), 500
```

### Unsubscribe Callback

```python
@app.route('/<tenant_id>', methods=['DELETE'])
def unsubscription_handler(tenant_id: str):
    try:
        # Extract URL parameters
        own_service_instance = request.args.get('ownServiceInstance', '')
        service_instances = request.args.get('serviceInstances', '')
        plan_name = request.args.get('planName', '')
        subscription_guid = request.args.get('subscriptionGUID', '')

        # Your unsubscription logic here
        # - Clean up tenant resources
        # - Remove tenant data
        # - Revoke access

        response = UnsubscriptionResponse(
            status="success",
            message=f"Tenant {tenant_id} unsubscribed successfully"
        )
        return jsonify(response.model_dump(by_alias=True))
        
    except Exception as e:
        error = CallbackErrorResponse(
            code=500,
            messageForCustomer="Unsubscription processing failed",
            errorDetails="Internal server error during unsubscription processing"
        )
        return jsonify(error.model_dump(by_alias=True)), 500
```

### Dependencies Callback

```python
@app.route('/<tenant_id>/dependencies', methods=['GET'])
def dependencies_handler(tenant_id: str):
    try:
        # Discover dependencies using the SDK
        client = create_client("my-instance")
        dependencies = client.list_dependencies()

        response = DependenciesResponse(root=dependencies)
        return jsonify(response.model_dump(by_alias=True))

    except Exception as e:
        error = CallbackErrorResponse(
            code=500,
            messageForCustomer="Dependencies retrieval failed",
            errorDetails="Internal server error during dependencies retrieval"
        )
        return jsonify(error.model_dump(by_alias=True)), 500
```

## Data Models

### API Models

```python
from sap_cloud_sdk.subscription_manager import (
    SubscriptionItem,
    SubscriptionProvider,
    SubscriptionSubscriber,
    Pagination,
    ApiErrorResponse
)
```

### Callback Models

```python
from sap_cloud_sdk.subscription_manager import (
    SubscriptionRequest,
    SubscriptionResponse,
    UnsubscriptionResponse,
    DependenciesResponse,
    Dependency,
    CallbackErrorResponse
)
```

## Error Handling

```python
from sap_cloud_sdk.subscription_manager import (
    SubscriptionManagerError,
    ClientCreationError,
    UnexpectedError,
    AuthenticationError
)

try:
    subs = client.list_subscriptions()
except AuthenticationError:
    print("Authentication failed")
except UnexpectedError as e:
    print(f"Operation failed: {e}")

try:
    deps = client.list_dependencies()
except UnexpectedError as e:
    print(f"Failed to list dependencies: {e}")
```

## Local Development Mode

Enable local mode for development:

```bash
export APPFND_LOCALDEV_SUBSCRIPTION_MANAGER=true
```

When local mode is enabled:
- A fake client returns realistic mock subscription and dependencies data
- No additional configuration needed

### Check Runtime Mode

```python
from sap_cloud_sdk.core.runtime_context import RuntimeContext

ctx = RuntimeContext()
if ctx.is_local("subscription-manager"):
    print("Running in local development mode")
else:
    print("Running in cloud mode")
```

## Cloud Mode Configuration

In cloud mode, credentials are resolved from:

### Environment Variables
```bash
export APPFND_CFG_SUBSCRIPTION_MANAGER_SMS_CREDENTIALS='{"clientid": "...", "clientsecret": "...", "url": "...", "subscription_manager_url": "..."}'
```

### Mounted Secrets (Kubernetes)
```
/etc/secrets/subscription-manager/credentials/
├── credentials
```

## Custom Configuration

```python
from sap_cloud_sdk.subscription_manager import create_client, SubscriptionManagerConfig

config = SubscriptionManagerConfig(
    service_url="https://api.sms.cf.example.com",
    oauth_url="https://example.authentication.com/oauth/token",
    client_id="your-client-id",
    client_secret="your-client-secret"
)

client = create_client(instance="my-instance", config=config)
```

## Container Hosting Dependencies Detection

The `list_dependencies()` method scans the `/etc/secrets/appfnd/` directory structure:

```
/etc/secrets/appfnd/
├── service1/
│   ├── instance1/
│   │   ├── credentials    # Contains {"xsappname": "app1", ...}
│   │   └── uaa           # Contains {"xsappname": "app1-uaa", ...}
│   └── instance2/
│       └── credentials
└── service2/
    └── default/
        └── credentials
```

**Important:**
- Requires read access to `/etc/secrets/appfnd/`
- Only works in Container Hosting environments with mounted service bindings
- Returns empty list if directory doesn't exist
- Automatically deduplicates `xsappname` values
