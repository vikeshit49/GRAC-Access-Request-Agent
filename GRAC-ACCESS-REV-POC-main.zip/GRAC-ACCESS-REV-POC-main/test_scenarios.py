"""
Scenario tests for the GRAC Access Review Agent.
Runs multi-turn conversations and asserts on action_type, tool calls, and response content.

Usage:
    .venv\Scripts\python test_scenarios.py
    .venv\Scripts\python test_scenarios.py --scenario lost_access
    .venv\Scripts\python test_scenarios.py --scenario sod
    .venv\Scripts\python test_scenarios.py --scenario submit

TODO — fill in before running:
    ROLE_WITH_SOD      : name of a role that triggers SoD conflicts for PRANAY_USER_ID
    ALREADY_HELD_ROLE  : a role name/keyword that PRANAY_USER_ID currently holds (active)
    COLLEAGUE_NAME     : first name of a colleague who has active GRC assignments
"""

import json
import sys
import uuid
import argparse
from dataclasses import dataclass, field
from typing import Optional
import requests

BASE_URL      = "http://localhost:9000"
USER_EMAIL    = "pranay.garoo@sap.com"
CONNECTOR     = "GX2CLNT600"

# ── TODO: fill these in ────────────────────────────────────────────────────────
ROLE_WITH_SOD     = "TODO_ROLE_THAT_HAS_SOD_CONFLICTS"
ALREADY_HELD_ROLE = "TODO_KEYWORD_FOR_ROLE_YOU_ALREADY_HAVE"
COLLEAGUE_NAME    = "TODO_COLLEAGUE_FIRST_NAME"
# ──────────────────────────────────────────────────────────────────────────────


@dataclass
class Turn:
    user:   str
    checks: list[str] = field(default_factory=list)   # strings that must appear in agent response
    action_type: Optional[str] = None                  # expected action_type if known
    must_not: list[str] = field(default_factory=list)  # strings that must NOT appear


class AgentSession:
    def __init__(self, name: str):
        self.name        = name
        self.context_id  = None
        self.msg_counter = 0
        self.failures    = []
        self.passed      = 0

    def send(self, text: str) -> dict:
        self.msg_counter += 1
        message = {
            "messageId": f"msg-{self.msg_counter:03d}",
            "role":      "user",
            "parts":     [{"kind": "text", "text": text}],
            "metadata":  {"userEmail": USER_EMAIL},
        }
        if self.context_id:
            message["contextId"] = self.context_id

        resp = requests.post(BASE_URL + "/", json={
            "jsonrpc": "2.0",
            "method":  "message/send",
            "id":      str(uuid.uuid4()),
            "params":  {"message": message},
        }, timeout=120)
        data = resp.json()
        result = data.get("result", {})
        if result.get("contextId"):
            self.context_id = result["contextId"]
        return result

    def _extract_payload(self, result: dict) -> dict:
        for artifact in result.get("artifacts", []):
            for part in artifact.get("parts", []):
                if part.get("kind") == "data" and part.get("data"):
                    return part["data"]
        return {}

    def run_turn(self, turn: Turn, turn_idx: int) -> dict:
        print(f"  Turn {turn_idx}: {turn.user[:80]}")
        result  = self.send(turn.user)
        payload = self._extract_payload(result)
        message = payload.get("message", "")
        action  = payload.get("action_type", "")

        print(f"    → action_type={action}  message={message[:120]}")

        # Check action_type
        if turn.action_type and action != turn.action_type:
            self.failures.append(
                f"[{self.name}] Turn {turn_idx}: expected action_type={turn.action_type}, got={action}"
            )
        else:
            self.passed += 1

        # Check must-contain strings
        combined = json.dumps(payload).lower()
        for check in turn.checks:
            if check.lower() not in combined:
                self.failures.append(
                    f"[{self.name}] Turn {turn_idx}: expected '{check}' in response"
                )
            else:
                self.passed += 1

        # Check must-not strings
        for bad in turn.must_not:
            if bad.lower() in combined:
                self.failures.append(
                    f"[{self.name}] Turn {turn_idx}: '{bad}' must NOT appear in response"
                )
            else:
                self.passed += 1

        return payload


def run_scenario(name: str, turns: list[Turn]) -> list[str]:
    print(f"\n{'='*60}")
    print(f"SCENARIO: {name}")
    print(f"{'='*60}")
    session = AgentSession(name)
    last_payload = {}
    for i, turn in enumerate(turns, 1):
        last_payload = session.run_turn(turn, i)
    print(f"  Result: {session.passed} checks passed, {len(session.failures)} failed")
    for f in session.failures:
        print(f"  FAIL: {f}")
    return session.failures


# ── Scenario definitions ───────────────────────────────────────────────────────

def scenario_happy_path():
    return run_scenario("Happy Path — new access need", [
        Turn(
            user="I need access to post goods issues",
            action_type="select_intent",
        ),
        Turn(
            user="I need new access, I've never had it before",
            action_type="select_system",
        ),
        Turn(
            user=CONNECTOR,
            action_type="select_role",
            checks=["peer", "approval"],   # signal_summary fields should appear
        ),
    ])


def scenario_lost_access():
    return run_scenario("Lost Access — had it before", [
        Turn(
            user="I need access to post goods issues",
            action_type="select_intent",
        ),
        Turn(
            user="I had this access before but it expired",
            # Agent should check assignment history — NOT jump straight to catalog search.
            # We verify it does NOT immediately return select_role without checking history.
            checks=["assignment", "previous"],
            must_not=[],
        ),
    ])


def scenario_sod():
    return run_scenario("SoD Conflict — must surface before submit", [
        Turn(
            user=f"I need access to {ROLE_WITH_SOD}",
            action_type="select_intent",
        ),
        Turn(
            user="I need new access",
            action_type="select_system",
        ),
        Turn(
            user=CONNECTOR,
        ),
        Turn(
            user=ROLE_WITH_SOD,
        ),
        Turn(
            user="Create access request",
            # Agent must surface SoD before asking for justification
            action_type="analysis_complete",
            checks=["risk", "conflict"],
        ),
    ])


def scenario_userid_not_email():
    """Verify agent resolved UserId and uses it — email must not appear as a tool parameter."""
    return run_scenario("UserId carry-through — email must not be used in tool calls", [
        Turn(
            user="I need access to approve purchase orders",
            # After first LLM call, agent should have resolved UserId from email.
            # Check that response doesn't show email being passed to tools.
            must_not=["pranay.garoo@sap.com used as userid"],
        ),
    ])


def scenario_duplicate_blocked():
    return run_scenario("Duplicate Assignment — must not re-request", [
        Turn(
            user=f"I need the {ALREADY_HELD_ROLE} role",
            action_type="select_intent",
        ),
        Turn(
            user="I need new access",
            action_type="select_system",
        ),
        Turn(
            user=CONNECTOR,
        ),
        Turn(
            user=ALREADY_HELD_ROLE,
            # Agent should detect existing active assignment and block
            checks=["already", "assigned"],
            must_not=["create-access-request"],
        ),
    ])


def scenario_colleague_copy():
    return run_scenario("Colleague Copy", [
        Turn(
            user=f"Give me the same access as {COLLEAGUE_NAME}",
            checks=[COLLEAGUE_NAME.lower()],
        ),
        Turn(
            user="Yes, copy all of them",
            checks=["justification"],
        ),
    ])


# ── Entry point ────────────────────────────────────────────────────────────────

ALL_SCENARIOS = {
    "happy_path":      scenario_happy_path,
    "lost_access":     scenario_lost_access,
    "sod":             scenario_sod,
    "userid":          scenario_userid_not_email,
    "duplicate":       scenario_duplicate_blocked,
    "colleague":       scenario_colleague_copy,
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenario", choices=list(ALL_SCENARIOS.keys()),
                        help="Run a single scenario (default: all)")
    args = parser.parse_args()

    # Warn about TODOs
    todos = [v for v in [ROLE_WITH_SOD, ALREADY_HELD_ROLE, COLLEAGUE_NAME] if v.startswith("TODO")]
    if todos:
        print(f"\n⚠  Fill in TODOs at top of file before running: {todos}")
        print("   Scenarios that need them will be skipped.\n")

    to_run = {args.scenario: ALL_SCENARIOS[args.scenario]} if args.scenario else ALL_SCENARIOS
    all_failures = []

    for name, fn in to_run.items():
        if name in ("sod", "duplicate", "colleague") and any(v.startswith("TODO") for v in [ROLE_WITH_SOD, ALREADY_HELD_ROLE, COLLEAGUE_NAME]):
            print(f"\nSKIP {name} — TODO values not filled in")
            continue
        all_failures.extend(fn())

    print(f"\n{'='*60}")
    if all_failures:
        print(f"FAILED — {len(all_failures)} assertion(s):")
        for f in all_failures:
            print(f"  • {f}")
        sys.exit(1)
    else:
        print("ALL CHECKS PASSED")


if __name__ == "__main__":
    main()
