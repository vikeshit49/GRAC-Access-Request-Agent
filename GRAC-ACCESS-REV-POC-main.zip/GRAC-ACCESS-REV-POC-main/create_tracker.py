import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import fills
from openpyxl.utils import get_column_letter

wb = openpyxl.Workbook()

# ── Palette ──────────────────────────────────────────────────────────────────
SAP_NAVY      = "1C3461"
SAP_BLUE      = "0057B8"
SAP_LIGHT_BG  = "F5F7FA"
WHITE         = "FFFFFF"
BORDER_GRAY   = "D4D8DC"
TEXT_DARK     = "0B0B0B"
TEXT_MID      = "52514E"
TEXT_LIGHT    = "898781"

# Status colors (fill / font)
C_FULL        = ("C8EFD4", "0A5C24")   # green
C_PARTIAL     = ("FFF3CD", "7A4F00")   # amber
C_INPROG      = ("FFE5CC", "7A3300")   # orange
C_NOTSTARTED  = ("FDDCDC", "7A1414")   # red
C_HEADER_ROW  = ("EAF1FB", SAP_NAVY)

def border(sides="all", color=BORDER_GRAY, style="thin"):
    s = Side(border_style=style, color=color)
    n = Side(border_style=None)
    if sides == "all":
        return Border(left=s, right=s, top=s, bottom=s)
    if sides == "bottom":
        return Border(bottom=s)
    if sides == "top_bottom":
        return Border(top=s, bottom=s)
    return Border()

def fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)

def font(bold=False, color=TEXT_DARK, size=10, italic=False):
    return Font(bold=bold, color=color, size=size, italic=italic,
                name="Segoe UI")

def align(h="left", v="center", wrap=False):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)


# ══════════════════════════════════════════════════════════════════════════════
# SHEET 1 — Agent Info
# ══════════════════════════════════════════════════════════════════════════════
ws_info = wb.active
ws_info.title = "Agent Info"
ws_info.sheet_view.showGridLines = False

# Column widths
ws_info.column_dimensions["A"].width = 3
ws_info.column_dimensions["B"].width = 22
ws_info.column_dimensions["C"].width = 42
ws_info.column_dimensions["D"].width = 3

# Row heights
for r in range(1, 30):
    ws_info.row_dimensions[r].height = 18

# ── Big header banner (rows 2-4) ─────────────────────────────────────────────
ws_info.merge_cells("B2:C2")
c = ws_info["B2"]
c.value = "Agent Technical Readiness Tracker"
c.font = Font(bold=True, color=WHITE, size=16, name="Segoe UI")
c.fill = fill(SAP_NAVY)
c.alignment = align("left", "center")
ws_info.row_dimensions[2].height = 38

ws_info.merge_cells("B3:C3")
c = ws_info["B3"]
c.value = "15 checklist criteria · Section 2.1 Platform Integration & Instrumentation · Track implementation status across sandbox & productive"
c.font = Font(bold=False, color="A0B8D8", size=10, name="Segoe UI", italic=True)
c.fill = fill(SAP_NAVY)
c.alignment = align("left", "center")
ws_info.row_dimensions[3].height = 22

# spacer row 4
for col in ["B", "C"]:
    ws_info[f"{col}4"].fill = fill(SAP_BLUE)
ws_info.row_dimensions[4].height = 4

# ── Field rows ────────────────────────────────────────────────────────────────
fields = [
    ("Agent Name",    ""),
    ("Owner",         ""),
    ("Git Repo",      ""),
    ("Sandbox URL",   ""),
]

for i, (label, default) in enumerate(fields):
    row = 6 + i * 2   # rows 6, 8, 10, 12  (with spacer rows between)
    ws_info.row_dimensions[row].height = 26

    # Label cell
    lc = ws_info.cell(row=row, column=2, value=label)
    lc.font = Font(bold=True, color=SAP_NAVY, size=9, name="Segoe UI")
    lc.fill = fill(SAP_LIGHT_BG)
    lc.alignment = align("left", "center")
    lc.border = border("all", BORDER_GRAY)

    # Value cell
    vc = ws_info.cell(row=row, column=3, value=default)
    vc.font = Font(bold=False, color=TEXT_DARK, size=10, name="Segoe UI")
    vc.fill = fill(WHITE)
    vc.alignment = align("left", "center")
    vc.border = border("all", BORDER_GRAY)

    # Spacer row
    ws_info.row_dimensions[row + 1].height = 6

# ── Footer note ──────────────────────────────────────────────────────────────
ws_info.merge_cells("B16:C16")
c = ws_info["B16"]
c.value = "Fill in Tracker sheet per criterion. Use Resources sheet for links & docs."
c.font = Font(italic=True, color=TEXT_LIGHT, size=9, name="Segoe UI")
c.alignment = align("left", "center")
ws_info.row_dimensions[16].height = 20

# ── Overall Technical Readiness ───────────────────────────────────────────────
# Spacer
ws_info.row_dimensions[17].height = 10

# Section label
ws_info.merge_cells("B18:C18")
c = ws_info["B18"]
c.value = "Overall Technical Readiness"
c.font = Font(bold=True, color=WHITE, size=10, name="Segoe UI")
c.fill = fill(SAP_NAVY)
c.alignment = align("left", "center")
ws_info.row_dimensions[18].height = 26

# Big % number pulled from Tracker sheet avg
ws_info.merge_cells("B19:C21")
c = ws_info["B19"]
# Tracker sheet avg is in G{sum_row} — we reference it cross-sheet
# sum_row is built after the Tracker sheet; we use a placeholder formula
# that will be replaced after sum_row is known (done below after Tracker built)
c.value = "=Tracker!G18"   # placeholder — corrected below
c.font = Font(bold=True, color=SAP_NAVY, size=36, name="Segoe UI")
c.fill = fill(SAP_LIGHT_BG)
c.alignment = align("center", "center")
c.border = border("all", BORDER_GRAY)
c.number_format = '0"%"'
ws_info.row_dimensions[19].height = 40
ws_info.row_dimensions[20].height = 40
ws_info.row_dimensions[21].height = 40

# Caption
ws_info.merge_cells("B22:C22")
c = ws_info["B22"]
c.value = "Average % Complete across all 15 TR criteria  ·  Update in Tracker sheet"
c.font = Font(italic=True, color=TEXT_LIGHT, size=8, name="Segoe UI")
c.alignment = align("center", "center")
ws_info.row_dimensions[22].height = 18


# ══════════════════════════════════════════════════════════════════════════════
# SHEET 2 — Tracker
# ══════════════════════════════════════════════════════════════════════════════
ws = wb.create_sheet("Tracker")
ws.sheet_view.showGridLines = False
ws.freeze_panes = "A3"

# Column widths
col_widths = {
    "A": 28,   # Criterion
    "B": 52,   # Key
    "C": 16,   # Status
    "D": 16,   # Validated In
    "E": 16,   # Required Env
    "F": 50,   # Notes
    "G": 14,   # % Complete
}
for col, w in col_widths.items():
    ws.column_dimensions[col].width = w

# ── Section header row 1 ──────────────────────────────────────────────────────
ws.merge_cells("A1:G1")
c = ws["A1"]
c.value = "2.1  Platform Integration & Instrumentation"
c.font = Font(bold=True, color=WHITE, size=11, name="Segoe UI")
c.fill = fill(SAP_NAVY)
c.alignment = align("left", "center")
ws.row_dimensions[1].height = 28

# ── Column header row 2 ───────────────────────────────────────────────────────
headers = ["Criterion", "Checklist Key", "Status", "Validated In", "Required Env", "Notes", "% Complete"]
for i, h in enumerate(headers, 1):
    c = ws.cell(row=2, column=i, value=h)
    c.font = Font(bold=True, color=SAP_NAVY, size=9, name="Segoe UI")
    c.fill = fill(C_HEADER_ROW[0])
    c.alignment = align("center", "center")
    c.border = border("all", BORDER_GRAY)
ws.row_dimensions[2].height = 22

# ── Criteria data ─────────────────────────────────────────────────────────────
criteria = [
    ("A2A Server",          "technical_readiness.checklist.agent_itself_is_exposed_as_a2a_server"),
    ("AGW MCP Integration", "technical_readiness.checklist.agw_mcp_integration"),
    ("Eval AI",             "technical_readiness.checklist.eval_ai"),
    ("Joule ORD Labels",    "technical_readiness.checklist.joule_ord_labels"),
    ("Audit Log V3",        "technical_readiness.checklist.audit_log_v3"),
    ("Extensibility",       "technical_readiness.checklist.supports_extensibility"),
    ("Level 0",             "technical_readiness.checklist.level_0"),
    ("Metering",            "technical_readiness.checklist.metering"),
    ("SPII Assistant",      "technical_readiness.checklist.spii_assistant"),
    ("Observability",       "technical_readiness.checklist.observability"),
    ("Memory",              "technical_readiness.checklist.memory"),
    ("SPII Endpoint",       "technical_readiness.checklist.spii_endpoint"),
    ("SPII AGW Foundation", "technical_readiness.checklist.spii_agw_foundation"),
    ("SPII Joule",          "technical_readiness.checklist.spii_joule"),
    ("ORD Endpoint",        "technical_readiness.checklist.validate_ord_endpoint"),
]

for i, (name, key) in enumerate(criteria):
    row = i + 3
    ws.row_dimensions[row].height = 22
    zebra = SAP_LIGHT_BG if i % 2 == 0 else WHITE

    # Criterion
    c = ws.cell(row=row, column=1, value=name)
    c.font = Font(bold=True, color=TEXT_DARK, size=9, name="Segoe UI")
    c.fill = fill(zebra)
    c.alignment = align("left", "center")
    c.border = border("all", BORDER_GRAY)

    # Key
    c = ws.cell(row=row, column=2, value=key)
    c.font = Font(color=TEXT_MID, size=8, name="Segoe UI", italic=True)
    c.fill = fill(zebra)
    c.alignment = align("left", "center")
    c.border = border("all", BORDER_GRAY)

    # Status (default: not started)
    c = ws.cell(row=row, column=3, value="not started")
    c.font = Font(color=C_NOTSTARTED[1], size=9, name="Segoe UI", bold=True)
    c.fill = fill(C_NOTSTARTED[0])
    c.alignment = align("center", "center")
    c.border = border("all", BORDER_GRAY)

    # Validated In (default: —)
    c = ws.cell(row=row, column=4, value="—")
    c.font = Font(color=TEXT_MID, size=9, name="Segoe UI")
    c.fill = fill(zebra)
    c.alignment = align("center", "center")
    c.border = border("all", BORDER_GRAY)

    # Required Env (default: TBD)
    c = ws.cell(row=row, column=5, value="TBD")
    c.font = Font(color=TEXT_LIGHT, size=9, name="Segoe UI", italic=True)
    c.fill = fill(zebra)
    c.alignment = align("center", "center")
    c.border = border("all", BORDER_GRAY)

    # Notes
    c = ws.cell(row=row, column=6, value="")
    c.font = Font(color=TEXT_DARK, size=9, name="Segoe UI")
    c.fill = fill(WHITE)
    c.alignment = align("left", "center", wrap=True)
    c.border = border("all", BORDER_GRAY)

    # % Complete (manual entry)
    c = ws.cell(row=row, column=7, value=0)
    c.font = Font(color=TEXT_DARK, size=9, name="Segoe UI", bold=True)
    c.fill = fill(zebra)
    c.alignment = align("center", "center")
    c.border = border("all", BORDER_GRAY)
    c.number_format = '0"%"'

# ── Summary row ───────────────────────────────────────────────────────────────
sum_row = len(criteria) + 3
ws.row_dimensions[sum_row].height = 24
ws.merge_cells(f"A{sum_row}:B{sum_row}")
c = ws[f"A{sum_row}"]
c.value = "Summary"
c.font = Font(bold=True, color=WHITE, size=9, name="Segoe UI")
c.fill = fill(SAP_NAVY)
c.alignment = align("left", "center")
c.border = border("all", SAP_NAVY)

status_range = f"C3:C{sum_row - 1}"
summary_labels = [
    ("full",        f'=COUNTIF({status_range},"full")',        C_FULL),
    ("partial",     f'=COUNTIF({status_range},"partial")',     C_PARTIAL),
    ("in progress", f'=COUNTIF({status_range},"in progress")', C_INPROG),
    ("not started", f'=COUNTIF({status_range},"not started")', C_NOTSTARTED),
]
for col_offset, (label, formula, colors) in enumerate(summary_labels):
    col = 3 + col_offset
    c = ws.cell(row=sum_row, column=col,
                value=f'{label}: ')
    # We'll put label + count in the same cell via a formula trick —
    # just put the count and let the label column header speak
    c = ws.cell(row=sum_row, column=col, value=formula)
    c.font = Font(bold=True, color=colors[1], size=9, name="Segoe UI")
    c.fill = fill(colors[0])
    c.alignment = align("center", "center")
    c.border = border("all", BORDER_GRAY)

# Notes cell for summary
c = ws.cell(row=sum_row, column=6, value="")
c.fill = fill(SAP_LIGHT_BG)
c.border = border("all", BORDER_GRAY)

# Avg % Complete in summary
pct_range = f"G3:G{sum_row - 1}"
c = ws.cell(row=sum_row, column=7, value=f"=AVERAGE({pct_range})")
c.font = Font(bold=True, color=SAP_NAVY, size=9, name="Segoe UI")
c.fill = fill(C_HEADER_ROW[0])
c.alignment = align("center", "center")
c.border = border("all", BORDER_GRAY)
c.number_format = '0"%"'

# ── Dropdown validations ──────────────────────────────────────────────────────
dv_status = DataValidation(
    type="list",
    formula1='"not started,in progress,partial,full"',
    allow_blank=False,
    showDropDown=False,
    showErrorMessage=True,
    errorTitle="Invalid status",
    error="Choose: not started, in progress, partial, full"
)
dv_status.sqref = f"C3:C{sum_row - 1}"
ws.add_data_validation(dv_status)

dv_env_validated = DataValidation(
    type="list",
    formula1='"—,sandbox,productive"',
    allow_blank=False,
    showDropDown=False
)
dv_env_validated.sqref = f"D3:D{sum_row - 1}"
ws.add_data_validation(dv_env_validated)

dv_env_required = DataValidation(
    type="list",
    formula1='"TBD,sandbox,productive"',
    allow_blank=False,
    showDropDown=False
)
dv_env_required.sqref = f"E3:E{sum_row - 1}"
ws.add_data_validation(dv_env_required)

# ── Conditional formatting on Status column ───────────────────────────────────
status_cells = f"C3:C{sum_row - 1}"

from openpyxl.formatting.rule import Rule
from openpyxl.styles.differential import DifferentialStyle

def make_cf_rule(value, bg, fg):
    dxf = DifferentialStyle(
        fill=PatternFill(bgColor=bg),
        font=Font(color=fg, bold=True, name="Segoe UI")
    )
    return Rule(type="containsText", operator="containsText",
                text=value, dxf=dxf,
                formula=[f'NOT(ISERROR(SEARCH("{value}",C3)))'])

ws.conditional_formatting.add(status_cells, make_cf_rule("full",        C_FULL[0],        C_FULL[1]))
ws.conditional_formatting.add(status_cells, make_cf_rule("partial",     C_PARTIAL[0],     C_PARTIAL[1]))
ws.conditional_formatting.add(status_cells, make_cf_rule("in progress", C_INPROG[0],      C_INPROG[1]))
ws.conditional_formatting.add(status_cells, make_cf_rule("not started", C_NOTSTARTED[0],  C_NOTSTARTED[1]))


# ══════════════════════════════════════════════════════════════════════════════
# SHEET 3 — Resources
# ══════════════════════════════════════════════════════════════════════════════
ws_res = wb.create_sheet("Resources")
ws_res.sheet_view.showGridLines = False

ws_res.column_dimensions["A"].width = 30
ws_res.column_dimensions["B"].width = 55
ws_res.column_dimensions["C"].width = 40

# Header banner
ws_res.merge_cells("A1:C1")
c = ws_res["A1"]
c.value = "Resources"
c.font = Font(bold=True, color=WHITE, size=13, name="Segoe UI")
c.fill = fill(SAP_NAVY)
c.alignment = align("left", "center")
ws_res.row_dimensions[1].height = 32

# Column headers
res_headers = ["Title / Description", "URL", "Notes"]
for i, h in enumerate(res_headers, 1):
    c = ws_res.cell(row=2, column=i, value=h)
    c.font = Font(bold=True, color=SAP_NAVY, size=9, name="Segoe UI")
    c.fill = fill(C_HEADER_ROW[0])
    c.alignment = align("center", "center")
    c.border = border("all", BORDER_GRAY)
ws_res.row_dimensions[2].height = 22

# Pre-seed with standards doc row
seed_rows = [
    ("TR Standards (Central Team)", "", "The TR checklist definition published by central team"),
    ("ORD Endpoint Docs", "", ""),
    ("SPII Implementation Guide", "", ""),
    ("A2A Protocol Reference", "", ""),
    ("SAP Cloud SDK Python", "", ""),
    ("Eval AI (aeval) Setup", "", ""),
    ("Audit Log V3 Docs", "", ""),
    ("Extensibility Framework", "", ""),
    ("Metering / OTel Guide", "", ""),
]
for i, (title, url, notes) in enumerate(seed_rows):
    row = i + 3
    ws_res.row_dimensions[row].height = 22
    zebra = SAP_LIGHT_BG if i % 2 == 0 else WHITE

    for col_i, val in enumerate([title, url, notes], 1):
        c = ws_res.cell(row=row, column=col_i, value=val)
        c.font = Font(color=TEXT_MID if col_i == 1 else TEXT_DARK, size=9,
                      name="Segoe UI", italic=(col_i == 1))
        c.fill = fill(zebra)
        c.alignment = align("left", "center")
        c.border = border("all", BORDER_GRAY)


# ── Save ──────────────────────────────────────────────────────────────────────
# Fix cross-sheet formula now that sum_row is known
ws_info["B19"].value = f"=Tracker!G{sum_row}"

out_path = r"c:\Users\I764259\OneDrive - SAP SE\Desktop\APP_FNDA\GRAC-ACCESS-REV-POC\agent_tr_tracker_template.xlsx"
wb.save(out_path)
print(f"Saved: {out_path}")
