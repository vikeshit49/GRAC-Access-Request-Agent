from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt
import copy

# ── Colour palette ─────────────────────────────────────────────────────────────
SAP_BLUE       = RGBColor(0x00, 0x3F, 0x72)   # dark SAP blue
SAP_GOLD       = RGBColor(0xF0, 0xAB, 0x00)   # SAP gold accent
WHITE          = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_GREY     = RGBColor(0xF5, 0xF5, 0xF5)
MID_GREY       = RGBColor(0x60, 0x60, 0x60)
DARK_GREY      = RGBColor(0x33, 0x33, 0x33)
TABLE_HEADER   = RGBColor(0x00, 0x3F, 0x72)
TABLE_ROW_ALT  = RGBColor(0xE8, 0xF0, 0xF8)

prs = Presentation()
prs.slide_width  = Inches(13.33)
prs.slide_height = Inches(7.5)

BLANK = prs.slide_layouts[6]   # completely blank layout


# ── Helpers ────────────────────────────────────────────────────────────────────

def add_rect(slide, l, t, w, h, fill=None, line_color=None, line_width=Pt(0)):
    shape = slide.shapes.add_shape(1, Inches(l), Inches(t), Inches(w), Inches(h))
    shape.line.width = line_width
    if fill:
        shape.fill.solid()
        shape.fill.fore_color.rgb = fill
    else:
        shape.fill.background()
    if line_color:
        shape.line.color.rgb = line_color
    else:
        shape.line.fill.background()
    return shape


def add_textbox(slide, l, t, w, h, text, size=18, bold=False, color=DARK_GREY,
                align=PP_ALIGN.LEFT, wrap=True, italic=False):
    txb = slide.shapes.add_textbox(Inches(l), Inches(t), Inches(w), Inches(h))
    txb.word_wrap = wrap
    tf = txb.text_frame
    tf.word_wrap = wrap
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    return txb


def add_text_lines(slide, l, t, w, h, lines, base_size=16, color=DARK_GREY):
    """lines = list of (text, size, bold, italic, indent)"""
    txb = slide.shapes.add_textbox(Inches(l), Inches(t), Inches(w), Inches(h))
    txb.word_wrap = True
    tf = txb.text_frame
    tf.word_wrap = True
    first = True
    for (text, size, bold, italic, indent) in lines:
        if first:
            p = tf.paragraphs[0]
            first = False
        else:
            p = tf.add_paragraph()
        p.space_before = Pt(3)
        if indent:
            p.level = 1
        run = p.add_run()
        run.text = text
        run.font.size = Pt(size)
        run.font.bold = bold
        run.font.italic = italic
        run.font.color.rgb = color
    return txb


def slide_background(slide, color=WHITE):
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = color


def add_top_bar(slide, title_text, subtitle_text=None):
    add_rect(slide, 0, 0, 13.33, 1.4, fill=SAP_BLUE)
    add_textbox(slide, 0.4, 0.15, 12.5, 0.8, title_text,
                size=28, bold=True, color=WHITE, align=PP_ALIGN.LEFT)
    if subtitle_text:
        add_textbox(slide, 0.4, 0.85, 12.5, 0.45, subtitle_text,
                    size=14, bold=False, color=SAP_GOLD, align=PP_ALIGN.LEFT)
    # thin gold rule under bar
    add_rect(slide, 0, 1.4, 13.33, 0.04, fill=SAP_GOLD)


def add_footer(slide, text="Building Agents on SAP BTP — What's Actually Inside"):
    add_rect(slide, 0, 7.2, 13.33, 0.3, fill=SAP_BLUE)
    add_textbox(slide, 0.3, 7.22, 12.7, 0.25, text,
                size=9, color=WHITE, align=PP_ALIGN.LEFT)


def add_table(slide, l, t, w, headers, rows, col_widths=None):
    cols = len(headers)
    row_count = len(rows) + 1
    tbl = slide.shapes.add_table(row_count, cols,
                                  Inches(l), Inches(t),
                                  Inches(w), Inches(0.35 * row_count)).table
    if col_widths:
        total = sum(col_widths)
        for i, cw in enumerate(col_widths):
            tbl.columns[i].width = Inches(w * cw / total)

    def cell_set(cell, text, bg, fg=WHITE, bold=False, sz=12):
        cell.text = text
        cell.fill.solid()
        cell.fill.fore_color.rgb = bg
        p = cell.text_frame.paragraphs[0]
        p.alignment = PP_ALIGN.LEFT
        run = p.runs[0] if p.runs else p.add_run()
        run.font.size = Pt(sz)
        run.font.bold = bold
        run.font.color.rgb = fg

    for ci, h in enumerate(headers):
        cell_set(tbl.cell(0, ci), h, TABLE_HEADER, WHITE, bold=True, sz=12)

    for ri, row in enumerate(rows):
        bg = TABLE_ROW_ALT if ri % 2 == 0 else WHITE
        for ci, val in enumerate(row):
            cell_set(tbl.cell(ri + 1, ci), val, bg, DARK_GREY, sz=11)

    return tbl


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 1 — Title
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, SAP_BLUE)

# big white title
add_textbox(sl, 1.0, 1.8, 11.3, 1.5,
            "Building Agents on SAP BTP", size=40, bold=True, color=WHITE,
            align=PP_ALIGN.CENTER)
add_textbox(sl, 1.0, 3.1, 11.3, 0.8,
            "What's Actually Inside", size=36, bold=True, color=SAP_GOLD,
            align=PP_ALIGN.CENTER)
add_rect(sl, 3.5, 3.95, 6.3, 0.05, fill=WHITE)
add_textbox(sl, 1.0, 4.1, 11.3, 0.6,
            "What they are, how they work, and how you can start building one",
            size=16, color=WHITE, align=PP_ALIGN.CENTER, italic=True)

add_footer(sl)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 2 — Agenda
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, WHITE)
add_top_bar(sl, "What We'll Cover Today")
add_footer(sl)

agenda_items = [
    ("1", "What is an agent, really"),
    ("2", "The agentic loop"),
    ("3", "Your starting point: the bootstrap"),
    ("4", "Is your use case a good fit?"),
    ("5", "Key takeaways"),
]
box_top = 1.6
for num, label in agenda_items:
    add_rect(sl, 0.5, box_top, 0.5, 0.45, fill=SAP_BLUE)
    add_textbox(sl, 0.5, box_top, 0.5, 0.45, num, size=16, bold=True,
                color=WHITE, align=PP_ALIGN.CENTER)
    add_textbox(sl, 1.2, box_top + 0.04, 10.0, 0.4, label,
                size=16, color=DARK_GREY)
    box_top += 0.65


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 3 — Section card: What Is an Agent
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, SAP_BLUE)
add_textbox(sl, 1.0, 2.0, 11.3, 0.6, "Section 1 of 4",
            size=18, color=SAP_GOLD, align=PP_ALIGN.CENTER)
add_textbox(sl, 1.0, 2.7, 11.3, 1.2, "What Is an Agent, Really",
            size=36, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
add_rect(sl, 4.0, 4.0, 5.3, 0.06, fill=SAP_GOLD)
add_footer(sl)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 4 — What an agent is
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, WHITE)
add_top_bar(sl, "An Agent Is Not a Chatbot")
add_footer(sl)

# Left panel
add_rect(sl, 0.4, 1.6, 5.8, 1.1, fill=LIGHT_GREY)
add_textbox(sl, 0.6, 1.65, 5.4, 0.45, "A chatbot responds.", size=15, bold=True, color=MID_GREY)
add_textbox(sl, 0.6, 2.05, 5.4, 0.55,
            "An agent does something.", size=17, bold=True, color=SAP_BLUE)

add_textbox(sl, 0.4, 2.85, 5.8, 0.55,
            "Like asking a colleague to go figure it out and come back to you — not just answer the question.",
            size=13, color=MID_GREY, italic=True)

# Right panel — three pillars
pillar_data = [
    ("1. Brain", "An LLM that reasons\nabout what to do next"),
    ("2. Tools", "Capabilities it uses to\nget information or act"),
    ("3. Loop", "Keeps working until\nthe job is done"),
]
px = 6.6
for title, desc in pillar_data:
    add_rect(sl, px, 1.6, 2.1, 1.6, fill=SAP_BLUE)
    add_textbox(sl, px + 0.1, 1.65, 1.9, 0.5, title, size=14, bold=True, color=SAP_GOLD)
    add_textbox(sl, px + 0.1, 2.1, 1.9, 0.9, desc, size=12, color=WHITE)
    px += 2.2

add_textbox(sl, 0.4, 4.3, 12.5, 0.4,
            "Take any one of these away and you no longer have an agent.",
            size=13, bold=True, color=SAP_BLUE)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 5 — Section card: The Agentic Loop
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, SAP_BLUE)
add_textbox(sl, 1.0, 2.0, 11.3, 0.6, "Section 2 of 4",
            size=18, color=SAP_GOLD, align=PP_ALIGN.CENTER)
add_textbox(sl, 1.0, 2.7, 11.3, 1.2, "The Agentic Loop",
            size=36, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
add_rect(sl, 4.0, 4.0, 5.3, 0.06, fill=SAP_GOLD)
add_footer(sl)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 6 — The agentic loop
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, WHITE)
add_top_bar(sl, "How an Agent Thinks: Reason → Think → Act → Observe → Repeat")
add_footer(sl)

steps = [
    ("Reason",  "What is the situation? What do I know so far?"),
    ("Think",   "What is the best next step given what I know?"),
    ("Act",     "Do it — call a tool, fetch data, take an action"),
    ("Observe", "What came back? What does this tell me?"),
    ("Repeat",  "Start again, now with more information — until done"),
]
sx = 0.35
for step, desc in steps:
    add_rect(sl, sx, 1.6, 2.3, 0.65, fill=SAP_BLUE)
    add_textbox(sl, sx + 0.08, 1.62, 2.15, 0.32, step, size=13, bold=True, color=SAP_GOLD)
    add_textbox(sl, sx + 0.08, 1.93, 2.15, 0.28, desc, size=10, color=WHITE)
    if sx < 10.0:
        add_textbox(sl, sx + 2.3, 1.85, 0.25, 0.3, "→", size=16, bold=True, color=SAP_BLUE)
    sx += 2.6

# Why it matters bullets
bullets = [
    "Handle tasks where the number of steps isn't known in advance",
    "Change direction if what it finds leads somewhere unexpected",
    "Work across multiple systems — each as a separate step",
    "Ask for clarification when it doesn't have enough to proceed",
]
add_textbox(sl, 0.4, 2.55, 8.0, 0.4,
            "Because of this loop, an agent can:", size=13, bold=True, color=DARK_GREY)
bt = 2.95
for b in bullets:
    add_textbox(sl, 0.7, bt, 10.5, 0.35, f"•  {b}", size=12, color=DARK_GREY)
    bt += 0.38

add_textbox(sl, 0.4, 4.45, 12.5, 0.4,
            "This is what makes an agent fundamentally different from a script or a workflow.",
            size=13, bold=True, color=SAP_BLUE)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 7 — Section card: The Bootstrap
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, SAP_BLUE)
add_textbox(sl, 1.0, 2.0, 11.3, 0.6, "Section 3 of 4",
            size=18, color=SAP_GOLD, align=PP_ALIGN.CENTER)
add_textbox(sl, 1.0, 2.7, 11.3, 1.2, "Your Starting Point: The Bootstrap",
            size=36, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
add_rect(sl, 4.0, 4.0, 5.3, 0.06, fill=SAP_GOLD)
add_footer(sl)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 8 — The bootstrap + five files
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, WHITE)
add_top_bar(sl, "Two Inputs. A Running Agent.",
            "sap-agent-bootstrap skill")
add_footer(sl)

# Inputs → outputs strip
add_textbox(sl, 0.4, 1.55, 3.5, 0.35, "You provide:", size=13, bold=True, color=SAP_BLUE)
add_textbox(sl, 0.4, 1.9,  3.5, 0.3,  "• Agent name", size=12, color=DARK_GREY)
add_textbox(sl, 0.4, 2.2,  3.5, 0.3,  "• Agent description", size=12, color=DARK_GREY)

add_textbox(sl, 4.2, 1.55, 0.8, 0.9, "→", size=32, bold=True, color=SAP_GOLD, align=PP_ALIGN.CENTER)

you_get = [
    "Connected to SAP AI Core",
    "Registered with Joule",
    "CI/CD pipeline via GitHub Actions",
    "AgentCard published",
    "Telemetry instrumented",
]
add_textbox(sl, 5.2, 1.55, 4.0, 0.35, "You get:", size=13, bold=True, color=SAP_BLUE)
yt = 1.9
for item in you_get:
    add_rect(sl, 5.2, yt, 0.25, 0.25, fill=SAP_GOLD)
    add_textbox(sl, 5.55, yt, 3.5, 0.28, item, size=12, color=DARK_GREY)
    yt += 0.32

# Files table
add_textbox(sl, 0.4, 3.45, 12.5, 0.35,
            "Five files are created — each owns one job:", size=13, bold=True, color=DARK_GREY)

add_table(sl, 0.4, 3.85, 12.5,
          headers=["File", "What it does"],
          rows=[
              ["app/agent.py",          "The brain — agent logic and system prompt"],
              ["app/agent_executor.py", "The bridge — connects Joule to your agent"],
              ["app/main.py",           "The front door — registers agent, starts server"],
              ["app.yaml",              "The deployment config — model, name, services"],
              ["Dockerfile + CI/CD",    "The delivery — build and deploy pipeline"],
          ],
          col_widths=[3, 9])

add_textbox(sl, 0.4, 6.6, 12.5, 0.35,
            "The one file you always edit first:  app/agent.py  — specifically the system prompt.",
            size=12, bold=True, color=SAP_BLUE)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 9 — The system prompt
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, WHITE)
add_top_bar(sl, "The System Prompt: Your Agent's Job Description")
add_footer(sl)

add_textbox(sl, 0.4, 1.6, 12.5, 0.4,
            "The single most important thing you write.", size=16, bold=True, color=SAP_BLUE)

tells = [
    "What the agent is and what it's there to do",
    "How it should approach problems",
    "What it should and shouldn't do",
    "Domain knowledge it needs to do its job well",
]
add_textbox(sl, 0.4, 2.1, 6.0, 0.35, "It tells the agent:", size=13, bold=True, color=DARK_GREY)
tt = 2.5
for item in tells:
    add_textbox(sl, 0.7, tt, 5.8, 0.32, f"•  {item}", size=13, color=DARK_GREY)
    tt += 0.36

# Highlight box
add_rect(sl, 6.5, 1.6, 6.4, 2.2, fill=SAP_BLUE)
add_textbox(sl, 6.7, 1.7, 6.0, 0.45,
            "Treat it like code.", size=15, bold=True, color=SAP_GOLD)
add_textbox(sl, 6.7, 2.15, 6.0, 0.35,
            "Keep it in version control.", size=13, color=WHITE)
add_textbox(sl, 6.7, 2.5, 6.0, 0.35,
            "Iterate on it.", size=13, color=WHITE)
add_textbox(sl, 6.7, 3.0, 6.0, 0.6,
            "Most agent failures are system\nprompt failures.", size=13, bold=True, color=SAP_GOLD)

add_textbox(sl, 0.4, 4.05, 12.5, 0.35,
            "If your agent gives wrong answers, look here first.",
            size=14, bold=True, color=SAP_BLUE)

add_textbox(sl, 0.4, 4.5, 12.5, 0.5,
            "No platform skill can write your business rules, domain knowledge, or compliance requirements for you.\nThis is where your LOB expertise lives.",
            size=12, color=MID_GREY, italic=True)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 10 — Platform vs. what you build
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, WHITE)
add_top_bar(sl, "What the Platform Covers — And What's Still Yours")
add_footer(sl)

# Left table — covered
add_textbox(sl, 0.4, 1.55, 6.0, 0.35,
            "Bootstrap + skills handle:", size=13, bold=True, color=SAP_BLUE)
add_table(sl, 0.4, 1.95, 6.2,
          headers=["Capability", ""],
          rows=[
              ["Connected to SAP AI Core and Joule",    "Yes"],
              ["CI/CD and deployment pipeline",          "Yes"],
              ["Context management (long conversations)","Yes"],
              ["MCP client to connect to backends",      "Yes"],
              ["Structured output framework",            "Yes"],
              ["Response formatting",                    "Yes"],
          ],
          col_widths=[5, 1.2])

# Right table — yours
add_textbox(sl, 6.8, 1.55, 6.1, 0.35,
            "What's still yours — from LOB perspective:", size=13, bold=True, color=SAP_BLUE)
add_table(sl, 6.8, 1.95, 6.1,
          headers=["You build", "Why"],
          rows=[
              ["System prompt & domain knowledge",    "No skill writes your business rules"],
              ["MCP server / Agent Gateway setup",    "Skills give client — you expose capabilities"],
              ["Structured output schema",            "You define what fields your use case needs"],
              ["Joule UI card design",                "Buttons, lists, postbacks — yours to design"],
              ["Backend authentication",              "Your system's credentials & token handling"],
              ["Conversation memory & thread IDs",   "Persistent multi-turn memory across sessions"],
              ["Audit logging & compliance",          "Your LOB's specific requirements"],
              ["Error handling",                      "What agent says when something goes wrong"],
          ],
          col_widths=[3.2, 2.9])


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 11 — Section card: Use Case Fit
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, SAP_BLUE)
add_textbox(sl, 1.0, 2.0, 11.3, 0.6, "Section 4 of 4",
            size=18, color=SAP_GOLD, align=PP_ALIGN.CENTER)
add_textbox(sl, 1.0, 2.7, 11.3, 1.2, "Is Your Use Case a Good Fit?",
            size=36, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
add_rect(sl, 4.0, 4.0, 5.3, 0.06, fill=SAP_GOLD)
add_footer(sl)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 12 — Fit or not fit
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, WHITE)
add_top_bar(sl, "Three Questions — and Three Signs It's the Wrong Tool")
add_footer(sl)

# Left — use it
add_rect(sl, 0.4, 1.6, 6.0, 0.4, fill=SAP_BLUE)
add_textbox(sl, 0.5, 1.62, 5.8, 0.36,
            "Use an agent when you answer YES to at least two:",
            size=13, bold=True, color=WHITE)

questions = [
    "1.  Would a human expert need to look at data before deciding what to do next?",
    "2.  Does the answer require information from more than one system?",
    "3.  Does the path change depending on what the data says?",
]
qt = 2.1
for q in questions:
    add_rect(sl, 0.4, qt, 0.3, 0.45, fill=SAP_GOLD)
    add_textbox(sl, 0.85, qt + 0.05, 5.4, 0.38, q, size=12, color=DARK_GREY)
    qt += 0.58

# Right — don't use it
add_rect(sl, 6.8, 1.6, 6.1, 0.4, fill=RGBColor(0xCC, 0x33, 0x33))
add_textbox(sl, 6.9, 1.62, 5.9, 0.36,
            "Don't use an agent when:",
            size=13, bold=True, color=WHITE)

dont_items = [
    ("Simple lookup",        "\"What is user X's balance?\" → just call the API"),
    ("Fixed process",        "Same steps every time → use a workflow"),
    ("Sub-second response",  "Agents have loop overhead — not for real-time"),
    ("Pure data display",    "Report or table → a UI component is better"),
]
dt = 2.1
for title, desc in dont_items:
    add_textbox(sl, 6.8, dt, 2.0, 0.42, f"• {title}", size=12, bold=True, color=SAP_BLUE)
    add_textbox(sl, 8.9, dt, 3.9, 0.42, desc, size=11, color=MID_GREY)
    dt += 0.52

add_rect(sl, 0.4, 4.3, 12.5, 0.5, fill=LIGHT_GREY)
add_textbox(sl, 0.6, 4.35, 12.1, 0.38,
            "Agents are slower and more expensive than direct API calls.  Justify the cost with complexity.",
            size=13, bold=True, color=SAP_BLUE)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 13 — Key Takeaways
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
slide_background(sl, WHITE)
add_top_bar(sl, "Key Takeaways")
add_footer(sl)

takeaways = [
    ("1", "An agent = brain + tools + loop.",
          "The loop is what makes it different from a chatbot or a script."),
    ("2", "Bootstrap = connected and running, not finished.",
          "Two inputs, one skill, a deployed agent. Then you build on top."),
    ("3", "The system prompt is your most important file.",
          "Write it seriously. Most agent failures start here."),
    ("4", "The platform covers infrastructure. You cover domain.",
          "Skills handle context, MCP, structured output. Business rules are yours."),
    ("5", "Start minimal. Add one capability at a time.",
          "Driven by real problems — not by what looks impressive."),
    ("6", "Test use case fit before you build.",
          "Variable path + multiple systems = fits. Fixed flow = it doesn't."),
]

tx = 0.4
ty = 1.6
col_w = 6.1
for i, (num, headline, detail) in enumerate(takeaways):
    cx = tx if i % 2 == 0 else tx + col_w + 0.5
    cy = ty + (i // 2) * 1.55
    add_rect(sl, cx, cy, col_w, 1.35, fill=LIGHT_GREY)
    add_rect(sl, cx, cy, 0.45, 1.35, fill=SAP_BLUE)
    add_textbox(sl, cx, cy + 0.45, 0.45, 0.45, num, size=16, bold=True,
                color=WHITE, align=PP_ALIGN.CENTER)
    add_textbox(sl, cx + 0.55, cy + 0.05, col_w - 0.65, 0.42,
                headline, size=13, bold=True, color=SAP_BLUE)
    add_textbox(sl, cx + 0.55, cy + 0.5, col_w - 0.65, 0.75,
                detail, size=11, color=MID_GREY)


# ── Save ───────────────────────────────────────────────────────────────────────
out = "Session2_Building_Agents_on_SAP_BTP.pptx"
prs.save(out)
print(f"Saved: {out}")