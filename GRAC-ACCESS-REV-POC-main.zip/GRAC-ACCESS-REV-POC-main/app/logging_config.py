import json
import logging


class _JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict = {
            "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "level":     record.levelname,
            "logger":    record.name,
            "message":   record.getMessage(),
        }
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        # Inject OTel trace/span IDs when present on the record
        for otel_field in ("otelTraceID", "otelSpanID", "otelServiceName"):
            val = getattr(record, otel_field, None)
            if val:
                payload[otel_field] = val
        # Inject extension context attributes (set by ExtensionContextLogFilter)
        for ext_field in (
            "ext_is_extension", "ext_extension_type", "ext_capability_id",
            "ext_extension_id", "ext_extension_name", "ext_extension_version",
            "ext_item_name",
        ):
            val = getattr(record, ext_field, None)
            if val is not None:
                payload[ext_field] = val
        return json.dumps(payload, ensure_ascii=False)


def setup_logging(level: int = logging.INFO) -> None:
    """Configure root logger with JSON output. Call once at process startup."""
    handler = logging.StreamHandler()
    handler.setFormatter(_JsonFormatter())
    # ExtensionContextLogFilter injects ext_* attributes from OTel baggage into
    # each LogRecord emitted inside an extension_context() block.  The filter
    # must be on the handler (not the logger) so it runs for propagated records.
    try:
        from extension_telemetry.log_filter import ExtensionContextLogFilter
        handler.addFilter(ExtensionContextLogFilter())
    except Exception:
        pass
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)
