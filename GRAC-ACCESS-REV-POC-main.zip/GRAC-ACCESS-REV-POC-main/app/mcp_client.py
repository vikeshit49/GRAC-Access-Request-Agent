"""MCP Client — connects to GRAC ARQ MCP Server on MCP Hub via Destination Service."""

import logging
import os
from pathlib import Path
from typing import Any, Optional

import httpx
import jwt
import yaml
from httpx import Auth, Request
from langchain_mcp_adapters.client import MultiServerMCPClient

logger = logging.getLogger(__name__)

BINDING_BASE_PATH = "/etc/secrets/appfnd/destination"


def _read_destination_binding(instance_name: str) -> dict:
    binding_dir = Path(BINDING_BASE_PATH) / instance_name
    if binding_dir.exists():
        required = ["clientid", "clientsecret", "url", "uri"]
        if all((binding_dir / f).exists() for f in required):
            data = {}
            for f in required:
                data[f] = (binding_dir / f).read_text().strip()
            logger.info("Read destination binding from %s", binding_dir)
            return data

    # Fallback to env vars (local dev)
    client_id     = os.getenv("DESTINATION_CLIENT_ID")
    client_secret = os.getenv("DESTINATION_CLIENT_SECRET")
    auth_url      = os.getenv("DESTINATION_AUTH_URL")
    base_url      = os.getenv("DESTINATION_BASE_URL")

    if not all([client_id, client_secret, auth_url, base_url]):
        raise ValueError(
            f"Destination binding not found at {binding_dir}. "
            "Set DESTINATION_CLIENT_ID / CLIENT_SECRET / AUTH_URL / BASE_URL env vars for local dev."
        )
    return {"clientid": client_id, "clientsecret": client_secret, "url": auth_url, "uri": base_url}


def _get_destination_token(binding: dict) -> str:
    with httpx.Client(timeout=15.0) as client:
        resp = client.post(
            f"{binding['url']}/oauth/token",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type":    "client_credentials",
                "client_id":     binding["clientid"],
                "client_secret": binding["clientsecret"],
            },
        )
        resp.raise_for_status()
        return resp.json()["access_token"]


def _resolve_destination(name: str, binding: dict, dest_token: str) -> tuple[str, str]:
    url = f"{binding['uri']}/destination-configuration/v1/destinations/{name}"
    with httpx.Client(timeout=15.0) as client:
        resp = client.get(url, headers={"Authorization": f"Bearer {dest_token}"})
        if not resp.is_success:
            raise RuntimeError(f"Destination '{name}' fetch failed: {resp.status_code} {resp.text}")
        cfg = resp.json()

    tokens = cfg.get("authTokens", [])
    if not tokens:
        raise RuntimeError(f"No auth tokens in destination '{name}'")
    token    = tokens[0]["value"]
    base_url = cfg.get("destinationConfiguration", {}).get("URL", "")
    if not base_url:
        raise RuntimeError(f"No URL in destination '{name}'")
    return base_url, token


class _MCPBearerAuth(Auth):
    """httpx Auth handler with automatic token refresh for MCP Hub."""

    def __init__(self, dest_name: str, dest_instance: str):
        self._dest_name     = dest_name
        self._dest_instance = dest_instance
        self.base_url, self._token = self._fetch()

    def _fetch(self) -> tuple[str, str]:
        binding   = _read_destination_binding(self._dest_instance)
        dest_tok  = _get_destination_token(binding)
        return _resolve_destination(self._dest_name, binding, dest_tok)

    def _is_expired(self) -> bool:
        try:
            jwt.decode(self._token, algorithms=["RS256"],
                       options={"verify_exp": True, "verify_signature": False})
            return False
        except jwt.ExpiredSignatureError:
            return True
        except Exception:
            return False

    def auth_flow(self, request: Request):
        if self._is_expired():
            self.base_url, self._token = self._fetch()
        request.headers["Authorization"] = f"Bearer {self._token}"
        yield request


async def get_mcp_client() -> MultiServerMCPClient:
    """
    Read app.yaml, resolve each enabled MCP server via Destination Service,
    and return a ready MultiServerMCPClient.
    """
    app_yaml = Path(__file__).parent.parent / "app.yaml"
    if not app_yaml.exists():
        raise ValueError(f"app.yaml not found at {app_yaml}")

    with open(app_yaml) as f:
        cfg = yaml.safe_load(f)

    spec = cfg.get("spec", {})

    # Resolve destination instance name
    dest_instance: Optional[str] = None
    for req in spec.get("requires", []):
        if req.get("service") == "destination":
            dest_instance = req.get("name")
            break
    if not dest_instance:
        raise ValueError("No destination service entry in app.yaml spec.requires")

    servers = spec.get("servers", [])
    if not servers:
        raise ValueError("No servers configured in app.yaml spec.servers")

    mcp_config: dict[str, dict[str, Any]] = {}
    for srv in servers:
        if not srv.get("enabled", True):
            continue
        server_id = srv.get("id")
        if not server_id:
            logger.warning("MCP server entry missing 'id', skipping")
            continue

        dest_name = srv.get("destination") or os.getenv("MCP_DEST_NAME")
        if not dest_name:
            logger.error("No MCP destination configured for server '%s' — set MCP_DEST_NAME in app.yaml", server_id)
            continue
        try:
            auth       = _MCPBearerAuth(dest_name, dest_instance)
            # TEMP: MCP_HUB_GENERATOR points to /hub — rewrite to /mcp for tool endpoint
            # server_url = f"{auth.base_url.rstrip('/')}/{server_id}"
            base_url   = auth.base_url.rstrip('/').replace('/registry/v1/hub', '/registry/v1/mcp')
            server_url = f"{base_url}/{server_id}"
            key        = srv.get("name", server_id)
            mcp_config[key] = {
                "url":       server_url,
                "transport": "streamable_http",
                "auth":      auth,
            }
            logger.info("MCP server '%s' → %s", key, server_url)
        except Exception as e:
            logger.error("Failed to configure MCP server '%s': %s", server_id, e)

    if not mcp_config:
        raise ValueError("No MCP servers could be configured")

    client = MultiServerMCPClient(mcp_config)
    logger.info("MCP client ready with %d server(s)", len(mcp_config))
    return client
