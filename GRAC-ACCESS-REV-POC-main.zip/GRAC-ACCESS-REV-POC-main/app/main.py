# OTEL patch: remove Kyma's injected OTEL path BEFORE any imports.
import os
import sys
sys.path = [p for p in sys.path if "otel-auto-instrumentation" not in p]
for _mod in list(sys.modules.keys()):
    if _mod.startswith("opentelemetry"):
        del sys.modules[_mod]

# Cap OTel export timeouts
os.environ.setdefault("OTEL_EXPORTER_OTLP_TIMEOUT", "5000")
os.environ.setdefault("OTEL_BSP_EXPORT_TIMEOUT", "5000")
os.environ.setdefault("OTEL_BSP_MAX_EXPORT_BATCH_SIZE", "32")
os.environ.setdefault("OTEL_BLRP_EXPORT_TIMEOUT", "5000")
os.environ.setdefault("OTEL_METRIC_EXPORT_TIMEOUT", "5000")

# langgraph.runtime patch
try:
    from langgraph.runtime import ExecutionInfo, ServerInfo  # noqa: F401
except ImportError:
    import langgraph.runtime as _lgr
    class ExecutionInfo:  # type: ignore[no-redef]
        pass
    class ServerInfo:  # type: ignore[no-redef]
        pass
    _lgr.ExecutionInfo = ExecutionInfo  # type: ignore[attr-defined]
    _lgr.ServerInfo = ServerInfo  # type: ignore[attr-defined]

try:
    import langgraph.runtime as _lgr_rt
    if hasattr(_lgr_rt, "Runtime"):
        for _attr in ("execution_info", "server_info"):
            if not hasattr(_lgr_rt.Runtime, _attr):
                setattr(_lgr_rt.Runtime, _attr, None)
except Exception:
    pass

import logging

# OTel init
try:
    from sap_cloud_sdk.aicore import set_aicore_config
    set_aicore_config()
except Exception as e:
    print(f"[WARN] set_aicore_config failed: {e}")

auto_instrument = None
try:
    from sap_cloud_sdk.core.telemetry import auto_instrument
except Exception as e:
    print(f"[WARN] auto_instrument unavailable: {e}")

# Undo buggy MCP instrumentation injected by traceloop-sdk / auto_instrument().
# opentelemetry-instrumentation-mcp wraps BaseSession.send_request with a
# @dont_throw decorator that silently returns None on any tracing error,
# corrupting MCP initialize() responses with AttributeError on protocolVersion.
try:
    from opentelemetry.instrumentation.utils import unwrap
    unwrap("mcp.shared.session.BaseSession", "send_request")
    import mcp.client.streamable_http  # noqa: F401
    unwrap("mcp.client.streamable_http", "streamablehttp_client")
    # langchain_mcp_adapters caches a local binding via `from ... import` —
    # unwrap() above fixes the module but not the cached name.
    import langchain_mcp_adapters.sessions  # noqa: F401
    langchain_mcp_adapters.sessions.streamablehttp_client = (
        mcp.client.streamable_http.streamablehttp_client
    )
except Exception:
    pass  # Instrumentation was not active — nothing to unwrap

_IAS_MIDDLEWARE_AVAILABLE = False
try:
    from sap_cloud_sdk.core.telemetry.middleware import StarletteIASTelemetryMiddleware
    _IAS_MIDDLEWARE_AVAILABLE = True
except Exception:
    pass

import click
import uvicorn
from contextlib import asynccontextmanager
from a2a.server.context import ServerCallContext
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes import create_agent_card_routes, create_jsonrpc_routes
from a2a.server.routes.common import ServerCallContextBuilder
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCapabilities, AgentCard, AgentSkill
from starlette.applications import Starlette
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from agent_executor import GRACAgentExecutor, get_agent_instance
from context_vars import scp_session_id
from logging_config import setup_logging

setup_logging()
logger = logging.getLogger(__name__)

HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "9000"))


class JouleSessionMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        raw = request.headers.get("x-scp-request-id", "")
        if raw:
            parts  = raw.split("-")
            stable = "-".join(parts[:5]) if len(parts) >= 5 else raw
            scp_session_id.set(stable)
            logger.info(f"[Middleware] x-scp-request-id={raw} → stable={stable}")
        else:
            scp_session_id.set(None)
            logger.info("[Middleware] No x-scp-request-id header found")
        return await call_next(request)


class GRACContextBuilder(ServerCallContextBuilder):
    def build(self, request: Request) -> ServerCallContext:
        return ServerCallContext(state={"headers": dict(request.headers)})


@click.command()
@click.option("--host", default=HOST)
@click.option("--port", default=PORT)
def main(host: str, port: int):
    skill = AgentSkill(
        id="grac_access",
        name="GRAC Access & Risk Analysis",
        description=(
            "Runs risk analysis and creates GRAC access requests. "
            "Reviews user access assignments and roles in SAP GRC, "
            "identifies SoD conflicts, and provides access certification recommendations."
        ),
        tags=["grac", "access", "risk", "sod", "compliance", "sap"],
        examples=[
            "Review access for user John Doe",
            "Are there any SoD conflicts for the Finance team?",
            "What roles should be revoked in the current access review campaign?",
        ],
    )
    _agent_extensions = None
    try:
        from extension_capabilities import EXTENSION_CAPABILITIES as _EC
        from sap_cloud_sdk.extensibility import build_extension_capabilities as _build_ext
        _agent_extensions = _build_ext(_EC)
    except Exception as _ext_err:
        logger.warning("Extensibility not available: %s", _ext_err)

    agent_card = AgentCard(
        name="GRAC Agent",
        description="Agent for GRAC access request and risk analysis",
        version="1.0.0",
        capabilities=AgentCapabilities(
            streaming=True,
            push_notifications=False,
            extensions=_agent_extensions,
        ),
        default_input_modes=["text", "text/plain"],
        default_output_modes=["text", "text/plain", "application/json"],
        skills=[skill],
    )

    request_handler = DefaultRequestHandler(
        agent_executor=GRACAgentExecutor(),
        task_store=InMemoryTaskStore(),
        agent_card=agent_card,
    )

    async def health(request: Request) -> JSONResponse:
        return JSONResponse({"status": "ok"})

    from a2a.server.request_handlers.response_helpers import agent_card_to_dict

    async def agent_card_legacy(request: Request) -> JSONResponse:
        return JSONResponse(agent_card_to_dict(agent_card))

    routes = (
        create_agent_card_routes(agent_card)
        + create_jsonrpc_routes(
            request_handler=request_handler,
            rpc_url="/",
            context_builder=GRACContextBuilder(),
            enable_v0_3_compat=True,
        )
        + [
            Route("/.well-known/agent.json", endpoint=agent_card_legacy, methods=["GET"]),
            Route("/health", endpoint=health, methods=["GET"]),
        ]
    )

    @asynccontextmanager
    async def lifespan(app):
        yield

    app = Starlette(routes=routes, lifespan=lifespan)
    try:
        from opentelemetry.instrumentation.starlette import StarletteInstrumentor
        StarletteInstrumentor().instrument_app(app)
    except Exception as _e:
        logger.warning("StarletteInstrumentor unavailable: %s", _e)
    app.add_middleware(JouleSessionMiddleware)
    if _IAS_MIDDLEWARE_AVAILABLE:
        try:
            auto_instrument(middlewares=[StarletteIASTelemetryMiddleware(app=app)])
        except Exception as e:
            logger.warning("StarletteIASTelemetryMiddleware failed: %s", e)



    logger.info(f"Starting GRAC Access Review A2A server at http://{host}:{port}")
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    main()
