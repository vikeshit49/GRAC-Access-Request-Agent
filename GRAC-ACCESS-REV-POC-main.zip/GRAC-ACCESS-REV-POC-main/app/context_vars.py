from contextvars import ContextVar

scp_session_id: ContextVar[str] = ContextVar('scp_session_id', default=None)
