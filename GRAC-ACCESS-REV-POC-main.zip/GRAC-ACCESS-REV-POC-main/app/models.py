"""
Structured response model for the GRAC agent.

GRACResponse is bound to the LLM as a tool (following the LangGraph
"respond in structured format" pattern). The agent ALWAYS calls this
tool as its final step instead of producing free text. The action_type
field drives deterministic Joule UI card rendering in agent_executor.py.
"""

from typing import Literal, Optional
from pydantic import BaseModel, Field


class RoleItem(BaseModel):
    role_name:      str
    description:    str           = ""
    usage:          Optional[int] = None
    signal_summary: str           = Field(
        default="",
        description=(
            "One sentence built strictly from actual data returned by tools in this turn. "
            "Combine all available signals: peer adoption (count _PeerGroups rows), "
            "approval rate (AP / (AP+RE) from _Requests, exclude empty), "
            "org usage (TotalExecutionCount), T-code match (which requested T-codes appear in _actions), "
            "and rejection reason (CommentText from most recent RE row if approval rate is low). "
            "Example: '4 peers · 92% approval · 318 uses · covers ME21N' or "
            "'0 peers · 40% approval · last rejection: SoD conflict with MM01'. "
            "If a signal has no data, omit it. Never estimate or invent numbers."
        )
    )


class UserItem(BaseModel):
    user_id:       str
    display_name:  str = ""
    email:         str = ""
    peer_group_id: str = ""


class SystemItem(BaseModel):
    connector:       str
    connection_type: str = ""


class RiskItem(BaseModel):
    risk_id:           str
    occurrence_count:  int        = 0
    has_mitigation:    bool       = False
    conflicting_roles: list[str]  = Field(default_factory=list)
    accontrolids:      list[str]  = Field(default_factory=list)


class OptionItem(BaseModel):
    label:       str
    description: str = ""


class RoleUsage(BaseModel):
    role_name:       str
    execution_count: int
    usage_status:    str  # UNUSED | RARE | MODERATE | FREQUENT


class RequestCreated(BaseModel):
    request_number: str           # reqno — the only ID shown to users
    user_id:        Optional[str] = None
    role:           Optional[str] = None


class GRACResponse(BaseModel):
    """
    Final response to the user. Always call this tool as your last step —
    never produce free text as a final answer. The action_type field controls
    which Joule UI card is rendered. Choose it carefully:

    - select_intent:      Present a set of options to route the conversation — use when the user's intent needs clarification or branching. Populate intent_options.
    - select_role:        You found role candidates — show a selection list card.
    - select_user:        Multiple users matched a name — show a disambiguation card.
    - select_system:      Connector is unknown or multiple connectors found — show a system selection card.
    - analysis_complete:  SoD / usage analysis is done — show 3-option action card.
    - request_created:    A request was submitted — show confirmation message.
    - text:               Any other response — plain text, no card.

    CRITICAL RULE — never embed lists in the message field:
    Whenever you have a list of options for the user to choose from (roles, users, systems,
    or any other selection), you MUST use the appropriate select_* action_type and populate
    the corresponding candidates list. NEVER write the options as bullet points or numbered
    lists inside the message text. The message field is for a single short sentence only when
    a card is being shown. The card renders the options — the message just introduces it.
    """

    message: str = Field(
        description=(
            "Message text shown to the user. Use markdown. "
            "When action_type is select_*: ONE short sentence introducing the card (e.g. 'I found these systems — which one do you need?'). "
            "Never list the options here — they belong in the candidates list. "
            "For analysis_complete: full analysis text ending with 'What would you like to do next?' "
            "For text: plain conversational response."
        )
    )

    action_type: Literal[
        "select_intent",
        "select_role",
        "select_user",
        "select_system",
        "analysis_complete",
        "request_created",
        "text",
    ] = Field(description=(
        "Controls which Joule UI card is rendered. "
        "Choosing 'text' when you have a list of options (roles, users, systems) means no card renders "
        "and the user cannot make a structured selection — the conversation stalls. "
        "Always use the matching select_* type and populate its candidates list instead."
    ))

    intent_options: list[OptionItem] = Field(
        default_factory=list,
        description="Populate when action_type is select_intent. One entry per option — set label to the human-readable option text, description to a short explanation. Empty for all other action types."
    )

    role_candidates: list[RoleItem] = Field(
        default_factory=list,
        description="Populate when action_type is select_role. One entry per role candidate (max 5). Empty for all other action types."
    )

    user_candidates: list[UserItem] = Field(
        default_factory=list,
        description="Populate when action_type is select_user. One entry per matched user. Empty for all other action types."
    )

    system_candidates: list[SystemItem] = Field(
        default_factory=list,
        description="Populate when action_type is select_system. One entry per connector returned by get-systems. Empty for all other action types."
    )

    # analysis_complete
    outcome: Optional[str] = Field(
        default=None,
        description=(
            "Required when action_type is analysis_complete. Pick one: "
            "'CLEAR' — no SoD conflicts, role is safe to request; "
            "'REQUIRES REVIEW' — SoD conflicts found, user must acknowledge before proceeding; "
            "'RECOMMENDED ACTION' — no conflicts but notable signals (low peer adoption, prior rejection) worth surfacing."
        )
    )
    selected_role:  Optional[str]       = None
    user_id:        Optional[str]       = None
    connector:      Optional[str]       = None
    risks_found:    list[RiskItem]      = Field(default_factory=list)
    role_usage:     Optional[RoleUsage] = None
    existing_roles: list[dict]          = Field(default_factory=list)

    # request_created
    request_created: Optional[RequestCreated] = None
