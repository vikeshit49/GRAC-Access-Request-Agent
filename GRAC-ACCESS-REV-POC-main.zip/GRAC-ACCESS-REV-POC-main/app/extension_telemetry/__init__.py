"""
Extension Telemetry - Instrumented wrappers for extension calls.

Provides framework-agnostic and framework-specific wrappers that automatically
add OpenTelemetry span attributes when calling extension tools.  Uses the
``extension_context`` context manager from the SAP Cloud SDK for Python to set
OTel baggage, and explicitly stamps span attributes on the agent's own spans for
visibility in agent-side traces.

Framework-agnostic utilities (always available — re-exported from the SDK):
    from extension_telemetry import (
        ExtensionType,
        call_extension_tool,
        call_extension_hook,
        emit_extensions_summary_span,
        reset_tool_call_metrics,
        get_tool_call_metrics,
        reset_hook_call_metrics,
        get_hook_call_metrics,
        ExtensionContextLogFilter,
    )

LangChain (requires ``langchain-mcp-adapters``):
    from extension_telemetry import ExtensionTelemetryInterceptor
"""

import logging

from sap_cloud_sdk.core.telemetry import (
    ExtensionContextLogFilter,
    ExtensionType,
    call_extension_hook,
    call_extension_tool,
    emit_extensions_summary_span,
    get_hook_call_metrics,
    get_tool_call_metrics,
    record_hook_call_duration,
    record_tool_call_duration,
    reset_hook_call_metrics,
    reset_tool_call_metrics,
)

# Framework-specific wrappers are loaded lazily so that importing this package
# never fails due to a missing AI framework dependency.
_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "ExtensionTelemetryInterceptor": ("._langchain", "ExtensionTelemetryInterceptor"),
}

_FRAMEWORK_HINTS: dict[str, str] = {
    "ExtensionTelemetryInterceptor": "langchain-mcp-adapters  (pip install langchain-mcp-adapters)",
}


def __getattr__(name: str) -> object:
    if name in _LAZY_IMPORTS:
        module_path, attr_name = _LAZY_IMPORTS[name]
        try:
            import importlib
            module = importlib.import_module(module_path, package=__name__)
            value = getattr(module, attr_name)
            globals()[name] = value
            return value
        except ImportError as exc:
            hint = _FRAMEWORK_HINTS.get(name, "")
            raise ImportError(
                f"'{name}' requires {hint} to be installed."
            ) from exc
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


_logger = logging.getLogger(__name__)
_SPAN_ATTR_AVAILABLE = False
try:
    from sap_cloud_sdk.core.telemetry import add_span_attribute as _add_span_attr
    _SPAN_ATTR_AVAILABLE = True
except ImportError:
    pass


def record_extension_impl(subdomain: str, instruction_len: int, mcp_server_count: int) -> None:
    """Record extension capability details on the current OTel span (legacy helper)."""
    if not _SPAN_ATTR_AVAILABLE:
        return
    try:
        _add_span_attr("ext.subdomain", subdomain)
        _add_span_attr("ext.instruction_injected", instruction_len > 0)
        _add_span_attr("ext.instruction_len", instruction_len)
        _add_span_attr("ext.mcp_server_count", mcp_server_count)
    except Exception as e:
        _logger.debug("Extension telemetry record failed: %s", e)


__all__ = [
    # Framework-agnostic (re-exported from SDK)
    "ExtensionType",
    "call_extension_tool",
    "call_extension_hook",
    "emit_extensions_summary_span",
    "reset_tool_call_metrics",
    "get_tool_call_metrics",
    "reset_hook_call_metrics",
    "get_hook_call_metrics",
    "record_tool_call_duration",
    "record_hook_call_duration",
    "ExtensionContextLogFilter",
    # LangChain (lazy)
    "ExtensionTelemetryInterceptor",
    # Legacy helper
    "record_extension_impl",
]
