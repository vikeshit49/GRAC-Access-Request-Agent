import logging
import uuid

from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.tasks import TaskUpdater
from a2a.types.a2a_pb2 import Part, Task, TaskState, TaskStatus
from google.protobuf import json_format, struct_pb2

try:
    from sap_cloud_sdk.core.telemetry import add_span_attribute, invoke_agent_span
    _TELEMETRY_AVAILABLE = True
except ImportError:
    _TELEMETRY_AVAILABLE = False

try:
    from sap_cloud_sdk.ias import parse_token as _parse_token
    _IAS_AVAILABLE = True
except ImportError:
    _IAS_AVAILABLE = False

from contextlib import contextmanager
from metering import report_operations_count, report_token_usage
from auditlog import log_agent_access, log_data_access, log_access_request_created
from langgraph.errors import GraphRecursionError

@contextmanager
def _noop_ctx():
    yield

from agent import GRACAgent


class _HookShortCircuit(Exception):
    """Raised when a BEFORE hook signals stop_execution and canShortCircuit=True."""

    def __init__(self, reason: str = "") -> None:
        self.reason = reason
        super().__init__(reason)

# Extension telemetry — emit a summary span after each completed request
_emit_summary = None
_reset_tool_metrics = lambda: None
_reset_hook_metrics = lambda: None
_get_tool_metrics = lambda: (0, 0.0)
try:
    from extension_telemetry import (
        emit_extensions_summary_span as _emit_summary,
        get_tool_call_metrics as _get_tool_metrics,
        reset_hook_call_metrics as _reset_hook_metrics,
        reset_tool_call_metrics as _reset_tool_metrics,
    )
except Exception:
    pass

# Extensibility client — created once at startup, reused for every request.
# The LRU cache inside the client (10-min TTL, 256 entries) amortises the
# destination-service lookup across concurrent requests.
_AGENT_ORD_ID = "sap.appfnd:agent:grac-access-rev-poc:v1"
_extensibility_client = None
_HookType = None
try:
    from sap_cloud_sdk.extensibility import (
        HookType as _HookType,
        create_client as _create_ext_client,
    )
    _extensibility_client = _create_ext_client(_AGENT_ORD_ID)
    logger.info("Extensibility client initialized | ord_id=%s", _AGENT_ORD_ID)
except Exception as _ext_client_err:
    logger.warning("Extensibility client unavailable: %s", _ext_client_err)

logger = logging.getLogger(__name__)

_agent_instances: dict[str, GRACAgent] = {}


def _struct_to_dict(obj) -> dict:
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    try:
        return json_format.MessageToDict(obj)
    except Exception:
        return {}


def _dict_to_part(data: dict) -> Part:
    s = struct_pb2.Struct()
    json_format.ParseDict(data, s)
    val = struct_pb2.Value(struct_value=s)
    return Part(data=val, media_type="application/json")


def get_agent_instance(persona: str) -> GRACAgent:
    if persona not in _agent_instances:
        logger.info("Creating agent instance | persona=%s", persona)
        _agent_instances[persona] = GRACAgent(persona=persona)
    else:
        logger.info("Using cached agent instance | persona=%s", persona)
    return _agent_instances[persona]


def _postback_button(title: str, value: str, text: str = "") -> dict:
    return {"type": "postback", "title": title, "value": value, "text": text or value}


def _list_element(title: str, subtitle: str = "", buttons: list = None) -> dict:
    return {
        "title":       title,
        "subtitle":    subtitle,
        "description": None,
        "imageUrl":    None,
        "imageStyle":  None,
        "status":      None,
        "statusState": None,
        "buttons":     buttons or [],
    }


def _list_message(elements: list, prompt: str) -> list:
    """Two-part Joule action: text prompt + list card with postback buttons."""
    return [
        {
            "type": "message",
            "message": {
                "type":     "text",
                "content":  prompt,
                "markdown": True,
            },
        },
        {
            "type": "message",
            "message": {
                "type": "list",
                "content": {
                    "enableDetailView": False,
                    "title":            None,
                    "subtitle":         None,
                    "elements":         elements,
                },
            },
        },
    ]


def _build_actions(data: dict) -> list | None:
    """
    Build Joule UI actions from GRACResponse.action_type.
    Returns None when no card is needed (plain text turn).
    """
    action_type = data.get("action_type", "text")

    # ── Intent / routing card ────────────────────────────────────────────────
    if action_type == "select_intent":
        options  = data.get("intent_options", [])
        elements = [
            _list_element(
                title    = o.get("label", ""),
                subtitle = o.get("description", ""),
                buttons  = [_postback_button("Select", o.get("label", ""), o.get("label", ""))],
            )
            for o in options
        ]
        return _list_message(elements, data.get("message", "How can I help you?"))

    # ── Role selection card ──────────────────────────────────────────────────
    if action_type == "select_role":
        candidates = data.get("role_candidates", [])
        elements   = [
            _list_element(
                title    = r.get("role_name", ""),
                subtitle = r.get("signal_summary") or r.get("description", ""),
                buttons  = [_postback_button("Select", r.get("role_name", ""))],
            )
            for r in candidates[:5]
        ]
        return _list_message(elements, data.get("message", "Which role would you like me to analyse?"))

    # ── User disambiguation card ─────────────────────────────────────────────
    if action_type == "select_user":
        candidates = data.get("user_candidates", [])
        elements   = [
            _list_element(
                title    = u.get("display_name") or u.get("user_id", ""),
                subtitle = u.get("email", ""),
                buttons  = [_postback_button(
                    "Select",
                    f"Selected user: {u.get('user_id', '')} ({u.get('display_name', '') or u.get('email', '')})",
                )],
            )
            for u in candidates[:8]
        ]
        return _list_message(elements, data.get("message", "Which user did you mean?"))

    # ── System selection card ────────────────────────────────────────────────
    if action_type == "select_system":
        systems  = data.get("system_candidates", [])
        elements = [
            _list_element(
                title    = s.get("connector", ""),
                subtitle = s.get("connection_type", ""),
                buttons  = [_postback_button("Select", s.get("connector", ""))],
            )
            for s in systems
        ]
        return _list_message(elements, data.get("message", "Which system would you like to check?"))

    # ── Post-analysis action card ────────────────────────────────────────────
    if action_type == "analysis_complete":
        elements = [
            _list_element(
                title    = "Create access request",
                subtitle = "Proceed and submit the access request",
                buttons  = [_postback_button("Select", "Create access request")],
            ),
            _list_element(
                title    = "Suggest a safer alternative",
                subtitle = "Find a role with fewer SoD conflicts",
                buttons  = [_postback_button("Select", "Suggest a safer alternative")],
            ),
            _list_element(
                title    = "Cancel",
                subtitle = "Abort and take no action",
                buttons  = [_postback_button("Select", "Cancel")],
            ),
        ]
        return _list_message(elements, "What would you like to do next?")

    return None


class GRACAgentExecutor(AgentExecutor):
    """GRAC Access Review AgentExecutor."""

    def __init__(self):
        self.agent = None

    async def execute(
        self,
        context: RequestContext,
        event_queue: EventQueue,
    ) -> None:
        metadata   = _struct_to_dict(getattr(context.message, "metadata", None))
        persona_id = (metadata.get("personaId") or metadata.get("PersonaId") or "").lower()
        persona    = "admin" if "admin" in persona_id else "end_user"
        user_email = metadata.get("userEmail", "")
        query      = context.get_user_input()
        logger.info("Request | persona=%s | user_email=%s", persona, user_email)

        self.agent = get_agent_instance(persona)
        task_id    = context.task_id or str(uuid.uuid4())
        context_id = context.context_id or str(uuid.uuid4())

        await event_queue.enqueue_event(Task(
            id=task_id,
            context_id=context_id,
            status=TaskStatus(state=TaskState.TASK_STATE_SUBMITTED),
        ))

        updater = TaskUpdater(event_queue, task_id, context_id)
        await updater.start_work()
        _reset_tool_metrics()
        _reset_hook_metrics()

        joule_headers = {}
        try:
            joule_headers = context.call_context.state["headers"]
        except Exception:
            pass
        dwc_subdomain = joule_headers.get("dwc-subdomain", "")

        _ias_claims = None
        if _IAS_AVAILABLE:
            try:
                auth_hdr = joule_headers.get("authorization", "")
                if auth_hdr:
                    _ias_claims = _parse_token(auth_hdr)
            except Exception:
                pass
        user_initiator_id = ""
        if _ias_claims is not None:
            user_initiator_id = (
                _ias_claims.get("sub", "") if isinstance(_ias_claims, dict)
                else getattr(_ias_claims, "sub", "")
            )

        # ── Tenant ID + per-request extension implementation ─────────────────
        tenant_id = ""
        if _ias_claims is not None:
            tenant_id = (
                _ias_claims.get("app_tid", "") if isinstance(_ias_claims, dict)
                else getattr(_ias_claims, "app_tid", "")
            )
        _ext_impl = None
        _has_ext_instr = False
        if _extensibility_client is not None and tenant_id:
            try:
                _ext_impl = _extensibility_client.get_extension_capability_implementation(
                    tenant=tenant_id, capability_id="default"
                )
            except Exception as _ext_fetch_err:
                logger.debug("Extension impl fetch failed: %s", _ext_fetch_err)
        # Inject extension instruction via the ContextVar that call_model reads
        if _ext_impl is not None:
            _instr = getattr(_ext_impl, "instruction", None) or ""
            if _instr:
                try:
                    from agent import _ext_instruction as _ext_instr_var
                    _ext_instr_var.set(_instr)
                    _has_ext_instr = True
                    logger.info("Extension instruction injected | len=%d", len(_instr))
                except Exception:
                    pass

        log_agent_access(
            user=user_email, persona=persona, query_summary=query or "", success=True,
            dwc_subdomain=dwc_subdomain, user_initiator_id=user_initiator_id,
        )
        conversation_id = joule_headers.get("conversationid")
        thread_id = (
            f"{persona}_{conversation_id}" if conversation_id
            else f"{persona}_{context_id}"
        )
        logger.info("Thread | thread=%s | conversation=%s", thread_id, conversation_id)

        try:
            span_ctx = (
                invoke_agent_span(
                    provider="sap-aicore",
                    agent_name="grac-access-agent",
                    conversation_id=thread_id,
                )
                if _TELEMETRY_AVAILABLE
                else _noop_ctx()
            )
            with span_ctx:
                if _TELEMETRY_AVAILABLE:
                    add_span_attribute("grac.persona", persona)
                    add_span_attribute("grac.user_email", user_email)

                # ── BEFORE hooks (fail-open — never block the agent) ──────────
                _inbound_token = joule_headers.get("authorization", "").removeprefix("Bearer ").strip()
                if _ext_impl is not None and _extensibility_client is not None:
                    for _hook in [h for h in (getattr(_ext_impl, "hooks", None) or [])
                                  if _HookType and getattr(h, "type", None) == _HookType.BEFORE]:
                        try:
                            _hook_resp = await _extensibility_client.call_hook_agw(
                                hook=_hook, user_token=_inbound_token or None,
                                message=None, headers=dict(joule_headers),
                                tenant_subdomain=dwc_subdomain,
                            )
                            logger.info("Pre-hook executed: %s", getattr(_hook, "id", ""))
                            if _hook_resp is not None:
                                _meta = getattr(_hook_resp, "metadata", {}) or {}
                                if _meta.get("stop_execution") and getattr(_hook, "can_short_circuit", False):
                                    raise _HookShortCircuit(
                                        _meta.get("stop_execution_reason")
                                        or f"Pre-hook '{getattr(_hook, 'id', '')}' blocked execution."
                                    )
                        except _HookShortCircuit:
                            raise
                        except Exception as _h_err:
                            logger.debug("Pre-hook '%s' skipped: %s", getattr(_hook, "id", ""), _h_err)

                async for item in self.agent.stream(
                    query=query,
                    context_id=thread_id,
                    context={"persona": persona, "threadId": thread_id, "userEmail": user_email},
                    dwc_subdomain=dwc_subdomain,
                    inbound_token=_inbound_token,
                ):
                    is_task_complete   = item["is_task_complete"]
                    require_user_input = item["require_user_input"]

                    if not is_task_complete and not require_user_input:
                        await updater.update_status(TaskState.TASK_STATE_WORKING)
                        continue

                    if require_user_input:
                        await updater.update_status(TaskState.TASK_STATE_INPUT_REQUIRED)
                        break

                    # ── Final response ───────────────────────────────────────────
                    message_content = item["content"]
                    data            = item.get("data", {})
                    action_type     = data.get("action_type", "text")

                    logger.info("Response | action_type=%s | roles=%d | users=%d | risks=%d",
                                action_type,
                                len(data.get("role_candidates", [])),
                                len(data.get("user_candidates", [])),
                                len(data.get("risks_found", [])))

                    # Audit: GRC data was read/analysed
                    log_data_access(user=user_email, action_type=action_type, subject_id=user_email, dwc_subdomain=dwc_subdomain, user_initiator_id=user_initiator_id)

                    # Audit: access request submitted
                    if action_type == "request_created":
                        log_access_request_created(
                            user=user_email,
                            role=data.get("selected_role", "unknown"),
                            target_user=data.get("target_user", user_email),
                            dwc_subdomain=dwc_subdomain,
                            user_initiator_id=user_initiator_id,
                        )

                    if _TELEMETRY_AVAILABLE:
                        add_span_attribute("grac.action_type", action_type)

                    # ── Metering — only on successful business turns, never on errors ──
                    op_count      = item.get("op_count", 0)
                    input_tokens  = item.get("input_tokens", 0)
                    output_tokens = item.get("output_tokens", 0)
                    claims = _ias_claims
                    origin = joule_headers.get("x-sap-origin", "unknown")
                    if op_count:
                        report_operations_count(claims, op_count, origin)
                    report_token_usage(claims, origin,
                                       input_tokens=input_tokens,
                                       output_tokens=output_tokens)

                    actions = _build_actions(data)

                    joule_data = {k: v for k, v in data.items() if k not in (
                        "action_type", "role_candidates", "user_candidates", "system_candidates"
                    )}

                    response_payload = {
                        "status":            "success",
                        "message":           message_content,
                        "contextId":         persona,
                        "final_answer_type": "data" if actions or action_type != "text" else "text",
                        "data":              joule_data,
                    }
                    if actions:
                        response_payload["actions"] = actions

                    await updater.add_artifact(
                        parts=[_dict_to_part(response_payload)],
                        name="grac_result",
                    )
                    # ── AFTER hooks (fail-open) ───────────────────────────────
                    if _ext_impl is not None and _extensibility_client is not None:
                        for _hook in [h for h in (getattr(_ext_impl, "hooks", None) or [])
                                      if _HookType and getattr(h, "type", None) == _HookType.AFTER]:
                            try:
                                await _extensibility_client.call_hook_agw(
                                    hook=_hook, user_token=_inbound_token or None,
                                    message=None, headers=dict(joule_headers),
                                    tenant_subdomain=dwc_subdomain,
                                )
                                logger.info("Post-hook executed: %s", getattr(_hook, "id", ""))
                            except Exception as _h_err:
                                logger.debug("Post-hook '%s' skipped: %s", getattr(_hook, "id", ""), _h_err)
                    _tc, _td = _get_tool_metrics()
                    if _emit_summary is not None:
                        _emit_summary(
                            tool_call_count=_tc,
                            hook_call_count=0,
                            has_instruction=_has_ext_instr,
                            total_duration_ms=_td,
                        )
                    await updater.complete()
                    break

        except _HookShortCircuit as _sc:
            logger.warning("Execution blocked by pre-hook: %s", _sc.reason)
            await updater.add_artifact(
                parts=[_dict_to_part({
                    "status": "blocked",
                    "message": _sc.reason or "Request was blocked by a pre-execution hook.",
                    "contextId": persona,
                    "final_answer_type": "text",
                    "data": {"action_type": "text", "risks_found": []},
                })],
                name="grac_result",
            )
            await updater.complete()
        except GraphRecursionError:
            logger.warning("Recursion limit reached | thread=%s", thread_id)
            await updater.add_artifact(
                parts=[_dict_to_part({
                    "status": "success",
                    "message": "I wasn't able to find a suitable role after several searches. Please try describing your need differently, or contact your GRC administrator.",
                    "contextId": persona,
                    "final_answer_type": "text",
                    "data": {"action_type": "text", "risks_found": []},
                })],
                name="grac_result",
            )
            await updater.complete()
        except Exception:
            logger.exception("Error processing request | thread=%s", thread_id)
            await updater.failed()

    async def cancel(
        self, context: RequestContext, event_queue: EventQueue
    ) -> None:
        task_id    = context.task_id or ""
        context_id = context.context_id or ""
        updater    = TaskUpdater(event_queue, task_id, context_id)
        await updater.cancel()
