"""
SAP Unified Metering — three OTel counters for commercial billing.

Counters are lazily initialised on first use to ensure auto_instrument()
has already configured the global MeterProvider.

Replace the two TODO placeholders with real values from Jarvis onboarding
before going to production.
"""

import logging
from opentelemetry import metrics

logger = logging.getLogger(__name__)

# TODO: Replace with your CLD system role from onboarding
CLD_SYSTEM_ROLE = "GRAC_ACCESS_AGENT"

# TODO: Replace with your AI feature ID from Jarvis (format: AI-LPR0000-STEP-XXXX-YYQQ)
METERING_ENTITY_ID = "AI-TODO-STEP-TODO-TODO"

MODEL    = "sap/anthropic--claude-4.5-sonnet"
PROVIDER = MODEL.split("/", 1)[0]  # "sap"

_ops_counter    = None
_input_counter  = None
_output_counter = None
_initialized    = False


def _setup_metrics():
    global _ops_counter, _input_counter, _output_counter, _initialized
    if _initialized:
        return
    try:
        meter = metrics.get_meter_provider().get_meter("cloud_sdk_metering")
        _ops_counter    = meter.create_counter("sap.metering.gen_ai.operations_count")
        _input_counter  = meter.create_counter("sap.metering.gen_ai.total_input_tokens_count")
        _output_counter = meter.create_counter("sap.metering.gen_ai.total_output_tokens_count")
        _initialized    = True
        logger.info("Metering counters initialised")
    except Exception as e:
        logger.warning("Failed to initialise metering counters: %s", e)


def _tenant_id(claims) -> str:
    if claims is not None:
        return getattr(claims, "sap_gtid", None) or "unknown"
    return "unknown"


def report_operations_count(claims, value: int, origin: str) -> None:
    """Report agent actions/steps — call once per completed agentic turn."""
    _setup_metrics()
    if not _ops_counter:
        return
    try:
        _ops_counter.add(value, {
            "sap.tenancy.tenant_id":       _tenant_id(claims),
            "sap.ai.agent.trigger.type":   origin,
            "sap.cld.system_role":         CLD_SYSTEM_ROLE,
            "sap.metering.entity.id":      METERING_ENTITY_ID,
        })
    except Exception as e:
        logger.warning("report_operations_count failed: %s", e)


def report_token_usage(
    claims,
    origin: str,
    input_tokens: int = 0,
    output_tokens: int = 0,
) -> None:
    """Report input/output token consumption — call once per completed turn."""
    _setup_metrics()
    token_attrs = {
        "sap.tenancy.tenant_id":       _tenant_id(claims),
        "gen_ai.provider.name":        PROVIDER,
        "gen_ai.request.model":        MODEL,
        "sap.ai.agent.trigger.type":   origin,
        "sap.cld.system_role":         CLD_SYSTEM_ROLE,
        "sap.metering.entity.id":      METERING_ENTITY_ID,
    }
    try:
        if input_tokens and _input_counter:
            _input_counter.add(input_tokens, token_attrs)
        if output_tokens and _output_counter:
            _output_counter.add(output_tokens, token_attrs)
    except Exception as e:
        logger.warning("report_token_usage failed: %s", e)
