import asyncio
import logging
from collections.abc import AsyncIterable
from pathlib import Path
from typing import Any, Literal

print("AGENT_VERSION: tool-call-logging-v2")

from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain_litellm import ChatLiteLLM
from langgraph.graph import START, StateGraph
from langgraph.graph.message import MessagesState
from langgraph.prebuilt import ToolNode

from mcp_client import get_mcp_client
from models import GRACResponse

logger = logging.getLogger(__name__)

_PROMPT_DIR = Path(__file__).parent / "prompts"


def _load_prompt(filename: str) -> str:
    return (_PROMPT_DIR / filename).read_text(encoding="utf-8")

try:
    from sap_cloud_sdk.agent_memory import HanaCheckpointer
    memory = HanaCheckpointer()
    logger.info("Using HanaCheckpointer for persistent agent memory")
except Exception as _mem_err:
    from langgraph.checkpoint.memory import MemorySaver
    memory = MemorySaver()
    logger.warning("HanaCheckpointer unavailable, falling back to MemorySaver: %s", _mem_err)

# ── Extensibility runtime ────────────────────────────────────────────────────
from contextvars import ContextVar

_ext_instruction: ContextVar[str] = ContextVar("ext_instruction", default="")
_ext_bound_model: ContextVar = ContextVar("ext_bound_model", default=None)

_ext_client = None
try:
    from sap_cloud_sdk.extensibility import create_client as _create_ext_client
    from extension_capabilities import EXTENSION_CAPABILITIES as _EC
    if _EC is not None:
        _ext_client = _create_ext_client(_EC)
        logger.info("Extensibility client initialized")
except Exception as _ext_init_err:
    logger.warning("Extensibility client unavailable: %s", _ext_init_err)


def _route(state: MessagesState) -> Literal["tools", "__end__"]:
    """End the graph when the LLM calls GRACResponse. Continue to tools otherwise."""
    last = state["messages"][-1]
    if not isinstance(last, AIMessage) or not last.tool_calls:
        return "__end__"
    if last.tool_calls[0]["name"] == GRACResponse.__name__:
        return "__end__"
    return "tools"


class GRACAgent:
    """GRAC Access Review Agent — structured response via GRACResponse tool binding."""

    SYSTEM_INSTRUCTION   = _load_prompt("system_base.txt")
    PERSONA_INSTRUCTIONS = {
        "end_user": _load_prompt("persona_end_user.txt"),
        "admin":    _load_prompt("persona_admin.txt"),
    }
    SUPPORTED_CONTENT_TYPES = ["text", "text/plain"]

    def __init__(self, persona: str = "end_user"):
        self.persona = persona

        persona_addon = self.PERSONA_INSTRUCTIONS.get(
            persona, self.PERSONA_INSTRUCTIONS["end_user"]
        )
        self.full_system_prompt = self.SYSTEM_INSTRUCTION 
        # + "\n\n" + persona_addon

        logger.info("Initializing GRAC agent | persona=%s | prompt_len=%d",
                    persona, len(self.full_system_prompt))

        self.base_model = ChatLiteLLM(
            model="sap/anthropic--claude-4.5-sonnet",
            temperature=0.0,
            max_tokens=16384,
        )

        self.graph        = None
        self._initialized = False
        self._init_lock   = asyncio.Lock()

    async def _initialize(self):
        async with self._init_lock:
            if self._initialized:
                return

        # Load MCP tools
        mcp_tools = []
        try:
            client    = await get_mcp_client()
            mcp_tools = await client.get_tools()
            logger.info("MCP tools loaded | count=%d | tools=%s",
                        len(mcp_tools), [t.name for t in mcp_tools])
        except Exception as e:
            logger.warning("MCP unavailable — starting with no tools: %s", e)

        self._mcp_tools = mcp_tools  # stored for per-request extension merging

        # Bind MCP tools + GRACResponse to the model
        # GRACResponse acts as the structured final-answer tool (PDF pattern)
        all_tools  = mcp_tools + [GRACResponse]
        bound_model = self.base_model.bind_tools(all_tools)

        system_prompt = self.full_system_prompt

        async def call_model(state: MessagesState):
            raw = state["messages"]
            patched = []
            for i, msg in enumerate(raw):
                patched.append(msg)
                if (
                    isinstance(msg, AIMessage)
                    and msg.tool_calls
                    and msg.tool_calls[0]["name"] == GRACResponse.__name__
                ):
                    next_msg = raw[i + 1] if i + 1 < len(raw) else None
                    if not isinstance(next_msg, ToolMessage):
                        patched.append(ToolMessage(
                            content="ok",
                            tool_call_id=msg.tool_calls[0]["id"],
                        ))
            _extra = _ext_instruction.get()
            messages = [{"role": "system", "content": system_prompt + ("\n\n" + _extra if _extra else "")}] + patched
            _model = _ext_bound_model.get() or bound_model
            return {"messages": [await _model.ainvoke(messages)]}

        builder = StateGraph(MessagesState)
        builder.add_node("agent", call_model)
        builder.add_node("tools", ToolNode(mcp_tools))

        builder.add_edge(START, "agent")
        builder.add_conditional_edges("agent", _route, ["tools", "__end__"])
        builder.add_edge("tools", "agent")

        self.graph        = builder.compile(checkpointer=memory)
        self._initialized = True

    async def stream(
        self, query: str, context_id: str, context: dict = None,
        dwc_subdomain: str = "", inbound_token: str = "",
    ) -> AsyncIterable[dict[str, Any]]:
        await self._initialize()

        yaml_context = context or {}
        user_email   = yaml_context.get("userEmail", "")
        if user_email:
            query = f"[Logged-in user email: {user_email}]\n{query}"

        logger.debug("Stream start | thread=%s | persona=%s | query=%.100s",
                     context_id, self.persona, query)

        # ── Extension capability implementation (per-request) ────────────────
        _ext_instruction.set("")
        _ext_bound_model.set(None)
        _ext_impl = None
        if _ext_client is not None and dwc_subdomain:
            try:
                _ext_impl = _ext_client.get_extension_capability_implementation(subdomain=dwc_subdomain)
                _instr = getattr(_ext_impl, "instruction", None) or ""
                _mcp_servers_list = getattr(_ext_impl, "mcp_servers", None) or []
                if _instr:
                    _ext_instruction.set(_instr)
                    logger.debug("Extension instruction injected | len=%d", len(_instr))
                from extension_telemetry import record_extension_impl
                record_extension_impl(dwc_subdomain, len(_instr), len(_mcp_servers_list))
            except Exception as _ext_req_err:
                logger.debug("Extension impl unavailable: %s", _ext_req_err)

        inputs = {"messages": [HumanMessage(content=query)]}
        config = {"configurable": {"thread_id": context_id}, "recursion_limit": 15}

        import contextlib
        async with contextlib.AsyncExitStack() as _ext_stack:
            # ── Load extension MCP tools via Agent Gateway ────────────────────
            _ext_mcp_servers = (getattr(_ext_impl, "mcp_servers", None) or []) if _ext_impl else []
            if _ext_mcp_servers and inbound_token:
                try:
                    from sap_cloud_sdk.agentgateway import create_client as _create_agw
                    from extension_telemetry import ExtensionTelemetryInterceptor
                    from langchain_mcp_adapters.client import MultiServerMCPClient
                    _agw = _create_agw(tenant_subdomain=dwc_subdomain)
                    _agw_auth = await _agw.get_user_auth(user_token=inbound_token)
                    _ext_server_cfgs = {}
                    for _srv in _ext_mcp_servers:
                        _srv_id = getattr(_srv, "ord_id", str(_srv))
                        _gtid   = getattr(_srv, "global_tenant_id", "")
                        _ext_server_cfgs[_srv_id] = {
                            "url":       f"{_agw_auth.gateway_url}/v1/mcp/{_srv_id}/{_gtid}",
                            "transport": "streamable_http",
                            "headers":   {"Authorization": f"Bearer {_agw_auth.access_token}"},
                        }
                    _interceptor = ExtensionTelemetryInterceptor(ext_impl=_ext_impl)
                    _ext_mcp_client = await _ext_stack.enter_async_context(
                        MultiServerMCPClient(_ext_server_cfgs, tool_interceptors=[_interceptor])
                    )
                    _ext_tools = await _ext_mcp_client.get_tools()
                    if _ext_tools:
                        _all_tools = self._mcp_tools + _ext_tools + [GRACResponse]
                        _ext_bound_model.set(self.base_model.bind_tools(_all_tools))
                        logger.info("Extension tools merged | core=%d ext=%d",
                                    len(self._mcp_tools), len(_ext_tools))
                except Exception as _ext_mcp_err:
                    logger.warning("Extension MCP tools unavailable (continuing): %s", _ext_mcp_err)

            async for item in self.graph.astream(inputs, config, stream_mode="values"):
                last = item["messages"][-1]
                if isinstance(last, AIMessage) and last.tool_calls:
                    tool_name = last.tool_calls[0]["name"]
                    tool_args = last.tool_calls[0].get("args", {})
                    if tool_name == GRACResponse.__name__:
                        logger.info("GRACResponse call | action_type=%s | message=%.120s",
                                    tool_args.get("action_type", "?"),
                                    tool_args.get("message", ""))
                    else:
                        logger.info("Tool call | tool=%s | args=%s", tool_name, tool_args)
                        yield {
                            "is_task_complete":   False,
                            "require_user_input": False,
                            "content":            "Looking up...",
                        }
                elif isinstance(last, ToolMessage):
                    response_len = len(str(last.content))
                    logger.info("Tool response | tool_call_id=%s | response_len=%d",
                                last.tool_call_id, response_len)

            yield await self._build_response(config)

    async def _build_response(self, config: dict) -> dict[str, Any]:
        state    = await self.graph.aget_state(config)
        messages = state.values.get("messages", [])

        if not messages:
            return {
                "is_task_complete":   False,
                "require_user_input": True,
                "content":            "Unable to process your request. Please try again.",
                "op_count":           0,
                "input_tokens":       0,
                "output_tokens":      0,
            }

        last = messages[-1]

        # Slice to current turn only — from last HumanMessage onward
        # Prevents double-counting ops from prior conversation turns in memory
        last_human_idx = 0
        for i, m in enumerate(messages):
            if isinstance(m, HumanMessage):
                last_human_idx = i
        current_turn = messages[last_human_idx + 1:]

        # Count operations = AI messages with tool calls in this turn (1 per loop iteration)
        op_count      = sum(1 for m in current_turn if isinstance(m, AIMessage) and m.tool_calls)
        input_tokens  = sum(
            (m.usage_metadata or {}).get("input_tokens", 0)
            for m in current_turn if isinstance(m, AIMessage)
        )
        output_tokens = sum(
            (m.usage_metadata or {}).get("output_tokens", 0)
            for m in current_turn if isinstance(m, AIMessage)
        )

        # Happy path: LLM called GRACResponse — extract structured payload
        if isinstance(last, AIMessage) and last.tool_calls:
            tc = last.tool_calls[0]
            if tc["name"] == GRACResponse.__name__:
                try:
                    resp = GRACResponse(**tc["args"])
                    logger.info("GRACResponse | action_type=%s | roles=%d | users=%d | risks=%d | ops=%d | in_tok=%d | out_tok=%d",
                                resp.action_type, len(resp.role_candidates),
                                len(resp.user_candidates), len(resp.risks_found),
                                op_count, input_tokens, output_tokens)
                    return {
                        "is_task_complete":   True,
                        "require_user_input": False,
                        "content":            resp.message,
                        "data":               resp.model_dump(exclude_none=True),
                        "op_count":           op_count,
                        "input_tokens":       input_tokens,
                        "output_tokens":      output_tokens,
                    }
                except Exception as e:
                    logger.error("Failed to parse GRACResponse: %s", e)

        # Fallback: plain text response
        content = last.content if isinstance(last, AIMessage) else ""
        return {
            "is_task_complete":   True,
            "require_user_input": False,
            "content":            content,
            "data":               {"action_type": "text"},
            "op_count":           op_count,
            "input_tokens":       input_tokens,
            "output_tokens":      output_tokens,
        }