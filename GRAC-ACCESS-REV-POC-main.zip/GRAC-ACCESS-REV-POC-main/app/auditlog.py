import logging
from contextlib import contextmanager
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

# ── Audit Log v3 (auditlog_ng) ───────────────────────────────────────────────
_V3_AVAILABLE = False
try:
    from sap_cloud_sdk.core.auditlog_ng import create_client as _ng_create_client
    from sap_cloud_sdk.core.auditlog_ng.gen.sap.auditlog.auditevent.v2 import auditevent_pb2 as pb
    from sap_cloud_sdk.destination import (
        ConsumptionLevel,
        ConsumptionOptions,
        get_destination,
    )
    _V3_AVAILABLE = True
except Exception as _v3_err:
    logger.warning("auditlog_ng unavailable — v2 fallback active: %s", _v3_err)

# ── Audit Log v2 (legacy fallback) ──────────────────────────────────────────
_V2_AVAILABLE = False
_client_v2 = None
try:
    from sap_cloud_sdk.core.auditlog import (
        ChangeAttribute,
        DataAccessAttribute,
        DataAccessEvent as _DataAccessV2,
        DataModificationEvent as _DataModificationV2,
        SecurityEvent as _SecurityEventV2,
        SecurityEventAttribute,
        Tenant,
        create_client as _v2_create_client,
    )
    _client_v2 = _v2_create_client()
    _V2_AVAILABLE = True
except Exception as _v2_err:
    logger.warning("Audit log v2 client unavailable: %s", _v2_err)


@contextmanager
def _resolve_v3(dwc_subdomain: str):
    """Resolve AuditLogV3_Destination with SUBACCOUNT-level Fragment merge.

    Extracts endpoint/deployment_id/namespace from the merged destinationConfiguration
    rather than passing the raw dest dict to _ng_create_client.
    """
    dest = get_destination(
        "AuditLogV3_Destination",
        level=ConsumptionLevel.SUBACCOUNT,
        tenant=dwc_subdomain,
        options=ConsumptionOptions(
            fragment_name=f"AuditLogV3_Fragment_{dwc_subdomain}",
            fragment_level=ConsumptionLevel.SUBACCOUNT,
        ),
    )
    cfg = dest.get("destinationConfiguration", {})
    endpoint      = cfg.get("endpoint") or cfg.get("URL") or cfg.get("uri", "")
    deployment_id = cfg.get("deploymentId") or cfg.get("DeploymentId") or cfg.get("deployment_id", "")
    namespace     = cfg.get("namespace") or cfg.get("Namespace", "")
    tenant_id     = cfg.get("applicationTenantId", "unknown")
    client = _ng_create_client(
        endpoint=endpoint,
        deployment_id=deployment_id,
        namespace=namespace,
    )
    try:
        yield client, tenant_id
    finally:
        try:
            client.close()
        except Exception:
            pass


def _log_v2(event) -> None:
    if not _V2_AVAILABLE or _client_v2 is None:
        return
    try:
        _client_v2.log(event)
    except Exception as e:
        logger.warning("Audit log v2 write failed: %s", e)


def log_agent_access(
    user: str,
    persona: str,
    query_summary: str,
    success: bool,
    dwc_subdomain: str = "",
    user_initiator_id: str = "",
) -> None:
    """Security event — user invoked the GRAC agent."""
    if _V3_AVAILABLE and dwc_subdomain:
        try:
            with _resolve_v3(dwc_subdomain) as (client, tenant_id):
                event = pb.SecurityEvent(
                    user=user_initiator_id or user or "unknown",
                    data=f"GRAC agent invoked | persona={persona} | query={query_summary[:120]}",
                    attributes=[pb.Attribute(name="success", value=str(success).lower())],
                    common=pb.Common(tenant_id=tenant_id, user_initiator_id=user_initiator_id or user or "unknown"),
                )
                event.common.timestamp.FromDatetime(datetime.now(timezone.utc))
                client.send(event)
            return
        except Exception as e:
            logger.warning("auditlog_ng SecurityEvent failed, using v2: %s", e)
    if _V2_AVAILABLE:
        _log_v2(_SecurityEventV2(
            data=f"GRAC agent invoked | persona={persona} | query={query_summary[:120]}",
            user=user or "unknown",
            tenant=Tenant.PROVIDER,
            attributes=[SecurityEventAttribute("success", str(success).lower())],
        ))


def log_data_access(
    user: str,
    action_type: str,
    subject_id: str,
    dwc_subdomain: str = "",
    user_initiator_id: str = "",
) -> None:
    """Data access event — agent read GRC role/risk/user data on behalf of the user."""
    if _V3_AVAILABLE and dwc_subdomain:
        try:
            with _resolve_v3(dwc_subdomain) as (client, tenant_id):
                event = pb.DataAccess(
                    user=user_initiator_id or user or "unknown",
                    object=pb.Object(type="grc_data", id={"action_type": action_type}),
                    subject=pb.Subject(type="sap_user", id={"user_id": subject_id or "unknown"}),
                    attributes=[pb.Attribute(name="grc_roles_and_risks")],
                    common=pb.Common(tenant_id=tenant_id, user_initiator_id=user_initiator_id or user or "unknown"),
                )
                event.common.timestamp.FromDatetime(datetime.now(timezone.utc))
                client.send(event)
            return
        except Exception as e:
            logger.warning("auditlog_ng DataAccess failed, using v2: %s", e)
    if _V2_AVAILABLE:
        _log_v2(_DataAccessV2(
            object_type="grc_data",
            object_id={"action_type": action_type},
            subject_type="sap_user",
            subject_id={"user_id": subject_id or "unknown"},
            subject_role="end_user",
            attributes=[DataAccessAttribute("grc_roles_and_risks", successful=True)],
            user=user or "unknown",
            tenant=Tenant.PROVIDER,
        ))


def log_access_request_created(
    user: str,
    role: str,
    target_user: str,
    dwc_subdomain: str = "",
    user_initiator_id: str = "",
) -> None:
    """Data modification event — agent submitted a GRC access request."""
    if _V3_AVAILABLE and dwc_subdomain:
        try:
            with _resolve_v3(dwc_subdomain) as (client, tenant_id):
                event = pb.DataModification(
                    user=user_initiator_id or user or "unknown",
                    object=pb.Object(type="grc_access_request", id={"role": role}),
                    subject=pb.Subject(type="sap_user", id={"user_id": target_user or "unknown"}),
                    attributes=[pb.Attribute(name="role_assignment", new_value=role, old_value="none")],
                    common=pb.Common(tenant_id=tenant_id, user_initiator_id=user_initiator_id or user or "unknown"),
                )
                event.common.timestamp.FromDatetime(datetime.now(timezone.utc))
                client.send(event)
            return
        except Exception as e:
            logger.warning("auditlog_ng DataModification failed, using v2: %s", e)
    if _V2_AVAILABLE:
        _log_v2(_DataModificationV2(
            object_type="grc_access_request",
            object_id={"role": role},
            subject_type="sap_user",
            subject_id={"user_id": target_user or "unknown"},
            subject_role="end_user",
            attributes=[ChangeAttribute("role_assignment", role, "none")],
            user=user or "unknown",
            tenant=Tenant.PROVIDER,
        ))
