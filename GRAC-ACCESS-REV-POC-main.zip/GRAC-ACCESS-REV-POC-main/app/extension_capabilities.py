import logging

logger = logging.getLogger(__name__)

EXTENSION_CAPABILITIES = None
PRE_HOOK = None
POST_HOOK = None
try:
    from sap_cloud_sdk.extensibility import (
        ExtensionCapabilities,
        HookCapability,
        HookType,
        ToolAdditions,
    )

    PRE_HOOK = HookCapability(
        type=HookType.BEFORE,
        id="grac_pre_hook",
        display_name="Before Hook",
        description="Executed before the GRAC agent processes the access request.",
    )

    POST_HOOK = HookCapability(
        type=HookType.AFTER,
        id="grac_post_hook",
        display_name="After Hook",
        description="Executed after the GRAC agent completes the access request.",
    )

    EXTENSION_CAPABILITIES = ExtensionCapabilities(
        instruction_supported=True,
        tool_additions=ToolAdditions(enabled=True),
        supported_hooks=[PRE_HOOK, POST_HOOK],
    )
except Exception as _e:
    logger.warning("Extensibility SDK not available: %s", _e)
