# Local Dev Quick Reference

## 1. Start Jaeger (traces UI)

Run once — keep this terminal open.

```powershell
& "C:\Users\I764259\Downloads\jaeger-2.20.0-windows-amd64\jaeger-2.20.0-windows-amd64\jaeger.exe"
```

UI: http://localhost:16686

---

## 2. Start Agent

```powershell
Get-Content app\.env.local | Where-Object { $_ -notmatch '^#' -and $_ -ne '' } | ForEach-Object { $name, $value = $_ -split '=', 2; [System.Environment]::SetEnvironmentVariable($name, $value) }
.venv\Scripts\python app\main.py --host 0.0.0.0 --port 9000
```

Agent runs at: http://localhost:9000

---

## 3a. Browser Chatbot (recommended)

Open a new terminal:

```powershell
.venv\Scripts\python chatbot.py
```

Open **http://localhost:8080** in your browser.
- Chat bubbles with Markdown rendering
- Collapsible tool-call inspector per message
- "Raw JSON" toggle for debugging
- "New conversation" button to reset the session

## 3b. CLI Test (raw JSON)

Open a new terminal:

```powershell
.venv\Scripts\python test_agent.py
```

---

## 4. View Traces

1. Open http://localhost:16686
2. Select service: `grac-agent`
3. Click **Find Traces**
4. Click any trace → expand `ChatLiteLLM.chat` for LLM reasoning, `execute_tool:*` for tool calls
